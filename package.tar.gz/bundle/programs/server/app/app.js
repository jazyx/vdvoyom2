var require = meteorInstall({"imports":{"api":{"methods":{"admin":{"account.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/account.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => CreateAccount
});
let hsl2hex;
module.link("../../../tools/generic/utilities", {
  hsl2hex(v) {
    hsl2hex = v;
  }

}, 0);
let getGoldenAngleAt, getCodeFrom;
module.link("../../../tools/custom/project", {
  getGoldenAngleAt(v) {
    getGoldenAngleAt = v;
  },

  getCodeFrom(v) {
    getCodeFrom = v;
  }

}, 1);
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 2);
const {
  User,
  Teacher,
  Group
} = collections;

class CreateAccount {
  constructor(accountData) {
    this.accountData = accountData; // console.log("CreateAccount accountData:", accountData)
    /// <<< HARD-CODED

    this.saturation = 60;
    this.luminosity = 50; // accountData.path = []
    /// HARD-CODED >>>

    this.createUniqueQCode();
    this.createUser();
    accountData.accountCreated = true;
    accountData.status = "CreateGroup"; // console.log("accountData after createUser:", accountData)
    // console.log("————————————————————————————")
    //
    // d_code: "HABIg"
    // native: "en-GB"
    // q_code: "3819"
    // q_color: "#33cc60"
    // q_index: 1
    // status: "CreateAccount"
    // user_id: "DcMNnhN7meZ7hmSr4"
    // username: "James"
    // path:  []
    //
    // = username:   "Влад"
    // = teacher:    "jn"
    // = d_code:     "d9Uvl"
    // + q_code:     "0381"
    // + user_id:    "BqKkMjjBSRzedasyT"
    // + group_id:   "PWwknSiHCGmsivSXg"
    // + newAccount: true
    // + path:       []
    //
    // // Not needed in the return value
    // = language:   "en-GB"
    // = native:     "ru"
    // + q_color:    "#33cc60"
    // + q_index:    1
    // + logged_in:   []

    const notNeeded = ["language", "native", "q_color", "q_index", "logged_in"];
    notNeeded.forEach(key => {
      delete accountData[key];
    });
  }

  createUniqueQCode() {
    // Create or recyle a number between 0001 and 9999
    let newest = User.findOne({}, {
      fields: {
        q_index: 1
      },
      sort: {
        q_index: -1
      }
    });
    let q_index = newest ? newest.q_index + 1 : 1;
    let hue, q_code, q_color;

    if (q_index < 6765) {
      // Use the Golden Angle to get the next value
      hue = getGoldenAngleAt(q_index);
      q_code = getCodeFrom(hue);
    } else if (q_index < 8901) {// TODO: Use the Golden Angle, but check for duplicate q_code's
    } else if (q_index < 10000) {// TODO: Find a gap in the index numbers
    } else {// TODO: We can't have more than 9999 unique q_codes. Find the
        // User with a name different from this.accountData.username
        // who logged in last the longest time ago, archive that User
        // record and reuse that User's q_index and q_code. The q_color
        // will be reset below.
      }

    q_color = hsl2hex(hue, this.saturation, this.luminosity);
    this.accountData.q_index = q_index;
    this.accountData.q_code = q_code;
    this.accountData.q_color = q_color;
  }

  createUser() {
    const {
      username,
      native,
      q_index,
      q_code,
      q_color,
      d_code
    } = this.accountData;
    const fields = {
      username,
      native,
      q_index,
      q_code,
      q_color
    };
    fields.history = {};
    fields.logged_in = []; // console.log("createUser accountData = ", this.accountData)

    this.accountData.user_id = User.insert(fields);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"activate.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/activate.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => ToggleActivation
});
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);
const {
  Group
} = collections;

class ToggleActivation {
  constructor(groupData) {
    // console.log("ToggleActivation groupData:", groupData)
    const {
      _id,
      d_code,
      active
    } = groupData;
    const action = active ? "$push" : "$pull";
    const select = {
      _id
    };
    const update = {
      $set: {
        active
      },
      [action]: {
        logged_in: d_code
      }
    };
    const result = Group.update(select, update); // 1 = success; 0 = not
    // console.log( "ToggleActivation:", result
    //            , "db.group.update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(update)
    //            + ")"
    //            )

    if (result) {
      groupData.teacher_logged_in = true;
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/group.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => CreateGroup
});
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);
const {
  Group
} = collections;

class CreateGroup {
  constructor(accountData) {
    // Minimum:
    // { user_id: <>
    // , teacher: <>
    // , language: <>
    // }
    // console.log("accountData before CreateGroup:", accountData)
    const group = {
      owner: accountData.teacher,
      language: accountData.language,
      active: false // becomes true if Teacher logs in personally
      ,
      lobby: "",
      chat_room: "",
      members: [accountData.user_id, accountData.teacher],
      logged_in: [] // // Will be added by the Client
      // , view_data: {}
      // , view_size: { width, height }

    };
    accountData.group_id = Group.insert(group);
    accountData.groupCreated = true; // console.log("accountData after CreateGroup:", accountData)
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"join.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/join.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => JoinGroup
});
let removeFrom;
module.link("../../../tools/generic/utilities", {
  removeFrom(v) {
    removeFrom = v;
  }

}, 0);
let collections, getNextIndex;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  },

  getNextIndex(v) {
    getNextIndex = v;
  }

}, 1);
const {
  User,
  Group
} = collections;

class JoinGroup {
  constructor(accountData) {
    /* console.log("JoinGroup", accountData)
     *
     * { user_id: "YZ2xJoHf5SDzZPQED"
     * , d_code: "dm4eN"
     *
     * // Manual log in will use teacher to find group_id, or will
     * // create a new group using user_id, teacher and language
     * // (group_id will be overridden, because it might refer to
     * //  the last group the user joined, rather than the group with
     * //  this teacher)
     * , teacher:  "aa"
     * , language: "ru"
     *
     * // auto_login will not have teacher or language, so requires
     * // group_id
     * , group_id: "97NS2hDEYntEhXXbr"
     * }
     */
    let {
      user_id,
      d_code,
      teacher,
      language,
      group_id
    } = accountData;

    if (teacher && language) {
      group_id = this.groupWithThisTeacher(user_id, teacher);
    }

    if (group_id) {
      // The user might have chosen a different group from last time
      accountData.group_id = group_id;
    } else {
      return accountData.status = "CreateGroup"; // We'll be back
    }

    let success = this.joinGroup(group_id, d_code);

    if (success) {
      const d_codes = this.getLoggedInCodes(group_id);
      accountData.page = this.getPage(accountData, d_codes);
      success = this.addUserHistoryItem(group_id, d_code, user_id);

      if (success) {
        accountData.status = "JoinGroup_success";
      } else {
        accountData.status = "JoinGroup_noHistoryItem";
      }

      this.moveTeacherDCodeToEnd(group_id, d_codes);
    } else {
      accountData.status = "JoinGroup_fail";
    }
  }

  groupWithThisTeacher(user_id, teacher) {
    const select = {
      members: {
        $all: [user_id, teacher],
        $size: 2
      }
    };
    const {
      _id
    } = Group.findOne(select) || {};
    return _id;
  }

  joinGroup(group_id, d_code) {
    const select = {
      _id: group_id
    };
    const push = {
      $push: {
        logged_in: d_code
      }
    };
    const success = Group.update(select, push);
    return success;
  }

  getPage(accountData, d_codes) {
    let page = {
      view: "Activity"
    };
    let readFromGroup = d_codes.length > 1;

    if (!readFromGroup) {
      readFromGroup = accountData.restore_all;
    }

    if (readFromGroup) {
      const select = {
        _id: accountData.group_id
      };
      const options = {
        fields: {
          page: 1
        }
      };
      const groupData = Group.findOne(select, options);

      if (groupData && groupData.page) {
        page = groupData.page;
      }
    } // console.log("join.js getPage page:", page)


    return page;
  } // TODO is the genNextIndex thing needed? Is it even working?


  addUserHistoryItem(group_id, d_code, user_id) {
    const index = getNextIndex("history"); // could use a random value

    const select = {
      _id: user_id
    };
    const item = {
      in: index
    };
    const path = "history." + group_id; // { ...
    // , history: {
    //     <group_id>: [ ...
    //     , { d_code: "xxxxx"
    //       , in:  ISO_loggedInTime
    //       , out: ISO_loggedOutTime
    //       , status: { TBD }
    //       }
    //     ]
    //   }
    // , ...
    // }
    // Insert the { in: <...> } history item at index position 0, so
    // that a subsequent operation to add an out: <...> field to this
    // item will find it.

    const push = {
      $push: {
        [path]: {
          $each: [item],
          $position: 0
        }
      }
    };
    let success = User.update(select, push);

    if (success) {
      select[path + ".in"] = index;
      const created = {
        $currentDate: {
          [path + ".$.in"]: true
        }
      }; // console.log( "db.user.update("
      //            + JSON.stringify(select)
      //            + ", "
      //            + JSON.stringify(created)
      //            + ")"
      //            )

      success = User.update(select, created);
    }

    return success;
  }

  getLoggedInCodes(_id) {
    // Get a list of all the logged_in d_codes
    const select = {
      _id
    };
    const options = {
      fields: {
        logged_in: 1
      }
    };
    const {
      logged_in
    } = Group.findOne(select, options); // console.log( "logged_in:", logged_in
    //            , "   <<<   db.group.findOne("
    //            + JSON.stringify(select)
    //            + ","
    //            + JSON.stringify(options.fields)
    //            + ").pretty()"
    //            )

    return logged_in;
  }

  moveTeacherDCodeToEnd(_id, d_codes) {
    // Get the _ids of the Users with the given d_codes
    const logged_in = d_codes.map(d_code => ({
      logged_in: d_code
    }));
    const userSelect = {
      $or: logged_in
    };
    const options = {
      fields: {
        logged_in: 1
      }
    };
    const users = User.find(userSelect, options).fetch(); // console.log( "user:", user
    //            , "   <<<   db.user.find("
    //            + JSON.stringify(userSelect)
    //            + ","
    //            + JSON.stringify(options.fields)
    //            + ").pretty()"
    //            )
    // Remove the d_codes of known users from logged_in

    users.forEach(userData => {
      const user_codes = userData.logged_in;

      const removeFunction = item => user_codes.includes(item);

      removeFrom(d_codes, removeFunction, true);
    }); // If there are any d_codes left, they must be the teacher's
    // console.log("logged_in:", logged_in)

    const groupSelect = {
      _id
    };
    d_codes.forEach(teacher_code => {
      // Remove it from the logged_in array...
      const pull = {
        $pull: {
          logged_in: teacher_code
        }
      };
      const push = {
        $push: {
          logged_in: teacher_code
        }
      };
      Group.update(groupSelect, pull); // ... and then add it back at the end

      Group.update(groupSelect, push);
    }); // Alternative solution:
    // * Add a logged_in field to the Teacher records
    // * Get the _id of the owner of this Group
    // * Retrieve the d_codes of that teacher
    // * Find which of those d_codes are present in the logged_in list
    // * Remove all those d_codes from the list
    // * Add them back at the end
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"leave.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/leave.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => LeaveGroup
});
let destroyTracker;
module.link("../../collections/points", {
  destroyTracker(v) {
    destroyTracker = v;
  }

}, 0);
let arrayOverlap;
module.link("../../../tools/generic/utilities", {
  arrayOverlap(v) {
    arrayOverlap = v;
  }

}, 1);
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 2);
const {
  User,
  Teacher,
  Group
} = collections;

class LeaveGroup {
  constructor(deviceData) {
    let {
      id,
      d_code,
      group_id,
      dismissed = false
    } = deviceData;

    if (!group_id) {
      group_id = this.getGroup_id(d_code);

      if (!group_id) {
        return;
      }
    } // Common actions for both Teachers and Users


    this.removeDeviceFromGroup(group_id, d_code); // destroyTracker.call({ _id: d_code, group_id })
    // Separate actions

    if (id.length < 5) {
      // "xxxx" => 456976 teacher id`s
      const teacherViews = this.getTeacherViewCount(id, group_id);

      if (!teacherViews) {
        this.deactivateGroup(group_id);
      }
    } else {
      this.userIsLeaving(id, group_id, dismissed);
    }
  }

  getGroup_id(d_code) {
    const select = {
      logged_in: d_code
    };
    const options = {};

    const _ids = Group.find(select, options).fetch().map(doc => doc._id);

    if (_ids.length > 1) {// console.log("Leaving multiple groups?", _ids)
    }

    return _ids[0]; // may be undefined
  } // Common actions


  removeDeviceFromGroup(group_id, d_code) {
    const select = {
      _id: group_id,
      logged_in: d_code
    };
    const pull = {
      $pull: {
        logged_in: d_code
      }
    };
    const result = Group.update(select, pull); // console.log( "result:", result
    // , ", group_id", group_id
    // , "db.group.update("
    //   + JSON.stringify(select)
    //   + ", "
    //   + JSON.stringify(pull)
    //   + ")"
    // )
  }

  getTeacherViewCount(id, group_id) {
    let select = {
      id
    };
    const options = {
      fields: {
        logged_in: 1
      }
    };
    const teacher = Teacher.findOne(select, options) || {
      logged_in: [],
      fake: true
    };
    const d_codes = teacher.logged_in; // console.log( "teacher", teacher
    //            , "teacher's d_codes:", teacher.logged_in
    //            , "db.teacher.findOne("
    //            , JSON.stringify(select)
    //            , ", "
    //            , JSON.stringify(options)
    //            , ")"
    //            )

    select = {
      _id: group_id
    };
    const {
      logged_in
    } = Group.findOne(select, options); // console.log( "group's d_codes:", logged_in
    //            , "db.group.findOne("
    //            , JSON.stringify(select)
    //            , ", "
    //            , JSON.stringify(options)
    //            , ")"
    //            )

    const t_codes = arrayOverlap(logged_in, d_codes);
    return t_codes.length;
  } // Teacher actions


  deactivateGroup(group_id) {
    const select = {
      _id: group_id
    };
    const set = {
      $set: {
        active: false
      }
    };
    const result = Group.update(select, set); // console.log( "deactivateGroup:", result
    //            , "db.group.update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(set)
    //            + ")")
  } // User actions


  userIsLeaving(_id, group_id, dismissed) {
    this.updateUserHistory(_id, group_id);

    if (!dismissed) {
      // The User is leaving of their own accord. If this is the last
      // user in the group, the Teacher should return to the Teach
      // view.
      this.closeGroupIfDone(group_id);
    }
  }

  updateUserHistory(_id, group_id) {
    const path = "history." + group_id;
    const pathOut = path + ".$.out";
    const select = {
      _id,
      [path + ".in"]: {
        $exists: true
      },
      [pathOut]: {
        $exists: false
      }
    };
    const update = {
      $currentDate: {
        [pathOut]: true
      }
    };
    const result = User.update(select, update); // console.log( "updateUserHistory:", result
    //            , "<<< db.user.update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(update)
    //            + ")"
    //            )
  }

  closeGroupIfDone(group_id) {
    const {
      logged_in,
      owner,
      active // should always be true

    } = this.getGroupMemberStatus(group_id);
    const ownerD_codes = this.getOwnerD_codes(owner, logged_in);
    const d_codeCount = ownerD_codes.length; // console.log(
    //   "closeGroupIfDone — logged_in:", logged_in
    // , "owner:", owner
    // , "active:", active
    // , "ownerD_codes:", ownerD_codes
    // , "d_codeCount:", d_codeCount
    // )

    if (d_codeCount && d_codeCount === logged_in.length) {
      // The teacher is the only person left
      this.deactivateGroup(group_id);
    } else {
      this.promoteSlave(group_id, logged_in, ownerD_codes);
    }
  }

  getGroupMemberStatus(group_id) {
    const select = {
      _id: group_id
    };
    const options = {
      fields: {
        logged_in: 1,
        owner: 1,
        active: 1
      }
    };
    const status = Group.findOne(select, options); // console.log( "status:", status
    //            , "db.group.findOne("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(options.fields)
    //            + ")")

    return status;
  }

  getOwnerD_codes(owner, d_codes) {
    const select = {
      id: owner
    };
    const options = {
      fields: {
        logged_in: 1
      }
    };
    const {
      logged_in
    } = Teacher.findOne(select, options); // console.log( "getOwnerD_codes logged_in:", logged_in
    //            , "db.teacher.findOne("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(options.fields)
    //            + ")"
    //            )

    d_codes = arrayOverlap(d_codes, logged_in);
    return d_codes;
  } // UNTESTED // UNTESTED // UNTESTED // UNTESTED // UNTESTED //


  promoteSlave(group_id, logged_in, ownerD_codes) {
    // Make sure the teacher is not master (= first in logged_in)
    let slave;
    logged_in.every((d_code, index) => {
      if (ownerD_codes.includes(d_code)) {
        return true;
      } else {
        slave = index && d_code; // 0 if slave already at index 0

        return false;
      }
    });

    if (slave) {
      const select = {
        _id: group_id
      };
      const pull = {
        $pull: {
          logged_in: slave
        }
      };
      const push = {
        $push: {
          logged_in: {
            $each: [slave],
            $position: 0
          }
        }
      };
      let result = Group.update(select, pull); // console.log( "pull slave:", result
      //            , "db.group.findOne("
      //            + JSON.stringify(select)
      //            + ", "
      //            + JSON.stringify(pull)
      //            + ")")

      result = Group.update(select, push); // console.log( "push slave:", result
      //            , "db.group.findOne("
      //            + JSON.stringify(select)
      //            + ", "
      //            + JSON.stringify(push)
      //            + ")")
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"login.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/login.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => LogIn
});
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);
const {
  User,
  Teacher,
  Group
} = collections;

class LogIn {
  constructor(accountData) {
    this.accountData = accountData; // console.log("accountData before Login:", accountData)

    const nameExists = this.userWithThisNameExists();

    if (!nameExists) {
      // This might be:
      // [ ] A new user
      accountData.status = "CreateAccount";
    } else if (accountData.status === "CreateAccount" && !accountData.accountCreated) {
      // This might be:
      // [ ] A new user with a common name
      // An earlier call to log in was referred back to the Client
      // because a user with the given username already exists and the
      // q_code was missing or did not match, and the user pressed
      // the Create New Account button
      return; // There's nothing to do here yet, but we'll be back
      // with accountCreated set to true
    } else if (!accountData.q_code) {
      // This might be:
      // [ ] A new user with a common name
      // [ ] A returning user
      // [ ] ... on a new device
      // [ ] --- or on a device with someone else's localStorage
      // We need to ask if the user has a PIN code (returning user on
      // device with no [prior] localStorage) or not (new user)
      accountData.status = "RequestPIN";
    } else {
      // This might be:
      // [x] A new user for whom a q_code has just been created
      // [ ] A returning user on a device with so. else's localStorage
      // [ ] A returning user logging in manually...
      // [ ] ... perhaps to start with a new teacher
      // [ ] A returning user logging in automatically
      const existingUser = this.logInUserFromNameAndQCode();

      if (!existingUser) {
        accountData.status = "RequestPIN";
      } else {
        accountData.status = "loggedIn";
        accountData.loggedIn = true;
      }
    }
  }

  userWithThisNameExists() {
    const username = this.accountData.username;
    const nameExists = User.findOne({
      username
    }, {});
    return !!nameExists;
  }

  logInUserFromNameAndQCode() {
    const {
      username,
      q_code,
      d_code
    } = this.accountData;
    const select = {
      username,
      q_code
    };
    const push = {
      $push: {
        logged_in: d_code
      }
    };
    const result = User.update(select, push); // 1 = success; 0 = not

    if (result) {
      const options = {
        fields: {
          q_color: 1
        }
      };
      const {
        _id: user_id,
        q_color
      } = User.findOne(select, options);
      Object.assign(this.accountData, {
        user_id,
        q_color
      });
    }

    return result;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"loginTeacher.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/loginTeacher.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => LogInTeacher
});
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);
const {
  Teacher,
  Group
} = collections;

class LogInTeacher {
  constructor(accountData) {
    // console.log("LogInTeacher accountData:", accountData)
    const {
      id,
      d_code
    } = accountData;
    const left = this.leaveAllGroups(id, d_code);
    const loggedIn = this.setLoggedIn(id, d_code);
    accountData.loggedIn = loggedIn;
  }

  setLoggedIn(id, d_code) {
    const select = {
      id
    };
    const addToSet = {
      $addToSet: {
        logged_in: d_code
      }
    };
    const result = Teacher.update(select, addToSet); // 1 = success; 0 = not
    // console.log( "setLoggedIn:", result
    //            , "db.teacher.update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(addToSet)
    //            + ")"
    //            )

    return result;
  }

  leaveAllGroups(id, d_code) {
    const select = {
      members: id,
      logged_in: d_code
    };
    const pull = {
      $pull: {
        logged_in: d_code
      }
    };
    const result = Group.update(select, pull); // 1 = success; 0 = not
    // console.log( "leaveAllGroups:", result
    //            , "db.group.update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(pull)
    //            + ")"
    //            )

    return result;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logout.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin/logout.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => LogOut
});
let collections;
module.link("../../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);
const {
  User,
  Teacher,
  Group
} = collections;

class LogOut {
  constructor(logOutData) {
    const {
      id,
      d_code
    } = logOutData;
    const update = {
      $pull: {
        logged_in: d_code
      }
    };
    let key, collection;
    const isTeacher = id.length < 5;

    if (isTeacher) {
      // "xxxx" => 456976 teacher id`s
      key = "id";
      collection = Teacher;
    } else {
      key = "_id";
      collection = User;
    }

    const select = {
      [key]: id
    };
    const result = collection.update(select, update); // console.log( "result:", result
    //            , "<<< LogOut device db."
    //               + collection._name
    //               + ".update("
    //            + JSON.stringify(select)
    //            + ", "
    //            + JSON.stringify(update)
    //            + ")"
    //            )
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"assets":{"importAssets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/assets/importAssets.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => ImportAssets
});
module.link("../mint");
let Log;
module.link("./log.js", {
  default(v) {
    Log = v;
  }

}, 0);
let IOHelper;
module.link("./ioHelper", {
  default(v) {
    IOHelper = v;
  }

}, 1);
let removeFrom;
module.link("../../../tools/generic/utilities", {
  removeFrom(v) {
    removeFrom = v;
  }

}, 2);
let PUBLIC_DIRECTORY, ASSETS_FOLDER, IMAGE_REGEX, JSON_REGEX;
module.link("../../../tools/custom/constants", {
  PUBLIC_DIRECTORY(v) {
    PUBLIC_DIRECTORY = v;
  },

  ASSETS_FOLDER(v) {
    ASSETS_FOLDER = v;
  },

  IMAGE_REGEX(v) {
    IMAGE_REGEX = v;
  },

  JSON_REGEX(v) {
    JSON_REGEX = v;
  }

}, 3);
let collections;
module.link("../../collections/publisher.js", {
  default(v) {
    collections = v;
  }

}, 4);

const fs = require('fs');

const path = require('path');

class ImportAssets extends IOHelper {
  constructor(options) {
    super();
    this.logger = new Log();
    this.log = this.logger.addEntry;

    if (typeof options === "object") {
      const {
        zipFile,
        parentFolder
      } = options;

      if (parentFolder) {
        const activity = this.getActivityNameFrom(parentFolder);

        if (activity) {
          this.installAssets(zipFile, parentFolder, activity);
        }
      }
    } else {
      // the call came from launch.js
      this.importSubfoldersOf(ASSETS_FOLDER);
    }

    this.logger.save();
  }
  /** TODO: TEST WITH CUSTOM IMPORT
   *
   * @return  {string}  The activity name from parent folder path.
   */


  getActivityNameFromParentFolderPath() {
    // public/activities/<ActivityName>/assets/...
    const regex = /\/public\/Activities\/(\w+)/;
    const match = regex.exec(this.parentFolder);

    if (match) {
      const activityName = match[1];

      if (activityName) {
        return activityName;
      }
    }
  }

  installAssets(activity, zipFile, parentFolder) {
    // TODO: unzip zipFile
    const subFolders = fs.readdirSync(parentFolder);
    this.treatFolder(activity, parentFolder, subFolders);
  }
  /**
   * Called by constructor if no options are given, and recursively
   *
   * @param  {string}  folder              absolute path to
   *                                       ASSETS_FOLDER or one of its
   *                                       immediate children
   * @param  {undefined|string}  activity  undefined when first called
   *                                       then the name of one of the
   *                                       items in folder
   */


  importSubfoldersOf(folder, activity) {
    const exploreSubFolders = !activity;
    const contents = fs.readdirSync(folder); // console.log("importSubfoldersOf", folder, activity)
    // console.log(contents)
    // [ 'Cloze', 'Nim', 'Spiral', 'Vocabulary' ]

    contents.forEach(subFolder => {
      const parentFolder = path.join(folder, subFolder);
      const subFolders = fs.readdirSync(parentFolder); // console.log("subfolders of",parentFolder, subFolders)

      const hasJSON = subFolders.find(item => JSON_REGEX.test(item));

      if (hasJSON) {
        if (!activity) {
          activity = subFolder;
        }

        this.treatFolder(activity, parentFolder, subFolders);
      } else if (exploreSubFolders) {
        this.importSubfoldersOf(parentFolder, subFolder);
      } else {
        const message = "No JSON found: items ignored in ".concat(parentFolder);
        this.log(message);
        console.log(message);
      }
    });
  }
  /** If no errors, updates JSON and MongoDB where JSON has changed
   *  crawling any subfolders from branch to leaf recursively.
   *
   * Called by:
   * + ImportAssets.installAssets       < specific folder
   * +             .treatActivityFolder < all activities, from root
   *
   * —— Three types of input ——
   *
   * Standalone
   * ==========
   * activity:     "Nim"
   * parentFolder: '..../public/activities/Nim'
   * contents:     [ 'audio', 'image', 'l10n.json' ]
   *
   * Branch
   * ======
   * activity:     "Vocabulary"
   * parentFolder: '..../public/activities/Vocabulary'
   * contents:     [ 'icon.jpg', 'rank.json', 'home', 'basic' ]
   *
   * Leaf
   * ====
   * activity:     "Vocabulary"
   * parentFolder: '..../public/activities/Vocabulary/basic'
   * contents:     [ 'audio', 'icon.jpg', 'image', 'rack.json' ]
   */


  treatFolder(activity, parentFolder, contents) {
    const {
      jsonPath,
      json
    } = this.readJSONFile(parentFolder, contents);

    if (!json) {
      // An error will already have been logged
      return -1;
    }

    const localPath = this.getLocalPath(parentFolder);
    const collection = collections[activity];
    const select = {
      localPath
    }; // console.log("treatFolder", activity, path)

    const toUpdate = this.directoryNeedsUpdating( // now returns true
    jsonPath, collection, select);

    if (!toUpdate) {
      const message = "        Set is up-to-date: ".concat(localPath);
      this.log(message);
      return 1; // JSON hasn't changed
    } // Creates an icon if there is none, even if none is needed


    const icon = this.getIconMap(parentFolder, contents);

    if (contents.includes('audio') || contents.includes('image')) {
      const message = "        Adding phrases from: ".concat(localPath);
      this.log(message);
      return this.addPhraseSet(parentFolder, contents, icon, localPath, jsonPath, json, collection);
    } else {
      const message = "        Adding assets from: ".concat(localPath);
      this.log(message);
      this.crawlSubFolders(parentFolder, contents, icon, localPath, jsonPath, json, collection, activity);
    }
  }

  addPhraseSet(parentFolder, contents, icon, localPath, jsonPath, json, collection) {
    const assets = {
      audio: {},
      image: {},
      icon
    }; // Add audio and image assets

    this.crawlAudioFolder(parentFolder, contents, assets.audio);
    this.crawlImageFolder(parentFolder, contents, assets.image);
    const cancelled = this.treatJSON( // cancel if tag present+invalid
    localPath, jsonPath, json, collection, assets);
    return cancelled;
  }
  /** Returns a string like "/Activity/folder/.../exercise"
   *  which is a version of parentFolder from which the path
   *  to the `.../public/Activities/` folder has been
   *  trimmed. There should be no trailing "/"
   *
   * @param    {string}    parentFolder  absolute path to parent
   * @return   {string}    like '/Activity/folder/.../exercise'
   */


  getLocalPath(parentFolder) {
    const localPath = parentFolder.replace(ASSETS_FOLDER, "/");
    return localPath;
  }

  crawlAudioFolder(parentFolder, contents, audioMap) {
    let audio = "audio";

    if (!contents.includes(audio)) {
      return;
    }

    audio = path.join(parentFolder, audio);
    contents = fs.readdirSync(audio); // console.log("audio/ contents:", contents)
    // audio/ contents: [ 'ru' ]

    contents.forEach(folder => {
      this.crawlAudioSubFolder(audio, folder, audioMap);
    });
  }

  crawlAudioSubFolder(audioFolder, lang, audioMap) {
    const folderPath = path.join(audioFolder, lang);
    const contents = fs.readdirSync(folderPath); // console.log("audio/" + lang + "/ contents:", contents)
    // audio/ru/ contents: [ '01.mp3', '02.mp3', '03.mp3', ... ]
    // Assume that all audio files will be in MP3 format. Any
    // file that does not have the MP3 format may be a folder
    // with additional audio assets for a given phrase.
    //
    // TODO: Deal with additional audio assets
    // TODO: Add credits and transcription data from json file

    contents.forEach(file => {
      const extension = path.extname(file);

      if (extension.toLowerCase() === ".mp3") {
        let src = path.join(folderPath, file);
        const stats = fs.statSync(src);
        const size = stats.size;
        src = src.replace(PUBLIC_DIRECTORY, "");
        let fileName = path.basename(file, extension);

        if (!isNaN(fileName)) {
          // Remove any leading zeros
          fileName = "" + parseFloat(fileName);
        }

        const phraseAudio = audioMap[fileName] || (audioMap[fileName] = {});
        const localized = phraseAudio[lang] || (phraseAudio[lang] = []);
        localized.push({
          src,
          size
        });
      } else {// TODO: Deal with additional audio assets
      }
    });
  }

  crawlImageFolder(parentFolder, contents, imageMap) {
    let image = "image";

    if (!contents.includes(image)) {
      return;
    }

    const folderPath = path.join(parentFolder, image);
    contents = fs.readdirSync(folderPath); // console.log("image/ contents:", contents)
    // image/ contents: [ 03.gif','04.png','1.jpg','20.png' ...]

    contents.forEach(file => {
      if (IMAGE_REGEX.test(file)) {
        let src = path.join(folderPath, file);
        const stats = fs.statSync(src);
        const size = stats.size;
        src = src.replace(PUBLIC_DIRECTORY, "");
        const extension = path.extname(file);
        let fileName = path.basename(file, extension);

        if (!isNaN(fileName)) {
          // Remove any leading zeros
          fileName = "" + parseFloat(fileName);
        }

        const phraseImages = imageMap[fileName] || (imageMap[fileName] = []);
        phraseImages.push({
          src,
          size
        });
      } else {// TODO: Deal with additional image assets
      }
    });
  }
  /** Check for valid tag; update MongoDB set (+ phrases); save JSON
   *
   * Called by treatFolder() if JSON file was updated
   *
   * @param    {string}  localPath   "/Activity/folder/.../exercise"
   * @param    {string}  jsonPath    absolute path to JSON file
   * @param    {object}  json        object read from JSON file
   * @param    {object}  assets      { audio: {}
   *                                 , image: {}
   *                                [, icon:  <string>]
   *                                 }
   * @param    {object}  collection  MongoDB collection
   *
   * @return   {number}  -1: tag value in json or json.set invalid
   *                      0: set document (and phrase documents)
   *                         successfully updated, JSON saved
   */


  treatJSON(localPath, jsonPath, json, collection, assets, activity) {
    const set = json.set || json;
    let {
      tag,
      ignore_missing_files
    } = set;
    let addPhrases = false;
    let phrases;

    if (tag) {
      // should be string, string[] or select object
      if (typeof tag === "string") {
        tag = [tag];
        addPhrases = true;
      } else if (Array.isArray(tag)) {
        tag = tag.filter(item => typeof item === "string");
        addPhrases = tag.length;
      } else if (typeof tag === "object") {// TODO: Check that this is a valid selector object
        // Allow the set to be added, but don't add any phrases
      } else {
        // tag exists but is invalid
        const message = "ERROR in activity ".concat(activity, "\n        Invalid tag found in file at\n        ").concat(jsonPath, "\n        No set treated, no phrases updated.\n        ");
        this.log(message);
        return -1;
      }
    }

    const select = {
      path: localPath
    };
    const toUpdate = this.directoryNeedsUpdating(jsonPath, collection, select);
    this.getSet(set, localPath, assets.icon, collection, toUpdate); // Creates a record in collection and retrieves its _id if
    // no record exists yet: set._id will now exist

    if (addPhrases && (phrases = json.phrases)) {
      // Update json with details of available assets
      this.addAssetsToPhrases(phrases, assets, tag, ignore_missing_files); // Insert or update phrase documents in MongoDB

      this.treatPhrases(phrases, collection); // Each phrase will now have its own _id
    }

    const mod = this.writeJSON(jsonPath, json);
    collection.update({
      _id: set._id
    }, {
      $set: {
        mod
      }
    });
    return 0; // not cancelled
  }

  getSet(set, localPath, icon, collection, _id) {
    if (_id === true) {
      _id = set._id;
    }

    if (icon) {
      set.icon = icon;
    }

    set.path = localPath;
    const parent = localPath.split("/");
    parent.pop();
    set.parent = parent.join("/");

    if (_id) {
      collection.update({
        _id
      }, set, {
        upsert: true
      });
    } else {
      _id = collection.insert(set);
      set._id = _id;
    }
  }

  addAssetsToPhrases(phrases, assets, tagArray, ignore_missing_files) {
    const audio = assets.audio;
    const image = assets.image;
    phrases.forEach(phraseData => {
      let name = phraseData.name;
      let phrase = phraseData.phrase; // Some activities have no "phrase" entry (e.g. Spiral)
      // As a result, they don't have any audio either

      const hasPhrases = typeof phrase === "object";
      const languages = hasPhrases ? Object.keys(phrase) : ["ignore_phrase"];
      const lang = languages[0];

      if (!isNaN(name)) {
        name = "" + parseFloat(name);
      }

      let files;

      if (hasPhrases) {
        files = audio[name];

        if (files) {
          phraseData.audio = files;

          if (!ignore_missing_files) {
            const missingLanguages = this.getMissing(languages, files);

            if (missingLanguages) {
              this.log("Missing       LANG  for phrase " + phraseData.name + ": " + JSON.stringify(missingLanguages) + " \"" + phrase[lang] + "\"");
            }
          }
        } else if (!ignore_missing_files) {
          this.log("Missing       audio for phrase " + phraseData.name + ":        \"" + phrase[lang] + "\"");
        }
      } else {
        // Provide a placeholder phrase with a `lang` entry, in case
        // the image is missing
        phrase = {
          "ignore_phrase": ""
        };
      }

      files = image[name];

      if (files) {
        phraseData.image = files;
      } else if (!ignore_missing_files) {
        this.log("Missing image       for phrase " + phraseData.name + ":        \"" + phrase[lang] + "\"");
      }

      phraseData.tags = [...(phraseData.tags || []), ...tagArray].filter((tag, index, array) => array.indexOf(tag) === index);
    });
  }

  getMissing(languages, files) {
    const available = Object.keys(files);
    const missing = languages.filter(lang => !available.includes(lang));

    if (!missing.length) {
      return 0;
    }

    return missing;
  }

  treatPhrases(phrases, collection) {
    phrases.forEach(phraseData => {
      let {
        _id
      } = phraseData;

      if (_id) {
        collection.update({
          _id
        }, phraseData, {
          upsert: true
        });
      } else {
        _id = collection.insert(phraseData);
        phraseData._id = _id;
      }
    });
  }

  crawlSubFolders(parentFolder, subFolders, icon, localPath, jsonPath, json, collection, activity) {
    // console.log("crawlSubFolders:",parentFolder)
    // console.log(subFolders)
    // Treat rank.json files
    const jsonFiles = subFolders.filter(item => JSON_REGEX.test(item));
    removeFrom(subFolders, item => jsonFiles.includes(item), true);
    this.treatJSON(localPath, jsonPath, json, collection, {
      icon
    }, activity);
    subFolders.forEach(folder => {
      folder = path.join(parentFolder, folder); // try {

      const contents = fs.readdirSync(folder);
      this.treatFolder(activity, folder, contents); // } catch(error) {
      //   const message = `<<<<<<*>>>>>>
      //   ERROR trying to import asset folder for ${activity}
      //   ${error}
      //   `
      //   this.log(message)
      // }
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ioHelper.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/assets/ioHelper.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => IOHelper
});
let getColor, removeFrom;
module.link("../../../tools/generic/utilities", {
  getColor(v) {
    getColor = v;
  },

  removeFrom(v) {
    removeFrom = v;
  }

}, 0);
let PUBLIC_DIRECTORY, EN_REGEX, JSON_REGEX, ICON_REGEX;
module.link("../../../tools/custom/constants", {
  PUBLIC_DIRECTORY(v) {
    PUBLIC_DIRECTORY = v;
  },

  EN_REGEX(v) {
    EN_REGEX = v;
  },

  JSON_REGEX(v) {
    JSON_REGEX = v;
  },

  ICON_REGEX(v) {
    ICON_REGEX = v;
  }

}, 1);

const fs = require('fs');

const path = require('path'); // Used to generate icon.svg files in different colours


let number = 0;

class IOHelper {
  constructor(log) {
    this.log = log;
  }
  /** Compares mod date of JSON file with the MongoDB document
   *  associated with this file. Returns Boolean or string _id.
   *
   *  Called by ActivityInstaller.updateActivityRecordIfNeeded()
   *            ImportAssetFolder.treatFolder()
   *
   * @param   {string}   jsonPath    apsolute path to JSON file
   * @param   {object}   collection  MongoDB collection
   * @param   {object}   select      { _id: <> }
   *                                 { key: <activity name> }
   *
   * @return  {boolean}  > false      MongoDB mod is identical
   *                     > true       no MongoDB document exists
   *                     > string _id of out-of-date MongoDB document
   */


  directoryNeedsUpdating(jsonPath, collection, select) {
    // return true
    const stats = fs.statSync(jsonPath);
    const mod = stats.mtimeMs;
    const options = {
      fields: {
        mod: 1
      }
    };
    const doc = collection.findOne(select, options); // console.log("directoryNeedsUpdating", jsonPath, doc)

    return true;

    if (doc) {
      if (doc.mod === mod) {
        return false;
      }

      return doc._id;
    }

    return true;
  }
  /**
   *
   * Called by ActivityInstaller.doActivityUpdate()
   *           ImportAssetFolder.treatFolder()
   *
   * @param  {string}   parentFolder  absolute path to parent folder
   * @param  {string[]} contents      names of items in folder
   *
   * @return {Object}   { jsonPath: <absolute path to json file>
   *                    , json:     { ... }
   *                    }
   */


  readJSONFile(parentFolder, contents) {
    const jsonFiles = contents.filter(file => JSON_REGEX.test(file)); // console.log(
    //   "readJSONFile"
    // , parentFolder
    // , contents
    // , JSON_REGEX
    // , jsonFiles
    // )

    if (jsonFiles.length !== 1) {
      const message = "ERROR in ImportAssetFolder ".concat(this.activity, "\n      There should be one and only one JSON file:\n        ").concat(JSON.stringify(jsonFiles), "\n      Aborting.");
      this.log(message); // console.log(message)

      return {};
    } // HACK: Remove JSON file from contents, as we don't want it
    // around when we start importing assets.


    removeFrom(contents, item => jsonFiles.includes(item), true); // console.log("contents after json removed:", contents)

    const jsonPath = path.join(parentFolder, jsonFiles[0]);
    let json; // try {

    json = fs.readFileSync(jsonPath);
    json = JSON.parse(json); // } catch(error) {
    //   const message =
    //   `Error reading JSON file ${jsonPath}:
    //   ${error}  `
    //   this.log(message)
    //   return {} // doc will not be updated
    // }
    // console.log("jsonPath:", jsonPath)
    // console.log("json:", json)

    return {
      jsonPath,
      json
    };
  }

  writeJSON(jsonPath, json) {
    // Remove the mod property from the JSON string, since it will
    // be obsolete as soon as the file is modified, and we will be
    // returning the new modification date to MongoDB
    if (Meteor.isDevelopment) {
      const replacer = (key, value) => key === "mod" ? undefined : value;

      const jsonString = JSON.stringify(json, replacer, '\t');
      fs.writeFileSync(jsonPath, jsonString);
    }

    const stats = fs.statSync(jsonPath);
    const mod = stats.mtimeMs;
    return mod;
  }
  /** Returns absolute path to icon, or short icon name, as asked
   *
   * Called by:
   * + importAll()        - deals with root Activity icon
   * + doActivityUpdate() - deals with icon at root of each activity
   * + treatFolder()      - deals with icon for each set
   *
   * @param  {string}    parentFolder  absolute path to parent folder
   * @param  {string[]}  contents      array of file short names
   *
   * @return {string}    relative path from /public/
   */


  getIconMap(parentFolder, contents) {
    const iconMap = {};
    let icons = contents.filter(file => ICON_REGEX.test(file)); // HACK: Remove icon items from contents, as they will not be
    // required by importAssets

    removeFrom(contents, item => icons.includes(item), true);
    let icon, iconPath;

    if (!icons.length) {
      icons.push(this._createPlaceholderIcon(parentFolder));
    }

    if (icons.includes("icon")) {
      // Use localized icons if they are provided.
      // Check that this icon folder contains an icon with the name
      // "en". Only files which share the same extension as the "en"
      // icon can be displayed.
      icon = "icon";
      iconPath = path.join(parentFolder, icon);
      icons = fs.readdirSync(iconPath);
      let enIcon = icons.filter(icon => EN_REGEX.test(icon));

      if (enIcon.length) {// enIcon = enIcon[0]
      } else {
        const message = "\n        WARNING: Default icon (\"en\") not found at ".concat(iconPath, "\n        Available icons: ").concat(JSON.stringify(icons), "\n        A placeholder en.svg will be used instead\n        ");
        this.log(message);
        icons.push(this._createPlaceholderIcon(iconPath, "en"));
      }

      iconPath += "/^0"; // + extension

      iconMap.icons = icons;
    } else {
      iconPath = path.join(parentFolder, icons[0]);
    }

    iconMap.src = iconPath.replace(PUBLIC_DIRECTORY, "");
    return iconMap;
  }
  /** Creates an SVG file in parentFolder; returns short file name
   *
   * Called by getIconMap()
   *
   * @param      {string}    parentFolder   absolute path to folder
   * @param      {string}    [name="icon"]  "en" | undefined
   *
   * @returns    {string}    "en.svg" | "icon.svg"
   */


  _createPlaceholderIcon(parentFolder) {
    let name = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "icon";
    const iconName = name + ".svg";
    const colour = getColor({
      number: number++,
      format: "hex"
    });
    const svg = "<?xml version=\"1.0\"\n  encoding=\"UTF-8\"\n  standalone=\"no\"\n?>\n\n<svg\n  xmlns=\"http://www.w3.org/2000/svg\"\n  viewBox=\"0 0 400 400\"\n  height=\"400\"\n  width=\"400\"\n  fill=\"".concat(colour, "\"\n  stroke=\"none\"\n>\n  <rect\n    x=\"0\"\n    width=\"400\"\n    height=\"400\"\n    rx=\"80\"\n  />\n</svg>");
    const iconPath = path.join(parentFolder, iconName);
    fs.writeFileSync(iconPath, svg);
    return iconName;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"log.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/assets/log.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Log
});

class Log {
  constructor() {
    this.logSheet = "";
    this.addEntry = this.addEntry.bind(this);
    this.save = this.save.bind(this);
  }

  addEntry(message) {
    this.logSheet += "\n" + message;
  }

  save() {//console.log( "LOG", this.logSheet + "\n~~~~~~~~~~~~~~~~~~")
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fluency":{"scheduler.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/fluency/scheduler.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Scheduler
});
let getRandom;
module.link("/imports/tools/generic/utilities", {
  getRandom(v) {
    getRandom = v;
  }

}, 0);
let collections;
module.link("/imports/api/collections/publisher", {
  default(v) {
    collections = v;
  }

}, 1);
const {
  Fluency
} = collections; /// <<< HARD-CODED

const MIN_SPACING = 5; // minimum of 5 items between repetitions

const FOUR_DAYS = 5760; // 4 days in minutes

const MINUTES_TO_MS = 60 * 1000; /// HARD-CODED >>>

class Scheduler {
  constructor(_ref) {
    let {
      user_id,
      group_id,
      correct,
      timeStamp
    } = _ref;
    this.user_id = user_id;
    this.group_id = group_id;
    this.correct = correct;
    this.timeStamp = timeStamp;
    this.setNextSeen = this.setNextSeen.bind(this);
    const ids = Object.keys(correct);
    this.count = ids.length;
    ids.forEach(this.setNextSeen);
  }

  getTime(stamp) {
    if (!stamp) {
      stamp = +new Date();
    }

    return new Date(stamp).toTimeString().substring(0, 8);
  }

  setNextSeen(phrase_id) {
    const select = {
      user_id: this.user_id,
      group_id: this.group_id,
      phrase_id
    };
    const fluencyDoc = Fluency.findOne(select);
    /* {
     *   "_id"        : "7nToxTv7iNQ3ge3zj",
     *   "phrase_id"  : "TYhvrctxvi9bHDuvk",
     *   "next_seen"  : 1595577614381,
     *
     *   "user_id"    : "SWvYPe3Xht8AuBgKi",
     *   "group_id"   : "MthDQhr6w4K5yJXrS",
     *
     *   "times_seen" : 0,
     *   "first_seen" : 0,
     *   "last_seen"  : 0,
     *   "flops"      : 4,
     *   "score"      : 0,
     *   "spacing"    : 5,
     *   "collection" : "Vocabulary",
     *   "level"      : "TODO"
     * }
     */
    // Standard housekeeping

    const correct = this.correct[phrase_id];
    const last_seen = +new Date();
    let next_seen;
    let {
      flops,
      times_seen,
      first_seen,
      spacing
    } = fluencyDoc;
    flops = 16 * !correct + (flops >> 1);

    if (!times_seen) {
      first_seen = last_seen;

      if (correct) {
        spacing = FOUR_DAYS * MIN_SPACING;
        next_seen = first_seen + FOUR_DAYS * MINUTES_TO_MS; // 4 days => 20 days => 100 days = 3 months +
      }
    }

    const ratio = correct ? fluencyDoc.right || 5 : fluencyDoc.wrong || 1 / 2;
    spacing = Math.max(MIN_SPACING, ratio * spacing);

    if (!next_seen) {
      next_seen = this.reschedule(last_seen, spacing);
    }

    times_seen += 1;
    const set = {
      $set: {
        flops,
        times_seen,
        first_seen // may be reset to its current value
        ,
        last_seen // real time
        ,
        next_seen,
        spacing
      }
    };
    Fluency.update(select, set);
  }
  /**
   * { function_description }
   *
   * @param  {timeStamp} now      milliseconds since the epoch
   * @param  {number}    spacing  minimum number of intervening items
   * @param  {number}    ratio    how spacing should change
   *
   * @return {number}    next_seen timestamp
   */


  reschedule(now, spacing, ratio) {
    let next_seen;
    let startTime = this.timeStamp;
    const select = {};
    const options = {
      sort: {
        next_seen: 1
      },
      limit: 1,
      skip: this.count + spacing,
      fields: {
        next_seen: 1,
        phrase: 1
      }
    }; // Assume that MIN_SPACING items take about 1 minute, and
    // calculate the time in minutes before the item should be
    // repeated.

    const spaceTime = spacing / MIN_SPACING * MINUTES_TO_MS; // Determine when the item currently that many places further
    // down the queue is scheduled to repeat, and when we expect
    // that should happen.

    const first = Fluency.find(select, options).fetch()[0];
    let firstTime = this.timeStamp + spaceTime;
    console.log("first:", first, "   <<<   db.fluency.find({}," + JSON.stringify(options.fields) + ").sort(" + JSON.stringify(options.sort) + ").skip(" + options.skip + ").limit(" + options.limit + ")"); // We want to randomize the spacing a bit, so now we calculate
    // the timing expected for the item twice as far away

    options.skip = this.count + 1 + spacing * 2;
    const last = Fluency.find(select, options).fetch()[0];
    let lastTime = this.timeStamp + spaceTime * 2; // console.log("now:", this.getTime(now))
    // console.log("current:", this.getTime(this.timeStamp))
    // if (first) {
    //   console.log("first:", this.getTime(first.next_seen))
    // } else {
    //   console.log("first", undefined)
    // }
    // console.log("firstTime:", this.getTime(firstTime))
    // if (last) {
    //   console.log("last:", this.getTime(last.next_seen))
    // } else {
    //   console.log("last", undefined)
    // }
    // console.log("lastTime:", this.getTime(lastTime))

    if (first) {
      if (last) {
        if (lastTime > last.next_seen) {
          // Items are scheduled closer together than they can be
          // reviewed. Use the number of intervening items as a
          // guide to when to reschedule. Make the end time earlier.
          lastTime = last.next_seen;
        }
      }

      if (firstTime > first.next_seen) {
        // Items are scheduled closer together than they can be
        // reviewed. Use the number of intervening items as a
        // guide to when to reschedule. Make the start time
        // earlier.
        firstTime = first.next_seen;
      } else if (firstTime < now) {
        // All items before now will be served with no gaps. But
        // there is a gap, and we don't want this item to be
        // reserved too soon. Delay it until enough items have
        // been served.
        firstTime = first.next_seen; // Now it's _just_ possible that lastTime is before
        // firstTime, because of the gap.

        if (lastTime < firstTime) {
          lastTime = firstTime + spaceTime;
        }
      } else {
        // There may not be enough intervening items before we can
        // show this item again. Using the calculated time, starting
        // from now, will create a gap for new items to be served,
        // if that is necessary.
        firstTime = Math.min(now + spaceTime, first.next_seen);
        lastTime = Math.min(now + spaceTime * 2, last.next_seen);
      }
    } else {
      // There aren't enough items scheduled to use placing.
      // Reschedule from now.
      firstTime = now + spaceTime;
      lastTime = now + spaceTime * 2;
    } // next_seen = firstTime // (lastTime + firstTime) / 2


    next_seen = getRandom(lastTime, firstTime);
    return next_seen;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"admin.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/admin.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  createAccount: () => createAccount,
  createGroup: () => createGroup,
  logIn: () => logIn,
  logInTeacher: () => logInTeacher,
  toggleActivation: () => toggleActivation,
  logOut: () => logOut,
  share: () => share,
  setPage: () => setPage,
  setIndex: () => setIndex,
  addToFluency: () => addToFluency,
  setFluency: () => setFluency
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let LogIn;
module.link("./admin/login", {
  default(v) {
    LogIn = v;
  }

}, 2);
let LogOut;
module.link("./admin/logout", {
  default(v) {
    LogOut = v;
  }

}, 3);
let JoinGroup;
module.link("./admin/join", {
  default(v) {
    JoinGroup = v;
  }

}, 4);
let LeaveGroup;
module.link("./admin/leave", {
  default(v) {
    LeaveGroup = v;
  }

}, 5);
let CreateGroup;
module.link("./admin/group", {
  default(v) {
    CreateGroup = v;
  }

}, 6);
let LogInTeacher;
module.link("./admin/loginTeacher", {
  default(v) {
    LogInTeacher = v;
  }

}, 7);
let CreateAccount;
module.link("./admin/account", {
  default(v) {
    CreateAccount = v;
  }

}, 8);
let ToggleActivation;
module.link("./admin/activate", {
  default(v) {
    ToggleActivation = v;
  }

}, 9);
let Scheduler;
module.link("./fluency/scheduler", {
  default(v) {
    Scheduler = v;
  }

}, 10);
let collections;
module.link("../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 11);
const {
  Group,
  Fluency,
  Vocabulary
} = collections; // used by share, setPage and setIndex

/** Creates or updates a User record after profiling
 *  Calling the method a second time reuses the existing records
 */

const createAccount = {
  name: 'vdvoyom.createAccount',

  call(accountData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [accountData], options, callback);
  },

  validate(accountData) {
    new SimpleSchema({
      username: {
        type: String
      },
      native: {
        type: String
      },
      teacher: {
        type: String
      },
      language: {
        type: String
      },
      d_code: {
        type: String
      } // action will have been added if the original call was to logIn
      ,
      action: {
        type: String,
        optional: true
      }
    }).validate(accountData);
  },

  run(accountData) {
    new CreateAccount(accountData); // modifies accountData
    // console.log("After CreateAccount accountData is", accountData)

    new LogIn(accountData); // , action: "loggedIn"
    // console.log("Data to return from CreateAccount", accountData)

    return accountData;
  }

};
const createGroup = {
  name: 'vdvoyom.createGroup',

  call(accountData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [accountData], options, callback);
  },

  validate(accountData) {
    new SimpleSchema({
      user_id: {
        type: String
      },
      teacher: {
        type: String
      },
      language: {
        type: String
      } // Other properties may exist but will not be used
      ,
      username: {
        type: String,
        optional: true
      },
      native: {
        type: String,
        optional: true
      },
      d_code: {
        type: String,
        optional: true
      },
      action: {
        type: String,
        optional: true
      }
    }).validate(accountData);
  },

  run(accountData) {
    new CreateGroup(accountData); // modifies accountData

    new JoinGroup(accountData); // action

    return accountData;
  }

};
const logIn = {
  name: 'vdvoyom.logIn',

  call(logInData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [logInData], options, callback);
  },

  validate(logInData) {
    // console.log(JSON.stringify(logInData, null, "  "))
    new SimpleSchema({
      username: {
        type: String
      },
      d_code: {
        type: String
      },
      restore_all: {
        type: Boolean,
        optional: true
      } // Sent only if automatic login is NOT used
      ,
      native: {
        type: String,
        optional: true
      } // for User doc
      ,
      teacher: {
        type: String,
        optional: true
      } // for Group doc
      ,
      language: {
        type: String,
        optional: true
      } //      —⫵—
      ,
      q_code: {
        type: String,
        optional: true
      } // created on server
      // if q_code is missing or does not match username, Client may be
      // asked to provide a PIN, and then logIn will be called again.
      // In that case, status will be set to "RequestPIN" which may be
      // altered to "CreateAccount" if user has no PIN, and pin_given
      // will be set to true
      ,
      pin_given: {
        type: Boolean,
        optional: true
      },
      status: {
        type: String,
        optional: true
      } // Sent only if localStorage is available on Client
      ,
      user_id: {
        type: String,
        optional: true
      },
      group_id: {
        type: String,
        optional: true
      },
      q_color: {
        type: String,
        optional: true
      } // May not be useful on Client, so not available
      ,
      q_index: {
        type: Number,
        optional: true
      }
    }).validate(logInData);
  },

  run(logInData) {
    new LogIn(logInData);
    let {
      status
    } = logInData;

    switch (status) {
      // New user
      case "CreateAccount":
        createAccount.run(logInData);
      // fall through to createGroup

      case "CreateGroup":
        createGroup.run(logInData); // logInData modified

        return logInData;
      // Existing user, perhaps with a new teacher

      case "loggedIn":
        new JoinGroup(logInData); // fall through; action: loggedIn

        if (logInData.status === "CreateGroup") {
          createGroup.run(logInData);
        }

      // Name that matches an existing user, but invalid q_code

      case "RequestPIN":
        return logInData;

      default:
        throw "Unknown action in vdvoyom.logIn: '" + action + "'";
    }
  }

};
const logInTeacher = {
  name: 'vdvoyom.logInTeacher',

  call(logInData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [logInData], options, callback);
  },

  validate(logInData) {
    new SimpleSchema({
      id: {
        type: String
      },
      d_code: {
        type: String
      }
    }).validate(logInData);
  },

  run(logInData) {
    new LogInTeacher(logInData);
    return logInData;
  }

};
const toggleActivation = {
  name: 'vdvoyom.toggleActivation',

  call(groupData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [groupData], options, callback);
  },

  validate(groupData) {
    new SimpleSchema({
      _id: {
        type: String
      },
      d_code: {
        type: String
      },
      active: {
        type: Boolean
      }
    }).validate(groupData);
  },

  run(groupData) {
    new ToggleActivation(groupData);
    return groupData;
  }

};
const logOut = {
  name: 'vdvoyom.log',

  call(logOutData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [logOutData], options, callback);
  },

  validate(logOutData) {
    new SimpleSchema({
      id: {
        type: String
      } // < 5 chars = teacher; > 5 chars = user
      // 'xxxx' => 456976 combinations
      ,
      d_code: {
        type: String
      } // A Teacher might log out without being part of a group
      // , group_id: { type: String, optional: true }

    }).validate(logOutData);
  },

  run(logOutData) {
    new LeaveGroup(logOutData); // adds .leftGroup = [<id>, ...]

    new LogOut(logOutData);
    return logOutData;
  }

};
const share = {
  name: 'vdvoyom.share',

  call(shareData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [shareData], options, callback);
  },

  validate(shareData) {
    new SimpleSchema({
      _id: {
        type: String
      },
      key: {
        type: String
      },
      data: SimpleSchema.oneOf({
        type: String
      }, {
        type: Object,
        blackbox: true
      })
    }).validate(shareData);
  },

  run(shareData) {
    const {
      _id,
      key,
      data
    } = shareData;
    const select = {
      _id
    };
    const set = {
      $set: {
        [key]: data
      }
    };
    Group.update(select, set); // console.log( shareData, JSON.stringify(select), JSON.stringify(set))
  }

};
const setPage = {
  name: 'vdvoyom.setPage',

  call(setPageData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setPageData], options, callback);
  },

  validate(setPageData) {
    // TODO:
    // Ensure that either view or path (or both) are present
    // Ensure that index (if present) is not greater than
    //   path.length - 1
    const tagSchema = new SimpleSchema.oneOf({
      type: String
    }, {
      type: Array
    });
    new SimpleSchema({
      group_id: {
        type: String
      },
      page: {
        type: Object
      },
      "page.view": {
        type: String,
        optional: true
      },
      "page.path": {
        type: String,
        optional: true
      },
      "page.index": {
        type: Number,
        optional: true
      } // , "page.activity": { type: String,  optional: true }
      ,
      "page.tag": {
        type: tagSchema,
        optional: true
      },
      "page.tag.$": {
        type: String
      },
      "page.data": {
        type: Object,
        optional: true,
        blackbox: true
      }
    }).validate(setPageData);
  },

  run(setPageData) {
    const {
      group_id: _id,
      page
    } = setPageData;
    const select = {
      _id
    };
    const set = {
      $set: {
        page
      }
    };
    Group.update(select, set); // console.log(
    //   'db.group.update('
    // + JSON.stringify(select)
    // + ", "
    // + JSON.stringify(set)
    // + ")"
    // // , setPageData
    // )
  }

};
const setIndex = {
  name: "vdvoyom.setIndex",

  call(setIndexData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setIndexData], options, callback);
  },

  validate(setIndexData) {
    new SimpleSchema({
      group_id: {
        type: String
      },
      index: {
        type: Number
      }
    }).validate(setIndexData);
  },

  run(setIndexData) {
    const {
      group_id: _id,
      index
    } = setIndexData;
    const select = {
      _id
    };
    const set = {
      $set: {
        "page.index": index
      }
    };
    Group.update(select, set);
  }

};
const addToFluency = {
  name: 'vocabulary.addToFluency',

  call(fluencyItemArray, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [fluencyItemArray], options, callback);
  },

  validate(fluencyItemArray) {
    fluencyItemArray.forEach(item => {
      new SimpleSchema({
        phrase_id: {
          type: String
        },
        user_id: {
          type: String
        },
        group_id: {
          type: String
        },
        next_seen: {
          type: Number
        }
      }).validate(item);
    });
  },

  run(fluencyItemArray) {
    const fillers = {
      times_seen: 0,
      first_seen: 0,
      last_seen: 0,
      flops: 4,
      score: 0,
      spacing: 5 // show 5 others before a repeat | ≈ 1 minute
      // , right:      5
      // , wrong:      1/2
      ,
      collection: "Vocabulary",
      level: "TODO"
    };
    fluencyItemArray.forEach(fluencyObject => {
      fluencyObject = _objectSpread({}, fluencyObject, {}, fillers);
      Fluency.insert(fluencyObject);
    });
  }

};
const setFluency = {
  name: "vdvoyom.setFluency",

  call(setFluencyData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setFluencyData], options, callback);
  },

  validate(setFluencyData) {
    new SimpleSchema({
      user_id: {
        type: String
      },
      group_id: {
        type: String
      },
      correct: {
        type: Object,
        blackbox: true
      },
      timeStamp: {
        type: Number
      }
    }).validate(setFluencyData);
  },

  run(setFluencyData) {
    new Scheduler(setFluencyData);
  }

};
// To register a new method with Meteor's DDP system, add it here
const methods = [createAccount, createGroup, logIn, logOut, logInTeacher, toggleActivation, share, setPage, setIndex, addToFluency, setFluency];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"assets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/assets.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  importFolder: () => importFolder
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let ImportAssets;
module.link("./assets/importAssets", {
  default(v) {
    ImportAssets = v;
  }

}, 2);
let collections;
module.link("../collections/publisher", {
  default(v) {
    collections = v;
  }

}, 3);
const {
  Group
} = collections; // used by share, setPage and setIndex

/** Creates or updates a User record after profiling
 *  Calling the method a second time reuses the existing records
 */

const importFolder = {
  name: 'assets.importFolder',

  call(importData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [importData], options, callback);
  },

  validate(importData) {// new SimpleSchema({
    //   username: { type: String }
    // , native:   { type: String }
    // , teacher:  { type: String }
    // , language: { type: String }
    // , d_code:   { type: String }
    // // action will have been added if the original call was to logIn
    // , action:   { type: String, optional: true }
    // }).validate(importData)
  },

  run(importData) {
    new ImportAssets(importData);
  }

};
// To register a new method with Meteor's DDP system, add it here
const methods = [importFolder];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mint.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/methods/mint.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  methods: () => methods
});
let admin;
module.link("./admin", {
  "*"(v) {
    admin = v;
  }

}, 0);
let assets;
module.link("./assets", {
  "*"(v) {
    assets = v;
  }

}, 1);
let drag;
module.link("../../public/Activities/Drag/methods.js", {
  "*"(v) {
    drag = v;
  }

}, 2);
let flash;
module.link("../../public/Activities/Flash/methods.js", {
  "*"(v) {
    flash = v;
  }

}, 3);
let spiral;
module.link("../../public/Activities/Spiral/methods.js", {
  "*"(v) {
    spiral = v;
  }

}, 4);
let vocabulary;
module.link("../../public/Activities/Vocabulary/methods.js", {
  "*"(v) {
    vocabulary = v;
  }

}, 5);

const methods = _objectSpread({}, admin, {}, assets, {}, drag, {}, flash, {}, spiral, {}, vocabulary);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"admin.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/collections/admin.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  publishQueries: () => publishQueries,
  collections: () => collections
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
// Export collections individually: import { Name } from '...'
const Chat = new Mongo.Collection('chat');
const User = new Mongo.Collection('user');
const Group = new Mongo.Collection('group');
const Fluency = new Mongo.Collection('fluency');
const UIText = new Mongo.Collection('uitext');
const Counters = new Mongo.Collection('counters');
const Teacher = new Mongo.Collection('teacher');
const Activity = new Mongo.Collection('activity'); // Define the queries that will be used to publish these collections
// in the standard way

const publishQueries = {
  Chat: {},
  User: {},
  Group: {},
  Fluency: {},
  UIText: {},
  Counters: {},
  Teacher: {
    $or: [{
      file: {
        $exists: false
      }
    }, {
      file: {
        $ne: "xxxx"
      }
    }]
  },
  Activity: {}
};
const collections = {
  Chat,
  User,
  Group,
  Fluency,
  UIText,
  Counters,
  Teacher,
  Activity
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mint.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/collections/mint.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  collections: () => collections,
  publishQueries: () => publishQueries
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let adminCollections, adminQueries;
module.link("./admin", {
  collections(v) {
    adminCollections = v;
  },

  publishQueries(v) {
    adminQueries = v;
  }

}, 1);
const Cloze = new Mongo.Collection('cloze');
const Nim = new Mongo.Collection('nim');
const Spiral = new Mongo.Collection('spiral');
const Stories = new Mongo.Collection('stories');
const Vocabulary = new Mongo.Collection('vocabulary');

const collections = _objectSpread({}, adminCollections, {
  Cloze,
  Nim,
  Spiral,
  Stories,
  Vocabulary
});

const publishQueries = _objectSpread({}, adminQueries, {
  "Cloze": {},
  "Nim": {},
  "Spiral": {},
  "Stories": {},
  "Vocabulary": {}
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"points.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/collections/points.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  createTracker: () => createTracker,
  update: () => update,
  destroyTracker: () => destroyTracker,
  clearPoints: () => clearPoints
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
///// COLLECTION //// COLLECTION //// COLLECTION //// COLLECTION /////
let Points; // MongoDB-free collection
/// METHODS // METHODS // METHODS // METHODS // METHODS // METHODS ///

const createTracker = {
  name: "points.createTracker",

  call(trackerData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [trackerData], options, callback);
  },

  validate(trackerData) {
    new SimpleSchema({
      _id: {
        type: String
      } // d_code for user|teacher's device
      ,
      color: {
        type: String
      },
      group_id: {
        type: String
      }
    }).validate(trackerData);
  }
  /** Create a document for the current User in group group_id
   *
   *  The _id of the new document will be stored in the Client. Each
   *  time the User moves the mouse or drags the mouse or a touch
   *  point on the screen, the x, y and other properties of this
   *  document will be updated. All Users and Teachers connected to
   *  group group_id will be able to display the cursor/touch position
   *  of this User on their screen.
   */
  ,

  run(trackerData) {
    const _id = Points.insert(trackerData);

    return _id; // should be same as trackerData._id
  }

};
const update = {
  name: "points.update",

  call(pointData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [pointData], options, callback);
  },

  validate(pointData) {
    new SimpleSchema({
      _id: {
        type: String
      },
      group_id: {
        type: String
      },
      x: {
        type: Number
      },
      y: {
        type: Number
      },
      active: {
        type: Boolean
      },
      touchend: {
        type: Boolean
      },
      touch: {
        type: Object,
        optional: true,
        blackbox: true
      }
    }).validate(pointData);

    if (pointData.touch) {
      new SimpleSchema({
        radiusX: {
          type: Number
        },
        radiusY: {
          type: Number
        },
        rotationAngle: {
          type: Number
        }
      }).validate(pointData.touch);
    }
  },

  run(pointData) {
    // {_id, group_id, x, y, active }
    const _id = pointData._id;
    Points.update({
      _id
    }, {
      $set: pointData
    }); // not _id, number
  }

};
const destroyTracker = {
  name: "points.destroyTracker",

  call(trackerData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [trackerData], options, callback);
  },

  validate(trackerData) {
    new SimpleSchema({
      _id: {
        type: String
      } // d_code for user|teacher's device
      ,
      group_id: {
        type: String
      }
    }).validate(trackerData);
  },

  run(trackerData) {
    const {
      group_id
    } = trackerData;
    const result = Points.remove(trackerData); // console.log("Points.remove("
    //            + JSON.stringify(trackerData)
    //            + ") =>"
    //            + "result:", result)

    const members = Points.find({
      group_id
    }, {}).fetch();

    if (members.length < 2) {
      Points.remove({
        group_id
      });
    }

    return false;
  }

};
const clearPoints = {
  name: "points.clear",

  call(trackerData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [trackerData], options, callback);
  },

  validate() {},

  run(trackerData) {
    const result = Points.remove({}); // console.log("Points.remove( {} ) =>"
    //            + "result:", result)

    return result;
  }

};
const methods = [createTracker, update, destroyTracker, clearPoints // Debug only
];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});

if (Meteor.isServer) {
  Points = new Meteor.Collection('points', {
    connection: null
  });
  Meteor.publish('overDPP', function () {
    // `publish` requires the classic function() {} syntax for `this`
    const subscription = this;
    const publication = Points.find({}).observeChanges({
      added: function (id, fields) {
        subscription.added("points", id, fields);
      },
      changed: function (id, fields) {
        subscription.changed("points", id, fields);
      },
      removed: function (id) {
        subscription.removed("points", id);
      }
    });
    subscription.ready();
    subscription.onStop(() => {
      publication.stop();
    });
  });
}

if (Meteor.isClient) {
  Points = new Meteor.Collection('points'); // connection undefined

  Meteor.subscribe('overDPP'); // REMOVE Debug Only // REMOVE Debug Only // REMOVE Debug Only //

  window.Points = Points;
  window.clearPoints = clearPoints;
}

module.exportDefault(Points);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publisher.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/collections/publisher.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  getNextIndex: () => getNextIndex
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let collections, publishQueries;
module.link("./mint", {
  collections(v) {
    collections = v;
  },

  publishQueries(v) {
    publishQueries = v;
  }

}, 2);

// console.log("collections", Object.keys(collections))
if (Meteor.isServer) {
  for (name in collections) {
    const select = publishQueries[name];
    const collection = collections[name]; // console.log(name, select)

    name = collection._name; // name.toLowerCase()
    // The publication method is run each time a client subscribes to
    // the named collection. The subscription may be made directly or
    // through the /imports/api/methods/mint.js script

    Meteor.publish(name, function public(caller) {
      // We need to use the classic function () syntax so that we can
      // use this to access the Meteor connection and use this.user_id
      let items = collection.find(select); // (customSelect || select)

      if (typeof caller === "string") {
        for (var _len = arguments.length, more = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          more[_key - 1] = arguments[_key];
        }

        console.log("Publishing", collection._name, "for", caller, ...more); // console.log(
        //   "Items 1 - 4 /"
        // , collection.find(select).count()
        // , collection.find(select, { limit: 4 }).fetch()
        // )
      }

      return items;
    });
  }
} // Called by addUserHistoryItem() in join.js


const getNextIndex = _id => {
  const Counters = collections.Counters;
  let inc = 1;

  if (Meteor.isMeteor) {
    Counters.upsert({
      _id
    }, {
      $inc: {
        index: inc
      }
    });
    inc = 0;
  }

  const index = Counters.findOne({
    _id
  }) || {
    index: 0
  }.index + inc;
  return index;
};

module.exportDefault(collections);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"public":{"Activities":{"Drag":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/public/Activities/Drag/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  setViewData: () => setViewData,
  toggleComplete: () => toggleComplete,
  toggleShow: () => toggleShow,
  setDragTarget: () => setDragTarget,
  updateDragTarget: () => updateDragTarget,
  dropDragTarget: () => dropDragTarget
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let collections;
module.link("/imports/api/collections/publisher", {
  default(v) {
    collections = v;
  }

}, 2);
const {
  Group
} = collections;
const setViewData = {
  name: "drag.setViewData",

  call(setViewData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setViewData], options, callback);
  },

  validate(setViewData) {
    new SimpleSchema({
      group_id: {
        type: String
      },
      data: {
        type: Object,
        blackbox: true
      }
    }).validate(setViewData);
  },

  run(setViewData) {
    const {
      group_id: _id,
      data
    } = setViewData;
    const select = {
      _id
    };
    const set = {
      $set: {
        "page.data": data
      }
    };
    Group.update(select, set);
  }

};
const toggleComplete = {
  name: "drag.toggleComplete",

  call(toggleCompleteData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [toggleCompleteData], options, callback);
  },

  validate(toggleCompleteData) {
    new SimpleSchema({
      complete: {
        type: Boolean
      },
      group_id: {
        type: String
      }
    }).validate(toggleCompleteData);
  },

  run(toggleCompleteData) {
    const {
      group_id: _id,
      complete
    } = toggleCompleteData;
    const select = {
      _id
    };
    const set = {
      $set: {
        "page.data.complete": complete
      }
    };
    const result = Group.update(select, set); // console.log( "db.group.update("
    //            + JSON.stringify(select)
    //            + ","
    //            + JSON.stringify(set)
    //            + ") >>> result:", result
    //            )
  }

};
const toggleShow = {
  name: "drag.toggleShow",

  call(toggleShowData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [toggleShowData], options, callback);
  },

  validate(toggleShowData) {
    new SimpleSchema({
      index: {
        type: Number
      },
      group_id: {
        type: String
      }
    }).validate(toggleShowData);
  },

  run(toggleShowData) {
    const {
      group_id: _id,
      index
    } = toggleShowData;
    const select = {
      _id
    };
    const set = {
      $set: {
        ["page.data.show." + index]: true
      }
    };
    const result = Group.update(select, set); // console.log( "db.group.update("
    //            + JSON.stringify(select)
    //            + ","
    //            + JSON.stringify(set)
    //            + ") >>> result:", result
    //            )
  }

};
const setDragTarget = {
  name: "drag.setDragTarget",

  call(dragTargetData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [dragTargetData], options, callback);
  },

  validate(dragTargetData) {
    new SimpleSchema({
      drag_id: {
        type: String
      } // id of HTML element
      ,
      pilot: {
        type: String
      } // d_code for user|teacher's device
      ,
      group_id: {
        type: String
      },
      x: {
        type: Number
      },
      y: {
        type: Number
      }
    }).validate(dragTargetData);
  }
  /* Call will throw an error if any user (including pilot) started an
   * action but did not complete it.
   * TODO: Ensure that all pilot actions are removed when the pilot
   * logs out.
   */
  ,

  run(dragTargetData) {
    const {
      group_id: _id,
      pilot,
      drag_id,
      x,
      y
    } = dragTargetData;
    const select = {
      _id
    }; // const options = { fields: { "page.data": 1 } }
    // const { page } = Group.findOne(select, options)
    //               || { page: {} } // if group has no page.data yet
    // const data = page.data || {}
    // if (data.pilot) {
    //   // There is already an operation in progress
    //   throw ("Group " + _id + " locked by a process from " + data.pilot)
    // }

    const set = {
      $set: {
        "page.data.pilot": pilot,
        "page.data.drag_id": drag_id,
        "page.data.x": x,
        "page.data.y": y
      },
      $unset: {
        "page.data.drop": 0
      }
    };
    return Group.update(select, set);
  }

};
const updateDragTarget = {
  name: "drag.updateDragTarget",

  call(dragTargetData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [dragTargetData], options, callback);
  },

  validate(dragTargetData) {
    new SimpleSchema({
      group_id: {
        type: String
      },
      pilot: {
        type: String
      },
      x: {
        type: Number
      },
      y: {
        type: Number
      }
    }).validate(dragTargetData);
  },

  run(dragTargetData) {
    const {
      group_id: _id,
      pilot,
      x,
      y
    } = dragTargetData;
    const select = {
      _id,
      "page.data.pilot": pilot
    };
    const set = {
      $set: {
        "page.data.x": x,
        "page.data.y": y
      }
    };
    return Group.update(select, set);
  }

};
const dropDragTarget = {
  name: "drag.dropDragTarget",

  call(dropTargetData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [dropTargetData], options, callback);
  },

  validate(dropTargetData) {
    new SimpleSchema({
      group_id: {
        type: String
      }
    }).validate(dropTargetData);
  },

  run(dropTargetData) {
    const {
      group_id: _id
    } = dropTargetData;
    const select = {
      _id
    };
    const unset = {
      $unset: {
        "page.data.pilot": 0,
        "page.data.drag_id": 0,
        "page.data.x": 0,
        "page.data.y": 0
      }
    };
    return Group.update(select, unset);
  }

};
const methods = [setViewData, toggleShow, toggleComplete, setDragTarget, updateDragTarget, dropDragTarget];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Flash":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/public/Activities/Flash/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  placeholder: () => placeholder
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let collections;
module.link("/imports/api/collections/publisher", {
  default(v) {
    collections = v;
  }

}, 2);
const {
  Groups
} = collections;
const placeholder = {
  name: "flash.placeholder",

  call(placeholderData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [placeholderData], options, callback);
  },

  validate(placeholderData) {// new SimpleSchema({
    //   group_id: { type: String }
    // , data: { type: Object, blackbox: true }
    // }).validate(placeholderData)
  },

  run(placeholderData) {// const { group_id: _id, data } = placeholderData
    // const select = { _id }
    // const set = { $set: { "page.data": data } }
    // Groups.update(select, set)
  }

};
const methods = [placeholder];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Spiral":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/public/Activities/Spiral/methods.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  setStart: () => setStart
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let collections;
module.link("../../../../imports/api/collections/mint", {
  collections(v) {
    collections = v;
  }

}, 2);
const {
  Group
} = collections;
const setStart = {
  name: 'spiral.setStart',

  call(setStartData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setStartData], options, callback);
  },

  validate(setStartData) {
    new SimpleSchema({
      group_id: {
        type: String
      },
      start: {
        type: Number
      }
    }).validate(setStartData);
  },

  run(setStartData) {
    const {
      group_id: _id,
      start
    } = setStartData;
    const select = {
      _id
    };
    const set = {
      $set: {
        "page.data.start": start
      }
    };
    Group.update(select, set);
  }

};
// To register a new method with Meteor's DDP system, add it here
const methods = [setStart];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Vocabulary":{"methods.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/public/Activities/Vocabulary/methods.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// /**
//  * /public/activities/Vocabulary/methods.js
//  */
// import { Meteor } from 'meteor/meteor'
// import SimpleSchema from 'simpl-schema'
// import { collections } from '/imports/api/collections/mint'
// const { Fluency, Group } = collections
// export const addToFluency = {
//   name: 'vocabulary.addToFluency'
// , call(fluencyItemArray, callback) {
//     const options = {
//       returnStubValue: true
//     , throwStubExceptions: true
//     }
//     Meteor.apply(this.name, [fluencyItemArray], options, callback)
//   }
// , validate(fluencyItemArray) {
//     fluencyItemArray.forEach( item => {
//       new SimpleSchema({    
//           phrase_id:  { type: String }
//         , user_id:    { type: String }
//         , group_id:   { type: String }
//         , next_seen:  { type: Number }
//       }).validate(item)
//     })
//   }
// , run(fluencyItemArray) {
//     const fillers = {
//       times_seen: 0
//     , first_seen: 0
//     , last_seen:  0
//     , flops:      4
//     , score:      0
//     , collection: "Vocabulary"
//     , level:      "TODO"
//     }
//     fluencyItemArray.forEach( fluencyObject => {
//       fluencyObject = {...fluencyObject, ...fillers}
//       Fluency.insert(fluencyObject)
//     })
//   }
// }
// // To register a new method with Meteor's DDP system, add it here
// const methods = [
//   addToFluency
// ]
// methods.forEach(method => {
//   Meteor.methods({
//     [method.name]: function (args) {
//       method.validate.call(this, args)
//       return method.run.call(this, args)
//     }
//   })
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"tools":{"custom":{"constants.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/tools/custom/constants.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  PUBLIC_DIRECTORY: () => PUBLIC_DIRECTORY,
  ACTIVITY_FOLDER: () => ACTIVITY_FOLDER,
  ASSETS_FOLDER: () => ASSETS_FOLDER,
  ICON_REGEX: () => ICON_REGEX,
  IMAGE_REGEX: () => IMAGE_REGEX,
  JSON_REGEX: () => JSON_REGEX,
  SET_REGEX: () => SET_REGEX,
  EN_REGEX: () => EN_REGEX
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
const PWD = process.env.PWD; // Development: /home/blackslate/Repos/jazyx/Activities
// Production:  /var/www/jazyx/<subdomain>/bundle

const formats = "jpe?g|png|svg|gif|webm)"; // trailing ) deliberate

const lookAhead = "\\.(?:" + formats + "$"; // leading ( only
/// <<< HARD-CODED

const PUBLIC_DIRECTORY = Meteor.isDevelopment ? PWD + "/public" : PWD + "/programs/web.browser/app";
const ACTIVITY_FOLDER = PUBLIC_DIRECTORY + '/Activities/';
const ASSETS_FOLDER = PUBLIC_DIRECTORY + '/Assets/';
const ICON_REGEX = new RegExp("^(icon" + lookAhead + ")|(icon)$"); // Used to find default icon in /icon/ folders: /icon/en.xxx

const EN_REGEX = new RegExp("en\.(" + formats); // Used to identify image files in image/ folder

const IMAGE_REGEX = new RegExp("([^/.]+)" + lookAhead); // four-letter + .json

const JSON_REGEX = /^((?:root)|(?:rank)|(?:rack)|(?:l10n))\.json$/; // Splits PATH_REGEX into chunks like "/Activity" and "/exercise"

const SET_REGEX = /(?=\/)/; /// HARD-CODED >>>
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"project.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/tools/custom/project.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  getGoldenAngleAt: () => getGoldenAngleAt,
  getCodeFrom: () => getCodeFrom,
  getIconSrc: () => getIconSrc
});
let getRandomFromArray;
module.link("../generic/utilities", {
  getRandomFromArray(v) {
    getRandomFromArray = v;
  }

}, 0);
let IMAGE_REGEX;
module.link("./constants", {
  IMAGE_REGEX(v) {
    IMAGE_REGEX = v;
  }

}, 1);
const GOLDEN_ANGLE = 180 * (3 - Math.sqrt(5));
const RATIO = 14221 / 512; // stretches 360 to 9999.140

const getGoldenAngleAt = index => {
  let angle = index * GOLDEN_ANGLE;
  angle -= Math.floor(angle / 360) * 360; // 0.0 ≤ angle < 360.0

  return angle;
};

const getCodeFrom = angle => {
  let code = Math.round(angle * RATIO); // The following lines depend on 0 ≤  code ≤ 9999, because of the
  // values of RATIO. If RATIO is multiplied by 10, for example,
  // we'll need an extra zero and an extra } else if { statement.

  if (code < 10) {
    code = "000" + code;
  } else if (code < 100) {
    code = "00" + code;
  } else if (code < 1000) {
    code = "0" + code;
  } else {
    code = "" + code;
  }

  return code;
};

const getIconSrc = (iconData, lang) => {
  let {
    src,
    icons
  } = iconData;

  const languageMatch = (icons, lang) => {
    return icons.find(icon => {
      const match = IMAGE_REGEX.exec(icon);

      if (match && match[1] === lang) {
        return true;
      }
    });
  };

  if (icons) {
    // src will be of the format "/path/to/icon/^0"
    let icon = languageMatch(icons, lang); // may be dialect xx-XX

    if (!icon) {
      // Use a generic language icon
      lang = lang.replace(/-.*$/, ""); // "xx-XX" => "xx"

      icon = languageMatch(icons, lang);
    }

    if (!icon) {
      // An "en" icon was created automatically at startUp if it
      // didn't already exist. Use this language as a fallback.
      icon = languageMatch(icons, "en");
    }

    src = src.replace("^0", icon);
  }

  return src;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"generic":{"utilities.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/tools/generic/utilities.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  rgbify: () => rgbify,
  tweenColor: () => tweenColor,
  toneColor: () => toneColor,
  translucify: () => translucify,
  getColor: () => getColor,
  hsl2rgb: () => hsl2rgb,
  hsl2hex: () => hsl2hex,
  HSLtoRGB: () => HSLtoRGB,
  buttonColors: () => buttonColors,
  removeFrom: () => removeFrom,
  getDifferences: () => getDifferences,
  trackChanges: () => trackChanges,
  shuffle: () => shuffle,
  getRandom: () => getRandom,
  getRandomFromArray: () => getRandomFromArray,
  arrayOverlap: () => arrayOverlap,
  getUnused: () => getUnused,
  getPageXY: () => getPageXY,
  getXY: () => getXY,
  detectMovement: () => detectMovement,
  setTrackedEvents: () => setTrackedEvents,
  intersect: () => intersect,
  intersection: () => intersection,
  union: () => union,
  pointWithin: () => pointWithin,
  overlap: () => overlap,
  valuesMatch: () => valuesMatch,
  getFontFamily: () => getFontFamily,
  hash: () => hash,
  trimImage: () => trimImage,
  substitute: () => substitute,
  getLocalized: () => getLocalized,
  localize: () => localize,
  getElementIndex: () => getElementIndex
});

const rgbify = color => {
  if (color.substring(0, 3).toLowerCase() === "hsl") {
    return HSLtoRGB(color);
  }

  if (color[0] === "#") {
    color = color.slice(1);
  }

  if (color.length === 3) {
    color = color[0] + color[0] + color[1] + color[1] + color[2] + color[2];
  }

  const hex = parseInt(color, 16);
  return [hex >> 16 // red
  , hex >> 8 & 0x00FF // green
  , hex & 0xFF // blue
  ];
};

const tweenColor = (color1, color2, ratio) => {
  const rgb1 = rgbify(color1);
  const rgb2 = rgbify(color2);
  const hex = rgb1.map((value, index) => {
    value = Math.round(value - (value - rgb2[index]) * ratio);
    value = Math.max(0, Math.min(value, 255));
    return (value < 16 ? "0" : "") + value.toString(16);
  });
  return "#" + hex.join("");
};

const toneColor = (color, ratio) => {
  const prefix = color[0] === "#";

  if (prefix) {
    color = color.slice(1);
  }

  const rgb = rgbify(color).map(value => {
    value = Math.floor(Math.max(0, Math.min(255, value * ratio)));
    return (value < 16 ? "0" : "") + value.toString(16);
  });
  return (prefix ? "#" : "") + rgb.join("");
};

const translucify = (color, opacity) => {
  if (color[0] === "#") {
    color = color.slice(1);
  }

  const rgb = rgbify(color);
  return "rgba(".concat(rgb[0], ", ").concat(rgb[1], ", ").concat(rgb[2], ", ").concat(opacity, ")");
};

const getColor = (_ref) => {
  let {
    number,
    s = 0.5,
    l = 0.33,
    format = "hsl"
  } = _ref;
  const h = number * 137.50776405; // ≈ golden angle: 180*(3-√5)

  s = Math.max(0, Math.min(s, 1));
  l = Math.max(0, Math.min(l, 1));

  switch (format.toLowerCase()) {
    case "rgb":
      return hsl2rgb(h, s, l);

    case "hex":
      return hsl2hex(h, s * 100, l * 100);

    default:
      // "hsl"
      return "hsl(".concat(h, ",").concat(s * 100, "%,").concat(l * 100, "%)");
  }
};

const hsl2rgb = (h, s, l) => {
  let a = s * Math.min(l, 1 - l);

  let f = function (n) {
    let k = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : (n + h / 30) % 12;
    return l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
  };

  return [f(0), f(8), f(4)];
};

const hsl2hex = (h, s, l) => {
  h /= 360;
  s /= 100;
  l /= 100;
  let r, g, b;

  if (s === 0) {
    r = g = b = l; // achromatic
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  const toHex = x => {
    const hex = Math.round(x * 255).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  };

  return "#".concat(toHex(r)).concat(toHex(g)).concat(toHex(b));
};

const HSLtoRGB = colorString => {
  // "hsl(412.523,50%,40%)" <<< percentages
  // "412.523, 0.5, 0.4"    <<< ratios
  let rgb = [0, 0, 0];
  const regex = /(hsl\s*\(\s*)?([0-9.]+)\s*,\s*([0-9.]+)(%?)\s*,\s*([0-9.]+)(%?)\s*\)?/;
  const match = regex.exec(colorString);

  if (match) {
    let h = parseFloat(match[2], 10);
    let s = parseFloat(match[3], 10);
    let l = parseFloat(match[5], 10);

    while (h > 360) {
      h -= 360;
    }

    while (h < 0) {
      h += 360;
    }

    if (match[4]) {
      s /= 100;
    }

    s = Math.max(0, Math.min(s, 1));

    if (match[6]) {
      l /= 100;
    }

    l = Math.max(0, Math.min(l, 1));
    rgb = hsl2rgb(h, s, l) // [<0.0-1.0>, <0.0-1.0>, <0.0-1.0>]
    .map(number => Math.round(number * 255));
  }

  return rgb;
};

const buttonColors = (color, values) => {
  const output = {
    restBg: 1,
    restTint: 1.5,
    restShade: 0.75,
    overBg: 1.1,
    overTint: 1.65,
    overShade: 0.667,
    downBg: 0.95,
    downTint: 1.333,
    downShade: 0.6
  };
  const keys = Object.keys(output);

  (function merge(input) {
    if (typeof input === "object") {
      keys.forEach(key => {
        const value = input[key];

        if (!isNaN(value)) {
          if (value > 0) {
            output[key] = value;
          }
        }
      });
    }
  })();

  keys.forEach(key => output[key] = toneColor(color, output[key]));
  return output;
};

const removeFrom = (array, item, removeAll) => {
  let removed = 0;
  let index, found;

  do {
    if (typeof item === "function") {
      index = array.findIndex(item);
    } else {
      index = array.indexOf(item);
    }

    found = !(index < 0);

    if (found) {
      array.splice(index, 1);
      removed += 1;
    }
  } while (removeAll && found);

  return removed;
};

const getDifferences = () => {
  let previous = [];
  return array => {
    const plus = array.filter(item => previous.indexOf(item) < 0);
    const minus = previous.filter(item => array.indexOf(item) < 0);
    previous = [...array];
    return {
      plus,
      minus
    };
  };
};

const trackChanges = array => {
  const current = array;
  let previous = [...array];
  return () => {
    const plus = array.filter(item => previous.indexOf(item) < 0);
    const minus = previous.filter(item => array.indexOf(item) < 0);
    previous = [...array];
    return {
      plus,
      minus
    };
  };
};

const shuffle = a => {
  let ii = a.length;

  while (ii) {
    const jj = Math.floor(Math.random() * ii);
    ii -= 1;
    [a[ii], a[jj]] = [a[jj], a[ii]];
  }

  return a; // for chaining
};

const getRandom = function (max) {
  let min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const getRandomFromArray = array => {
  return array[Math.floor(Math.random() * array.length)];
};

const arrayOverlap = (array1, array2) => {
  if (!array1 || !array1.length || !array2 || !array2.length) {
    return [];
  }

  return array1.filter(item => array2.includes(item));
};

const getUnused = (source, used, tolerateDuplicates) => {
  const unused = source.slice(0);
  used.forEach(item => removeFrom(unused, item));
  let item = getRandomFromArray(unused);

  if (!item && tolerateDuplicates) {
    // May return the same item multiple times,
    // rather than creating a smooth spread
    item = getRandomFromArray(source);
  }

  return item;
};

const getPageXY = event => {
  if (event.targetTouches && event.targetTouches.length) {
    event = event.targetTouches[0] || {};
  }

  return {
    x: event.pageX,
    y: event.pageY
  };
};

const getXY = (event, frame) => {
  if (["client", "page", "offset"].indexOf(frame) < 0) {
    frame = "client";
  }

  if (event.targetTouches && event.targetTouches.length) {
    event = event.targetTouches[0] || {};
  }

  return {
    x: event[frame + "X"],
    y: event[frame + "Y"]
  };
};

const detectMovement = (event, triggerDelta) => {
  const trigger2 = triggerDelta * triggerDelta;

  function movementDetected(resolve, reject) {
    const {
      x: startX,
      y: startY
    } = getPageXY(event);
    const options = {
      event,
      drag,
      drop
    };
    const cancel = setTrackedEvents(options); // { actions: { move: <"touchmove" | "mousemove">
    //              end:  <"toucheend" | "mouseup">
    // , drag: function
    // , drop: function
    // }
    // Check if the mouse/touch has moved more than triggerDelta
    // pixels in any direction, and resolve promise if so.

    function drag(event) {
      const {
        x,
        y
      } = getPageXY(event);
      const deltaX = startX - x;
      const deltaY = startY - y;
      const delta2 = deltaX * deltaX + deltaY * deltaY;

      if (delta2 > trigger2) {
        setTrackedEvents(cancel);
        resolve();
      }
    } // Reject promise if the mouse is release before the mouse/touch
    // moved triggerDelta pixels in any direction.


    function drop(event) {
      setTrackedEvents(cancel);
      reject();
    }
  }

  return new Promise(movementDetected);
};

const setTrackedEvents = (_ref2) => {
  let {
    actions,
    event,
    drag,
    drop
  } = _ref2;
  // Omit event to cancel tracking
  const body = document.body;

  if (event) {
    if (typeof actions !== "object") {
      actions = {};
    }

    if (event.type === "touchstart") {
      actions.move = "touchmove";
      actions.end = "touchend";
    } else {
      actions.move = "mousemove";
      actions.end = "mouseup";
    }

    body.addEventListener(actions.move, drag, false);
    body.addEventListener(actions.end, drop, false);
  } else {
    body.removeEventListener(actions.move, drag, false);
    body.removeEventListener(actions.end, drop, false);
  }

  return {
    actions,
    drag,
    drop
  };
};

const intersect = (rect1, rect2) => {
  return rect1.x < rect2.right && rect2.x < rect1.right && rect1.y < rect2.bottom && rect2.y < rect1.bottom;
};

const intersection = (rect1, rect2) => {
  const left = Math.max(rect1.left || rect1.x || 0, rect2.left || rect2.x || 0);
  const right = Math.min(rect1.right || rect1.left + rect1.width || 0, rect2.right || rect2.left + rect2.width || 0);

  if (!(left < right)) {
    return 0;
  }

  const top = Math.max(rect1.top || rect1.y || 0, rect2.top || rect2.y || 0);
  const bottom = Math.min(rect1.bottom || rect1.top + rect1.height || 0, rect2.bottom || rect2.top + rect2.height || 0);

  if (!(top < bottom)) {
    return 0;
  }

  const x = left;
  const y = top;
  const width = right - x;
  const height = bottom - y;
  return {
    x,
    y,
    left,
    right,
    top,
    bottom,
    width,
    height
  };
};

const union = rects => {
  const [rect, ...rest] = rects;
  let {
    left,
    right,
    top,
    bottom
  } = rect;
  rest.forEach(rect => {
    left = Math.min(left, rect.left);
    right = Math.max(right, rect.right);
    top = Math.min(top, rect.top);
    bottom = Math.max(bottom, rect.bottom);
  });
  const x = left;
  const y = top;
  const width = right - left;
  const height = bottom - top;
  return {
    x,
    y,
    left,
    right,
    top,
    bottom,
    width,
    height
  };
};

const pointWithin = (x, y, rect) => {
  return rect.x <= x && rect.y <= y && rect.right > x && rect.bottom > y;
};

const overlap = (rect, container) => {
  let overlap = intersection(rect, container); // 0 or rect object

  if (overlap) {
    const width = rect.width || rect.left - rect.right;
    const height = rect.height || rect.bottom - rect.top;
    overlap = overlap.width * overlap.height / (width * height);
  }

  return overlap;
};

const valuesMatch = (a, b) => {
  if (!a || typeof a !== "object" || !b || typeof b !== "object") {
    return false;
  }

  const propsA = Object.getOwnPropertyNames(a);
  const propsB = Object.getOwnPropertyNames(b);

  if (propsA.length !== propsA.length) {
    return false;
  }

  const total = propsA.length;

  for (let ii = 0; ii < total; ii += 1) {
    const prop = propsA[ii];

    if (a[prop] !== b[prop]) {
      return false;
    }

    if (!removeFrom(propsB, prop)) {
      // prop is undefined in a and missing in b
      return false;
    }
  }

  return true;
};

const getFontFamily = ff => {
  const start = ff.indexOf('family=');
  if (start === -1) return 'sans-serif';
  let end = ff.indexOf('&', start);
  if (end === -1) end = undefined;
  ff = ff.slice(start + 7, end).replace("+", " ");
  ff = '"' + ff + '"';
  return ff; // + ', sans-serif'
};

const hash = function (str) {
  let seed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  let h1 = 0xdeadbeef ^ seed,
      h2 = 0x41c6ce57 ^ seed;

  for (let i = 0, ch; i < str.length; i++) {
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }

  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
};

const trimImage = image => {
  const c = document.createElement("canvas");
  c.width = image.width;
  c.height = image.height;
  const ctx = c.getContext('2d');
  ctx.drawImage(image, 0, 0);
  const copy = document.createElement('canvas').getContext('2d');
  const pixels = ctx.getImageData(0, 0, c.width, c.height);
  const l = pixels.data.length;
  const bound = {
    top: null,
    left: null,
    right: null,
    bottom: null
  };
  let ii, x, y; // Iterate over every pixel to find the highest
  // and where it ends on every axis ()

  for (ii = 0; ii < l; ii += 4) {
    if (pixels.data[ii + 3] !== 0) {
      x = ii / 4 % c.width;
      y = ~~(ii / 4 / c.width);

      if (bound.top === null) {
        bound.top = y;
      }

      if (bound.left === null) {
        bound.left = x;
      } else if (x < bound.left) {
        bound.left = x;
      }

      if (bound.right === null) {
        bound.right = x;
      } else if (bound.right < x) {
        bound.right = x;
      }

      if (bound.bottom === null) {
        bound.bottom = y;
      } else if (bound.bottom < y) {
        bound.bottom = y;
      }
    }
  } // Calculate the height and width of the content


  const trimHeight = bound.bottom - bound.top;
  const trimWidth = bound.right - bound.left;
  const trimmed = ctx.getImageData(bound.left, bound.top, trimWidth, trimHeight); // console.log(bound)

  copy.canvas.width = trimWidth;
  copy.canvas.height = trimHeight;
  copy.putImageData(trimmed, 0, 0); // Return an image

  const trimmedImage = new Image();
  trimmedImage.src = copy.canvas.toDataURL();
  return trimmedImage;
};

const substitute = (phrase, options) => {
  if (options && typeof options === "object") {
    if (typeof phrase === "object") {
      phrase = phrase.replace;
    }

    for (key in options) {
      phrase = phrase.replace(key, options[key]);
    }
  } else if (typeof phrase === "object") {
    phrase = phrase.simple;
  } // Replace underscores with non-breaking spaces


  phrase = phrase.replace(/_/g, " ");
  return phrase;
};

const getLocalized = function (phraseData) {
  let code = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "en";
  let options = arguments.length > 2 ? arguments[2] : undefined;
  let phrase = phraseData[code];

  if (!phrase) {
    // Check if there is a more generic phrase without the region
    const stripRegex = /-\w+/;
    code = code.replace(stripRegex, ""); // "co-DE" => "co"

    phrase = phraseData[code];

    if (!phrase) {
      // Use any regional dialect of English as a fallback
      const available = Object.keys(phraseData);
      code = available.find(key => key.replace(stripRegex) === "en");

      if (code) {
        phrase = phraseData[code];
      } else {
        // Use the first available language
        phrase = phraseData[available[0]];
      }

      if (!phrase) {
        phrase = "<Missing>";
      }
    }
  }

  phrase = substitute(phrase, options);
  return phrase;
};

const localize = (cue, code, corpus, options) => {
  let phrase;
  const phraseData = corpus.find(phrase => phrase.cue === cue);

  if (phraseData) {
    phrase = getLocalized(phraseData, code, options);
  }

  if (!phrase) {
    console.log("Not found — cue:", cue, "code:", code, "phraseData:", phraseData);
    phrase = "***" + cue + "***";
  }

  return phrase;
};

const getElementIndex = (element, parentTag) => {
  let index = -1;

  if (element instanceof HTMLElement) {
    parentTag = typeof parentTag === "string" ? parentTag.toUpperCase() : "UL";

    while (element && element.parentNode.tagName !== parentTag) {
      element = element.parentNode;
    }

    if (element) {
      const siblings = [].slice.call(element.parentNode.children);
      index = siblings.indexOf(element);
    }
  }

  return index;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"minters":{"activities.js":function module(require,exports,module,__filename,__dirname){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/minters/activities.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => ActivityMinter
});

/**
 * /server/minters/activities.js
 */
const fs = require('fs');

const path = require('path');

class ActivityMinter {
  constructor(scripts) {
    /// <<< HARD-CODED
    let target = '../../imports/ui/activities/mint.js'; /// HARD-CODED >>>

    target = path.join(process.env.PWD, __dirname, target);
    const chunks = this.getChunks(scripts);
    let script = this.getScriptChunk();
    script += chunks.imports;
    script += chunks.names;
    fs.writeFileSync(target, script); // '../../public/activities/Drag/js/Drag.jsx'
  }

  getChunks(scripts) {
    let imports = "";
    let names = "";
    scripts.forEach(script => {
      const {
        name,
        file
      } = script;
      imports += "\nimport ".concat(name, " from '").concat(file, "'");
      names += "\n, ".concat(name);
    });
    names = "\n\nexport {\n ".concat(names.substring(2), "\n}");
    return {
      imports,
      names
    };
  }

  getScriptChunk() {
    return "/**\n * ** DO\xA0NOT\xA0EDIT\xA0THIS\xA0SCRIPT **\n * IT\xA0IS\xA0GENERATED\xA0AUTOMATICALLY\n *\xA0EACH\xA0TIME THE\xA0SERVER\xA0RESTARTS\n *\n * MODIFY\xA0THIS\xA0FILE\xA0INSTEAD:\n * /server/minters/activities.js\n * **** **** **** **** **** ****\n *\n * This script gathers together details of all the <ActivityName>.jsx\n * scripts found in the '/public/activities/<ActivityName>/' folders.\n * JSX\xA0scripts which do not have the same name as the folder itself\n * will be ignored. They can still be used as secondary views by other\n * activity components.\n *\n * The classes exported here are imported as 'views' by\n * '/imports/ui/App.jsx'\n */\n";
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collections.js":function module(require,exports,module,__filename,__dirname){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/minters/collections.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => CollectionMinter
});

/**
 * /server/minters/collections.js
 */
const fs = require('fs');

const path = require('path');

class CollectionMinter {
  constructor(collections) {
    /// <<< HARD-CODED
    let target = '../../imports/api/collections/mint.js'; /// HARD-CODED >>>

    target = path.join(process.env.PWD, __dirname, target);
    const scriptChunks = this.getScriptChunks();
    const importChunks = this.getImportChunks(collections);
    let script = scriptChunks[0];
    script += importChunks.creations;
    script += scriptChunks[1];
    script += importChunks.names;
    script += scriptChunks[2];
    script += importChunks.queries;
    script += scriptChunks[3];
    fs.writeFileSync(target, script);
  }

  getImportChunks(collections) {
    // let imports   = ""
    let creations = "";
    let names = "";
    let queries = "";
    collections.forEach(name => {
      // if (collection) {
      //   const { name, file } = collection
      //   const query=name[0].toLowerCase()+name.substring(1)+"Query"
      //   imports += `
      // import { ${name}
      //  , publishQuery as ${query}
      //  } from '${file}'`
      creations += "\nconst ".concat(name, " = new Mongo.Collection('").concat(name.toLowerCase(), "')");
      names += "\n, ".concat(name); //        queries += `
      // , "${name}": ${query}`
      // -      }

      queries += "\n, \"".concat(name, "\": {}");
    });
    return {
      creations,
      names,
      queries
    };
  }

  getScriptChunks() {
    return ["/**\n * ** DO\xA0NOT\xA0EDIT\xA0THIS\xA0SCRIPT **\n * IT\xA0IS\xA0GENERATED\xA0AUTOMATICALLY\n *\xA0EACH\xA0TIME THE\xA0SERVER\xA0RESTARTS\n *\n * MODIFY\xA0THIS\xA0FILE\xA0INSTEAD:\n * /server/minters/collections.js\n * **** **** ********** **** ****\n *\n * This script creates a MongoDB\xA0collection named after each of the\n * folders found at '/public/collections/'.\n *\n * The collections and publish queries exported here are\n * imported by './publisher.js', which publishes them all.\n */\n\n\n\nimport { Mongo } from 'meteor/mongo';\nimport { collections as adminCollections\n       , publishQueries as adminQueries\n       } from './admin'\n\n", "\n\n\nexport const collections = {\n  ...adminCollections", "\n}\n\n\nexport const publishQueries = {\n  ...adminQueries", "\n}"];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require,exports,module,__filename,__dirname){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/minters/methods.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => MethodMinter
});

/**
 * /server/minters/methods.js
 */
const fs = require('fs');

const path = require('path');

class MethodMinter {
  constructor(methods) {
    /// <<< HARD-CODED
    let target = '../../imports/api/methods/mint.js'; /// HARD-CODED >>>

    target = path.join(process.env.PWD, __dirname, target);
    const scriptChunks = this.getScriptChunks();
    const importChunks = this.getImportChunks(methods);
    let script = scriptChunks[0];
    script += importChunks.imports;
    script += scriptChunks[1];
    script += importChunks.names;
    script += scriptChunks[2];
    fs.writeFileSync(target, script);
  }

  getImportChunks(methods) {
    let imports = "";
    let names = "";
    methods.forEach(method => {
      let {
        name,
        file
      } = method;
      name = name.toLowerCase();
      imports += "\nimport *\xA0as ".concat(name, " from '").concat(file, "'");
      names += "\n, ...".concat(name);
    });
    return {
      imports,
      names
    };
  }

  getScriptChunks() {
    return ["/**\n * /imports/api/methods/mint.js\n *\n * ** DO\xA0NOT\xA0EDIT\xA0THIS\xA0SCRIPT **\n * IT\xA0IS\xA0GENERATED\xA0AUTOMATICALLY\n *\xA0EACH\xA0TIME THE\xA0SERVER\xA0RESTARTS\n *\n * MODIFY\xA0THIS\xA0FILE\xA0INSTEAD:\n *  /server/minters/methods.js\n * **** **** **** **** **** ****\n *\n * This script gathers together details of all the methods\n * from './admin.js' and the various methods.js files found\n * in the '/public/activities/<ActivityName>/' folders.\n *\n * The methods exported here are imported by '/server/main.js'\n * and various client-side scripts.\n */\n\nimport * as admin from './admin'\nimport * as assets from './assets'", "\n\nexport const methods = {\n  ...admin\n, ...assets", "\n}\n"];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collectJSON.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/collectJSON.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => CollectJSON
});
let collections;
module.link("../imports/api/collections/publisher", {
  default(v) {
    collections = v;
  }

}, 0);

const fs = require('fs');

const path = require('path');
/**
 * @class  CollectJSON (name)
 *
 * A CollectJSON instance expects to receive a path to afile either
 * in the /public or the /private folder. This path should lead to a
 * JSON file, with the format shown in the _treatJSON method.
 *
 * • The value of collection should be one of the capitalized
 *   collection names defined in AppName/imports/api/collection.js
 * • An as_is object with at least a version number must be included
 * • If the version indicated in the `as_is` entry is greater than the
 *   version number currently stored in the given collection, all the
 *   existing values will be removed and will be replaced by the
 *   new ones.
 */


class CollectJSON {
  constructor(jsonFile) {
    this.jsonFile = jsonFile; // console.log("CollectJSON", jsonFile)

    this._treatJSON = this._treatJSON.bind(this);
    this._checkResult = this._checkResult.bind(this); // Assets.getText(jsonFile, this._treatJSON)

    try {
      const data = fs.readFileSync(jsonFile);

      this._treatJSON(null, data);
    } catch (error) {
      console.log("Error reading", jsonFile, error);
    }
  }

  _treatJSON(error, data) {
    if (error) {
      return console.log("_treatJSON", error);
    }

    let json;

    try {
      json = JSON.parse(data);
    } catch (error) {
      return console.log("JSON.parse\n", this.jsonFile, "\n", error);
    } // console.log(json)
    // { "collection": "Collection" // target for new documents
    //
    // , "as_is": { // document will be added as is
    //     "version": <number>
    // [ , "key"|"tag": "<type of documents to be added>" ]
    //   , ...
    //   }
    //
    // , "<type>: [         // each entry will be added as a separate
    //                      // document with the type "<type>" and
    //                      // the version <as_is.version>
    //     { "<key>": "<value>"
    //     , ...
    //     }
    //   , ...
    //   ]
    // ]


    const collection = collections[json.collection];

    if (!collection) {
      console.log("Collection", json.collection);
      return console.log("missing for", this.jsonFile);
    }

    delete json.collection;

    const version = this._versionIsNewer(collection, json.as_is); // console.log("version:", version, json.collection, json.as_is)


    if (version) {
      const key = json.as_is.key; // CollectionName | Subset

      const tag = json.as_is.tag; // image type

      this._deleteOlderItems(collection, key, tag, version);

      this._insertNewItems(collection, json, version);
    }
  }

  _versionIsNewer(collection, as_is) {
    let key, tag, version; // Refuse to import documents unless:
    // * There is an as_is object...
    // * ... which contains a non-zero version

    if (!as_is || typeof as_is !== "object") {
      return false;
    } else if (!(version = as_is.version)) {
      return false;
    } // Check the existing version number for this particular key or
    // tag, as added from a previous as-is document.


    let versionSelect = {
      version: {
        $exists: true
      }
    };

    if (key = as_is.key) {
      versionSelect = {
        $and: [versionSelect, {
          key
        }]
      };
    } else if (tag = as_is.tag) {
      versionSelect = {
        $and: [versionSelect, {
          tag
        }]
      };
    }

    const document = collection.findOne(versionSelect); // console.log("**",collection._name)

    if (document) {
      if (version <= document.version) {
        return false;
      } else {
        console.log("Older version", document.version, "of", key || tag || collection._name, "is about to be removed", "and replaced with version", version);
      }
    }

    return version;
  }

  _deleteOlderItems(collection, key, tag, version) {
    let deleteSelect = {
      version: {
        $lt: version
      }
    };

    if (key) {
      deleteSelect = {
        $and: [deleteSelect, {
          key
        }]
      };
    } else if (tag) {
      deleteSelect = {
        $and: [deleteSelect, {
          $or: [{
            tag
          } // deletes as_is entry
          , {
            type: {
              $eq: tag
            }
          } // deletes all associated images
          ]
        }]
      };
    }

    const collectionName = key || collection._name;

    const callback = (e, d) => this._checkResult(e, d, collectionName);

    collection.remove(deleteSelect, callback);
  }

  _insertNewItems(collection, json, version) {
    const keys = Object.keys(json);
    let counter = 0;
    keys.forEach(key => {
      const value = json[key];

      if (Array.isArray(value)) {
        value.forEach(document => {
          document.type = key;
          document.version = version;
          collection.insert(document);
          counter += 1;
        });
      } else if (key === "as_is") {
        collection.insert(value);
        counter += 1;
      } else {
        // Use with caution. Old documents will not be cleared.
        collection.insert({
          [key]: value
        });
        counter += 1;
      }
    });
    console.log("Added", counter, "items to", collection._name);
  }

  _checkResult(error, data, key) {
    console.log("Removed", data, "items from", key, "error:", error);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"importActivities.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/importActivities.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => importActivities
});
module.link("/imports/api/methods/mint");
let Log;
module.link("/imports/api/methods/assets/log.js", {
  default(v) {
    Log = v;
  }

}, 0);
let IOHelper;
module.link("/imports/api/methods/assets/ioHelper", {
  default(v) {
    IOHelper = v;
  }

}, 1);
let ACTIVITY_FOLDER;
module.link("/imports/tools/custom/constants", {
  ACTIVITY_FOLDER(v) {
    ACTIVITY_FOLDER = v;
  }

}, 2);
let removeFrom;
module.link("/imports/tools/generic/utilities", {
  removeFrom(v) {
    removeFrom = v;
  }

}, 3);
let collections;
module.link("/imports/api/collections/publisher.js", {
  default(v) {
    collections = v;
  }

}, 4);
const {
  Activity
} = collections;

const fs = require('fs');

const path = require('path'); /// <<< HARD-CODED


const jsonName = "root.json"; /// HARD-CODED >>>

class importActivities extends IOHelper {
  constructor() {
    super();
    this.logger = new Log();
    this.log = this.logger.addEntry;
    this.treatActivityFolder = this.treatActivityFolder.bind(this);
    this.importAll();
    this.logger.save();
  }

  importAll() {
    const contents = fs.readdirSync(ACTIVITY_FOLDER); // console.log("importAll contents:", contents)
    // [ 'Cloze', 'Drag', 'Flash', 'Spiral', 'Vocabulary', 'icon.jpg' ]
    // Ensure that there is an icon that represents all activities
    // for the top-most Menu item

    const iconMap = this.getIconMap(ACTIVITY_FOLDER, contents); // getIconMap() removes icon name from contents.  All the
    // remaining names should be activity folders

    contents.forEach(this.treatActivityFolder);
  }
  /**
   * Called by importAll()
   *
   * @param    {string}   activity  name of activity folder
   */


  treatActivityFolder(activity) {
    const activityPath = path.join(ACTIVITY_FOLDER, activity);
    const stats = fs.statSync(activityPath);

    if (!stats.isDirectory()) {
      return;
    }

    var contents = fs.readdirSync(activityPath); // console.log("treatActivityFolder", activityPath, contents)
    // [ 'basic', 'home', 'icon', 'root.json' ]

    let cancelled = this.jsonIsMissing(contents, activityPath); // if (cancelled) { console.log("jsonIsMissing")}

    if (!cancelled) {
      const {
        json,
        jsonPath
      } = this.readJSONFile( // in IOHelper
      activityPath, [jsonName]);
      cancelled = !!json - 1; // 0 if json is valid, -1 if not

      if (!cancelled) {
        const toUpdate = this.get_IdOrUpdateConfirmation(jsonPath, activity);
        cancelled = !toUpdate;

        if (!cancelled) {
          // ... and has been updated since the last call
          this.updateActivityData(contents, activity, activityPath, json, jsonPath, toUpdate);
        }
      }
    }

    this.logOperation(cancelled);
  }
  /** Checks if jsonName (root.json) exists. If not logs the error.
   *
   * @param  {array}   contents      Names of files at activityPath
   *                                 [ 'icon' | 'icon.img'
   *                                 , 'root.json'
   *                                 , <subfolder>, ...
   *                                 ]
   * @param  {string}  activityPath  absolute path to folder
   *
   * @return {bqolean} -1: cancelled  - an error occurred
   *                   +1: cancelled  - no update needed
   *                    0: successful - root.json rewritten and
   *                                    MongoDB collection updated
   */


  jsonIsMissing(contents, activityPath) {
    // console.log(contents)
    // contents:  [ 'basic', 'home', 'icon', 'root.json' ]
    if (!contents.includes(jsonName)) {
      const message = "Error for ".concat(this.activity, " activity:\n        The \"").concat(jsonName, "\" file is missing for\n        ").concat(activityPath, "\n        Available items: ").concat(contents, "\n       ");
      this.log(message);
      return -1;
    }

    return 0;
  }

  get_IdOrUpdateConfirmation(jsonPath, activityName) {
    const select = {
      key: activityName
    };
    const toUpdate = this.directoryNeedsUpdating( // in IOHelper
    jsonPath, Activity, select); /// *** Currently always returns true *** ?///

    return toUpdate;
  }

  updateActivityData(contents, activity, activityPath, json, jsonPath, toUpdate) {
    const jsxRegex = new RegExp(activity + ".jsx?");
    const modal = !contents.find(file => jsxRegex.test(file)); // console.log(contents, modal)

    this.updateJSONObject(activity, activityPath, json, contents, modal); // Both 'icon' and JSON file will have been removed from contents

    if (!modal) {
      this.writeToFileAndMongoDB(json, jsonPath, toUpdate);
    }
  }

  updateJSONObject(activity, activityPath, json, contents, modal) {
    const path = "/" + activity;
    json.path = path;
    json.modal = modal; // Create a placeholder icon if none exists, and remove the
    // icon data from contents

    json.icon = this.getIconMap(activityPath, contents);
  }
  /** Writes any new data to the JSON file and updates Activity
   *  collection with the new data and the mod date of the JSON file.
   *
   * NOTE: If a MongoDB collection was created and then later
   * dropped, _id will be `true`, but json._id will contain the
   * _id from the dropped collection. The new document will thus
   * adopt the previous _id.
   *
   * If, on the other hand, the JSON file has been edited to
   * remove its previously-created _id, but a MongoDB document
   * still exists for this activity, then _id will contain the
   * current _id string, and no duplicate document will be created.
   *
   * @param   {string}   jsonPath    absolute path to JSON file
   * @param   {object}   json        { "name": { localized strings }
   *                                 , "description": ditto
   *                                 , "icon": <url>
   *                                 , "key":  <string activity name>
   *                                [, "_id":  <string _id>]
   *                                 }
   * @param   {array}    contents    [ ..., icon(.xxg), ... ]
   * @param   {multi}    _id         true or _id string
   */


  writeToFileAndMongoDB(json, jsonPath, _id) {
    if (_id === true) {
      _id = json._id; // may be undefined
    } // console.log("writeToFileAndMongoDB", JSON.stringify(json, null, "  "))


    if (!_id) {
      // Create a new document to get its _id...
      _id = Activity.insert(json);
      json._id = _id; // ... then save the updated JSON file and update the new
      // document with the file's new mod date

      const mod = this.writeJSON(jsonPath, json);
      Activity.update({
        _id
      }, {
        $set: {
          mod
        }
      });
    } else {
      // Save the _id to root.json and root.json's mod to MongoDB
      json._id = _id; // it probably already has this value

      json.mod = this.writeJSON(jsonPath, json);
      Activity.update({
        _id
      }, {
        $set: json
      }, {
        upsert: true
      });
    }
  }

  logOperation(cancelled, activityPath) {
    let message;

    if (!cancelled) {
      message = "+++++++++++++\n      Activity collection: update for ".concat(this.activity, " successful.\n      ");
    } else if (cancelled < 0) {
      // An error occured
      message = "-------------\n      ACIVITY ".concat(this.activity, " NOT\xA0UPDATED.\n      SEE\xA0ERROR\xA0MESSAGES\xA0ABOVE.\n      ");
    } else {
      // The JSON file has not been changed
      message = "=============\n      Activity ".concat(this.activity, " not\xA0updated.\n      This should be fine, but if you recently altered any asset\n      files or icons, please touch or resave the JSON file at...\n        ").concat(activityPath, "\n      ...to change its modification date.      ");
    }

    this.log(message);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"launch.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/launch.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Provision;
module.link("./provision", {
  default(v) {
    Provision = v;
  }

}, 0);
let ImportAssets;
module.link("../imports/api/methods/assets/importAssets", {
  default(v) {
    ImportAssets = v;
  }

}, 1);
let ImportActivities;
module.link("./importActivities", {
  default(v) {
    ImportActivities = v;
  }

}, 2);
// Update the UIText and Teacher collections, as needed
new Provision(); // Update the various activity collections, as needed

new ImportAssets();
new ImportActivities();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"provision.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/provision.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Provision
});
let CollectJSON;
module.link("./collectJSON", {
  default(v) {
    CollectJSON = v;
  }

}, 0);

const fs = require('fs');

const path = require('path');

class Provision {
  constructor() {
    const knownFile = "l10n.json";
    const privatePath = Assets.absoluteFilePath(knownFile).replace(knownFile, "");
    const jsonRegex = /.json$/;
    const JSONfiles = this.crawl(privatePath, jsonRegex);
    JSONfiles.forEach(jsonFile => {
      new CollectJSON(jsonFile);
    });
  }
  /**
   * Adds to `list` all documents with the extension `type` found in
   * folder or any of its subfolders
   *
   * @param      {string}  folder   The folder to search in
   * @param      {string}  regex    /.json$/ or any regex to define a
   *                                file type
   * @param      {array}   list     An (empty) array
   * @return     {Array}            The input list, now populated with
   *                                absolute paths to files of the
   *                                given type
   */


  crawl(folder, regex) {
    let list = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    const stats = fs.statSync(folder);

    if (stats.isDirectory()) {
      const contents = fs.readdirSync(folder);
      contents.forEach(item => {
        const itemPath = path.join(folder, item);

        if (regex.test(itemPath)) {
          list.push(itemPath);
        } else {
          this.crawl(itemPath, regex, list);
        }
      });
    }

    return list;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"setup.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/setup.js                                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!function (module1) {
  module1.export({
    default: () => SetUp
  });
  let MethodMinter;
  module1.link("./minters/methods", {
    default(v) {
      MethodMinter = v;
    }

  }, 0);
  let ActivityMinter;
  module1.link("./minters/activities", {
    default(v) {
      ActivityMinter = v;
    }

  }, 1);
  let CollectionMinter;
  module1.link("./minters/collections", {
    default(v) {
      CollectionMinter = v;
    }

  }, 2);
  let ICON_REGEX;
  module1.link("../imports/tools/custom/constants", {
    ICON_REGEX(v) {
      ICON_REGEX = v;
    }

  }, 3);

  const fs = require('fs');

  const path = require('path');

  class SetUp {
    constructor() {
      this.publicPath = "../../public/";
      this.browserPath = "../web.browser/app/";
      this.findActivities("Activities");
      this.getAssets("Assets");
    }

    findActivities(folder) {
      const activities = [];
      const activityPath = path.join(this.browserPath, folder);
      const activityNames = fs.readdirSync(activityPath);
      activityNames.forEach(name => {
        if (name !== "shared") {
          const directory = path.join(activityPath, name);
          const stats = fs.statSync(directory);

          if (stats.isDirectory()) {
            const activityData = this.getJSData(name, directory);

            if (activityData) {
              activities.push(activityData);
            } else {
              console.log("Ignoring module:", name);
            }
          }
        }
      });
      this.mintScripts(activities);
    }

    getJSData(name, folder) {
      let data;
      const contents = fs.readdirSync(folder);
      const keys = contents.map(file => {
        const baseName = path.basename(file, path.extname(file));

        if (baseName.toLowerCase() === name.toLowerCase()) {
          return "script";
        } else {
          return baseName;
        }
      });

      if (keys.includes("script") || keys.includes("methods")) {
        data = keys.reduce((map, key, index) => {
          let file = path.join(folder, contents[index]).replace(this.browserPath, this.publicPath);
          map[key] = {
            name,
            file
          };
          return map;
        }, {});
        return data;
      }
    }

    getAssets(folder) {
      const collections = [];
      const assetsPath = path.join(this.browserPath, folder);
      const assetNames = fs.readdirSync(assetsPath);
      assetNames.forEach(name => {
        const directory = path.join(assetsPath, name);
        const stats = fs.statSync(directory);

        if (stats.isDirectory()) {
          collections.push(name);
        }
      });
      new CollectionMinter(collections);
    }

    mintScripts(activities) {
      const scripts = [];
      const methods = [];
      activities.forEach(activity => {
        if (activity.script) {
          // Will be missing for modal activities
          scripts.push(activity.script);
        }

        if (activity.methods) {
          // May be missing for extended activities
          methods.push(activity.methods);
        }
      });
      new MethodMinter(methods);
      new ActivityMinter(scripts);
    }

  }
}.call(this, module);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.link("../imports/api/collections/points");
let SetUp;
module.link("./setup", {
  default(v) {
    SetUp = v;
  }

}, 1);
Meteor.startup(() => {
  if (Meteor.isDevelopment) {
    // Regenerate the various mint.js files that import and then
    // re-export combined collection, method and activity scripts
    // This ensures that access to MongoDB reflects any changes to
    // the activity modules
    new SetUp();
  } // Now that the MongoDB cellections and the methods to access them
  // are in sync with the activities, we can:
  // * Update the UIText and Teacher collections
  // * Update the Activity collections if necessary


  require('./launch.js');
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZG1pbi9hY2NvdW50LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2FjdGl2YXRlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2dyb3VwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2pvaW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvYWRtaW4vbGVhdmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvYWRtaW4vbG9naW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvYWRtaW4vbG9naW5UZWFjaGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2xvZ291dC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvaW1wb3J0QXNzZXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2Fzc2V0cy9pb0hlbHBlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvbG9nLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2ZsdWVuY3kvc2NoZWR1bGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL2Fzc2V0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9taW50LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9hZG1pbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvbWludC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvcG9pbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9wdWJsaXNoZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvcHVibGljL0FjdGl2aXRpZXMvRHJhZy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3B1YmxpYy9BY3Rpdml0aWVzL0ZsYXNoL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvcHVibGljL0FjdGl2aXRpZXMvU3BpcmFsL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvcHVibGljL0FjdGl2aXRpZXMvVm9jYWJ1bGFyeS9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3Rvb2xzL2N1c3RvbS9jb25zdGFudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdG9vbHMvY3VzdG9tL3Byb2plY3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdG9vbHMvZ2VuZXJpYy91dGlsaXRpZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9taW50ZXJzL2FjdGl2aXRpZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9taW50ZXJzL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWludGVycy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdEpTT04uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9pbXBvcnRBY3Rpdml0aWVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbGF1bmNoLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHJvdmlzaW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvc2V0dXAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsImRlZmF1bHQiLCJDcmVhdGVBY2NvdW50IiwiaHNsMmhleCIsImxpbmsiLCJ2IiwiZ2V0R29sZGVuQW5nbGVBdCIsImdldENvZGVGcm9tIiwiY29sbGVjdGlvbnMiLCJVc2VyIiwiVGVhY2hlciIsIkdyb3VwIiwiY29uc3RydWN0b3IiLCJhY2NvdW50RGF0YSIsInNhdHVyYXRpb24iLCJsdW1pbm9zaXR5IiwiY3JlYXRlVW5pcXVlUUNvZGUiLCJjcmVhdGVVc2VyIiwiYWNjb3VudENyZWF0ZWQiLCJzdGF0dXMiLCJub3ROZWVkZWQiLCJmb3JFYWNoIiwia2V5IiwibmV3ZXN0IiwiZmluZE9uZSIsImZpZWxkcyIsInFfaW5kZXgiLCJzb3J0IiwiaHVlIiwicV9jb2RlIiwicV9jb2xvciIsInVzZXJuYW1lIiwibmF0aXZlIiwiZF9jb2RlIiwiaGlzdG9yeSIsImxvZ2dlZF9pbiIsInVzZXJfaWQiLCJpbnNlcnQiLCJUb2dnbGVBY3RpdmF0aW9uIiwiZ3JvdXBEYXRhIiwiX2lkIiwiYWN0aXZlIiwiYWN0aW9uIiwic2VsZWN0IiwidXBkYXRlIiwiJHNldCIsInJlc3VsdCIsInRlYWNoZXJfbG9nZ2VkX2luIiwiQ3JlYXRlR3JvdXAiLCJncm91cCIsIm93bmVyIiwidGVhY2hlciIsImxhbmd1YWdlIiwibG9iYnkiLCJjaGF0X3Jvb20iLCJtZW1iZXJzIiwiZ3JvdXBfaWQiLCJncm91cENyZWF0ZWQiLCJKb2luR3JvdXAiLCJyZW1vdmVGcm9tIiwiZ2V0TmV4dEluZGV4IiwiZ3JvdXBXaXRoVGhpc1RlYWNoZXIiLCJzdWNjZXNzIiwiam9pbkdyb3VwIiwiZF9jb2RlcyIsImdldExvZ2dlZEluQ29kZXMiLCJwYWdlIiwiZ2V0UGFnZSIsImFkZFVzZXJIaXN0b3J5SXRlbSIsIm1vdmVUZWFjaGVyRENvZGVUb0VuZCIsIiRhbGwiLCIkc2l6ZSIsInB1c2giLCIkcHVzaCIsInZpZXciLCJyZWFkRnJvbUdyb3VwIiwibGVuZ3RoIiwicmVzdG9yZV9hbGwiLCJvcHRpb25zIiwiaW5kZXgiLCJpdGVtIiwiaW4iLCJwYXRoIiwiJGVhY2giLCIkcG9zaXRpb24iLCJjcmVhdGVkIiwiJGN1cnJlbnREYXRlIiwibWFwIiwidXNlclNlbGVjdCIsIiRvciIsInVzZXJzIiwiZmluZCIsImZldGNoIiwidXNlckRhdGEiLCJ1c2VyX2NvZGVzIiwicmVtb3ZlRnVuY3Rpb24iLCJpbmNsdWRlcyIsImdyb3VwU2VsZWN0IiwidGVhY2hlcl9jb2RlIiwicHVsbCIsIiRwdWxsIiwiTGVhdmVHcm91cCIsImRlc3Ryb3lUcmFja2VyIiwiYXJyYXlPdmVybGFwIiwiZGV2aWNlRGF0YSIsImlkIiwiZGlzbWlzc2VkIiwiZ2V0R3JvdXBfaWQiLCJyZW1vdmVEZXZpY2VGcm9tR3JvdXAiLCJ0ZWFjaGVyVmlld3MiLCJnZXRUZWFjaGVyVmlld0NvdW50IiwiZGVhY3RpdmF0ZUdyb3VwIiwidXNlcklzTGVhdmluZyIsIl9pZHMiLCJkb2MiLCJmYWtlIiwidF9jb2RlcyIsInNldCIsInVwZGF0ZVVzZXJIaXN0b3J5IiwiY2xvc2VHcm91cElmRG9uZSIsInBhdGhPdXQiLCIkZXhpc3RzIiwiZ2V0R3JvdXBNZW1iZXJTdGF0dXMiLCJvd25lckRfY29kZXMiLCJnZXRPd25lckRfY29kZXMiLCJkX2NvZGVDb3VudCIsInByb21vdGVTbGF2ZSIsInNsYXZlIiwiZXZlcnkiLCJMb2dJbiIsIm5hbWVFeGlzdHMiLCJ1c2VyV2l0aFRoaXNOYW1lRXhpc3RzIiwiZXhpc3RpbmdVc2VyIiwibG9nSW5Vc2VyRnJvbU5hbWVBbmRRQ29kZSIsImxvZ2dlZEluIiwiT2JqZWN0IiwiYXNzaWduIiwiTG9nSW5UZWFjaGVyIiwibGVmdCIsImxlYXZlQWxsR3JvdXBzIiwic2V0TG9nZ2VkSW4iLCJhZGRUb1NldCIsIiRhZGRUb1NldCIsIkxvZ091dCIsImxvZ091dERhdGEiLCJjb2xsZWN0aW9uIiwiaXNUZWFjaGVyIiwiSW1wb3J0QXNzZXRzIiwiTG9nIiwiSU9IZWxwZXIiLCJQVUJMSUNfRElSRUNUT1JZIiwiQVNTRVRTX0ZPTERFUiIsIklNQUdFX1JFR0VYIiwiSlNPTl9SRUdFWCIsImZzIiwicmVxdWlyZSIsImxvZ2dlciIsImxvZyIsImFkZEVudHJ5IiwiemlwRmlsZSIsInBhcmVudEZvbGRlciIsImFjdGl2aXR5IiwiZ2V0QWN0aXZpdHlOYW1lRnJvbSIsImluc3RhbGxBc3NldHMiLCJpbXBvcnRTdWJmb2xkZXJzT2YiLCJzYXZlIiwiZ2V0QWN0aXZpdHlOYW1lRnJvbVBhcmVudEZvbGRlclBhdGgiLCJyZWdleCIsIm1hdGNoIiwiZXhlYyIsImFjdGl2aXR5TmFtZSIsInN1YkZvbGRlcnMiLCJyZWFkZGlyU3luYyIsInRyZWF0Rm9sZGVyIiwiZm9sZGVyIiwiZXhwbG9yZVN1YkZvbGRlcnMiLCJjb250ZW50cyIsInN1YkZvbGRlciIsImpvaW4iLCJoYXNKU09OIiwidGVzdCIsIm1lc3NhZ2UiLCJjb25zb2xlIiwianNvblBhdGgiLCJqc29uIiwicmVhZEpTT05GaWxlIiwibG9jYWxQYXRoIiwiZ2V0TG9jYWxQYXRoIiwidG9VcGRhdGUiLCJkaXJlY3RvcnlOZWVkc1VwZGF0aW5nIiwiaWNvbiIsImdldEljb25NYXAiLCJhZGRQaHJhc2VTZXQiLCJjcmF3bFN1YkZvbGRlcnMiLCJhc3NldHMiLCJhdWRpbyIsImltYWdlIiwiY3Jhd2xBdWRpb0ZvbGRlciIsImNyYXdsSW1hZ2VGb2xkZXIiLCJjYW5jZWxsZWQiLCJ0cmVhdEpTT04iLCJyZXBsYWNlIiwiYXVkaW9NYXAiLCJjcmF3bEF1ZGlvU3ViRm9sZGVyIiwiYXVkaW9Gb2xkZXIiLCJsYW5nIiwiZm9sZGVyUGF0aCIsImZpbGUiLCJleHRlbnNpb24iLCJleHRuYW1lIiwidG9Mb3dlckNhc2UiLCJzcmMiLCJzdGF0cyIsInN0YXRTeW5jIiwic2l6ZSIsImZpbGVOYW1lIiwiYmFzZW5hbWUiLCJpc05hTiIsInBhcnNlRmxvYXQiLCJwaHJhc2VBdWRpbyIsImxvY2FsaXplZCIsImltYWdlTWFwIiwicGhyYXNlSW1hZ2VzIiwidGFnIiwiaWdub3JlX21pc3NpbmdfZmlsZXMiLCJhZGRQaHJhc2VzIiwicGhyYXNlcyIsIkFycmF5IiwiaXNBcnJheSIsImZpbHRlciIsImdldFNldCIsImFkZEFzc2V0c1RvUGhyYXNlcyIsInRyZWF0UGhyYXNlcyIsIm1vZCIsIndyaXRlSlNPTiIsInBhcmVudCIsInNwbGl0IiwicG9wIiwidXBzZXJ0IiwidGFnQXJyYXkiLCJwaHJhc2VEYXRhIiwibmFtZSIsInBocmFzZSIsImhhc1BocmFzZXMiLCJsYW5ndWFnZXMiLCJrZXlzIiwiZmlsZXMiLCJtaXNzaW5nTGFuZ3VhZ2VzIiwiZ2V0TWlzc2luZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0YWdzIiwiYXJyYXkiLCJpbmRleE9mIiwiYXZhaWxhYmxlIiwibWlzc2luZyIsImpzb25GaWxlcyIsImdldENvbG9yIiwiRU5fUkVHRVgiLCJJQ09OX1JFR0VYIiwibnVtYmVyIiwibXRpbWVNcyIsInJlYWRGaWxlU3luYyIsInBhcnNlIiwiTWV0ZW9yIiwiaXNEZXZlbG9wbWVudCIsInJlcGxhY2VyIiwidmFsdWUiLCJ1bmRlZmluZWQiLCJqc29uU3RyaW5nIiwid3JpdGVGaWxlU3luYyIsImljb25NYXAiLCJpY29ucyIsImljb25QYXRoIiwiX2NyZWF0ZVBsYWNlaG9sZGVySWNvbiIsImVuSWNvbiIsImljb25OYW1lIiwiY29sb3VyIiwiZm9ybWF0Iiwic3ZnIiwibG9nU2hlZXQiLCJiaW5kIiwiU2NoZWR1bGVyIiwiZ2V0UmFuZG9tIiwiRmx1ZW5jeSIsIk1JTl9TUEFDSU5HIiwiRk9VUl9EQVlTIiwiTUlOVVRFU19UT19NUyIsImNvcnJlY3QiLCJ0aW1lU3RhbXAiLCJzZXROZXh0U2VlbiIsImlkcyIsImNvdW50IiwiZ2V0VGltZSIsInN0YW1wIiwiRGF0ZSIsInRvVGltZVN0cmluZyIsInN1YnN0cmluZyIsInBocmFzZV9pZCIsImZsdWVuY3lEb2MiLCJsYXN0X3NlZW4iLCJuZXh0X3NlZW4iLCJmbG9wcyIsInRpbWVzX3NlZW4iLCJmaXJzdF9zZWVuIiwic3BhY2luZyIsInJhdGlvIiwicmlnaHQiLCJ3cm9uZyIsIk1hdGgiLCJtYXgiLCJyZXNjaGVkdWxlIiwibm93Iiwic3RhcnRUaW1lIiwibGltaXQiLCJza2lwIiwic3BhY2VUaW1lIiwiZmlyc3QiLCJmaXJzdFRpbWUiLCJsYXN0IiwibGFzdFRpbWUiLCJtaW4iLCJfb2JqZWN0U3ByZWFkIiwiY3JlYXRlQWNjb3VudCIsImNyZWF0ZUdyb3VwIiwibG9nSW4iLCJsb2dJblRlYWNoZXIiLCJ0b2dnbGVBY3RpdmF0aW9uIiwibG9nT3V0Iiwic2hhcmUiLCJzZXRQYWdlIiwic2V0SW5kZXgiLCJhZGRUb0ZsdWVuY3kiLCJzZXRGbHVlbmN5IiwiU2ltcGxlU2NoZW1hIiwiVm9jYWJ1bGFyeSIsImNhbGwiLCJjYWxsYmFjayIsInJldHVyblN0dWJWYWx1ZSIsInRocm93U3R1YkV4Y2VwdGlvbnMiLCJhcHBseSIsInZhbGlkYXRlIiwidHlwZSIsIlN0cmluZyIsIm9wdGlvbmFsIiwicnVuIiwibG9nSW5EYXRhIiwiQm9vbGVhbiIsInBpbl9naXZlbiIsIk51bWJlciIsInNoYXJlRGF0YSIsImRhdGEiLCJvbmVPZiIsImJsYWNrYm94Iiwic2V0UGFnZURhdGEiLCJ0YWdTY2hlbWEiLCJzZXRJbmRleERhdGEiLCJmbHVlbmN5SXRlbUFycmF5IiwiZmlsbGVycyIsInNjb3JlIiwibGV2ZWwiLCJmbHVlbmN5T2JqZWN0Iiwic2V0Rmx1ZW5jeURhdGEiLCJtZXRob2RzIiwibWV0aG9kIiwiYXJncyIsImltcG9ydEZvbGRlciIsImltcG9ydERhdGEiLCJhZG1pbiIsImRyYWciLCJmbGFzaCIsInNwaXJhbCIsInZvY2FidWxhcnkiLCJwdWJsaXNoUXVlcmllcyIsIk1vbmdvIiwiQ2hhdCIsIkNvbGxlY3Rpb24iLCJVSVRleHQiLCJDb3VudGVycyIsIkFjdGl2aXR5IiwiJG5lIiwiYWRtaW5Db2xsZWN0aW9ucyIsImFkbWluUXVlcmllcyIsIkNsb3plIiwiTmltIiwiU3BpcmFsIiwiU3RvcmllcyIsImNyZWF0ZVRyYWNrZXIiLCJjbGVhclBvaW50cyIsIlBvaW50cyIsInRyYWNrZXJEYXRhIiwiY29sb3IiLCJwb2ludERhdGEiLCJ4IiwieSIsInRvdWNoZW5kIiwidG91Y2giLCJyYWRpdXNYIiwicmFkaXVzWSIsInJvdGF0aW9uQW5nbGUiLCJyZW1vdmUiLCJpc1NlcnZlciIsImNvbm5lY3Rpb24iLCJwdWJsaXNoIiwic3Vic2NyaXB0aW9uIiwicHVibGljYXRpb24iLCJvYnNlcnZlQ2hhbmdlcyIsImFkZGVkIiwiY2hhbmdlZCIsInJlbW92ZWQiLCJyZWFkeSIsIm9uU3RvcCIsInN0b3AiLCJpc0NsaWVudCIsInN1YnNjcmliZSIsIndpbmRvdyIsImV4cG9ydERlZmF1bHQiLCJfbmFtZSIsInB1YmxpYyIsImNhbGxlciIsIml0ZW1zIiwibW9yZSIsImluYyIsImlzTWV0ZW9yIiwiJGluYyIsInNldFZpZXdEYXRhIiwidG9nZ2xlQ29tcGxldGUiLCJ0b2dnbGVTaG93Iiwic2V0RHJhZ1RhcmdldCIsInVwZGF0ZURyYWdUYXJnZXQiLCJkcm9wRHJhZ1RhcmdldCIsInRvZ2dsZUNvbXBsZXRlRGF0YSIsImNvbXBsZXRlIiwidG9nZ2xlU2hvd0RhdGEiLCJkcmFnVGFyZ2V0RGF0YSIsImRyYWdfaWQiLCJwaWxvdCIsIiR1bnNldCIsImRyb3BUYXJnZXREYXRhIiwidW5zZXQiLCJwbGFjZWhvbGRlciIsIkdyb3VwcyIsInBsYWNlaG9sZGVyRGF0YSIsInNldFN0YXJ0Iiwic2V0U3RhcnREYXRhIiwic3RhcnQiLCJBQ1RJVklUWV9GT0xERVIiLCJTRVRfUkVHRVgiLCJQV0QiLCJwcm9jZXNzIiwiZW52IiwiZm9ybWF0cyIsImxvb2tBaGVhZCIsIlJlZ0V4cCIsImdldEljb25TcmMiLCJnZXRSYW5kb21Gcm9tQXJyYXkiLCJHT0xERU5fQU5HTEUiLCJzcXJ0IiwiUkFUSU8iLCJhbmdsZSIsImZsb29yIiwiY29kZSIsInJvdW5kIiwiaWNvbkRhdGEiLCJsYW5ndWFnZU1hdGNoIiwicmdiaWZ5IiwidHdlZW5Db2xvciIsInRvbmVDb2xvciIsInRyYW5zbHVjaWZ5IiwiaHNsMnJnYiIsIkhTTHRvUkdCIiwiYnV0dG9uQ29sb3JzIiwiZ2V0RGlmZmVyZW5jZXMiLCJ0cmFja0NoYW5nZXMiLCJzaHVmZmxlIiwiZ2V0VW51c2VkIiwiZ2V0UGFnZVhZIiwiZ2V0WFkiLCJkZXRlY3RNb3ZlbWVudCIsInNldFRyYWNrZWRFdmVudHMiLCJpbnRlcnNlY3QiLCJpbnRlcnNlY3Rpb24iLCJ1bmlvbiIsInBvaW50V2l0aGluIiwib3ZlcmxhcCIsInZhbHVlc01hdGNoIiwiZ2V0Rm9udEZhbWlseSIsImhhc2giLCJ0cmltSW1hZ2UiLCJzdWJzdGl0dXRlIiwiZ2V0TG9jYWxpemVkIiwibG9jYWxpemUiLCJnZXRFbGVtZW50SW5kZXgiLCJzbGljZSIsImhleCIsInBhcnNlSW50IiwiY29sb3IxIiwiY29sb3IyIiwicmdiMSIsInJnYjIiLCJ0b1N0cmluZyIsInByZWZpeCIsInJnYiIsIm9wYWNpdHkiLCJzIiwibCIsImgiLCJhIiwiZiIsIm4iLCJrIiwiciIsImciLCJiIiwiaHVlMnJnYiIsInAiLCJxIiwidCIsInRvSGV4IiwiY29sb3JTdHJpbmciLCJ2YWx1ZXMiLCJvdXRwdXQiLCJyZXN0QmciLCJyZXN0VGludCIsInJlc3RTaGFkZSIsIm92ZXJCZyIsIm92ZXJUaW50Iiwib3ZlclNoYWRlIiwiZG93bkJnIiwiZG93blRpbnQiLCJkb3duU2hhZGUiLCJtZXJnZSIsImlucHV0IiwicmVtb3ZlQWxsIiwiZm91bmQiLCJmaW5kSW5kZXgiLCJzcGxpY2UiLCJwcmV2aW91cyIsInBsdXMiLCJtaW51cyIsImN1cnJlbnQiLCJpaSIsImpqIiwicmFuZG9tIiwiYXJyYXkxIiwiYXJyYXkyIiwic291cmNlIiwidXNlZCIsInRvbGVyYXRlRHVwbGljYXRlcyIsInVudXNlZCIsImV2ZW50IiwidGFyZ2V0VG91Y2hlcyIsInBhZ2VYIiwicGFnZVkiLCJmcmFtZSIsInRyaWdnZXJEZWx0YSIsInRyaWdnZXIyIiwibW92ZW1lbnREZXRlY3RlZCIsInJlc29sdmUiLCJyZWplY3QiLCJzdGFydFgiLCJzdGFydFkiLCJkcm9wIiwiY2FuY2VsIiwiZGVsdGFYIiwiZGVsdGFZIiwiZGVsdGEyIiwiUHJvbWlzZSIsImFjdGlvbnMiLCJib2R5IiwiZG9jdW1lbnQiLCJtb3ZlIiwiZW5kIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJyZWN0MSIsInJlY3QyIiwiYm90dG9tIiwid2lkdGgiLCJ0b3AiLCJoZWlnaHQiLCJyZWN0cyIsInJlY3QiLCJyZXN0IiwiY29udGFpbmVyIiwicHJvcHNBIiwiZ2V0T3duUHJvcGVydHlOYW1lcyIsInByb3BzQiIsInRvdGFsIiwicHJvcCIsImZmIiwic3RyIiwic2VlZCIsImgxIiwiaDIiLCJpIiwiY2giLCJjaGFyQ29kZUF0IiwiaW11bCIsImMiLCJjcmVhdGVFbGVtZW50IiwiY3R4IiwiZ2V0Q29udGV4dCIsImRyYXdJbWFnZSIsImNvcHkiLCJwaXhlbHMiLCJnZXRJbWFnZURhdGEiLCJib3VuZCIsInRyaW1IZWlnaHQiLCJ0cmltV2lkdGgiLCJ0cmltbWVkIiwiY2FudmFzIiwicHV0SW1hZ2VEYXRhIiwidHJpbW1lZEltYWdlIiwiSW1hZ2UiLCJ0b0RhdGFVUkwiLCJzaW1wbGUiLCJzdHJpcFJlZ2V4IiwiY3VlIiwiY29ycHVzIiwiZWxlbWVudCIsInBhcmVudFRhZyIsIkhUTUxFbGVtZW50IiwidG9VcHBlckNhc2UiLCJwYXJlbnROb2RlIiwidGFnTmFtZSIsInNpYmxpbmdzIiwiY2hpbGRyZW4iLCJBY3Rpdml0eU1pbnRlciIsInNjcmlwdHMiLCJ0YXJnZXQiLCJfX2Rpcm5hbWUiLCJjaHVua3MiLCJnZXRDaHVua3MiLCJzY3JpcHQiLCJnZXRTY3JpcHRDaHVuayIsImltcG9ydHMiLCJuYW1lcyIsIkNvbGxlY3Rpb25NaW50ZXIiLCJzY3JpcHRDaHVua3MiLCJnZXRTY3JpcHRDaHVua3MiLCJpbXBvcnRDaHVua3MiLCJnZXRJbXBvcnRDaHVua3MiLCJjcmVhdGlvbnMiLCJxdWVyaWVzIiwiTWV0aG9kTWludGVyIiwiQ29sbGVjdEpTT04iLCJqc29uRmlsZSIsIl90cmVhdEpTT04iLCJfY2hlY2tSZXN1bHQiLCJlcnJvciIsInZlcnNpb24iLCJfdmVyc2lvbklzTmV3ZXIiLCJhc19pcyIsIl9kZWxldGVPbGRlckl0ZW1zIiwiX2luc2VydE5ld0l0ZW1zIiwidmVyc2lvblNlbGVjdCIsIiRhbmQiLCJkZWxldGVTZWxlY3QiLCIkbHQiLCIkZXEiLCJjb2xsZWN0aW9uTmFtZSIsImUiLCJkIiwiY291bnRlciIsImltcG9ydEFjdGl2aXRpZXMiLCJqc29uTmFtZSIsInRyZWF0QWN0aXZpdHlGb2xkZXIiLCJpbXBvcnRBbGwiLCJhY3Rpdml0eVBhdGgiLCJpc0RpcmVjdG9yeSIsImpzb25Jc01pc3NpbmciLCJnZXRfSWRPclVwZGF0ZUNvbmZpcm1hdGlvbiIsInVwZGF0ZUFjdGl2aXR5RGF0YSIsImxvZ09wZXJhdGlvbiIsImpzeFJlZ2V4IiwibW9kYWwiLCJ1cGRhdGVKU09OT2JqZWN0Iiwid3JpdGVUb0ZpbGVBbmRNb25nb0RCIiwiUHJvdmlzaW9uIiwiSW1wb3J0QWN0aXZpdGllcyIsImtub3duRmlsZSIsInByaXZhdGVQYXRoIiwiQXNzZXRzIiwiYWJzb2x1dGVGaWxlUGF0aCIsImpzb25SZWdleCIsIkpTT05maWxlcyIsImNyYXdsIiwibGlzdCIsIml0ZW1QYXRoIiwibW9kdWxlMSIsIlNldFVwIiwicHVibGljUGF0aCIsImJyb3dzZXJQYXRoIiwiZmluZEFjdGl2aXRpZXMiLCJnZXRBc3NldHMiLCJhY3Rpdml0aWVzIiwiYWN0aXZpdHlOYW1lcyIsImRpcmVjdG9yeSIsImFjdGl2aXR5RGF0YSIsImdldEpTRGF0YSIsIm1pbnRTY3JpcHRzIiwiYmFzZU5hbWUiLCJyZWR1Y2UiLCJhc3NldHNQYXRoIiwiYXNzZXROYW1lcyIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJQztBQUFiLENBQWQ7QUFBMkMsSUFBSUMsT0FBSjtBQUFZSixNQUFNLENBQUNLLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDRCxTQUFPLENBQUNFLENBQUQsRUFBRztBQUFDRixXQUFPLEdBQUNFLENBQVI7QUFBVTs7QUFBdEIsQ0FBL0MsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSUMsZ0JBQUosRUFBcUJDLFdBQXJCO0FBQWlDUixNQUFNLENBQUNLLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDRSxrQkFBZ0IsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLG9CQUFnQixHQUFDRCxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNFLGFBQVcsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGVBQVcsR0FBQ0YsQ0FBWjtBQUFjOztBQUF0RSxDQUE1QyxFQUFvSCxDQUFwSDtBQUF1SCxJQUFJRyxXQUFKO0FBQWdCVCxNQUFNLENBQUNLLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBMUMsRUFBc0UsQ0FBdEU7QUFXelMsTUFBTTtBQUFFSSxNQUFGO0FBQVFDLFNBQVI7QUFBaUJDO0FBQWpCLElBQTJCSCxXQUFqQzs7QUFJZSxNQUFNTixhQUFOLENBQW9CO0FBQ2pDVSxhQUFXLENBQUNDLFdBQUQsRUFBYztBQUN2QixTQUFLQSxXQUFMLEdBQW1CQSxXQUFuQixDQUR1QixDQUV2QjtBQUVBOztBQUNBLFNBQUtDLFVBQUwsR0FBa0IsRUFBbEI7QUFDQSxTQUFLQyxVQUFMLEdBQWtCLEVBQWxCLENBTnVCLENBT3ZCO0FBQ0E7O0FBRUEsU0FBS0MsaUJBQUw7QUFDQSxTQUFLQyxVQUFMO0FBRUFKLGVBQVcsQ0FBQ0ssY0FBWixHQUE2QixJQUE3QjtBQUNBTCxlQUFXLENBQUNNLE1BQVosR0FBcUIsYUFBckIsQ0FkdUIsQ0FnQnZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQU1DLFNBQVMsR0FBRyxDQUNoQixVQURnQixFQUVoQixRQUZnQixFQUdoQixTQUhnQixFQUloQixTQUpnQixFQUtoQixXQUxnQixDQUFsQjtBQVFBQSxhQUFTLENBQUNDLE9BQVYsQ0FBa0JDLEdBQUcsSUFBSTtBQUFDLGFBQU9ULFdBQVcsQ0FBQ1MsR0FBRCxDQUFsQjtBQUF3QixLQUFsRDtBQUNEOztBQUdETixtQkFBaUIsR0FBRztBQUNsQjtBQUVBLFFBQUlPLE1BQU0sR0FBSWQsSUFBSSxDQUFDZSxPQUFMLENBQ1osRUFEWSxFQUVaO0FBQUVDLFlBQU0sRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUFWO0FBQ0VDLFVBQUksRUFBRTtBQUFFRCxlQUFPLEVBQUUsQ0FBQztBQUFaO0FBRFIsS0FGWSxDQUFkO0FBT0EsUUFBSUEsT0FBTyxHQUFHSCxNQUFNLEdBQ05BLE1BQU0sQ0FBQ0csT0FBUCxHQUFpQixDQURYLEdBRU4sQ0FGZDtBQUdBLFFBQUlFLEdBQUosRUFDSUMsTUFESixFQUVJQyxPQUZKOztBQUlBLFFBQUlKLE9BQU8sR0FBRyxJQUFkLEVBQW9CO0FBQ2xCO0FBQ0FFLFNBQUcsR0FBR3RCLGdCQUFnQixDQUFDb0IsT0FBRCxDQUF0QjtBQUNBRyxZQUFNLEdBQUd0QixXQUFXLENBQUNxQixHQUFELENBQXBCO0FBRUQsS0FMRCxNQUtPLElBQUlGLE9BQU8sR0FBRyxJQUFkLEVBQW9CLENBQ3pCO0FBRUQsS0FITSxNQUdBLElBQUlBLE9BQU8sR0FBRyxLQUFkLEVBQXFCLENBQzFCO0FBRUQsS0FITSxNQUdBLENBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUVESSxXQUFPLEdBQUczQixPQUFPLENBQUN5QixHQUFELEVBQU0sS0FBS2QsVUFBWCxFQUF1QixLQUFLQyxVQUE1QixDQUFqQjtBQUVBLFNBQUtGLFdBQUwsQ0FBaUJhLE9BQWpCLEdBQTJCQSxPQUEzQjtBQUNBLFNBQUtiLFdBQUwsQ0FBaUJnQixNQUFqQixHQUEyQkEsTUFBM0I7QUFDQSxTQUFLaEIsV0FBTCxDQUFpQmlCLE9BQWpCLEdBQTJCQSxPQUEzQjtBQUNEOztBQUdEYixZQUFVLEdBQUc7QUFDWCxVQUFNO0FBQ0pjLGNBREk7QUFFSkMsWUFGSTtBQUdKTixhQUhJO0FBSUpHLFlBSkk7QUFLSkMsYUFMSTtBQU1KRztBQU5JLFFBT0YsS0FBS3BCLFdBUFQ7QUFTQSxVQUFNWSxNQUFNLEdBQUc7QUFDYk0sY0FEYTtBQUViQyxZQUZhO0FBR2JOLGFBSGE7QUFJYkcsWUFKYTtBQUtiQztBQUxhLEtBQWY7QUFPQUwsVUFBTSxDQUFDUyxPQUFQLEdBQWlCLEVBQWpCO0FBQ0FULFVBQU0sQ0FBQ1UsU0FBUCxHQUFtQixFQUFuQixDQWxCVyxDQW9CWDs7QUFFQSxTQUFLdEIsV0FBTCxDQUFpQnVCLE9BQWpCLEdBQTRCM0IsSUFBSSxDQUFDNEIsTUFBTCxDQUFZWixNQUFaLENBQTVCO0FBQ0Q7O0FBN0hnQyxDOzs7Ozs7Ozs7OztBQ2ZuQzFCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJcUM7QUFBYixDQUFkO0FBQThDLElBQUk5QixXQUFKO0FBQWdCVCxNQUFNLENBQUNLLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBMUMsRUFBc0UsQ0FBdEU7QUFNOUQsTUFBTTtBQUFFTTtBQUFGLElBQVlILFdBQWxCOztBQUllLE1BQU04QixnQkFBTixDQUF1QjtBQUNwQzFCLGFBQVcsQ0FBQzJCLFNBQUQsRUFBWTtBQUNyQjtBQUVBLFVBQU07QUFBRUMsU0FBRjtBQUFPUCxZQUFQO0FBQWVRO0FBQWYsUUFBMEJGLFNBQWhDO0FBQ0EsVUFBTUcsTUFBTSxHQUFHRCxNQUFNLEdBQ04sT0FETSxHQUVOLE9BRmY7QUFJQSxVQUFNRSxNQUFNLEdBQUc7QUFBRUg7QUFBRixLQUFmO0FBQ0EsVUFBTUksTUFBTSxHQUFHO0FBQ2JDLFVBQUksRUFBRTtBQUNKSjtBQURJLE9BRE87QUFJYixPQUFDQyxNQUFELEdBQVU7QUFDUlAsaUJBQVMsRUFBRUY7QUFESDtBQUpHLEtBQWY7QUFRQSxVQUFNYSxNQUFNLEdBQUduQyxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUJDLE1BQXJCLENBQWYsQ0FqQnFCLENBa0JyQjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFFBQUlFLE1BQUosRUFBWTtBQUNWUCxlQUFTLENBQUNRLGlCQUFWLEdBQThCLElBQTlCO0FBQ0Q7QUFDRjs7QUFoQ21DLEM7Ozs7Ozs7Ozs7O0FDVnRDaEQsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUkrQztBQUFiLENBQWQ7QUFBeUMsSUFBSXhDLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUExQyxFQUFzRSxDQUF0RTtBQU16RCxNQUFNO0FBQUVNO0FBQUYsSUFBWUgsV0FBbEI7O0FBSWUsTUFBTXdDLFdBQU4sQ0FBa0I7QUFDL0JwQyxhQUFXLENBQUNDLFdBQUQsRUFBYztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxVQUFNb0MsS0FBSyxHQUFHO0FBQ1pDLFdBQUssRUFBT3JDLFdBQVcsQ0FBQ3NDLE9BRFo7QUFFWkMsY0FBUSxFQUFJdkMsV0FBVyxDQUFDdUMsUUFGWjtBQUdaWCxZQUFNLEVBQU0sS0FIQSxDQUdNO0FBSE47QUFJWlksV0FBSyxFQUFPLEVBSkE7QUFLWkMsZUFBUyxFQUFHLEVBTEE7QUFNWkMsYUFBTyxFQUFFLENBQ1AxQyxXQUFXLENBQUN1QixPQURMLEVBRVB2QixXQUFXLENBQUNzQyxPQUZMLENBTkc7QUFVWmhCLGVBQVMsRUFBRSxFQVZDLENBV2Q7QUFDQTtBQUNBOztBQWJjLEtBQWQ7QUFlQXRCLGVBQVcsQ0FBQzJDLFFBQVosR0FBdUI3QyxLQUFLLENBQUMwQixNQUFOLENBQWFZLEtBQWIsQ0FBdkI7QUFDQXBDLGVBQVcsQ0FBQzRDLFlBQVosR0FBMkIsSUFBM0IsQ0F6QnVCLENBMkJ2QjtBQUNEOztBQTdCOEIsQzs7Ozs7Ozs7Ozs7QUNWakMxRCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSXlEO0FBQWIsQ0FBZDtBQUF1QyxJQUFJQyxVQUFKO0FBQWU1RCxNQUFNLENBQUNLLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDdUQsWUFBVSxDQUFDdEQsQ0FBRCxFQUFHO0FBQUNzRCxjQUFVLEdBQUN0RCxDQUFYO0FBQWE7O0FBQTVCLENBQS9DLEVBQTZFLENBQTdFO0FBQWdGLElBQUlHLFdBQUosRUFBZ0JvRCxZQUFoQjtBQUE2QjdELE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjLEdBQTFCOztBQUEyQnVELGNBQVksQ0FBQ3ZELENBQUQsRUFBRztBQUFDdUQsZ0JBQVksR0FBQ3ZELENBQWI7QUFBZTs7QUFBMUQsQ0FBMUMsRUFBc0csQ0FBdEc7QUFRbkssTUFBTTtBQUFFSSxNQUFGO0FBQVFFO0FBQVIsSUFBa0JILFdBQXhCOztBQUllLE1BQU1rRCxTQUFOLENBQWdCO0FBQzdCOUMsYUFBVyxDQUFDQyxXQUFELEVBQWM7QUFDdkI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxRQUFJO0FBQUN1QixhQUFEO0FBQVVILFlBQVY7QUFBa0JrQixhQUFsQjtBQUEyQkMsY0FBM0I7QUFBcUNJO0FBQXJDLFFBQWtEM0MsV0FBdEQ7O0FBQ0EsUUFBSXNDLE9BQU8sSUFBSUMsUUFBZixFQUF5QjtBQUN2QkksY0FBUSxHQUFHLEtBQUtLLG9CQUFMLENBQTBCekIsT0FBMUIsRUFBbUNlLE9BQW5DLENBQVg7QUFDRDs7QUFFRCxRQUFJSyxRQUFKLEVBQWM7QUFDWjtBQUNBM0MsaUJBQVcsQ0FBQzJDLFFBQVosR0FBdUJBLFFBQXZCO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsYUFBTzNDLFdBQVcsQ0FBQ00sTUFBWixHQUFxQixhQUE1QixDQURLLENBRUw7QUFDRDs7QUFFRCxRQUFJMkMsT0FBTyxHQUFHLEtBQUtDLFNBQUwsQ0FBZVAsUUFBZixFQUF5QnZCLE1BQXpCLENBQWQ7O0FBRUEsUUFBSTZCLE9BQUosRUFBYTtBQUNYLFlBQU1FLE9BQU8sR0FBRyxLQUFLQyxnQkFBTCxDQUFzQlQsUUFBdEIsQ0FBaEI7QUFDQTNDLGlCQUFXLENBQUNxRCxJQUFaLEdBQW1CLEtBQUtDLE9BQUwsQ0FBYXRELFdBQWIsRUFBMEJtRCxPQUExQixDQUFuQjtBQUNBRixhQUFPLEdBQUcsS0FBS00sa0JBQUwsQ0FBd0JaLFFBQXhCLEVBQWtDdkIsTUFBbEMsRUFBMENHLE9BQTFDLENBQVY7O0FBRUEsVUFBSTBCLE9BQUosRUFBYTtBQUNYakQsbUJBQVcsQ0FBQ00sTUFBWixHQUFxQixtQkFBckI7QUFDRCxPQUZELE1BRU87QUFDTE4sbUJBQVcsQ0FBQ00sTUFBWixHQUFxQix5QkFBckI7QUFDRDs7QUFFRCxXQUFLa0QscUJBQUwsQ0FBMkJiLFFBQTNCLEVBQXFDUSxPQUFyQztBQUVELEtBYkQsTUFhTztBQUNMbkQsaUJBQVcsQ0FBQ00sTUFBWixHQUFxQixnQkFBckI7QUFDRDtBQUNGOztBQUdEMEMsc0JBQW9CLENBQUN6QixPQUFELEVBQVVlLE9BQVYsRUFBbUI7QUFDckMsVUFBTVIsTUFBTSxHQUFHO0FBQ2JZLGFBQU8sRUFBRTtBQUNQZSxZQUFJLEVBQUUsQ0FDSmxDLE9BREksRUFFSmUsT0FGSSxDQURDO0FBS1BvQixhQUFLLEVBQUU7QUFMQTtBQURJLEtBQWY7QUFVQSxVQUFNO0FBQUUvQjtBQUFGLFFBQVc3QixLQUFLLENBQUNhLE9BQU4sQ0FBY21CLE1BQWQsS0FBeUIsRUFBMUM7QUFFQSxXQUFPSCxHQUFQO0FBQ0Q7O0FBR0R1QixXQUFTLENBQUVQLFFBQUYsRUFBWXZCLE1BQVosRUFBb0I7QUFDM0IsVUFBTVUsTUFBTSxHQUFHO0FBQUVILFNBQUcsRUFBRWdCO0FBQVAsS0FBZjtBQUNBLFVBQU1nQixJQUFJLEdBQUc7QUFBRUMsV0FBSyxFQUFFO0FBQUV0QyxpQkFBUyxFQUFFRjtBQUFiO0FBQVQsS0FBYjtBQUNBLFVBQU02QixPQUFPLEdBQUduRCxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUI2QixJQUFyQixDQUFoQjtBQUVBLFdBQU9WLE9BQVA7QUFDRDs7QUFHREssU0FBTyxDQUFDdEQsV0FBRCxFQUFjbUQsT0FBZCxFQUF1QjtBQUM1QixRQUFJRSxJQUFJLEdBQUc7QUFBRVEsVUFBSSxFQUFFO0FBQVIsS0FBWDtBQUVBLFFBQUlDLGFBQWEsR0FBR1gsT0FBTyxDQUFDWSxNQUFSLEdBQWlCLENBQXJDOztBQUNBLFFBQUksQ0FBQ0QsYUFBTCxFQUFvQjtBQUNsQkEsbUJBQWEsR0FBRzlELFdBQVcsQ0FBQ2dFLFdBQTVCO0FBQ0Q7O0FBRUQsUUFBSUYsYUFBSixFQUFtQjtBQUNqQixZQUFNaEMsTUFBTSxHQUFHO0FBQUVILFdBQUcsRUFBRTNCLFdBQVcsQ0FBQzJDO0FBQW5CLE9BQWY7QUFDQSxZQUFNc0IsT0FBTyxHQUFHO0FBQUVyRCxjQUFNLEVBQUU7QUFBRXlDLGNBQUksRUFBRTtBQUFSO0FBQVYsT0FBaEI7QUFDQSxZQUFNM0IsU0FBUyxHQUFHNUIsS0FBSyxDQUFDYSxPQUFOLENBQWNtQixNQUFkLEVBQXNCbUMsT0FBdEIsQ0FBbEI7O0FBQ0EsVUFBSXZDLFNBQVMsSUFBSUEsU0FBUyxDQUFDMkIsSUFBM0IsRUFBaUM7QUFDL0JBLFlBQUksR0FBRzNCLFNBQVMsQ0FBQzJCLElBQWpCO0FBQ0Q7QUFDRixLQWYyQixDQWlCNUI7OztBQUVBLFdBQU9BLElBQVA7QUFDRCxHQXJHNEIsQ0F1RzdCOzs7QUFFQUUsb0JBQWtCLENBQUNaLFFBQUQsRUFBV3ZCLE1BQVgsRUFBbUJHLE9BQW5CLEVBQTRCO0FBQzVDLFVBQU0yQyxLQUFLLEdBQUduQixZQUFZLENBQUMsU0FBRCxDQUExQixDQUQ0QyxDQUNOOztBQUN0QyxVQUFNakIsTUFBTSxHQUFHO0FBQUVILFNBQUcsRUFBRUo7QUFBUCxLQUFmO0FBQ0EsVUFBTTRDLElBQUksR0FBSTtBQUFFQyxRQUFFLEVBQUVGO0FBQU4sS0FBZDtBQUNBLFVBQU1HLElBQUksR0FBSSxhQUFhMUIsUUFBM0IsQ0FKNEMsQ0FLNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBLFVBQU1nQixJQUFJLEdBQUc7QUFDWEMsV0FBSyxFQUFFO0FBQ0wsU0FBQ1MsSUFBRCxHQUFRO0FBQ05DLGVBQUssRUFBRSxDQUFDSCxJQUFELENBREQ7QUFFTkksbUJBQVMsRUFBRTtBQUZMO0FBREg7QUFESSxLQUFiO0FBU0EsUUFBSXRCLE9BQU8sR0FBR3JELElBQUksQ0FBQ21DLE1BQUwsQ0FBWUQsTUFBWixFQUFvQjZCLElBQXBCLENBQWQ7O0FBRUEsUUFBSVYsT0FBSixFQUFhO0FBQ1huQixZQUFNLENBQUN1QyxJQUFJLEdBQUcsS0FBUixDQUFOLEdBQXVCSCxLQUF2QjtBQUNBLFlBQU1NLE9BQU8sR0FBRztBQUNkQyxvQkFBWSxFQUFFO0FBQUUsV0FBQ0osSUFBSSxHQUFHLE9BQVIsR0FBa0I7QUFBcEI7QUFEQSxPQUFoQixDQUZXLENBTVg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBcEIsYUFBTyxHQUFHckQsSUFBSSxDQUFDbUMsTUFBTCxDQUNSRCxNQURRLEVBRVIwQyxPQUZRLENBQVY7QUFJRDs7QUFFRCxXQUFPdkIsT0FBUDtBQUNEOztBQUdERyxrQkFBZ0IsQ0FBQ3pCLEdBQUQsRUFBTTtBQUNwQjtBQUNBLFVBQU1HLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNc0MsT0FBTyxHQUFHO0FBQUVyRCxZQUFNLEVBQUU7QUFBRVUsaUJBQVMsRUFBRTtBQUFiO0FBQVYsS0FBaEI7QUFDQSxVQUFNO0FBQUVBO0FBQUYsUUFBZ0J4QixLQUFLLENBQUNhLE9BQU4sQ0FBY21CLE1BQWQsRUFBc0JtQyxPQUF0QixDQUF0QixDQUpvQixDQU1wQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFPM0MsU0FBUDtBQUNEOztBQUdEa0MsdUJBQXFCLENBQUM3QixHQUFELEVBQU13QixPQUFOLEVBQWU7QUFDbEM7QUFDQSxVQUFNN0IsU0FBUyxHQUFHNkIsT0FBTyxDQUFDdUIsR0FBUixDQUFhdEQsTUFBTSxLQUFLO0FBQUVFLGVBQVMsRUFBRUY7QUFBYixLQUFMLENBQW5CLENBQWxCO0FBQ0EsVUFBTXVELFVBQVUsR0FBRztBQUNqQkMsU0FBRyxFQUFFdEQ7QUFEWSxLQUFuQjtBQUdBLFVBQU0yQyxPQUFPLEdBQUc7QUFBRXJELFlBQU0sRUFBRTtBQUFFVSxpQkFBUyxFQUFFO0FBQWI7QUFBVixLQUFoQjtBQUNBLFVBQU11RCxLQUFLLEdBQUdqRixJQUFJLENBQUNrRixJQUFMLENBQVVILFVBQVYsRUFBc0JWLE9BQXRCLEVBQStCYyxLQUEvQixFQUFkLENBUGtDLENBU2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBQ0FGLFNBQUssQ0FBQ3JFLE9BQU4sQ0FBZXdFLFFBQVEsSUFBSTtBQUN6QixZQUFNQyxVQUFVLEdBQUdELFFBQVEsQ0FBQzFELFNBQTVCOztBQUNBLFlBQU00RCxjQUFjLEdBQUtmLElBQUksSUFBSWMsVUFBVSxDQUFDRSxRQUFYLENBQW9CaEIsSUFBcEIsQ0FBakM7O0FBQ0FyQixnQkFBVSxDQUFDSyxPQUFELEVBQVUrQixjQUFWLEVBQTBCLElBQTFCLENBQVY7QUFDRCxLQUpELEVBbEJrQyxDQXdCbEM7QUFDQTs7QUFFQSxVQUFNRSxXQUFXLEdBQUc7QUFBRXpEO0FBQUYsS0FBcEI7QUFDQXdCLFdBQU8sQ0FBQzNDLE9BQVIsQ0FBaUI2RSxZQUFZLElBQUk7QUFDL0I7QUFDQSxZQUFNQyxJQUFJLEdBQUc7QUFBRUMsYUFBSyxFQUFFO0FBQUVqRSxtQkFBUyxFQUFFK0Q7QUFBYjtBQUFULE9BQWI7QUFDQSxZQUFNMUIsSUFBSSxHQUFHO0FBQUVDLGFBQUssRUFBRTtBQUFFdEMsbUJBQVMsRUFBRStEO0FBQWI7QUFBVCxPQUFiO0FBQ0F2RixXQUFLLENBQUNpQyxNQUFOLENBQWFxRCxXQUFiLEVBQTBCRSxJQUExQixFQUorQixDQU0vQjs7QUFDQXhGLFdBQUssQ0FBQ2lDLE1BQU4sQ0FBYXFELFdBQWIsRUFBMEJ6QixJQUExQjtBQUNELEtBUkQsRUE1QmtDLENBc0NsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQWhPNEIsQzs7Ozs7Ozs7Ozs7QUNaL0J6RSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSW9HO0FBQWIsQ0FBZDtBQUF3QyxJQUFJQyxjQUFKO0FBQW1CdkcsTUFBTSxDQUFDSyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2tHLGdCQUFjLENBQUNqRyxDQUFELEVBQUc7QUFBQ2lHLGtCQUFjLEdBQUNqRyxDQUFmO0FBQWlCOztBQUFwQyxDQUF2QyxFQUE2RSxDQUE3RTtBQUFnRixJQUFJa0csWUFBSjtBQUFpQnhHLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUNtRyxjQUFZLENBQUNsRyxDQUFELEVBQUc7QUFBQ2tHLGdCQUFZLEdBQUNsRyxDQUFiO0FBQWU7O0FBQWhDLENBQS9DLEVBQWlGLENBQWpGO0FBQW9GLElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUExQyxFQUFzRSxDQUF0RTtBQVFoUSxNQUFNO0FBQUVJLE1BQUY7QUFBUUMsU0FBUjtBQUFpQkM7QUFBakIsSUFBMkJILFdBQWpDOztBQUllLE1BQU02RixVQUFOLENBQWlCO0FBQzlCekYsYUFBVyxDQUFDNEYsVUFBRCxFQUFhO0FBQ3RCLFFBQUk7QUFBRUMsUUFBRjtBQUFNeEUsWUFBTjtBQUFjdUIsY0FBZDtBQUF3QmtELGVBQVMsR0FBQztBQUFsQyxRQUE0Q0YsVUFBaEQ7O0FBRUEsUUFBSSxDQUFDaEQsUUFBTCxFQUFlO0FBQ2JBLGNBQVEsR0FBRyxLQUFLbUQsV0FBTCxDQUFpQjFFLE1BQWpCLENBQVg7O0FBRUEsVUFBSSxDQUFDdUIsUUFBTCxFQUFlO0FBQ2I7QUFDRDtBQUNGLEtBVHFCLENBV3RCOzs7QUFDQSxTQUFLb0QscUJBQUwsQ0FBMkJwRCxRQUEzQixFQUFxQ3ZCLE1BQXJDLEVBWnNCLENBYXRCO0FBRUE7O0FBQ0EsUUFBSXdFLEVBQUUsQ0FBQzdCLE1BQUgsR0FBWSxDQUFoQixFQUFtQjtBQUFDO0FBQ2xCLFlBQU1pQyxZQUFZLEdBQUcsS0FBS0MsbUJBQUwsQ0FBeUJMLEVBQXpCLEVBQTZCakQsUUFBN0IsQ0FBckI7O0FBQ0EsVUFBSSxDQUFDcUQsWUFBTCxFQUFtQjtBQUNqQixhQUFLRSxlQUFMLENBQXFCdkQsUUFBckI7QUFDRDtBQUVGLEtBTkQsTUFNTztBQUNMLFdBQUt3RCxhQUFMLENBQW1CUCxFQUFuQixFQUF1QmpELFFBQXZCLEVBQWlDa0QsU0FBakM7QUFDRDtBQUNGOztBQUdEQyxhQUFXLENBQUMxRSxNQUFELEVBQVM7QUFDbEIsVUFBTVUsTUFBTSxHQUFHO0FBQUVSLGVBQVMsRUFBRUY7QUFBYixLQUFmO0FBQ0EsVUFBTTZDLE9BQU8sR0FBRyxFQUFoQjs7QUFDQSxVQUFNbUMsSUFBSSxHQUFHdEcsS0FBSyxDQUFDZ0YsSUFBTixDQUFXaEQsTUFBWCxFQUFtQm1DLE9BQW5CLEVBQ09jLEtBRFAsR0FFT0wsR0FGUCxDQUVXMkIsR0FBRyxJQUFJQSxHQUFHLENBQUMxRSxHQUZ0QixDQUFiOztBQUdBLFFBQUl5RSxJQUFJLENBQUNyQyxNQUFMLEdBQWMsQ0FBbEIsRUFBcUIsQ0FDbkI7QUFDRDs7QUFFRCxXQUFPcUMsSUFBSSxDQUFDLENBQUQsQ0FBWCxDQVZrQixDQVVIO0FBQ2hCLEdBeEM2QixDQTJDOUI7OztBQUNBTCx1QkFBcUIsQ0FBQ3BELFFBQUQsRUFBV3ZCLE1BQVgsRUFBbUI7QUFDdEMsVUFBTVUsTUFBTSxHQUFHO0FBQUVILFNBQUcsRUFBRWdCLFFBQVA7QUFBaUJyQixlQUFTLEVBQUVGO0FBQTVCLEtBQWY7QUFDQSxVQUFNa0UsSUFBSSxHQUFLO0FBQUVDLFdBQUssRUFBRTtBQUFFakUsaUJBQVMsRUFBRUY7QUFBYjtBQUFULEtBQWY7QUFDQSxVQUFNYSxNQUFNLEdBQUduQyxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUJ3RCxJQUFyQixDQUFmLENBSHNDLENBS3RDO0FBQ1c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDWjs7QUFHRFcscUJBQW1CLENBQUNMLEVBQUQsRUFBS2pELFFBQUwsRUFBZTtBQUMvQixRQUFJYixNQUFNLEdBQUk7QUFBRThEO0FBQUYsS0FBZDtBQUNBLFVBQU0zQixPQUFPLEdBQUc7QUFBRXJELFlBQU0sRUFBRTtBQUFFVSxpQkFBUyxFQUFFO0FBQWI7QUFBVixLQUFoQjtBQUNBLFVBQU1nQixPQUFPLEdBQUd6QyxPQUFPLENBQUNjLE9BQVIsQ0FBZ0JtQixNQUFoQixFQUF3Qm1DLE9BQXhCLEtBQ0E7QUFBRTNDLGVBQVMsRUFBRSxFQUFiO0FBQWlCZ0YsVUFBSSxFQUFFO0FBQXZCLEtBRGhCO0FBRUEsVUFBTW5ELE9BQU8sR0FBR2IsT0FBTyxDQUFDaEIsU0FBeEIsQ0FMK0IsQ0FPL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQVEsVUFBTSxHQUFHO0FBQUVILFNBQUcsRUFBRWdCO0FBQVAsS0FBVDtBQUNBLFVBQU07QUFBRXJCO0FBQUYsUUFBZ0J4QixLQUFLLENBQUNhLE9BQU4sQ0FBY21CLE1BQWQsRUFBc0JtQyxPQUF0QixDQUF0QixDQWpCK0IsQ0FtQi9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQU1zQyxPQUFPLEdBQUdiLFlBQVksQ0FBQ3BFLFNBQUQsRUFBWTZCLE9BQVosQ0FBNUI7QUFFQSxXQUFPb0QsT0FBTyxDQUFDeEMsTUFBZjtBQUdGLEdBNUY2QixDQStGOUI7OztBQUNBbUMsaUJBQWUsQ0FBQ3ZELFFBQUQsRUFBVztBQUN4QixVQUFNYixNQUFNLEdBQUc7QUFBRUgsU0FBRyxFQUFFZ0I7QUFBUCxLQUFmO0FBQ0EsVUFBTTZELEdBQUcsR0FBTTtBQUFFeEUsVUFBSSxFQUFFO0FBQUVKLGNBQU0sRUFBRTtBQUFWO0FBQVIsS0FBZjtBQUNBLFVBQU1LLE1BQU0sR0FBR25DLEtBQUssQ0FBQ2lDLE1BQU4sQ0FBYUQsTUFBYixFQUFxQjBFLEdBQXJCLENBQWYsQ0FId0IsQ0FLeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsR0EzRzZCLENBOEc5Qjs7O0FBQ0FMLGVBQWEsQ0FBQ3hFLEdBQUQsRUFBTWdCLFFBQU4sRUFBZ0JrRCxTQUFoQixFQUEyQjtBQUN0QyxTQUFLWSxpQkFBTCxDQUF1QjlFLEdBQXZCLEVBQTRCZ0IsUUFBNUI7O0FBRUEsUUFBSSxDQUFDa0QsU0FBTCxFQUFnQjtBQUNkO0FBQ0E7QUFDQTtBQUNBLFdBQUthLGdCQUFMLENBQXNCL0QsUUFBdEI7QUFDRDtBQUNGOztBQUdEOEQsbUJBQWlCLENBQUM5RSxHQUFELEVBQU1nQixRQUFOLEVBQWdCO0FBQy9CLFVBQU0wQixJQUFJLEdBQUcsYUFBYTFCLFFBQTFCO0FBQ0EsVUFBTWdFLE9BQU8sR0FBR3RDLElBQUksR0FBRyxRQUF2QjtBQUNBLFVBQU12QyxNQUFNLEdBQUc7QUFDYkgsU0FEYTtBQUViLE9BQUMwQyxJQUFJLEdBQUMsS0FBTixHQUFjO0FBQUV1QyxlQUFPLEVBQUU7QUFBWCxPQUZEO0FBR2IsT0FBQ0QsT0FBRCxHQUFjO0FBQUVDLGVBQU8sRUFBRTtBQUFYO0FBSEQsS0FBZjtBQUtBLFVBQU03RSxNQUFNLEdBQUc7QUFDYjBDLGtCQUFZLEVBQUU7QUFDWixTQUFDa0MsT0FBRCxHQUFXO0FBREM7QUFERCxLQUFmO0FBTUEsVUFBTTFFLE1BQU0sR0FBR3JDLElBQUksQ0FBQ21DLE1BQUwsQ0FBWUQsTUFBWixFQUFvQkMsTUFBcEIsQ0FBZixDQWQrQixDQWdCL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFHRDJFLGtCQUFnQixDQUFDL0QsUUFBRCxFQUFXO0FBQ3pCLFVBQU07QUFBRXJCLGVBQUY7QUFDRWUsV0FERjtBQUVFVCxZQUZGLENBRVM7O0FBRlQsUUFHSSxLQUFLaUYsb0JBQUwsQ0FBMEJsRSxRQUExQixDQUhWO0FBSUEsVUFBTW1FLFlBQVksR0FBRyxLQUFLQyxlQUFMLENBQXFCMUUsS0FBckIsRUFBNEJmLFNBQTVCLENBQXJCO0FBQ0EsVUFBTTBGLFdBQVcsR0FBR0YsWUFBWSxDQUFDL0MsTUFBakMsQ0FOeUIsQ0FRekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsUUFBSWlELFdBQVcsSUFBSUEsV0FBVyxLQUFLMUYsU0FBUyxDQUFDeUMsTUFBN0MsRUFBcUQ7QUFDbkQ7QUFDQSxXQUFLbUMsZUFBTCxDQUFxQnZELFFBQXJCO0FBRUQsS0FKRCxNQUlPO0FBQ0wsV0FBS3NFLFlBQUwsQ0FBa0J0RSxRQUFsQixFQUE0QnJCLFNBQTVCLEVBQXVDd0YsWUFBdkM7QUFDRDtBQUNGOztBQUdERCxzQkFBb0IsQ0FBQ2xFLFFBQUQsRUFBVztBQUM3QixVQUFNYixNQUFNLEdBQUk7QUFBRUgsU0FBRyxFQUFFZ0I7QUFBUCxLQUFoQjtBQUNBLFVBQU1zQixPQUFPLEdBQUc7QUFBRXJELFlBQU0sRUFBRTtBQUN4QlUsaUJBQVMsRUFBRSxDQURhO0FBRXhCZSxhQUFLLEVBQUUsQ0FGaUI7QUFHeEJULGNBQU0sRUFBRTtBQUhnQjtBQUFWLEtBQWhCO0FBS0EsVUFBTXRCLE1BQU0sR0FBSVIsS0FBSyxDQUFDYSxPQUFOLENBQWNtQixNQUFkLEVBQXNCbUMsT0FBdEIsQ0FBaEIsQ0FQNkIsQ0FTN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQU8zRCxNQUFQO0FBQ0Q7O0FBR0R5RyxpQkFBZSxDQUFDMUUsS0FBRCxFQUFRYyxPQUFSLEVBQWlCO0FBQzlCLFVBQU1yQixNQUFNLEdBQUc7QUFBRThELFFBQUUsRUFBRXZEO0FBQU4sS0FBZjtBQUNBLFVBQU00QixPQUFPLEdBQUc7QUFBRXJELFlBQU0sRUFBRTtBQUFFVSxpQkFBUyxFQUFFO0FBQWI7QUFBVixLQUFoQjtBQUNBLFVBQU07QUFBRUE7QUFBRixRQUFnQnpCLE9BQU8sQ0FBQ2MsT0FBUixDQUFnQm1CLE1BQWhCLEVBQXdCbUMsT0FBeEIsQ0FBdEIsQ0FIOEIsQ0FLOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUFkLFdBQU8sR0FBR3VDLFlBQVksQ0FBQ3ZDLE9BQUQsRUFBVTdCLFNBQVYsQ0FBdEI7QUFFQSxXQUFPNkIsT0FBUDtBQUNELEdBbk42QixDQXNOOUI7OztBQUVBOEQsY0FBWSxDQUFDdEUsUUFBRCxFQUFXckIsU0FBWCxFQUFzQndGLFlBQXRCLEVBQW9DO0FBQzlDO0FBQ0EsUUFBSUksS0FBSjtBQUVBNUYsYUFBUyxDQUFDNkYsS0FBVixDQUFnQixDQUFDL0YsTUFBRCxFQUFTOEMsS0FBVCxLQUFtQjtBQUNqQyxVQUFJNEMsWUFBWSxDQUFDM0IsUUFBYixDQUFzQi9ELE1BQXRCLENBQUosRUFBbUM7QUFDakMsZUFBTyxJQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0w4RixhQUFLLEdBQUdoRCxLQUFLLElBQUk5QyxNQUFqQixDQURLLENBQ21COztBQUN4QixlQUFPLEtBQVA7QUFDRDtBQUNGLEtBUEQ7O0FBU0EsUUFBSThGLEtBQUosRUFBVztBQUNULFlBQU1wRixNQUFNLEdBQUc7QUFBRUgsV0FBRyxFQUFFZ0I7QUFBUCxPQUFmO0FBQ0EsWUFBTTJDLElBQUksR0FBRztBQUFFQyxhQUFLLEVBQUU7QUFBRWpFLG1CQUFTLEVBQUU0RjtBQUFiO0FBQVQsT0FBYjtBQUNBLFlBQU12RCxJQUFJLEdBQUc7QUFBRUMsYUFBSyxFQUFFO0FBQUV0QyxtQkFBUyxFQUFFO0FBQUNnRCxpQkFBSyxFQUFDLENBQUM0QyxLQUFELENBQVA7QUFBZTNDLHFCQUFTLEVBQUM7QUFBekI7QUFBYjtBQUFULE9BQWI7QUFDQSxVQUFJdEMsTUFBTSxHQUFHbkMsS0FBSyxDQUFDaUMsTUFBTixDQUFhRCxNQUFiLEVBQXFCd0QsSUFBckIsQ0FBYixDQUpTLENBTVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBckQsWUFBTSxHQUFHbkMsS0FBSyxDQUFDaUMsTUFBTixDQUFhRCxNQUFiLEVBQXFCNkIsSUFBckIsQ0FBVCxDQWJTLENBZVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDRjs7QUEzUDZCLEM7Ozs7Ozs7Ozs7O0FDWmhDekUsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUlnSTtBQUFiLENBQWQ7QUFBbUMsSUFBSXpILFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUExQyxFQUFzRSxDQUF0RTtBQU9uRCxNQUFNO0FBQUVJLE1BQUY7QUFBUUMsU0FBUjtBQUFpQkM7QUFBakIsSUFBMkJILFdBQWpDOztBQUllLE1BQU15SCxLQUFOLENBQVk7QUFDekJySCxhQUFXLENBQUNDLFdBQUQsRUFBYztBQUN2QixTQUFLQSxXQUFMLEdBQW1CQSxXQUFuQixDQUR1QixDQUV2Qjs7QUFFQSxVQUFNcUgsVUFBVSxHQUFHLEtBQUtDLHNCQUFMLEVBQW5COztBQUVBLFFBQUksQ0FBQ0QsVUFBTCxFQUFpQjtBQUNmO0FBQ0E7QUFFQXJILGlCQUFXLENBQUNNLE1BQVosR0FBcUIsZUFBckI7QUFFRCxLQU5ELE1BTU8sSUFBS04sV0FBVyxDQUFDTSxNQUFaLEtBQXVCLGVBQXZCLElBQ0QsQ0FBQ04sV0FBVyxDQUFDSyxjQURqQixFQUVLO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsYUFSVSxDQVFIO0FBQ0E7QUFFUixLQWJNLE1BYUEsSUFBSSxDQUFDTCxXQUFXLENBQUNnQixNQUFqQixFQUF5QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBaEIsaUJBQVcsQ0FBQ00sTUFBWixHQUFxQixZQUFyQjtBQUVELEtBWE0sTUFXQTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLFlBQU1pSCxZQUFZLEdBQUcsS0FBS0MseUJBQUwsRUFBckI7O0FBQ0EsVUFBSSxDQUFDRCxZQUFMLEVBQW1CO0FBQ2pCdkgsbUJBQVcsQ0FBQ00sTUFBWixHQUFxQixZQUFyQjtBQUVELE9BSEQsTUFHTztBQUNMTixtQkFBVyxDQUFDTSxNQUFaLEdBQXFCLFVBQXJCO0FBQ0FOLG1CQUFXLENBQUN5SCxRQUFaLEdBQXVCLElBQXZCO0FBQ0Q7QUFDRjtBQUNGOztBQUdESCx3QkFBc0IsR0FBRztBQUN2QixVQUFNcEcsUUFBUSxHQUFHLEtBQUtsQixXQUFMLENBQWlCa0IsUUFBbEM7QUFDQSxVQUFNbUcsVUFBVSxHQUFHekgsSUFBSSxDQUFDZSxPQUFMLENBQWE7QUFBRU87QUFBRixLQUFiLEVBQTJCLEVBQTNCLENBQW5CO0FBRUEsV0FBTyxDQUFDLENBQUNtRyxVQUFUO0FBQ0Q7O0FBR0RHLDJCQUF5QixHQUFHO0FBQzFCLFVBQU07QUFBRXRHLGNBQUY7QUFBWUYsWUFBWjtBQUFvQkk7QUFBcEIsUUFBK0IsS0FBS3BCLFdBQTFDO0FBRUEsVUFBTThCLE1BQU0sR0FBRztBQUFFWixjQUFGO0FBQVlGO0FBQVosS0FBZjtBQUNBLFVBQU0yQyxJQUFJLEdBQUc7QUFBRUMsV0FBSyxFQUFFO0FBQUV0QyxpQkFBUyxFQUFFRjtBQUFiO0FBQVQsS0FBYjtBQUNBLFVBQU1hLE1BQU0sR0FBR3JDLElBQUksQ0FBQ21DLE1BQUwsQ0FBWUQsTUFBWixFQUFvQjZCLElBQXBCLENBQWYsQ0FMMEIsQ0FLZTs7QUFFekMsUUFBSTFCLE1BQUosRUFBWTtBQUNWLFlBQU1nQyxPQUFPLEdBQUc7QUFBRXJELGNBQU0sRUFBRTtBQUFFSyxpQkFBTyxFQUFFO0FBQVg7QUFBVixPQUFoQjtBQUNBLFlBQU07QUFBRVUsV0FBRyxFQUFFSixPQUFQO0FBQWdCTjtBQUFoQixVQUE0QnJCLElBQUksQ0FBQ2UsT0FBTCxDQUFhbUIsTUFBYixFQUFxQm1DLE9BQXJCLENBQWxDO0FBQ0F5RCxZQUFNLENBQUNDLE1BQVAsQ0FBZSxLQUFLM0gsV0FBcEIsRUFBaUM7QUFBRXVCLGVBQUY7QUFBV047QUFBWCxPQUFqQztBQUNEOztBQUVELFdBQU9nQixNQUFQO0FBQ0Q7O0FBL0V3QixDOzs7Ozs7Ozs7OztBQ1gzQi9DLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJd0k7QUFBYixDQUFkO0FBQTBDLElBQUlqSSxXQUFKO0FBQWdCVCxNQUFNLENBQUNLLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBMUMsRUFBc0UsQ0FBdEU7QUFTMUQsTUFBTTtBQUFFSyxTQUFGO0FBQVdDO0FBQVgsSUFBcUJILFdBQTNCOztBQUllLE1BQU1pSSxZQUFOLENBQW1CO0FBQ2hDN0gsYUFBVyxDQUFDQyxXQUFELEVBQWM7QUFDdkI7QUFFQSxVQUFNO0FBQUU0RixRQUFGO0FBQU14RTtBQUFOLFFBQWlCcEIsV0FBdkI7QUFDQSxVQUFNNkgsSUFBSSxHQUFHLEtBQUtDLGNBQUwsQ0FBb0JsQyxFQUFwQixFQUF3QnhFLE1BQXhCLENBQWI7QUFDQSxVQUFNcUcsUUFBUSxHQUFHLEtBQUtNLFdBQUwsQ0FBaUJuQyxFQUFqQixFQUFxQnhFLE1BQXJCLENBQWpCO0FBRUFwQixlQUFXLENBQUN5SCxRQUFaLEdBQXVCQSxRQUF2QjtBQUNEOztBQUdETSxhQUFXLENBQUNuQyxFQUFELEVBQUt4RSxNQUFMLEVBQWE7QUFDdEIsVUFBTVUsTUFBTSxHQUFHO0FBQUU4RDtBQUFGLEtBQWY7QUFDQSxVQUFNb0MsUUFBUSxHQUFHO0FBQ2ZDLGVBQVMsRUFBRTtBQUNUM0csaUJBQVMsRUFBRUY7QUFERjtBQURJLEtBQWpCO0FBS0EsVUFBTWEsTUFBTSxHQUFHcEMsT0FBTyxDQUFDa0MsTUFBUixDQUFlRCxNQUFmLEVBQXVCa0csUUFBdkIsQ0FBZixDQVBzQixDQU8wQjtBQUVoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFPL0YsTUFBUDtBQUNEOztBQUdENkYsZ0JBQWMsQ0FBQ2xDLEVBQUQsRUFBS3hFLE1BQUwsRUFBYTtBQUN6QixVQUFNVSxNQUFNLEdBQUc7QUFBRVksYUFBTyxFQUFFa0QsRUFBWDtBQUFldEUsZUFBUyxFQUFFRjtBQUExQixLQUFmO0FBQ0EsVUFBTWtFLElBQUksR0FBRztBQUNYQyxXQUFLLEVBQUU7QUFDTGpFLGlCQUFTLEVBQUVGO0FBRE47QUFESSxLQUFiO0FBS0EsVUFBTWEsTUFBTSxHQUFHbkMsS0FBSyxDQUFDaUMsTUFBTixDQUFhRCxNQUFiLEVBQXFCd0QsSUFBckIsQ0FBZixDQVB5QixDQU9pQjtBQUUxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFPckQsTUFBUDtBQUNEOztBQW5EK0IsQzs7Ozs7Ozs7Ozs7QUNibEMvQyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSThJO0FBQWIsQ0FBZDtBQUFvQyxJQUFJdkksV0FBSjtBQUFnQlQsTUFBTSxDQUFDSyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ0csZUFBVyxHQUFDSCxDQUFaO0FBQWM7O0FBQTFCLENBQTFDLEVBQXNFLENBQXRFO0FBT3BELE1BQU07QUFBRUksTUFBRjtBQUFRQyxTQUFSO0FBQWlCQztBQUFqQixJQUEyQkgsV0FBakM7O0FBR2UsTUFBTXVJLE1BQU4sQ0FBYTtBQUMxQm5JLGFBQVcsQ0FBQ29JLFVBQUQsRUFBYTtBQUN0QixVQUFNO0FBQUV2QyxRQUFGO0FBQU14RTtBQUFOLFFBQWlCK0csVUFBdkI7QUFFQSxVQUFNcEcsTUFBTSxHQUFHO0FBQ2J3RCxXQUFLLEVBQUU7QUFDTGpFLGlCQUFTLEVBQUVGO0FBRE47QUFETSxLQUFmO0FBTUEsUUFBSVgsR0FBSixFQUNJMkgsVUFESjtBQUdBLFVBQU1DLFNBQVMsR0FBSXpDLEVBQUUsQ0FBQzdCLE1BQUgsR0FBWSxDQUEvQjs7QUFFQSxRQUFJc0UsU0FBSixFQUFlO0FBQUM7QUFDZDVILFNBQUcsR0FBRyxJQUFOO0FBQ0EySCxnQkFBVSxHQUFHdkksT0FBYjtBQUVELEtBSkQsTUFJTztBQUNMWSxTQUFHLEdBQUcsS0FBTjtBQUNBMkgsZ0JBQVUsR0FBR3hJLElBQWI7QUFDRDs7QUFFRCxVQUFNa0MsTUFBTSxHQUFHO0FBQUUsT0FBQ3JCLEdBQUQsR0FBT21GO0FBQVQsS0FBZjtBQUVBLFVBQU0zRCxNQUFNLEdBQUdtRyxVQUFVLENBQUNyRyxNQUFYLENBQWtCRCxNQUFsQixFQUEwQkMsTUFBMUIsQ0FBZixDQXpCc0IsQ0EyQnRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQXJDeUIsQzs7Ozs7Ozs7Ozs7QUNWNUI3QyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSWtKO0FBQWIsQ0FBZDtBQUEwQ3BKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLFNBQVo7QUFBdUIsSUFBSWdKLEdBQUo7QUFBUXJKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQytJLE9BQUcsR0FBQy9JLENBQUo7QUFBTTs7QUFBbEIsQ0FBdkIsRUFBMkMsQ0FBM0M7QUFBOEMsSUFBSWdKLFFBQUo7QUFBYXRKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ2dKLFlBQVEsR0FBQ2hKLENBQVQ7QUFBVzs7QUFBdkIsQ0FBekIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNELFVBQUo7QUFBZTVELE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUN1RCxZQUFVLENBQUN0RCxDQUFELEVBQUc7QUFBQ3NELGNBQVUsR0FBQ3RELENBQVg7QUFBYTs7QUFBNUIsQ0FBL0MsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSWlKLGdCQUFKLEVBQXFCQyxhQUFyQixFQUFtQ0MsV0FBbkMsRUFBK0NDLFVBQS9DO0FBQTBEMUosTUFBTSxDQUFDSyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ2tKLGtCQUFnQixDQUFDakosQ0FBRCxFQUFHO0FBQUNpSixvQkFBZ0IsR0FBQ2pKLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tKLGVBQWEsQ0FBQ2xKLENBQUQsRUFBRztBQUFDa0osaUJBQWEsR0FBQ2xKLENBQWQ7QUFBZ0IsR0FBMUU7O0FBQTJFbUosYUFBVyxDQUFDbkosQ0FBRCxFQUFHO0FBQUNtSixlQUFXLEdBQUNuSixDQUFaO0FBQWMsR0FBeEc7O0FBQXlHb0osWUFBVSxDQUFDcEosQ0FBRCxFQUFHO0FBQUNvSixjQUFVLEdBQUNwSixDQUFYO0FBQWE7O0FBQXBJLENBQTlDLEVBQW9MLENBQXBMO0FBQXVMLElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUE3QyxFQUF5RSxDQUF6RTs7QUF5QnpoQixNQUFNcUosRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNekUsSUFBSSxHQUFHeUUsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7O0FBSWUsTUFBTVIsWUFBTixTQUEyQkUsUUFBM0IsQ0FBbUM7QUFDaER6SSxhQUFXLENBQUNrRSxPQUFELEVBQVU7QUFDbkI7QUFFQSxTQUFLOEUsTUFBTCxHQUFjLElBQUlSLEdBQUosRUFBZDtBQUNBLFNBQUtTLEdBQUwsR0FBVyxLQUFLRCxNQUFMLENBQVlFLFFBQXZCOztBQUVBLFFBQUksT0FBT2hGLE9BQVAsS0FBbUIsUUFBdkIsRUFBaUM7QUFDL0IsWUFBTTtBQUFFaUYsZUFBRjtBQUFXQztBQUFYLFVBQTRCbEYsT0FBbEM7O0FBRUEsVUFBSWtGLFlBQUosRUFBa0I7QUFDaEIsY0FBTUMsUUFBUSxHQUFHLEtBQUtDLG1CQUFMLENBQXlCRixZQUF6QixDQUFqQjs7QUFDQSxZQUFJQyxRQUFKLEVBQWM7QUFDWixlQUFLRSxhQUFMLENBQW1CSixPQUFuQixFQUE0QkMsWUFBNUIsRUFBMENDLFFBQTFDO0FBQ0Q7QUFDRjtBQUVGLEtBVkQsTUFVUTtBQUFFO0FBQ1IsV0FBS0csa0JBQUwsQ0FBd0JiLGFBQXhCO0FBQ0Q7O0FBRUQsU0FBS0ssTUFBTCxDQUFZUyxJQUFaO0FBQ0Q7QUFHRDs7Ozs7O0FBSUFDLHFDQUFtQyxHQUFHO0FBQ3BDO0FBQ0EsVUFBTUMsS0FBSyxHQUFHLDZCQUFkO0FBQ0EsVUFBTUMsS0FBSyxHQUFHRCxLQUFLLENBQUNFLElBQU4sQ0FBVyxLQUFLVCxZQUFoQixDQUFkOztBQUNBLFFBQUlRLEtBQUosRUFBVztBQUNULFlBQU1FLFlBQVksR0FBR0YsS0FBSyxDQUFDLENBQUQsQ0FBMUI7O0FBQ0EsVUFBSUUsWUFBSixFQUFrQjtBQUNoQixlQUFPQSxZQUFQO0FBQ0Q7QUFDRjtBQUNGOztBQUdEUCxlQUFhLENBQUNGLFFBQUQsRUFBV0YsT0FBWCxFQUFvQkMsWUFBcEIsRUFBa0M7QUFDN0M7QUFDQSxVQUFNVyxVQUFVLEdBQUdqQixFQUFFLENBQUNrQixXQUFILENBQWVaLFlBQWYsQ0FBbkI7QUFDQSxTQUFLYSxXQUFMLENBQWlCWixRQUFqQixFQUEyQkQsWUFBM0IsRUFBeUNXLFVBQXpDO0FBQ0Q7QUFHRDs7Ozs7Ozs7Ozs7O0FBVUFQLG9CQUFrQixDQUFDVSxNQUFELEVBQVNiLFFBQVQsRUFBbUI7QUFDbkMsVUFBTWMsaUJBQWlCLEdBQUcsQ0FBQ2QsUUFBM0I7QUFDQSxVQUFNZSxRQUFRLEdBQUd0QixFQUFFLENBQUNrQixXQUFILENBQWVFLE1BQWYsQ0FBakIsQ0FGbUMsQ0FHbkM7QUFDQTtBQUNBOztBQUVBRSxZQUFRLENBQUMzSixPQUFULENBQWtCNEosU0FBUyxJQUFJO0FBQzdCLFlBQU1qQixZQUFZLEdBQUc5RSxJQUFJLENBQUNnRyxJQUFMLENBQVVKLE1BQVYsRUFBa0JHLFNBQWxCLENBQXJCO0FBQ0EsWUFBTU4sVUFBVSxHQUFHakIsRUFBRSxDQUFDa0IsV0FBSCxDQUFlWixZQUFmLENBQW5CLENBRjZCLENBSTdCOztBQUVBLFlBQU1tQixPQUFPLEdBQUdSLFVBQVUsQ0FBQ2hGLElBQVgsQ0FBZ0JYLElBQUksSUFBSXlFLFVBQVUsQ0FBQzJCLElBQVgsQ0FBZ0JwRyxJQUFoQixDQUF4QixDQUFoQjs7QUFDQSxVQUFJbUcsT0FBSixFQUFhO0FBQ1gsWUFBSSxDQUFDbEIsUUFBTCxFQUFlO0FBQ2JBLGtCQUFRLEdBQUdnQixTQUFYO0FBQ0Q7O0FBQ0QsYUFBS0osV0FBTCxDQUFpQlosUUFBakIsRUFBMkJELFlBQTNCLEVBQXlDVyxVQUF6QztBQUVELE9BTkQsTUFNTyxJQUFJSSxpQkFBSixFQUF1QjtBQUU1QixhQUFLWCxrQkFBTCxDQUF3QkosWUFBeEIsRUFBc0NpQixTQUF0QztBQUVELE9BSk0sTUFJQTtBQUNMLGNBQU1JLE9BQU8sNkNBQXFDckIsWUFBckMsQ0FBYjtBQUNBLGFBQUtILEdBQUwsQ0FBU3dCLE9BQVQ7QUFDQUMsZUFBTyxDQUFDekIsR0FBUixDQUFZd0IsT0FBWjtBQUNEO0FBQ0YsS0F0QkQ7QUF1QkQ7QUFHRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEyQkFSLGFBQVcsQ0FBQ1osUUFBRCxFQUFXRCxZQUFYLEVBQXlCZ0IsUUFBekIsRUFBbUM7QUFDNUMsVUFBTTtBQUFFTyxjQUFGO0FBQVlDO0FBQVosUUFBcUIsS0FBS0MsWUFBTCxDQUN6QnpCLFlBRHlCLEVBRXpCZ0IsUUFGeUIsQ0FBM0I7O0FBS0EsUUFBSSxDQUFDUSxJQUFMLEVBQVc7QUFDVDtBQUNBLGFBQU8sQ0FBQyxDQUFSO0FBQ0Q7O0FBRUQsVUFBTUUsU0FBUyxHQUFJLEtBQUtDLFlBQUwsQ0FBa0IzQixZQUFsQixDQUFuQjtBQUNBLFVBQU1mLFVBQVUsR0FBR3pJLFdBQVcsQ0FBQ3lKLFFBQUQsQ0FBOUI7QUFDQSxVQUFNdEgsTUFBTSxHQUFPO0FBQUUrSTtBQUFGLEtBQW5CLENBYjRDLENBZTVDOztBQUNBLFVBQU1FLFFBQVEsR0FBRyxLQUFLQyxzQkFBTCxFQUE2QjtBQUM1Q04sWUFEZSxFQUVmdEMsVUFGZSxFQUdmdEcsTUFIZSxDQUFqQjs7QUFNQSxRQUFJLENBQUNpSixRQUFMLEVBQWU7QUFDYixZQUFNUCxPQUFPLHdDQUFnQ0ssU0FBaEMsQ0FBYjtBQUNBLFdBQUs3QixHQUFMLENBQVN3QixPQUFUO0FBQ0EsYUFBTyxDQUFQLENBSGEsQ0FHSjtBQUNWLEtBMUIyQyxDQTRCNUM7OztBQUNBLFVBQU1TLElBQUksR0FBRyxLQUFLQyxVQUFMLENBQWdCL0IsWUFBaEIsRUFBOEJnQixRQUE5QixDQUFiOztBQUVBLFFBQUlBLFFBQVEsQ0FBQ2hGLFFBQVQsQ0FBa0IsT0FBbEIsS0FBOEJnRixRQUFRLENBQUNoRixRQUFULENBQWtCLE9BQWxCLENBQWxDLEVBQThEO0FBQzVELFlBQU1xRixPQUFPLDBDQUFrQ0ssU0FBbEMsQ0FBYjtBQUNBLFdBQUs3QixHQUFMLENBQVN3QixPQUFUO0FBRUEsYUFBTyxLQUFLVyxZQUFMLENBQ0xoQyxZQURLLEVBRUxnQixRQUZLLEVBR0xjLElBSEssRUFJTEosU0FKSyxFQUtMSCxRQUxLLEVBTUxDLElBTkssRUFPTHZDLFVBUEssQ0FBUDtBQVVELEtBZEQsTUFjTztBQUNMLFlBQU1vQyxPQUFPLHlDQUFpQ0ssU0FBakMsQ0FBYjtBQUNBLFdBQUs3QixHQUFMLENBQVN3QixPQUFUO0FBRUEsV0FBS1ksZUFBTCxDQUNFakMsWUFERixFQUVFZ0IsUUFGRixFQUdFYyxJQUhGLEVBSUVKLFNBSkYsRUFLRUgsUUFMRixFQU1FQyxJQU5GLEVBT0V2QyxVQVBGLEVBUUVnQixRQVJGO0FBVUQ7QUFDRjs7QUFHRCtCLGNBQVksQ0FDUmhDLFlBRFEsRUFFUmdCLFFBRlEsRUFHUmMsSUFIUSxFQUlSSixTQUpRLEVBS1JILFFBTFEsRUFNUkMsSUFOUSxFQU9SdkMsVUFQUSxFQVFSO0FBRUYsVUFBTWlELE1BQU0sR0FBRztBQUNiQyxXQUFLLEVBQUUsRUFETTtBQUViQyxXQUFLLEVBQUUsRUFGTTtBQUdiTjtBQUhhLEtBQWYsQ0FGRSxDQVFGOztBQUNBLFNBQUtPLGdCQUFMLENBQXNCckMsWUFBdEIsRUFBb0NnQixRQUFwQyxFQUE4Q2tCLE1BQU0sQ0FBQ0MsS0FBckQ7QUFDQSxTQUFLRyxnQkFBTCxDQUFzQnRDLFlBQXRCLEVBQW9DZ0IsUUFBcEMsRUFBOENrQixNQUFNLENBQUNFLEtBQXJEO0FBRUEsVUFBTUcsU0FBUyxHQUFHLEtBQUtDLFNBQUwsRUFBZ0I7QUFDaENkLGFBRGdCLEVBRWhCSCxRQUZnQixFQUdoQkMsSUFIZ0IsRUFJaEJ2QyxVQUpnQixFQUtoQmlELE1BTGdCLENBQWxCO0FBUUEsV0FBT0ssU0FBUDtBQUNEO0FBR0Q7Ozs7Ozs7Ozs7QUFRQVosY0FBWSxDQUFDM0IsWUFBRCxFQUFlO0FBQ3pCLFVBQU0wQixTQUFTLEdBQUcxQixZQUFZLENBQUN5QyxPQUFiLENBQXFCbEQsYUFBckIsRUFBb0MsR0FBcEMsQ0FBbEI7QUFFQSxXQUFPbUMsU0FBUDtBQUNEOztBQUdEVyxrQkFBZ0IsQ0FBQ3JDLFlBQUQsRUFBZWdCLFFBQWYsRUFBeUIwQixRQUF6QixFQUFrQztBQUNoRCxRQUFJUCxLQUFLLEdBQUcsT0FBWjs7QUFDQSxRQUFJLENBQUNuQixRQUFRLENBQUNoRixRQUFULENBQWtCbUcsS0FBbEIsQ0FBTCxFQUErQjtBQUM3QjtBQUNEOztBQUVEQSxTQUFLLEdBQUdqSCxJQUFJLENBQUNnRyxJQUFMLENBQVVsQixZQUFWLEVBQXdCbUMsS0FBeEIsQ0FBUjtBQUNBbkIsWUFBUSxHQUFHdEIsRUFBRSxDQUFDa0IsV0FBSCxDQUFldUIsS0FBZixDQUFYLENBUGdELENBUWhEO0FBQ0E7O0FBRUFuQixZQUFRLENBQUMzSixPQUFULENBQWtCeUosTUFBTSxJQUFJO0FBQzFCLFdBQUs2QixtQkFBTCxDQUF5QlIsS0FBekIsRUFBZ0NyQixNQUFoQyxFQUF3QzRCLFFBQXhDO0FBQ0QsS0FGRDtBQUdEOztBQUdEQyxxQkFBbUIsQ0FBQ0MsV0FBRCxFQUFjQyxJQUFkLEVBQW9CSCxRQUFwQixFQUE4QjtBQUMvQyxVQUFNSSxVQUFVLEdBQUc1SCxJQUFJLENBQUNnRyxJQUFMLENBQVUwQixXQUFWLEVBQXVCQyxJQUF2QixDQUFuQjtBQUNBLFVBQU03QixRQUFRLEdBQUd0QixFQUFFLENBQUNrQixXQUFILENBQWVrQyxVQUFmLENBQWpCLENBRitDLENBRy9DO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE5QixZQUFRLENBQUMzSixPQUFULENBQWlCMEwsSUFBSSxJQUFJO0FBQ3ZCLFlBQU1DLFNBQVMsR0FBRzlILElBQUksQ0FBQytILE9BQUwsQ0FBYUYsSUFBYixDQUFsQjs7QUFFQSxVQUFJQyxTQUFTLENBQUNFLFdBQVYsT0FBNEIsTUFBaEMsRUFBd0M7QUFDdEMsWUFBSUMsR0FBRyxHQUFHakksSUFBSSxDQUFDZ0csSUFBTCxDQUFVNEIsVUFBVixFQUFzQkMsSUFBdEIsQ0FBVjtBQUNBLGNBQU1LLEtBQUssR0FBRzFELEVBQUUsQ0FBQzJELFFBQUgsQ0FBWUYsR0FBWixDQUFkO0FBQ0EsY0FBTUcsSUFBSSxHQUFHRixLQUFLLENBQUNFLElBQW5CO0FBQ0FILFdBQUcsR0FBR0EsR0FBRyxDQUFDVixPQUFKLENBQVluRCxnQkFBWixFQUE4QixFQUE5QixDQUFOO0FBRUEsWUFBSWlFLFFBQVEsR0FBR3JJLElBQUksQ0FBQ3NJLFFBQUwsQ0FBY1QsSUFBZCxFQUFvQkMsU0FBcEIsQ0FBZjs7QUFDQSxZQUFJLENBQUNTLEtBQUssQ0FBQ0YsUUFBRCxDQUFWLEVBQXNCO0FBQ3BCO0FBQ0FBLGtCQUFRLEdBQUcsS0FBS0csVUFBVSxDQUFDSCxRQUFELENBQTFCO0FBQ0Q7O0FBRUQsY0FBTUksV0FBVyxHQUFHakIsUUFBUSxDQUFDYSxRQUFELENBQVIsS0FDRWIsUUFBUSxDQUFDYSxRQUFELENBQVIsR0FBcUIsRUFEdkIsQ0FBcEI7QUFFQSxjQUFNSyxTQUFTLEdBQUtELFdBQVcsQ0FBQ2QsSUFBRCxDQUFYLEtBQ0VjLFdBQVcsQ0FBQ2QsSUFBRCxDQUFYLEdBQW9CLEVBRHRCLENBQXBCO0FBR0FlLGlCQUFTLENBQUNwSixJQUFWLENBQWU7QUFDYjJJLGFBRGE7QUFFYkc7QUFGYSxTQUFmO0FBS0QsT0F0QkQsTUFzQk8sQ0FDTDtBQUNEO0FBQ0YsS0E1QkQ7QUE2QkQ7O0FBR0RoQixrQkFBZ0IsQ0FBQ3RDLFlBQUQsRUFBZWdCLFFBQWYsRUFBeUI2QyxRQUF6QixFQUFtQztBQUNqRCxRQUFJekIsS0FBSyxHQUFHLE9BQVo7O0FBQ0EsUUFBSSxDQUFDcEIsUUFBUSxDQUFDaEYsUUFBVCxDQUFrQm9HLEtBQWxCLENBQUwsRUFBK0I7QUFDN0I7QUFDRDs7QUFFRCxVQUFNVSxVQUFVLEdBQUc1SCxJQUFJLENBQUNnRyxJQUFMLENBQVVsQixZQUFWLEVBQXdCb0MsS0FBeEIsQ0FBbkI7QUFDQXBCLFlBQVEsR0FBR3RCLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZWtDLFVBQWYsQ0FBWCxDQVBpRCxDQVFqRDtBQUNBOztBQUVBOUIsWUFBUSxDQUFDM0osT0FBVCxDQUFpQjBMLElBQUksSUFBSTtBQUN2QixVQUFJdkQsV0FBVyxDQUFDNEIsSUFBWixDQUFpQjJCLElBQWpCLENBQUosRUFBNEI7QUFDMUIsWUFBSUksR0FBRyxHQUFHakksSUFBSSxDQUFDZ0csSUFBTCxDQUFVNEIsVUFBVixFQUFzQkMsSUFBdEIsQ0FBVjtBQUNBLGNBQU1LLEtBQUssR0FBRzFELEVBQUUsQ0FBQzJELFFBQUgsQ0FBWUYsR0FBWixDQUFkO0FBQ0EsY0FBTUcsSUFBSSxHQUFHRixLQUFLLENBQUNFLElBQW5CO0FBQ0FILFdBQUcsR0FBR0EsR0FBRyxDQUFDVixPQUFKLENBQVluRCxnQkFBWixFQUE4QixFQUE5QixDQUFOO0FBRUEsY0FBTTBELFNBQVMsR0FBRzlILElBQUksQ0FBQytILE9BQUwsQ0FBYUYsSUFBYixDQUFsQjtBQUNBLFlBQUlRLFFBQVEsR0FBR3JJLElBQUksQ0FBQ3NJLFFBQUwsQ0FBY1QsSUFBZCxFQUFvQkMsU0FBcEIsQ0FBZjs7QUFFQSxZQUFJLENBQUNTLEtBQUssQ0FBQ0YsUUFBRCxDQUFWLEVBQXNCO0FBQ3BCO0FBQ0FBLGtCQUFRLEdBQUcsS0FBS0csVUFBVSxDQUFDSCxRQUFELENBQTFCO0FBQ0Q7O0FBRUQsY0FBTU8sWUFBWSxHQUFHRCxRQUFRLENBQUNOLFFBQUQsQ0FBUixLQUNFTSxRQUFRLENBQUNOLFFBQUQsQ0FBUixHQUFxQixFQUR2QixDQUFyQjtBQUdBTyxvQkFBWSxDQUFDdEosSUFBYixDQUFrQjtBQUNoQjJJLGFBRGdCO0FBRWhCRztBQUZnQixTQUFsQjtBQUtELE9BdEJELE1Bc0JPLENBQ0w7QUFDRDtBQUNGLEtBMUJEO0FBMkJEO0FBR0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkFkLFdBQVMsQ0FBQ2QsU0FBRCxFQUFZSCxRQUFaLEVBQXNCQyxJQUF0QixFQUE0QnZDLFVBQTVCLEVBQXdDaUQsTUFBeEMsRUFBZ0RqQyxRQUFoRCxFQUEwRDtBQUNqRSxVQUFNNUMsR0FBRyxHQUFHbUUsSUFBSSxDQUFDbkUsR0FBTCxJQUFZbUUsSUFBeEI7QUFDQSxRQUFJO0FBQUV1QyxTQUFGO0FBQU9DO0FBQVAsUUFBZ0MzRyxHQUFwQztBQUNBLFFBQUk0RyxVQUFVLEdBQUcsS0FBakI7QUFDQSxRQUFJQyxPQUFKOztBQUVBLFFBQUlILEdBQUosRUFBUztBQUFFO0FBQ1QsVUFBSSxPQUFPQSxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0JBLFdBQUcsR0FBRyxDQUFFQSxHQUFGLENBQU47QUFDQUUsa0JBQVUsR0FBRyxJQUFiO0FBRUQsT0FKRCxNQUlPLElBQUlFLEtBQUssQ0FBQ0MsT0FBTixDQUFjTCxHQUFkLENBQUosRUFBd0I7QUFDN0JBLFdBQUcsR0FBR0EsR0FBRyxDQUFDTSxNQUFKLENBQVlySixJQUFJLElBQUksT0FBT0EsSUFBUCxLQUFnQixRQUFwQyxDQUFOO0FBQ0FpSixrQkFBVSxHQUFHRixHQUFHLENBQUNuSixNQUFqQjtBQUVELE9BSk0sTUFJQSxJQUFJLE9BQU9tSixHQUFQLEtBQWUsUUFBbkIsRUFBNkIsQ0FDbEM7QUFDQTtBQUVELE9BSk0sTUFJQTtBQUNMO0FBQ0EsY0FBTTFDLE9BQU8sK0JBQXdCcEIsUUFBeEIsNkRBRVhzQixRQUZXLDREQUFiO0FBS0EsYUFBSzFCLEdBQUwsQ0FBU3dCLE9BQVQ7QUFDQSxlQUFPLENBQUMsQ0FBUjtBQUNEO0FBQ0Y7O0FBRUQsVUFBTTFJLE1BQU0sR0FBRztBQUFFdUMsVUFBSSxFQUFFd0c7QUFBUixLQUFmO0FBQ0EsVUFBTUUsUUFBUSxHQUFHLEtBQUtDLHNCQUFMLENBQ2ZOLFFBRGUsRUFFZnRDLFVBRmUsRUFHZnRHLE1BSGUsQ0FBakI7QUFLQSxTQUFLMkwsTUFBTCxDQUFZakgsR0FBWixFQUFpQnFFLFNBQWpCLEVBQTRCUSxNQUFNLENBQUNKLElBQW5DLEVBQXlDN0MsVUFBekMsRUFBcUQyQyxRQUFyRCxFQXJDaUUsQ0FzQ2pFO0FBQ0E7O0FBRUEsUUFBSXFDLFVBQVUsS0FBS0MsT0FBTyxHQUFHMUMsSUFBSSxDQUFDMEMsT0FBcEIsQ0FBZCxFQUE0QztBQUMxQztBQUNBLFdBQUtLLGtCQUFMLENBQ0VMLE9BREYsRUFFRWhDLE1BRkYsRUFHRTZCLEdBSEYsRUFJRUMsb0JBSkYsRUFGMEMsQ0FTMUM7O0FBQ0EsV0FBS1EsWUFBTCxDQUFrQk4sT0FBbEIsRUFBMkJqRixVQUEzQixFQVYwQyxDQVcxQztBQUNEOztBQUVELFVBQU13RixHQUFHLEdBQUcsS0FBS0MsU0FBTCxDQUFlbkQsUUFBZixFQUF5QkMsSUFBekIsQ0FBWjtBQUVBdkMsY0FBVSxDQUFDckcsTUFBWCxDQUFrQjtBQUFFSixTQUFHLEVBQUU2RSxHQUFHLENBQUM3RTtBQUFYLEtBQWxCLEVBQW9DO0FBQUVLLFVBQUksRUFBRTtBQUFFNEw7QUFBRjtBQUFSLEtBQXBDO0FBRUEsV0FBTyxDQUFQLENBM0RpRSxDQTJEeEQ7QUFDVjs7QUFHREgsUUFBTSxDQUFDakgsR0FBRCxFQUFNcUUsU0FBTixFQUFpQkksSUFBakIsRUFBdUI3QyxVQUF2QixFQUFtQ3pHLEdBQW5DLEVBQXdDO0FBQzVDLFFBQUlBLEdBQUcsS0FBSyxJQUFaLEVBQWtCO0FBQ2hCQSxTQUFHLEdBQUc2RSxHQUFHLENBQUM3RSxHQUFWO0FBQ0Q7O0FBRUQsUUFBSXNKLElBQUosRUFBVTtBQUNSekUsU0FBRyxDQUFDeUUsSUFBSixHQUFXQSxJQUFYO0FBQ0Q7O0FBRUR6RSxPQUFHLENBQUNuQyxJQUFKLEdBQVd3RyxTQUFYO0FBQ0EsVUFBTWlELE1BQU0sR0FBR2pELFNBQVMsQ0FBQ2tELEtBQVYsQ0FBZ0IsR0FBaEIsQ0FBZjtBQUNBRCxVQUFNLENBQUNFLEdBQVA7QUFDQXhILE9BQUcsQ0FBQ3NILE1BQUosR0FBYUEsTUFBTSxDQUFDekQsSUFBUCxDQUFZLEdBQVosQ0FBYjs7QUFFQSxRQUFJMUksR0FBSixFQUFTO0FBQ1B5RyxnQkFBVSxDQUFDckcsTUFBWCxDQUFrQjtBQUFFSjtBQUFGLE9BQWxCLEVBQTJCNkUsR0FBM0IsRUFBZ0M7QUFBRXlILGNBQU0sRUFBRTtBQUFWLE9BQWhDO0FBRUQsS0FIRCxNQUdPO0FBQ0x0TSxTQUFHLEdBQUd5RyxVQUFVLENBQUM1RyxNQUFYLENBQWtCZ0YsR0FBbEIsQ0FBTjtBQUNBQSxTQUFHLENBQUM3RSxHQUFKLEdBQVVBLEdBQVY7QUFDRDtBQUNGOztBQUdEK0wsb0JBQWtCLENBQUNMLE9BQUQsRUFBU2hDLE1BQVQsRUFBZ0I2QyxRQUFoQixFQUF5QmYsb0JBQXpCLEVBQStDO0FBQy9ELFVBQU03QixLQUFLLEdBQUdELE1BQU0sQ0FBQ0MsS0FBckI7QUFDQSxVQUFNQyxLQUFLLEdBQUdGLE1BQU0sQ0FBQ0UsS0FBckI7QUFFQThCLFdBQU8sQ0FBQzdNLE9BQVIsQ0FBaUIyTixVQUFVLElBQUk7QUFDN0IsVUFBSUMsSUFBSSxHQUFHRCxVQUFVLENBQUNDLElBQXRCO0FBQ0EsVUFBSUMsTUFBTSxHQUFHRixVQUFVLENBQUNFLE1BQXhCLENBRjZCLENBSTdCO0FBQ0E7O0FBQ0EsWUFBTUMsVUFBVSxHQUFJLE9BQU9ELE1BQVAsS0FBa0IsUUFBdEM7QUFDQSxZQUFNRSxTQUFTLEdBQUdELFVBQVUsR0FDVjVHLE1BQU0sQ0FBQzhHLElBQVAsQ0FBWUgsTUFBWixDQURVLEdBRVYsQ0FBRSxlQUFGLENBRmxCO0FBR0EsWUFBTXJDLElBQUksR0FBR3VDLFNBQVMsQ0FBQyxDQUFELENBQXRCOztBQUVBLFVBQUksQ0FBQzNCLEtBQUssQ0FBQ3dCLElBQUQsQ0FBVixFQUFrQjtBQUNoQkEsWUFBSSxHQUFHLEtBQUt2QixVQUFVLENBQUN1QixJQUFELENBQXRCO0FBQ0Q7O0FBRUQsVUFBSUssS0FBSjs7QUFDQSxVQUFJSCxVQUFKLEVBQWdCO0FBQ2RHLGFBQUssR0FBR25ELEtBQUssQ0FBQzhDLElBQUQsQ0FBYjs7QUFDQSxZQUFJSyxLQUFKLEVBQVc7QUFDVE4sb0JBQVUsQ0FBQzdDLEtBQVgsR0FBbUJtRCxLQUFuQjs7QUFFQSxjQUFJLENBQUN0QixvQkFBTCxFQUEyQjtBQUN6QixrQkFBTXVCLGdCQUFnQixHQUFHLEtBQUtDLFVBQUwsQ0FBZ0JKLFNBQWhCLEVBQTJCRSxLQUEzQixDQUF6Qjs7QUFDQSxnQkFBSUMsZ0JBQUosRUFBc0I7QUFDcEIsbUJBQUsxRixHQUFMLENBQVMsb0NBQ0NtRixVQUFVLENBQUNDLElBRFosR0FFQyxJQUZELEdBRVFRLElBQUksQ0FBQ0MsU0FBTCxDQUFlSCxnQkFBZixDQUZSLEdBR0MsS0FIRCxHQUdTTCxNQUFNLENBQUNyQyxJQUFELENBSGYsR0FHd0IsSUFIakM7QUFLRDtBQUNGO0FBRUYsU0FkRCxNQWNPLElBQUksQ0FBQ21CLG9CQUFMLEVBQTJCO0FBQ2hDLGVBQUtuRSxHQUFMLENBQVMsb0NBQ0NtRixVQUFVLENBQUNDLElBRFosR0FFQyxhQUZELEdBRWlCQyxNQUFNLENBQUNyQyxJQUFELENBRnZCLEdBRWdDLElBRnpDO0FBSUQ7QUFDRixPQXRCRCxNQXNCTztBQUNMO0FBQ0E7QUFDQXFDLGNBQU0sR0FBRztBQUFFLDJCQUFpQjtBQUFuQixTQUFUO0FBQ0Q7O0FBRURJLFdBQUssR0FBR2xELEtBQUssQ0FBQzZDLElBQUQsQ0FBYjs7QUFDQSxVQUFJSyxLQUFKLEVBQVc7QUFDVE4sa0JBQVUsQ0FBQzVDLEtBQVgsR0FBbUJrRCxLQUFuQjtBQUNELE9BRkQsTUFFTyxJQUFJLENBQUN0QixvQkFBTCxFQUEyQjtBQUNoQyxhQUFLbkUsR0FBTCxDQUFVLG9DQUNBbUYsVUFBVSxDQUFDQyxJQURYLEdBRUEsYUFGQSxHQUVnQkMsTUFBTSxDQUFDckMsSUFBRCxDQUZ0QixHQUUrQixJQUZ6QztBQUlEOztBQUVEbUMsZ0JBQVUsQ0FBQ1csSUFBWCxHQUFrQixDQUFFLElBQUlYLFVBQVUsQ0FBQ1csSUFBWCxJQUFtQixFQUF2QixDQUFGLEVBQThCLEdBQUdaLFFBQWpDLEVBQ0NWLE1BREQsQ0FDUSxDQUFFTixHQUFGLEVBQU9oSixLQUFQLEVBQWM2SyxLQUFkLEtBQ05BLEtBQUssQ0FBQ0MsT0FBTixDQUFjOUIsR0FBZCxNQUF1QmhKLEtBRnpCLENBQWxCO0FBSUQsS0EzREQ7QUE0REQ7O0FBR0R5SyxZQUFVLENBQUNKLFNBQUQsRUFBWUUsS0FBWixFQUFtQjtBQUMzQixVQUFNUSxTQUFTLEdBQUd2SCxNQUFNLENBQUM4RyxJQUFQLENBQVlDLEtBQVosQ0FBbEI7QUFDQSxVQUFNUyxPQUFPLEdBQUdYLFNBQVMsQ0FBQ2YsTUFBVixDQUFrQnhCLElBQUksSUFDcEMsQ0FBQ2lELFNBQVMsQ0FBQzlKLFFBQVYsQ0FBbUI2RyxJQUFuQixDQURhLENBQWhCOztBQUlBLFFBQUksQ0FBQ2tELE9BQU8sQ0FBQ25MLE1BQWIsRUFBcUI7QUFDbkIsYUFBTyxDQUFQO0FBQ0Q7O0FBRUQsV0FBT21MLE9BQVA7QUFDRDs7QUFHRHZCLGNBQVksQ0FBQ04sT0FBRCxFQUFVakYsVUFBVixFQUFzQjtBQUNoQ2lGLFdBQU8sQ0FBQzdNLE9BQVIsQ0FBaUIyTixVQUFVLElBQUk7QUFDN0IsVUFBSTtBQUFFeE07QUFBRixVQUFVd00sVUFBZDs7QUFFQSxVQUFJeE0sR0FBSixFQUFTO0FBQ1B5RyxrQkFBVSxDQUFDckcsTUFBWCxDQUFrQjtBQUFFSjtBQUFGLFNBQWxCLEVBQTJCd00sVUFBM0IsRUFBdUM7QUFBRUYsZ0JBQU0sRUFBRTtBQUFWLFNBQXZDO0FBRUQsT0FIRCxNQUdPO0FBQ0x0TSxXQUFHLEdBQUd5RyxVQUFVLENBQUM1RyxNQUFYLENBQW1CMk0sVUFBbkIsQ0FBTjtBQUNBQSxrQkFBVSxDQUFDeE0sR0FBWCxHQUFpQkEsR0FBakI7QUFDRDtBQUNGLEtBVkQ7QUFXRDs7QUFHRHlKLGlCQUFlLENBQ1RqQyxZQURTLEVBRVRXLFVBRlMsRUFHVG1CLElBSFMsRUFJVEosU0FKUyxFQUtUSCxRQUxTLEVBTVRDLElBTlMsRUFPVHZDLFVBUFMsRUFRVGdCLFFBUlMsRUFTVDtBQUVKO0FBQ0E7QUFFQTtBQUNBLFVBQU0rRixTQUFTLEdBQUdyRixVQUFVLENBQUMwRCxNQUFYLENBQWtCckosSUFBSSxJQUFJeUUsVUFBVSxDQUFDMkIsSUFBWCxDQUFnQnBHLElBQWhCLENBQTFCLENBQWxCO0FBQ0FyQixjQUFVLENBQUNnSCxVQUFELEVBQWEzRixJQUFJLElBQUlnTCxTQUFTLENBQUNoSyxRQUFWLENBQW1CaEIsSUFBbkIsQ0FBckIsRUFBK0MsSUFBL0MsQ0FBVjtBQUVBLFNBQUt3SCxTQUFMLENBQWVkLFNBQWYsRUFBMEJILFFBQTFCLEVBQW9DQyxJQUFwQyxFQUEwQ3ZDLFVBQTFDLEVBQXNEO0FBQUU2QztBQUFGLEtBQXRELEVBQWdFN0IsUUFBaEU7QUFFQVUsY0FBVSxDQUFDdEosT0FBWCxDQUFtQnlKLE1BQU0sSUFBSTtBQUMzQkEsWUFBTSxHQUFHNUYsSUFBSSxDQUFDZ0csSUFBTCxDQUFVbEIsWUFBVixFQUF3QmMsTUFBeEIsQ0FBVCxDQUQyQixDQUczQjs7QUFDRSxZQUFNRSxRQUFRLEdBQUd0QixFQUFFLENBQUNrQixXQUFILENBQWVFLE1BQWYsQ0FBakI7QUFDQSxXQUFLRCxXQUFMLENBQWlCWixRQUFqQixFQUEyQmEsTUFBM0IsRUFBbUNFLFFBQW5DLEVBTHlCLENBTzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsS0FkRDtBQWVEOztBQXZqQitDLEM7Ozs7Ozs7Ozs7O0FDOUJsRGpMLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJb0o7QUFBYixDQUFkO0FBQXNDLElBQUk0RyxRQUFKLEVBQWF0TSxVQUFiO0FBQXdCNUQsTUFBTSxDQUFDSyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQzZQLFVBQVEsQ0FBQzVQLENBQUQsRUFBRztBQUFDNFAsWUFBUSxHQUFDNVAsQ0FBVDtBQUFXLEdBQXhCOztBQUF5QnNELFlBQVUsQ0FBQ3RELENBQUQsRUFBRztBQUFDc0QsY0FBVSxHQUFDdEQsQ0FBWDtBQUFhOztBQUFwRCxDQUEvQyxFQUFxRyxDQUFyRztBQUF3RyxJQUFJaUosZ0JBQUosRUFBcUI0RyxRQUFyQixFQUE4QnpHLFVBQTlCLEVBQXlDMEcsVUFBekM7QUFBb0RwUSxNQUFNLENBQUNLLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDa0osa0JBQWdCLENBQUNqSixDQUFELEVBQUc7QUFBQ2lKLG9CQUFnQixHQUFDakosQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDNlAsVUFBUSxDQUFDN1AsQ0FBRCxFQUFHO0FBQUM2UCxZQUFRLEdBQUM3UCxDQUFUO0FBQVcsR0FBaEU7O0FBQWlFb0osWUFBVSxDQUFDcEosQ0FBRCxFQUFHO0FBQUNvSixjQUFVLEdBQUNwSixDQUFYO0FBQWEsR0FBNUY7O0FBQTZGOFAsWUFBVSxDQUFDOVAsQ0FBRCxFQUFHO0FBQUM4UCxjQUFVLEdBQUM5UCxDQUFYO0FBQWE7O0FBQXhILENBQTlDLEVBQXdLLENBQXhLOztBQWdCMU4sTUFBTXFKLEVBQUUsR0FBR0MsT0FBTyxDQUFDLElBQUQsQ0FBbEI7O0FBQ0EsTUFBTXpFLElBQUksR0FBR3lFLE9BQU8sQ0FBQyxNQUFELENBQXBCLEMsQ0FJQTs7O0FBQ0EsSUFBSXlHLE1BQU0sR0FBRyxDQUFiOztBQUllLE1BQU0vRyxRQUFOLENBQWU7QUFDNUJ6SSxhQUFXLENBQUNpSixHQUFELEVBQU07QUFDZixTQUFLQSxHQUFMLEdBQVdBLEdBQVg7QUFDRDtBQUdEOzs7Ozs7Ozs7Ozs7Ozs7OztBQWVBZ0Msd0JBQXNCLENBQUNOLFFBQUQsRUFBV3RDLFVBQVgsRUFBdUJ0RyxNQUF2QixFQUErQjtBQUNuRDtBQUVBLFVBQU15SyxLQUFLLEdBQUsxRCxFQUFFLENBQUMyRCxRQUFILENBQVk5QixRQUFaLENBQWhCO0FBQ0EsVUFBTWtELEdBQUcsR0FBT3JCLEtBQUssQ0FBQ2lELE9BQXRCO0FBQ0EsVUFBTXZMLE9BQU8sR0FBRztBQUFFckQsWUFBTSxFQUFFO0FBQUVnTixXQUFHLEVBQUU7QUFBUDtBQUFWLEtBQWhCO0FBQ0EsVUFBTXZILEdBQUcsR0FBTytCLFVBQVUsQ0FBQ3pILE9BQVgsQ0FBbUJtQixNQUFuQixFQUEyQm1DLE9BQTNCLENBQWhCLENBTm1ELENBUW5EOztBQUVBLFdBQU8sSUFBUDs7QUFFQSxRQUFJb0MsR0FBSixFQUFTO0FBQ1AsVUFBSUEsR0FBRyxDQUFDdUgsR0FBSixLQUFZQSxHQUFoQixFQUFxQjtBQUNuQixlQUFPLEtBQVA7QUFDRDs7QUFFRCxhQUFPdkgsR0FBRyxDQUFDMUUsR0FBWDtBQUNEOztBQUVELFdBQU8sSUFBUDtBQUNEO0FBR0Q7Ozs7Ozs7Ozs7Ozs7O0FBWUFpSixjQUFZLENBQUN6QixZQUFELEVBQWVnQixRQUFmLEVBQXlCO0FBQ25DLFVBQU1nRixTQUFTLEdBQUdoRixRQUFRLENBQUNxRCxNQUFULENBQ2hCdEIsSUFBSSxJQUFJdEQsVUFBVSxDQUFDMkIsSUFBWCxDQUFnQjJCLElBQWhCLENBRFEsQ0FBbEIsQ0FEbUMsQ0FLbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsUUFBSWlELFNBQVMsQ0FBQ3BMLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDMUIsWUFBTXlHLE9BQU8sd0NBQ2lCLEtBQUtwQixRQUR0QiwwRUFHVHdGLElBQUksQ0FBQ0MsU0FBTCxDQUFlTSxTQUFmLENBSFMsc0JBQWI7QUFLQSxXQUFLbkcsR0FBTCxDQUFTd0IsT0FBVCxFQU4wQixDQU8xQjs7QUFDQSxhQUFPLEVBQVA7QUFDRCxLQXRCa0MsQ0F3Qm5DO0FBQ0E7OztBQUNBMUgsY0FBVSxDQUFDcUgsUUFBRCxFQUFXaEcsSUFBSSxJQUFJZ0wsU0FBUyxDQUFDaEssUUFBVixDQUFtQmhCLElBQW5CLENBQW5CLEVBQTZDLElBQTdDLENBQVYsQ0ExQm1DLENBMkJuQzs7QUFFQSxVQUFNdUcsUUFBUSxHQUFHckcsSUFBSSxDQUFDZ0csSUFBTCxDQUFVbEIsWUFBVixFQUF3QmdHLFNBQVMsQ0FBQyxDQUFELENBQWpDLENBQWpCO0FBRUEsUUFBSXhFLElBQUosQ0EvQm1DLENBZ0NuQzs7QUFDRUEsUUFBSSxHQUFHOUIsRUFBRSxDQUFDNEcsWUFBSCxDQUFnQi9FLFFBQWhCLENBQVA7QUFDQUMsUUFBSSxHQUFHaUUsSUFBSSxDQUFDYyxLQUFMLENBQVcvRSxJQUFYLENBQVAsQ0FsQ2lDLENBb0NuQztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUEsV0FBTztBQUNMRCxjQURLO0FBRUxDO0FBRkssS0FBUDtBQUlEOztBQUdEa0QsV0FBUyxDQUFDbkQsUUFBRCxFQUFXQyxJQUFYLEVBQWlCO0FBQ3hCO0FBQ0E7QUFDQTtBQUVBLFFBQUlnRixNQUFNLENBQUNDLGFBQVgsRUFBMEI7QUFDeEIsWUFBTUMsUUFBUSxHQUFHLENBQUNwUCxHQUFELEVBQU1xUCxLQUFOLEtBQWtCclAsR0FBRyxLQUFLLEtBQVIsR0FDQXNQLFNBREEsR0FFQUQsS0FGbkM7O0FBSUEsWUFBTUUsVUFBVSxHQUFHcEIsSUFBSSxDQUFDQyxTQUFMLENBQWVsRSxJQUFmLEVBQXFCa0YsUUFBckIsRUFBK0IsSUFBL0IsQ0FBbkI7QUFFQWhILFFBQUUsQ0FBQ29ILGFBQUgsQ0FBaUJ2RixRQUFqQixFQUEyQnNGLFVBQTNCO0FBQ0Q7O0FBQ0QsVUFBTXpELEtBQUssR0FBRzFELEVBQUUsQ0FBQzJELFFBQUgsQ0FBWTlCLFFBQVosQ0FBZDtBQUNBLFVBQU1rRCxHQUFHLEdBQUdyQixLQUFLLENBQUNpRCxPQUFsQjtBQUVBLFdBQU81QixHQUFQO0FBQ0Q7QUFHRDs7Ozs7Ozs7Ozs7Ozs7QUFZQTFDLFlBQVUsQ0FBQy9CLFlBQUQsRUFBZWdCLFFBQWYsRUFBeUI7QUFDakMsVUFBTStGLE9BQU8sR0FBRyxFQUFoQjtBQUVBLFFBQUlDLEtBQUssR0FBR2hHLFFBQVEsQ0FBQ3FELE1BQVQsQ0FBZ0J0QixJQUFJLElBQUlvRCxVQUFVLENBQUMvRSxJQUFYLENBQWdCMkIsSUFBaEIsQ0FBeEIsQ0FBWixDQUhpQyxDQUtqQztBQUNBOztBQUNBcEosY0FBVSxDQUFDcUgsUUFBRCxFQUFXaEcsSUFBSSxJQUFJZ00sS0FBSyxDQUFDaEwsUUFBTixDQUFlaEIsSUFBZixDQUFuQixFQUF5QyxJQUF6QyxDQUFWO0FBRUEsUUFBSThHLElBQUosRUFDSW1GLFFBREo7O0FBR0EsUUFBSSxDQUFDRCxLQUFLLENBQUNwTSxNQUFYLEVBQW1CO0FBQ2pCb00sV0FBSyxDQUFDeE0sSUFBTixDQUFXLEtBQUswTSxzQkFBTCxDQUE0QmxILFlBQTVCLENBQVg7QUFDRDs7QUFFRCxRQUFJZ0gsS0FBSyxDQUFDaEwsUUFBTixDQUFlLE1BQWYsQ0FBSixFQUE0QjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUVBOEYsVUFBSSxHQUFHLE1BQVA7QUFDQW1GLGNBQVEsR0FBRy9MLElBQUksQ0FBQ2dHLElBQUwsQ0FBVWxCLFlBQVYsRUFBd0I4QixJQUF4QixDQUFYO0FBQ0FrRixXQUFLLEdBQUd0SCxFQUFFLENBQUNrQixXQUFILENBQWVxRyxRQUFmLENBQVI7QUFFQSxVQUFJRSxNQUFNLEdBQUdILEtBQUssQ0FBQzNDLE1BQU4sQ0FBYXZDLElBQUksSUFBSW9FLFFBQVEsQ0FBQzlFLElBQVQsQ0FBY1UsSUFBZCxDQUFyQixDQUFiOztBQUVBLFVBQUlxRixNQUFNLENBQUN2TSxNQUFYLEVBQW1CLENBQ2pCO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsY0FBTXlHLE9BQU8sbUVBQytCNEYsUUFEL0Isd0NBRU14QixJQUFJLENBQUNDLFNBQUwsQ0FBZXNCLEtBQWYsQ0FGTixrRUFBYjtBQUtBLGFBQUtuSCxHQUFMLENBQVN3QixPQUFUO0FBRUEyRixhQUFLLENBQUN4TSxJQUFOLENBQVcsS0FBSzBNLHNCQUFMLENBQTRCRCxRQUE1QixFQUFzQyxJQUF0QyxDQUFYO0FBQ0Q7O0FBRURBLGNBQVEsSUFBSSxLQUFaLENBekIwQixDQXlCUjs7QUFDbEJGLGFBQU8sQ0FBQ0MsS0FBUixHQUFnQkEsS0FBaEI7QUFFRCxLQTVCRCxNQTRCTztBQUNMQyxjQUFRLEdBQUcvTCxJQUFJLENBQUNnRyxJQUFMLENBQVVsQixZQUFWLEVBQXdCZ0gsS0FBSyxDQUFDLENBQUQsQ0FBN0IsQ0FBWDtBQUNEOztBQUVERCxXQUFPLENBQUM1RCxHQUFSLEdBQWM4RCxRQUFRLENBQUN4RSxPQUFULENBQWlCbkQsZ0JBQWpCLEVBQW1DLEVBQW5DLENBQWQ7QUFFQSxXQUFPeUgsT0FBUDtBQUNEO0FBR0Q7Ozs7Ozs7Ozs7O0FBU0FHLHdCQUFzQixDQUFDbEgsWUFBRCxFQUE0QjtBQUFBLFFBQWJpRixJQUFhLHVFQUFSLE1BQVE7QUFDaEQsVUFBTW1DLFFBQVEsR0FBR25DLElBQUksR0FBRyxNQUF4QjtBQUNBLFVBQU1vQyxNQUFNLEdBQUdwQixRQUFRLENBQUM7QUFBRUcsWUFBTSxFQUFFQSxNQUFNLEVBQWhCO0FBQW9Ca0IsWUFBTSxFQUFFO0FBQTVCLEtBQUQsQ0FBdkI7QUFDQSxVQUFNQyxHQUFHLDBNQVVIRixNQVZHLHVIQUFUO0FBcUJBLFVBQU1KLFFBQVEsR0FBRy9MLElBQUksQ0FBQ2dHLElBQUwsQ0FBVWxCLFlBQVYsRUFBd0JvSCxRQUF4QixDQUFqQjtBQUNBMUgsTUFBRSxDQUFDb0gsYUFBSCxDQUFpQkcsUUFBakIsRUFBMkJNLEdBQTNCO0FBRUEsV0FBT0gsUUFBUDtBQUNEOztBQTdPMkIsQzs7Ozs7Ozs7Ozs7QUMxQjlCclIsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUltSjtBQUFiLENBQWQ7O0FBa0JlLE1BQU1BLEdBQU4sQ0FBUztBQUN0QnhJLGFBQVcsR0FBRztBQUNaLFNBQUs0USxRQUFMLEdBQWdCLEVBQWhCO0FBQ0EsU0FBSzFILFFBQUwsR0FBZ0IsS0FBS0EsUUFBTCxDQUFjMkgsSUFBZCxDQUFtQixJQUFuQixDQUFoQjtBQUNBLFNBQUtwSCxJQUFMLEdBQVksS0FBS0EsSUFBTCxDQUFVb0gsSUFBVixDQUFlLElBQWYsQ0FBWjtBQUNEOztBQUVEM0gsVUFBUSxDQUFDdUIsT0FBRCxFQUFVO0FBQ2hCLFNBQUttRyxRQUFMLElBQWlCLE9BQU9uRyxPQUF4QjtBQUNEOztBQUVEaEIsTUFBSSxHQUFHLENBQ0w7QUFDRDs7QUFicUIsQzs7Ozs7Ozs7Ozs7QUNsQnhCdEssTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUl5UjtBQUFiLENBQWQ7QUFBdUMsSUFBSUMsU0FBSjtBQUFjNVIsTUFBTSxDQUFDSyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQ3VSLFdBQVMsQ0FBQ3RSLENBQUQsRUFBRztBQUFDc1IsYUFBUyxHQUFDdFIsQ0FBVjtBQUFZOztBQUExQixDQUEvQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJRyxXQUFKO0FBQWdCVCxNQUFNLENBQUNLLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBakQsRUFBNkUsQ0FBN0U7QUFTbkosTUFBTTtBQUFFdVI7QUFBRixJQUFjcFIsV0FBcEIsQyxDQUdBOztBQUNBLE1BQU1xUixXQUFXLEdBQU0sQ0FBdkIsQyxDQUF5Qjs7QUFDekIsTUFBTUMsU0FBUyxHQUFRLElBQXZCLEMsQ0FBNEI7O0FBQzVCLE1BQU9DLGFBQWEsR0FBRyxLQUFLLElBQTVCLEMsQ0FDQTs7QUFHZSxNQUFNTCxTQUFOLENBQWdCO0FBQzdCOVEsYUFBVyxPQUE0QztBQUFBLFFBQTNDO0FBQUV3QixhQUFGO0FBQVdvQixjQUFYO0FBQXFCd08sYUFBckI7QUFBOEJDO0FBQTlCLEtBQTJDO0FBQ3JELFNBQUs3UCxPQUFMLEdBQWlCQSxPQUFqQjtBQUNBLFNBQUtvQixRQUFMLEdBQWlCQSxRQUFqQjtBQUNBLFNBQUt3TyxPQUFMLEdBQWlCQSxPQUFqQjtBQUNBLFNBQUtDLFNBQUwsR0FBaUJBLFNBQWpCO0FBRUEsU0FBS0MsV0FBTCxHQUFtQixLQUFLQSxXQUFMLENBQWlCVCxJQUFqQixDQUFzQixJQUF0QixDQUFuQjtBQUNBLFVBQU1VLEdBQUcsR0FBRzVKLE1BQU0sQ0FBQzhHLElBQVAsQ0FBWTJDLE9BQVosQ0FBWjtBQUNBLFNBQUtJLEtBQUwsR0FBYUQsR0FBRyxDQUFDdk4sTUFBakI7QUFFQXVOLE9BQUcsQ0FBQzlRLE9BQUosQ0FBWSxLQUFLNlEsV0FBakI7QUFDRDs7QUFHREcsU0FBTyxDQUFDQyxLQUFELEVBQVE7QUFDYixRQUFJLENBQUNBLEtBQUwsRUFBWTtBQUNWQSxXQUFLLEdBQUcsQ0FBRSxJQUFJQyxJQUFKLEVBQVY7QUFDRDs7QUFDRCxXQUFPLElBQUlBLElBQUosQ0FBU0QsS0FBVCxFQUFnQkUsWUFBaEIsR0FBK0JDLFNBQS9CLENBQXlDLENBQXpDLEVBQTJDLENBQTNDLENBQVA7QUFDRDs7QUFHRFAsYUFBVyxDQUFDUSxTQUFELEVBQVk7QUFFckIsVUFBTS9QLE1BQU0sR0FBRztBQUNiUCxhQUFPLEVBQUUsS0FBS0EsT0FERDtBQUVib0IsY0FBUSxFQUFFLEtBQUtBLFFBRkY7QUFHYmtQO0FBSGEsS0FBZjtBQU1BLFVBQU1DLFVBQVUsR0FBR2YsT0FBTyxDQUFDcFEsT0FBUixDQUFnQm1CLE1BQWhCLENBQW5CO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQTs7QUFDQSxVQUFNcVAsT0FBTyxHQUFHLEtBQUtBLE9BQUwsQ0FBYVUsU0FBYixDQUFoQjtBQUNBLFVBQU1FLFNBQVMsR0FBRyxDQUFFLElBQUlMLElBQUosRUFBcEI7QUFDQSxRQUFJTSxTQUFKO0FBRUEsUUFBSTtBQUFFQyxXQUFGO0FBQVNDLGdCQUFUO0FBQXFCQyxnQkFBckI7QUFBaUNDO0FBQWpDLFFBQTZDTixVQUFqRDtBQUVBRyxTQUFLLEdBQUksS0FBSyxDQUFDZCxPQUFQLElBQW1CYyxLQUFLLElBQUksQ0FBNUIsQ0FBUjs7QUFFQSxRQUFJLENBQUNDLFVBQUwsRUFBaUI7QUFDZkMsZ0JBQVUsR0FBR0osU0FBYjs7QUFFQSxVQUFJWixPQUFKLEVBQWE7QUFDWGlCLGVBQU8sR0FBR25CLFNBQVMsR0FBR0QsV0FBdEI7QUFDQWdCLGlCQUFTLEdBQUdHLFVBQVUsR0FBSWxCLFNBQVMsR0FBR0MsYUFBdEMsQ0FGVyxDQUdYO0FBQ0Q7QUFDRjs7QUFFRCxVQUFNbUIsS0FBSyxHQUFHbEIsT0FBTyxHQUNQVyxVQUFVLENBQUNRLEtBQVgsSUFBb0IsQ0FEYixHQUVQUixVQUFVLENBQUNTLEtBQVgsSUFBb0IsSUFBRSxDQUZwQztBQUdBSCxXQUFPLEdBQUdJLElBQUksQ0FBQ0MsR0FBTCxDQUFVekIsV0FBVixFQUF1QnFCLEtBQUssR0FBR0QsT0FBL0IsQ0FBVjs7QUFFQSxRQUFJLENBQUNKLFNBQUwsRUFBZ0I7QUFDZEEsZUFBUyxHQUFHLEtBQUtVLFVBQUwsQ0FBZ0JYLFNBQWhCLEVBQTJCSyxPQUEzQixDQUFaO0FBQ0Q7O0FBQ0RGLGNBQVUsSUFBSSxDQUFkO0FBRUEsVUFBTTFMLEdBQUcsR0FBRztBQUNWeEUsVUFBSSxFQUFFO0FBQ0ppUSxhQURJO0FBRUpDLGtCQUZJO0FBR0pDLGtCQUhJLENBR087QUFIUDtBQUlKSixpQkFKSSxDQUlPO0FBSlA7QUFLSkMsaUJBTEk7QUFNSkk7QUFOSTtBQURJLEtBQVo7QUFVQXJCLFdBQU8sQ0FBQ2hQLE1BQVIsQ0FBZUQsTUFBZixFQUF1QjBFLEdBQXZCO0FBQ0Q7QUFHRDs7Ozs7Ozs7Ozs7QUFTQWtNLFlBQVUsQ0FBQ0MsR0FBRCxFQUFNUCxPQUFOLEVBQWVDLEtBQWYsRUFBc0I7QUFDOUIsUUFBSUwsU0FBSjtBQUNBLFFBQUlZLFNBQVMsR0FBRyxLQUFLeEIsU0FBckI7QUFFQSxVQUFNdFAsTUFBTSxHQUFHLEVBQWY7QUFDQSxVQUFNbUMsT0FBTyxHQUFHO0FBQ2RuRCxVQUFJLEVBQUU7QUFBRWtSLGlCQUFTLEVBQUU7QUFBYixPQURRO0FBRWRhLFdBQUssRUFBRSxDQUZPO0FBR2RDLFVBQUksRUFBRSxLQUFLdkIsS0FBTCxHQUFhYSxPQUhMO0FBSWR4UixZQUFNLEVBQUU7QUFBRW9SLGlCQUFTLEVBQUUsQ0FBYjtBQUFnQjNELGNBQU0sRUFBRTtBQUF4QjtBQUpNLEtBQWhCLENBTDhCLENBWTlCO0FBQ0E7QUFDQTs7QUFDQSxVQUFNMEUsU0FBUyxHQUFJWCxPQUFPLEdBQUdwQixXQUFYLEdBQTBCRSxhQUE1QyxDQWY4QixDQWlCOUI7QUFDQTtBQUNBOztBQUNBLFVBQU04QixLQUFLLEdBQU9qQyxPQUFPLENBQUNqTSxJQUFSLENBQWFoRCxNQUFiLEVBQXFCbUMsT0FBckIsRUFBOEJjLEtBQTlCLEdBQXNDLENBQXRDLENBQWxCO0FBQ0EsUUFBSWtPLFNBQVMsR0FBRyxLQUFLN0IsU0FBTCxHQUFpQjJCLFNBQWpDO0FBRUF0SSxXQUFPLENBQUN6QixHQUFSLENBQWEsUUFBYixFQUF1QmdLLEtBQXZCLEVBQ2EsaUNBQ0FwRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTVLLE9BQU8sQ0FBQ3JELE1BQXZCLENBREEsR0FFQSxTQUZBLEdBR0FnTyxJQUFJLENBQUNDLFNBQUwsQ0FBZTVLLE9BQU8sQ0FBQ25ELElBQXZCLENBSEEsR0FJQSxTQUpBLEdBS0FtRCxPQUFPLENBQUM2TyxJQUxSLEdBTUEsVUFOQSxHQU9BN08sT0FBTyxDQUFDNE8sS0FQUixHQVFBLEdBVGIsRUF2QjhCLENBbUM5QjtBQUNBOztBQUNBNU8sV0FBTyxDQUFDNk8sSUFBUixHQUFlLEtBQUt2QixLQUFMLEdBQWEsQ0FBYixHQUFpQmEsT0FBTyxHQUFHLENBQTFDO0FBQ0EsVUFBTWMsSUFBSSxHQUFHbkMsT0FBTyxDQUFDak0sSUFBUixDQUFhaEQsTUFBYixFQUFxQm1DLE9BQXJCLEVBQThCYyxLQUE5QixHQUFzQyxDQUF0QyxDQUFiO0FBQ0EsUUFBSW9PLFFBQVEsR0FBRyxLQUFLL0IsU0FBTCxHQUFpQjJCLFNBQVMsR0FBRyxDQUE1QyxDQXZDOEIsQ0F5QzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsUUFBSUMsS0FBSixFQUFXO0FBQ1QsVUFBSUUsSUFBSixFQUFVO0FBQ1IsWUFBSUMsUUFBUSxHQUFHRCxJQUFJLENBQUNsQixTQUFwQixFQUErQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQW1CLGtCQUFRLEdBQUdELElBQUksQ0FBQ2xCLFNBQWhCO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJaUIsU0FBUyxHQUFHRCxLQUFLLENBQUNoQixTQUF0QixFQUFpQztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBaUIsaUJBQVMsR0FBR0QsS0FBSyxDQUFDaEIsU0FBbEI7QUFFRCxPQVBELE1BT08sSUFBSWlCLFNBQVMsR0FBR04sR0FBaEIsRUFBcUI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQU0saUJBQVMsR0FBR0QsS0FBSyxDQUFDaEIsU0FBbEIsQ0FMMEIsQ0FPMUI7QUFDQTs7QUFDQSxZQUFJbUIsUUFBUSxHQUFHRixTQUFmLEVBQTBCO0FBQ3hCRSxrQkFBUSxHQUFHRixTQUFTLEdBQUdGLFNBQXZCO0FBQ0Q7QUFFRixPQWJNLE1BYUE7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBRSxpQkFBUyxHQUFHVCxJQUFJLENBQUNZLEdBQUwsQ0FBU1QsR0FBRyxHQUFHSSxTQUFmLEVBQTBCQyxLQUFLLENBQUNoQixTQUFoQyxDQUFaO0FBQ0FtQixnQkFBUSxHQUFJWCxJQUFJLENBQUNZLEdBQUwsQ0FBU1QsR0FBRyxHQUFHSSxTQUFTLEdBQUcsQ0FBM0IsRUFBOEJHLElBQUksQ0FBQ2xCLFNBQW5DLENBQVo7QUFDRDtBQUVGLEtBdkNELE1BdUNPO0FBQ0w7QUFDQTtBQUNBaUIsZUFBUyxHQUFHTixHQUFHLEdBQUdJLFNBQWxCO0FBQ0FJLGNBQVEsR0FBSVIsR0FBRyxHQUFHSSxTQUFTLEdBQUcsQ0FBOUI7QUFDRCxLQXBHNkIsQ0FzRzlCOzs7QUFDQWYsYUFBUyxHQUFHbEIsU0FBUyxDQUFDcUMsUUFBRCxFQUFXRixTQUFYLENBQXJCO0FBRUEsV0FBT2pCLFNBQVA7QUFDRDs7QUFqTjRCLEM7Ozs7Ozs7Ozs7O0FDbkIvQixJQUFJcUIsYUFBSjs7QUFBa0JuVSxNQUFNLENBQUNLLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDNlQsaUJBQWEsR0FBQzdULENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCTixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDbVUsZUFBYSxFQUFDLE1BQUlBLGFBQW5CO0FBQWlDQyxhQUFXLEVBQUMsTUFBSUEsV0FBakQ7QUFBNkRDLE9BQUssRUFBQyxNQUFJQSxLQUF2RTtBQUE2RUMsY0FBWSxFQUFDLE1BQUlBLFlBQTlGO0FBQTJHQyxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBaEk7QUFBaUpDLFFBQU0sRUFBQyxNQUFJQSxNQUE1SjtBQUFtS0MsT0FBSyxFQUFDLE1BQUlBLEtBQTdLO0FBQW1MQyxTQUFPLEVBQUMsTUFBSUEsT0FBL0w7QUFBdU1DLFVBQVEsRUFBQyxNQUFJQSxRQUFwTjtBQUE2TkMsY0FBWSxFQUFDLE1BQUlBLFlBQTlPO0FBQTJQQyxZQUFVLEVBQUMsTUFBSUE7QUFBMVEsQ0FBZDtBQUFxUyxJQUFJckUsTUFBSjtBQUFXelEsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDb1EsUUFBTSxDQUFDblEsQ0FBRCxFQUFHO0FBQUNtUSxVQUFNLEdBQUNuUSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5VSxZQUFKO0FBQWlCL1UsTUFBTSxDQUFDSyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDeVUsZ0JBQVksR0FBQ3pVLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTRILEtBQUo7QUFBVWxJLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQzRILFNBQUssR0FBQzVILENBQU47QUFBUTs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTBJLE1BQUo7QUFBV2hKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUMwSSxVQUFNLEdBQUMxSSxDQUFQO0FBQVM7O0FBQXJCLENBQTdCLEVBQW9ELENBQXBEO0FBQXVELElBQUlxRCxTQUFKO0FBQWMzRCxNQUFNLENBQUNLLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNxRCxhQUFTLEdBQUNyRCxDQUFWO0FBQVk7O0FBQXhCLENBQTNCLEVBQXFELENBQXJEO0FBQXdELElBQUlnRyxVQUFKO0FBQWV0RyxNQUFNLENBQUNLLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNnRyxjQUFVLEdBQUNoRyxDQUFYO0FBQWE7O0FBQXpCLENBQTVCLEVBQXVELENBQXZEO0FBQTBELElBQUkyQyxXQUFKO0FBQWdCakQsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDMkMsZUFBVyxHQUFDM0MsQ0FBWjtBQUFjOztBQUExQixDQUE1QixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJb0ksWUFBSjtBQUFpQjFJLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNvSSxnQkFBWSxHQUFDcEksQ0FBYjtBQUFlOztBQUEzQixDQUFuQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJSCxhQUFKO0FBQWtCSCxNQUFNLENBQUNLLElBQVAsQ0FBWSxpQkFBWixFQUE4QjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDSCxpQkFBYSxHQUFDRyxDQUFkO0FBQWdCOztBQUE1QixDQUE5QixFQUE0RCxDQUE1RDtBQUErRCxJQUFJaUMsZ0JBQUo7QUFBcUJ2QyxNQUFNLENBQUNLLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDaUMsb0JBQWdCLEdBQUNqQyxDQUFqQjtBQUFtQjs7QUFBL0IsQ0FBL0IsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSXFSLFNBQUo7QUFBYzNSLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNxUixhQUFTLEdBQUNyUixDQUFWO0FBQVk7O0FBQXhCLENBQWxDLEVBQTRELEVBQTVEO0FBQWdFLElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUF2QyxFQUFtRSxFQUFuRTtBQStEdm1DLE1BQU07QUFBRU0sT0FBRjtBQUFTaVIsU0FBVDtBQUFrQm1EO0FBQWxCLElBQWlDdlUsV0FBdkMsQyxDQUNBOztBQUdBOzs7O0FBR08sTUFBTTJULGFBQWEsR0FBRztBQUMzQmxGLE1BQUksRUFBRSx1QkFEcUI7O0FBRzNCK0YsTUFBSSxDQUFDblUsV0FBRCxFQUFjb1UsUUFBZCxFQUF3QjtBQUMxQixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDcE8sV0FBRCxDQUF4QixFQUF1Q2lFLE9BQXZDLEVBQWdEbVEsUUFBaEQ7QUFDRCxHQVYwQjs7QUFZM0JJLFVBQVEsQ0FBQ3hVLFdBQUQsRUFBYztBQUNwQixRQUFJaVUsWUFBSixDQUFpQjtBQUNmL1MsY0FBUSxFQUFFO0FBQUV1VCxZQUFJLEVBQUVDO0FBQVIsT0FESztBQUVmdlQsWUFBTSxFQUFJO0FBQUVzVCxZQUFJLEVBQUVDO0FBQVIsT0FGSztBQUdmcFMsYUFBTyxFQUFHO0FBQUVtUyxZQUFJLEVBQUVDO0FBQVIsT0FISztBQUlmblMsY0FBUSxFQUFFO0FBQUVrUyxZQUFJLEVBQUVDO0FBQVIsT0FKSztBQUtmdFQsWUFBTSxFQUFJO0FBQUVxVCxZQUFJLEVBQUVDO0FBQVIsT0FMSyxDQU9qQjtBQVBpQjtBQVFmN1MsWUFBTSxFQUFJO0FBQUU0UyxZQUFJLEVBQUVDLE1BQVI7QUFBZ0JDLGdCQUFRLEVBQUU7QUFBMUI7QUFSSyxLQUFqQixFQVNHSCxRQVRILENBU1l4VSxXQVRaO0FBVUQsR0F2QjBCOztBQXlCM0I0VSxLQUFHLENBQUM1VSxXQUFELEVBQWM7QUFDZixRQUFJWCxhQUFKLENBQWtCVyxXQUFsQixFQURlLENBQ2dCO0FBRS9COztBQUVBLFFBQUlvSCxLQUFKLENBQVVwSCxXQUFWLEVBTGUsQ0FLWTtBQUUzQjs7QUFFQSxXQUFPQSxXQUFQO0FBQ0Q7O0FBbkMwQixDQUF0QjtBQTJDQSxNQUFNdVQsV0FBVyxHQUFHO0FBQ3pCbkYsTUFBSSxFQUFFLHFCQURtQjs7QUFHekIrRixNQUFJLENBQUNuVSxXQUFELEVBQWNvVSxRQUFkLEVBQXdCO0FBQzFCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNwTyxXQUFELENBQXhCLEVBQXVDaUUsT0FBdkMsRUFBZ0RtUSxRQUFoRDtBQUNELEdBVndCOztBQVl6QkksVUFBUSxDQUFDeFUsV0FBRCxFQUFjO0FBQ3BCLFFBQUlpVSxZQUFKLENBQWlCO0FBQ2YxUyxhQUFPLEVBQUU7QUFBRWtULFlBQUksRUFBRUM7QUFBUixPQURNO0FBRWZwUyxhQUFPLEVBQUc7QUFBRW1TLFlBQUksRUFBRUM7QUFBUixPQUZLO0FBR2ZuUyxjQUFRLEVBQUU7QUFBRWtTLFlBQUksRUFBRUM7QUFBUixPQUhLLENBS2pCO0FBTGlCO0FBTWZ4VCxjQUFRLEVBQUU7QUFBRXVULFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQixPQU5LO0FBT2Z4VCxZQUFNLEVBQUk7QUFBRXNULFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQixPQVBLO0FBUWZ2VCxZQUFNLEVBQUk7QUFBRXFULFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQixPQVJLO0FBU2Y5UyxZQUFNLEVBQUk7QUFBRTRTLFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQjtBQVRLLEtBQWpCLEVBVUdILFFBVkgsQ0FVWXhVLFdBVlo7QUFXRCxHQXhCd0I7O0FBMEJ6QjRVLEtBQUcsQ0FBQzVVLFdBQUQsRUFBYztBQUNmLFFBQUltQyxXQUFKLENBQWdCbkMsV0FBaEIsRUFEZSxDQUNjOztBQUM3QixRQUFJNkMsU0FBSixDQUFjN0MsV0FBZCxFQUZlLENBRWM7O0FBRTdCLFdBQU9BLFdBQVA7QUFDRDs7QUEvQndCLENBQXBCO0FBeUNBLE1BQU13VCxLQUFLLEdBQUc7QUFDbkJwRixNQUFJLEVBQUUsZUFEYTs7QUFHbkIrRixNQUFJLENBQUNVLFNBQUQsRUFBWVQsUUFBWixFQUFzQjtBQUN4QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDeUcsU0FBRCxDQUF4QixFQUFxQzVRLE9BQXJDLEVBQThDbVEsUUFBOUM7QUFDRCxHQVZrQjs7QUFZbkJJLFVBQVEsQ0FBQ0ssU0FBRCxFQUFZO0FBQ2xCO0FBQ0EsUUFBSVosWUFBSixDQUFpQjtBQUNmL1MsY0FBUSxFQUFFO0FBQUV1VCxZQUFJLEVBQUVDO0FBQVIsT0FESztBQUVmdFQsWUFBTSxFQUFJO0FBQUVxVCxZQUFJLEVBQUVDO0FBQVIsT0FGSztBQUlmMVEsaUJBQVcsRUFBRTtBQUFFeVEsWUFBSSxFQUFFSyxPQUFSO0FBQWlCSCxnQkFBUSxFQUFFO0FBQTNCLE9BSkUsQ0FNakI7QUFOaUI7QUFPZnhULFlBQU0sRUFBSTtBQUFFc1QsWUFBSSxFQUFFQyxNQUFSO0FBQWdCQyxnQkFBUSxFQUFFO0FBQTFCLE9BUEssQ0FPNEI7QUFQNUI7QUFRZnJTLGFBQU8sRUFBRztBQUFFbVMsWUFBSSxFQUFFQyxNQUFSO0FBQWdCQyxnQkFBUSxFQUFFO0FBQTFCLE9BUkssQ0FRNEI7QUFSNUI7QUFTZnBTLGNBQVEsRUFBRTtBQUFFa1MsWUFBSSxFQUFFQyxNQUFSO0FBQWdCQyxnQkFBUSxFQUFFO0FBQTFCLE9BVEssQ0FTNEI7QUFUNUI7QUFXZjNULFlBQU0sRUFBSTtBQUFFeVQsWUFBSSxFQUFFQyxNQUFSO0FBQWdCQyxnQkFBUSxFQUFFO0FBQTFCLE9BWEssQ0FXNEI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWhCaUI7QUFpQmZJLGVBQVMsRUFBQztBQUFFTixZQUFJLEVBQUVLLE9BQVI7QUFBaUJILGdCQUFRLEVBQUU7QUFBM0IsT0FqQks7QUFrQmZyVSxZQUFNLEVBQUk7QUFBRW1VLFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQixPQWxCSyxDQW9CakI7QUFwQmlCO0FBcUJmcFQsYUFBTyxFQUFHO0FBQUVrVCxZQUFJLEVBQUVDLE1BQVI7QUFBZ0JDLGdCQUFRLEVBQUU7QUFBMUIsT0FyQks7QUFzQmZoUyxjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUMsTUFBUjtBQUFnQkMsZ0JBQVEsRUFBRTtBQUExQixPQXRCSztBQXVCZjFULGFBQU8sRUFBRztBQUFFd1QsWUFBSSxFQUFFQyxNQUFSO0FBQWdCQyxnQkFBUSxFQUFFO0FBQTFCLE9BdkJLLENBeUJqQjtBQXpCaUI7QUEwQmY5VCxhQUFPLEVBQUc7QUFBRTRULFlBQUksRUFBRU8sTUFBUjtBQUFnQkwsZ0JBQVEsRUFBRTtBQUExQjtBQTFCSyxLQUFqQixFQTJCR0gsUUEzQkgsQ0EyQllLLFNBM0JaO0FBNEJELEdBMUNrQjs7QUE0Q25CRCxLQUFHLENBQUNDLFNBQUQsRUFBWTtBQUNiLFFBQUl6TixLQUFKLENBQVV5TixTQUFWO0FBRUEsUUFBSTtBQUFFdlU7QUFBRixRQUFhdVUsU0FBakI7O0FBRUEsWUFBUXZVLE1BQVI7QUFDRTtBQUNBLFdBQUssZUFBTDtBQUNFZ1QscUJBQWEsQ0FBQ3NCLEdBQWQsQ0FBa0JDLFNBQWxCO0FBQTZCOztBQUMvQixXQUFLLGFBQUw7QUFDRXRCLG1CQUFXLENBQUNxQixHQUFaLENBQWdCQyxTQUFoQixFQURGLENBQytCOztBQUM3QixlQUFPQSxTQUFQO0FBRUY7O0FBQ0EsV0FBSyxVQUFMO0FBQ0UsWUFBSWhTLFNBQUosQ0FBY2dTLFNBQWQsRUFERixDQUMyQjs7QUFDekIsWUFBSUEsU0FBUyxDQUFDdlUsTUFBVixLQUFxQixhQUF6QixFQUF3QztBQUN0Q2lULHFCQUFXLENBQUNxQixHQUFaLENBQWdCQyxTQUFoQjtBQUNEOztBQUVIOztBQUNBLFdBQUssWUFBTDtBQUNFLGVBQU9BLFNBQVA7O0FBRUY7QUFDRSxjQUFNLHVDQUF1Q2hULE1BQXZDLEdBQWdELEdBQXREO0FBcEJKO0FBc0JEOztBQXZFa0IsQ0FBZDtBQWdGQSxNQUFNNFIsWUFBWSxHQUFHO0FBQzFCckYsTUFBSSxFQUFFLHNCQURvQjs7QUFHMUIrRixNQUFJLENBQUNVLFNBQUQsRUFBWVQsUUFBWixFQUFzQjtBQUN4QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDeUcsU0FBRCxDQUF4QixFQUFxQzVRLE9BQXJDLEVBQThDbVEsUUFBOUM7QUFDRCxHQVZ5Qjs7QUFZMUJJLFVBQVEsQ0FBQ0ssU0FBRCxFQUFZO0FBQ2xCLFFBQUlaLFlBQUosQ0FBaUI7QUFDZnJPLFFBQUUsRUFBUTtBQUFFNk8sWUFBSSxFQUFFQztBQUFSLE9BREs7QUFFZnRULFlBQU0sRUFBSTtBQUFFcVQsWUFBSSxFQUFFQztBQUFSO0FBRkssS0FBakIsRUFHR0YsUUFISCxDQUdZSyxTQUhaO0FBSUQsR0FqQnlCOztBQW1CMUJELEtBQUcsQ0FBQ0MsU0FBRCxFQUFZO0FBQ2IsUUFBSWpOLFlBQUosQ0FBaUJpTixTQUFqQjtBQUNBLFdBQU9BLFNBQVA7QUFDRDs7QUF0QnlCLENBQXJCO0FBK0JBLE1BQU1uQixnQkFBZ0IsR0FBRztBQUM5QnRGLE1BQUksRUFBRSwwQkFEd0I7O0FBRzlCK0YsTUFBSSxDQUFDelMsU0FBRCxFQUFZMFMsUUFBWixFQUFzQjtBQUN4QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDMU0sU0FBRCxDQUF4QixFQUFxQ3VDLE9BQXJDLEVBQThDbVEsUUFBOUM7QUFDRCxHQVY2Qjs7QUFZOUJJLFVBQVEsQ0FBQzlTLFNBQUQsRUFBWTtBQUNsQixRQUFJdVMsWUFBSixDQUFpQjtBQUNmdFMsU0FBRyxFQUFLO0FBQUU4UyxZQUFJLEVBQUVDO0FBQVIsT0FETztBQUVmdFQsWUFBTSxFQUFFO0FBQUVxVCxZQUFJLEVBQUVDO0FBQVIsT0FGTztBQUdmOVMsWUFBTSxFQUFFO0FBQUU2UyxZQUFJLEVBQUVLO0FBQVI7QUFITyxLQUFqQixFQUlHTixRQUpILENBSVk5UyxTQUpaO0FBS0QsR0FsQjZCOztBQW9COUJrVCxLQUFHLENBQUNsVCxTQUFELEVBQVk7QUFDYixRQUFJRCxnQkFBSixDQUFxQkMsU0FBckI7QUFDQSxXQUFPQSxTQUFQO0FBQ0Q7O0FBdkI2QixDQUF6QjtBQWdDQSxNQUFNaVMsTUFBTSxHQUFHO0FBQ3BCdkYsTUFBSSxFQUFFLGFBRGM7O0FBR3BCK0YsTUFBSSxDQUFDaE0sVUFBRCxFQUFhaU0sUUFBYixFQUF1QjtBQUN6QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDakcsVUFBRCxDQUF4QixFQUFzQ2xFLE9BQXRDLEVBQStDbVEsUUFBL0M7QUFDRCxHQVZtQjs7QUFZcEJJLFVBQVEsQ0FBQ3JNLFVBQUQsRUFBYTtBQUNuQixRQUFJOEwsWUFBSixDQUFpQjtBQUNmck8sUUFBRSxFQUFRO0FBQUU2TyxZQUFJLEVBQUVDO0FBQVIsT0FESyxDQUVmO0FBQ0E7QUFIZTtBQUlmdFQsWUFBTSxFQUFJO0FBQUVxVCxZQUFJLEVBQUVDO0FBQVIsT0FKSyxDQUtmO0FBQ0Y7O0FBTmlCLEtBQWpCLEVBT0dGLFFBUEgsQ0FPWXJNLFVBUFo7QUFRRCxHQXJCbUI7O0FBdUJwQnlNLEtBQUcsQ0FBQ3pNLFVBQUQsRUFBYTtBQUNkLFFBQUkzQyxVQUFKLENBQWUyQyxVQUFmLEVBRGMsQ0FDYTs7QUFDM0IsUUFBSUQsTUFBSixDQUFXQyxVQUFYO0FBRUEsV0FBT0EsVUFBUDtBQUNEOztBQTVCbUIsQ0FBZjtBQW1DQSxNQUFNeUwsS0FBSyxHQUFHO0FBQ25CeEYsTUFBSSxFQUFFLGVBRGE7O0FBR25CK0YsTUFBSSxDQUFDYyxTQUFELEVBQVliLFFBQVosRUFBc0I7QUFDeEIsVUFBTW5RLE9BQU8sR0FBRztBQUNkb1EscUJBQWUsRUFBRSxJQURIO0FBRWRDLHlCQUFtQixFQUFFO0FBRlAsS0FBaEI7QUFLQTNFLFVBQU0sQ0FBQzRFLEtBQVAsQ0FBYSxLQUFLbkcsSUFBbEIsRUFBd0IsQ0FBQzZHLFNBQUQsQ0FBeEIsRUFBcUNoUixPQUFyQyxFQUE4Q21RLFFBQTlDO0FBQ0QsR0FWa0I7O0FBWW5CSSxVQUFRLENBQUNTLFNBQUQsRUFBWTtBQUNsQixRQUFJaEIsWUFBSixDQUFpQjtBQUNmdFMsU0FBRyxFQUFHO0FBQUU4UyxZQUFJLEVBQUVDO0FBQVIsT0FEUztBQUVmalUsU0FBRyxFQUFHO0FBQUVnVSxZQUFJLEVBQUVDO0FBQVIsT0FGUztBQUdmUSxVQUFJLEVBQUVqQixZQUFZLENBQUNrQixLQUFiLENBQ0o7QUFBRVYsWUFBSSxFQUFFQztBQUFSLE9BREksRUFFSjtBQUFFRCxZQUFJLEVBQUUvTSxNQUFSO0FBQWdCME4sZ0JBQVEsRUFBRTtBQUExQixPQUZJO0FBSFMsS0FBakIsRUFPR1osUUFQSCxDQU9ZUyxTQVBaO0FBUUQsR0FyQmtCOztBQXVCbkJMLEtBQUcsQ0FBQ0ssU0FBRCxFQUFZO0FBQ2IsVUFBTTtBQUFFdFQsU0FBRjtBQUFPbEIsU0FBUDtBQUFZeVU7QUFBWixRQUFxQkQsU0FBM0I7QUFDQSxVQUFNblQsTUFBTSxHQUFHO0FBQUVIO0FBQUYsS0FBZjtBQUNBLFVBQU02RSxHQUFHLEdBQU07QUFBRXhFLFVBQUksRUFBRTtBQUFFLFNBQUN2QixHQUFELEdBQU95VTtBQUFUO0FBQVIsS0FBZjtBQUNBcFYsU0FBSyxDQUFDaUMsTUFBTixDQUFhRCxNQUFiLEVBQXFCMEUsR0FBckIsRUFKYSxDQU1iO0FBQ0Q7O0FBOUJrQixDQUFkO0FBa0NBLE1BQU1xTixPQUFPLEdBQUc7QUFDckJ6RixNQUFJLEVBQUUsaUJBRGU7O0FBR3JCK0YsTUFBSSxDQUFDa0IsV0FBRCxFQUFjakIsUUFBZCxFQUF3QjtBQUMxQixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDaUgsV0FBRCxDQUF4QixFQUF1Q3BSLE9BQXZDLEVBQWdEbVEsUUFBaEQ7QUFDRCxHQVZvQjs7QUFZckJJLFVBQVEsQ0FBQ2EsV0FBRCxFQUFjO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBRUEsVUFBTUMsU0FBUyxHQUFHLElBQUlyQixZQUFZLENBQUNrQixLQUFqQixDQUNoQjtBQUFFVixVQUFJLEVBQUVDO0FBQVIsS0FEZ0IsRUFFaEI7QUFBRUQsVUFBSSxFQUFFbkg7QUFBUixLQUZnQixDQUFsQjtBQUtBLFFBQUkyRyxZQUFKLENBQWlCO0FBQ2Z0UixjQUFRLEVBQU07QUFBRThSLFlBQUksRUFBRUM7QUFBUixPQURDO0FBRWZyUixVQUFJLEVBQVU7QUFBRW9SLFlBQUksRUFBRS9NO0FBQVIsT0FGQztBQUdmLG1CQUFjO0FBQUUrTSxZQUFJLEVBQUVDLE1BQVI7QUFBaUJDLGdCQUFRLEVBQUU7QUFBM0IsT0FIQztBQUlmLG1CQUFjO0FBQUVGLFlBQUksRUFBRUMsTUFBUjtBQUFpQkMsZ0JBQVEsRUFBRTtBQUEzQixPQUpDO0FBS2Ysb0JBQWM7QUFBRUYsWUFBSSxFQUFFTyxNQUFSO0FBQWlCTCxnQkFBUSxFQUFFO0FBQTNCLE9BTEMsQ0FNakI7QUFOaUI7QUFPZixrQkFBYztBQUFFRixZQUFJLEVBQUVhLFNBQVI7QUFBbUJYLGdCQUFRLEVBQUU7QUFBN0IsT0FQQztBQVFmLG9CQUFjO0FBQUVGLFlBQUksRUFBRUM7QUFBUixPQVJDO0FBU2YsbUJBQWM7QUFDWkQsWUFBSSxFQUFFL00sTUFETTtBQUVaaU4sZ0JBQVEsRUFBRSxJQUZFO0FBR1pTLGdCQUFRLEVBQUU7QUFIRTtBQVRDLEtBQWpCLEVBY0daLFFBZEgsQ0FjWWEsV0FkWjtBQWVELEdBdENvQjs7QUF3Q3JCVCxLQUFHLENBQUNTLFdBQUQsRUFBYztBQUNmLFVBQU07QUFBRTFTLGNBQVEsRUFBRWhCLEdBQVo7QUFBaUIwQjtBQUFqQixRQUEwQmdTLFdBQWhDO0FBQ0EsVUFBTXZULE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNNkUsR0FBRyxHQUFNO0FBQUV4RSxVQUFJLEVBQUU7QUFBRXFCO0FBQUY7QUFBUixLQUFmO0FBQ0F2RCxTQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUIwRSxHQUFyQixFQUplLENBTWY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQXREb0IsQ0FBaEI7QUEwREEsTUFBTXNOLFFBQVEsR0FBRztBQUN0QjFGLE1BQUksRUFBRSxrQkFEZ0I7O0FBR3RCK0YsTUFBSSxDQUFDb0IsWUFBRCxFQUFlbkIsUUFBZixFQUF5QjtBQUMzQixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDbUgsWUFBRCxDQUF4QixFQUF3Q3RSLE9BQXhDLEVBQWlEbVEsUUFBakQ7QUFDRCxHQVZxQjs7QUFZdEJJLFVBQVEsQ0FBQ2UsWUFBRCxFQUFlO0FBQ3JCLFFBQUl0QixZQUFKLENBQWlCO0FBQ2Z0UixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUixPQURLO0FBRWZ4USxXQUFLLEVBQUs7QUFBRXVRLFlBQUksRUFBRU87QUFBUjtBQUZLLEtBQWpCLEVBR0dSLFFBSEgsQ0FHWWUsWUFIWjtBQUlELEdBakJxQjs7QUFtQnRCWCxLQUFHLENBQUNXLFlBQUQsRUFBZTtBQUNoQixVQUFNO0FBQUU1UyxjQUFRLEVBQUVoQixHQUFaO0FBQWlCdUM7QUFBakIsUUFBMkJxUixZQUFqQztBQUNBLFVBQU16VCxNQUFNLEdBQUc7QUFBRUg7QUFBRixLQUFmO0FBQ0EsVUFBTTZFLEdBQUcsR0FBRztBQUFFeEUsVUFBSSxFQUFFO0FBQUUsc0JBQWNrQztBQUFoQjtBQUFSLEtBQVo7QUFDQXBFLFNBQUssQ0FBQ2lDLE1BQU4sQ0FBYUQsTUFBYixFQUFxQjBFLEdBQXJCO0FBQ0Q7O0FBeEJxQixDQUFqQjtBQTRCQSxNQUFNdU4sWUFBWSxHQUFHO0FBQzFCM0YsTUFBSSxFQUFFLHlCQURvQjs7QUFHMUIrRixNQUFJLENBQUNxQixnQkFBRCxFQUFtQnBCLFFBQW5CLEVBQTZCO0FBQy9CLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNvSCxnQkFBRCxDQUF4QixFQUE0Q3ZSLE9BQTVDLEVBQXFEbVEsUUFBckQ7QUFDRCxHQVZ5Qjs7QUFZMUJJLFVBQVEsQ0FBQ2dCLGdCQUFELEVBQW1CO0FBQ3pCQSxvQkFBZ0IsQ0FBQ2hWLE9BQWpCLENBQTBCMkQsSUFBSSxJQUFJO0FBQ2hDLFVBQUk4UCxZQUFKLENBQWlCO0FBQ2JwQyxpQkFBUyxFQUFHO0FBQUU0QyxjQUFJLEVBQUVDO0FBQVIsU0FEQztBQUViblQsZUFBTyxFQUFLO0FBQUVrVCxjQUFJLEVBQUVDO0FBQVIsU0FGQztBQUdiL1IsZ0JBQVEsRUFBSTtBQUFFOFIsY0FBSSxFQUFFQztBQUFSLFNBSEM7QUFJYjFDLGlCQUFTLEVBQUc7QUFBRXlDLGNBQUksRUFBRU87QUFBUjtBQUpDLE9BQWpCLEVBS0dSLFFBTEgsQ0FLWXJRLElBTFo7QUFNRCxLQVBEO0FBUUQsR0FyQnlCOztBQXVCMUJ5USxLQUFHLENBQUNZLGdCQUFELEVBQW1CO0FBQ3BCLFVBQU1DLE9BQU8sR0FBRztBQUNkdkQsZ0JBQVUsRUFBRSxDQURFO0FBRWRDLGdCQUFVLEVBQUUsQ0FGRTtBQUdkSixlQUFTLEVBQUcsQ0FIRTtBQUlkRSxXQUFLLEVBQU8sQ0FKRTtBQUtkeUQsV0FBSyxFQUFPLENBTEU7QUFNZHRELGFBQU8sRUFBSyxDQU5FLENBTUE7QUFDaEI7QUFDQTtBQVJnQjtBQVNkaEssZ0JBQVUsRUFBRSxZQVRFO0FBVWR1TixXQUFLLEVBQU87QUFWRSxLQUFoQjtBQWFBSCxvQkFBZ0IsQ0FBQ2hWLE9BQWpCLENBQTBCb1YsYUFBYSxJQUFJO0FBQ3pDQSxtQkFBYSxxQkFBT0EsYUFBUCxNQUF5QkgsT0FBekIsQ0FBYjtBQUNBMUUsYUFBTyxDQUFDdlAsTUFBUixDQUFlb1UsYUFBZjtBQUNELEtBSEQ7QUFJRDs7QUF6Q3lCLENBQXJCO0FBNkNBLE1BQU01QixVQUFVLEdBQUc7QUFDeEI1RixNQUFJLEVBQUUsb0JBRGtCOztBQUd4QitGLE1BQUksQ0FBQzBCLGNBQUQsRUFBaUJ6QixRQUFqQixFQUEyQjtBQUM3QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDeUgsY0FBRCxDQUF4QixFQUEwQzVSLE9BQTFDLEVBQW1EbVEsUUFBbkQ7QUFDRCxHQVZ1Qjs7QUFZeEJJLFVBQVEsQ0FBQ3FCLGNBQUQsRUFBaUI7QUFDdkIsUUFBSTVCLFlBQUosQ0FBaUI7QUFDZjFTLGFBQU8sRUFBSTtBQUFFa1QsWUFBSSxFQUFFQztBQUFSLE9BREk7QUFFZi9SLGNBQVEsRUFBRztBQUFFOFIsWUFBSSxFQUFFQztBQUFSLE9BRkk7QUFHZnZELGFBQU8sRUFBSTtBQUFFc0QsWUFBSSxFQUFFL00sTUFBUjtBQUFnQjBOLGdCQUFRLEVBQUU7QUFBMUIsT0FISTtBQUlmaEUsZUFBUyxFQUFFO0FBQUVxRCxZQUFJLEVBQUVPO0FBQVI7QUFKSSxLQUFqQixFQUtHUixRQUxILENBS1lxQixjQUxaO0FBTUQsR0FuQnVCOztBQXFCeEJqQixLQUFHLENBQUNpQixjQUFELEVBQWlCO0FBQ2xCLFFBQUloRixTQUFKLENBQWNnRixjQUFkO0FBQ0Q7O0FBdkJ1QixDQUFuQjtBQTRCUDtBQUNBLE1BQU1DLE9BQU8sR0FBRyxDQUNkeEMsYUFEYyxFQUVaQyxXQUZZLEVBR1pDLEtBSFksRUFJWkcsTUFKWSxFQUtaRixZQUxZLEVBTVpDLGdCQU5ZLEVBT1pFLEtBUFksRUFRWkMsT0FSWSxFQVNaQyxRQVRZLEVBVVpDLFlBVlksRUFXWkMsVUFYWSxDQUFoQjtBQWdCQThCLE9BQU8sQ0FBQ3RWLE9BQVIsQ0FBZ0J1VixNQUFNLElBQUk7QUFDeEJwRyxRQUFNLENBQUNtRyxPQUFQLENBQWU7QUFDYixLQUFDQyxNQUFNLENBQUMzSCxJQUFSLEdBQWUsVUFBVTRILElBQVYsRUFBZ0I7QUFDN0JELFlBQU0sQ0FBQ3ZCLFFBQVAsQ0FBZ0JMLElBQWhCLENBQXFCLElBQXJCLEVBQTJCNkIsSUFBM0I7QUFDQSxhQUFPRCxNQUFNLENBQUNuQixHQUFQLENBQVdULElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0I2QixJQUF0QixDQUFQO0FBQ0Q7QUFKWSxHQUFmO0FBTUQsQ0FQRCxFOzs7Ozs7Ozs7OztBQzloQkE5VyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDOFcsY0FBWSxFQUFDLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSXRHLE1BQUo7QUFBV3pRLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ29RLFFBQU0sQ0FBQ25RLENBQUQsRUFBRztBQUFDbVEsVUFBTSxHQUFDblEsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVUsWUFBSjtBQUFpQi9VLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ3lVLGdCQUFZLEdBQUN6VSxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUk4SSxZQUFKO0FBQWlCcEosTUFBTSxDQUFDSyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQzhJLGdCQUFZLEdBQUM5SSxDQUFiO0FBQWU7O0FBQTNCLENBQXBDLEVBQWlFLENBQWpFO0FBQW9FLElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUF2QyxFQUFtRSxDQUFuRTtBQVdoUyxNQUFNO0FBQUVNO0FBQUYsSUFBWUgsV0FBbEIsQyxDQUNBOztBQUdBOzs7O0FBR08sTUFBTXNXLFlBQVksR0FBRztBQUMxQjdILE1BQUksRUFBRSxxQkFEb0I7O0FBRzFCK0YsTUFBSSxDQUFDK0IsVUFBRCxFQUFhOUIsUUFBYixFQUF1QjtBQUN6QixVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDOEgsVUFBRCxDQUF4QixFQUFzQ2pTLE9BQXRDLEVBQStDbVEsUUFBL0M7QUFDRCxHQVZ5Qjs7QUFZMUJJLFVBQVEsQ0FBQzBCLFVBQUQsRUFBYSxDQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDRCxHQXZCeUI7O0FBeUIxQnRCLEtBQUcsQ0FBQ3NCLFVBQUQsRUFBYTtBQUNkLFFBQUk1TixZQUFKLENBQWlCNE4sVUFBakI7QUFDRDs7QUEzQnlCLENBQXJCO0FBK0JQO0FBQ0EsTUFBTUosT0FBTyxHQUFHLENBQ2RHLFlBRGMsQ0FBaEI7QUFJQUgsT0FBTyxDQUFDdFYsT0FBUixDQUFnQnVWLE1BQU0sSUFBSTtBQUN4QnBHLFFBQU0sQ0FBQ21HLE9BQVAsQ0FBZTtBQUNiLEtBQUNDLE1BQU0sQ0FBQzNILElBQVIsR0FBZSxVQUFVNEgsSUFBVixFQUFnQjtBQUM3QkQsWUFBTSxDQUFDdkIsUUFBUCxDQUFnQkwsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkI2QixJQUEzQjtBQUNBLGFBQU9ELE1BQU0sQ0FBQ25CLEdBQVAsQ0FBV1QsSUFBWCxDQUFnQixJQUFoQixFQUFzQjZCLElBQXRCLENBQVA7QUFDRDtBQUpZLEdBQWY7QUFNRCxDQVBELEU7Ozs7Ozs7Ozs7O0FDdERBLElBQUkzQyxhQUFKOztBQUFrQm5VLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUM2VCxpQkFBYSxHQUFDN1QsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEJOLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUMyVyxTQUFPLEVBQUMsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlLLEtBQUo7QUFBVWpYLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQzJXLFNBQUssR0FBQzNXLENBQU47QUFBUTs7QUFBaEIsQ0FBdEIsRUFBd0MsQ0FBeEM7QUFBMkMsSUFBSTZMLE1BQUo7QUFBV25NLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQzZMLFVBQU0sR0FBQzdMLENBQVA7QUFBUzs7QUFBakIsQ0FBdkIsRUFBMEMsQ0FBMUM7QUFBNkMsSUFBSTRXLElBQUo7QUFBU2xYLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHlDQUFaLEVBQXNEO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUM0VyxRQUFJLEdBQUM1VyxDQUFMO0FBQU87O0FBQWYsQ0FBdEQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSTZXLEtBQUo7QUFBVW5YLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDBDQUFaLEVBQXVEO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUM2VyxTQUFLLEdBQUM3VyxDQUFOO0FBQVE7O0FBQWhCLENBQXZELEVBQXlFLENBQXpFO0FBQTRFLElBQUk4VyxNQUFKO0FBQVdwWCxNQUFNLENBQUNLLElBQVAsQ0FBWSwyQ0FBWixFQUF3RDtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDOFcsVUFBTSxHQUFDOVcsQ0FBUDtBQUFTOztBQUFqQixDQUF4RCxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJK1csVUFBSjtBQUFlclgsTUFBTSxDQUFDSyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQytXLGNBQVUsR0FBQy9XLENBQVg7QUFBYTs7QUFBckIsQ0FBNUQsRUFBbUYsQ0FBbkY7O0FBMEI1WixNQUFNc1csT0FBTyxxQkFDZkssS0FEZSxNQUVmOUssTUFGZSxNQUdmK0ssSUFIZSxNQUlmQyxLQUplLE1BS2ZDLE1BTGUsTUFNZkMsVUFOZSxDQUFiLEM7Ozs7Ozs7Ozs7O0FDMUJQclgsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ3FYLGdCQUFjLEVBQUMsTUFBSUEsY0FBcEI7QUFBbUM3VyxhQUFXLEVBQUMsTUFBSUE7QUFBbkQsQ0FBZDtBQUErRSxJQUFJOFcsS0FBSjtBQUFVdlgsTUFBTSxDQUFDSyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDa1gsT0FBSyxDQUFDalgsQ0FBRCxFQUFHO0FBQUNpWCxTQUFLLEdBQUNqWCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXpGO0FBQ0EsTUFBTWtYLElBQUksR0FBTyxJQUFJRCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsTUFBckIsQ0FBakI7QUFDQSxNQUFNL1csSUFBSSxHQUFPLElBQUk2VyxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsTUFBckIsQ0FBakI7QUFDQSxNQUFNN1csS0FBSyxHQUFNLElBQUkyVyxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsT0FBckIsQ0FBakI7QUFDQSxNQUFNNUYsT0FBTyxHQUFJLElBQUkwRixLQUFLLENBQUNFLFVBQVYsQ0FBcUIsU0FBckIsQ0FBakI7QUFDQSxNQUFNQyxNQUFNLEdBQUssSUFBSUgsS0FBSyxDQUFDRSxVQUFWLENBQXFCLFFBQXJCLENBQWpCO0FBQ0EsTUFBTUUsUUFBUSxHQUFHLElBQUlKLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixVQUFyQixDQUFqQjtBQUNBLE1BQU05VyxPQUFPLEdBQUksSUFBSTRXLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixTQUFyQixDQUFqQjtBQUNBLE1BQU1HLFFBQVEsR0FBRyxJQUFJTCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakIsQyxDQUdBO0FBQ0E7O0FBQ08sTUFBTUgsY0FBYyxHQUFHO0FBQzVCRSxNQUFJLEVBQU8sRUFEaUI7QUFFNUI5VyxNQUFJLEVBQU8sRUFGaUI7QUFHNUJFLE9BQUssRUFBTSxFQUhpQjtBQUk1QmlSLFNBQU8sRUFBSSxFQUppQjtBQUs1QjZGLFFBQU0sRUFBSyxFQUxpQjtBQU01QkMsVUFBUSxFQUFHLEVBTmlCO0FBTzVCaFgsU0FBTyxFQUFJO0FBQUUrRSxPQUFHLEVBQUUsQ0FDRjtBQUFFc0gsVUFBSSxFQUFFO0FBQUV0RixlQUFPLEVBQUU7QUFBWDtBQUFSLEtBREUsRUFFRjtBQUFFc0YsVUFBSSxFQUFFO0FBQUU2SyxXQUFHLEVBQUU7QUFBUDtBQUFSLEtBRkU7QUFBUCxHQVBpQjtBQVk1QkQsVUFBUSxFQUFFO0FBWmtCLENBQXZCO0FBZ0JBLE1BQU1uWCxXQUFXLEdBQUc7QUFDekIrVyxNQUR5QjtBQUV6QjlXLE1BRnlCO0FBR3pCRSxPQUh5QjtBQUl6QmlSLFNBSnlCO0FBS3pCNkYsUUFMeUI7QUFNekJDLFVBTnlCO0FBT3pCaFgsU0FQeUI7QUFRekJpWDtBQVJ5QixDQUFwQixDOzs7Ozs7Ozs7OztBQy9CUCxJQUFJekQsYUFBSjs7QUFBa0JuVSxNQUFNLENBQUNLLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDNlQsaUJBQWEsR0FBQzdULENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCTixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDUSxhQUFXLEVBQUMsTUFBSUEsV0FBakI7QUFBNkI2VyxnQkFBYyxFQUFDLE1BQUlBO0FBQWhELENBQWQ7QUFBK0UsSUFBSUMsS0FBSjtBQUFVdlgsTUFBTSxDQUFDSyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDa1gsT0FBSyxDQUFDalgsQ0FBRCxFQUFHO0FBQUNpWCxTQUFLLEdBQUNqWCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl3WCxnQkFBSixFQUFxQkMsWUFBckI7QUFBa0MvWCxNQUFNLENBQUNLLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNJLGFBQVcsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUN3WCxvQkFBZ0IsR0FBQ3hYLENBQWpCO0FBQW1CLEdBQW5DOztBQUFvQ2dYLGdCQUFjLENBQUNoWCxDQUFELEVBQUc7QUFBQ3lYLGdCQUFZLEdBQUN6WCxDQUFiO0FBQWU7O0FBQXJFLENBQXRCLEVBQTZGLENBQTdGO0FBd0I3SyxNQUFNMFgsS0FBSyxHQUFHLElBQUlULEtBQUssQ0FBQ0UsVUFBVixDQUFxQixPQUFyQixDQUFkO0FBQ0EsTUFBTVEsR0FBRyxHQUFHLElBQUlWLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixLQUFyQixDQUFaO0FBQ0EsTUFBTVMsTUFBTSxHQUFHLElBQUlYLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBQ0EsTUFBTVUsT0FBTyxHQUFHLElBQUlaLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixTQUFyQixDQUFoQjtBQUNBLE1BQU16QyxVQUFVLEdBQUcsSUFBSXVDLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixZQUFyQixDQUFuQjs7QUFHTyxNQUFNaFgsV0FBVyxxQkFDbkJxWCxnQkFEbUI7QUFFdEJFLE9BRnNCO0FBR3RCQyxLQUhzQjtBQUl0QkMsUUFKc0I7QUFLdEJDLFNBTHNCO0FBTXRCbkQ7QUFOc0IsRUFBakI7O0FBVUEsTUFBTXNDLGNBQWMscUJBQ3RCUyxZQURzQjtBQUV6QixXQUFTLEVBRmdCO0FBR3pCLFNBQU8sRUFIa0I7QUFJekIsWUFBVSxFQUplO0FBS3pCLGFBQVcsRUFMYztBQU16QixnQkFBYztBQU5XLEVBQXBCLEM7Ozs7Ozs7Ozs7O0FDekNQL1gsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ21ZLGVBQWEsRUFBQyxNQUFJQSxhQUFuQjtBQUFpQ3ZWLFFBQU0sRUFBQyxNQUFJQSxNQUE1QztBQUFtRDBELGdCQUFjLEVBQUMsTUFBSUEsY0FBdEU7QUFBcUY4UixhQUFXLEVBQUMsTUFBSUE7QUFBckcsQ0FBZDtBQUFpSSxJQUFJNUgsTUFBSjtBQUFXelEsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDb1EsUUFBTSxDQUFDblEsQ0FBRCxFQUFHO0FBQUNtUSxVQUFNLEdBQUNuUSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5VSxZQUFKO0FBQWlCL1UsTUFBTSxDQUFDSyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDeVUsZ0JBQVksR0FBQ3pVLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUEyQmxOO0FBRUEsSUFBSWdZLE1BQUosQyxDQUFXO0FBSVg7O0FBR08sTUFBTUYsYUFBYSxHQUFHO0FBQzNCbEosTUFBSSxFQUFFLHNCQURxQjs7QUFHM0IrRixNQUFJLENBQUNzRCxXQUFELEVBQWNyRCxRQUFkLEVBQXdCO0FBQzFCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNxSixXQUFELENBQXhCLEVBQXVDeFQsT0FBdkMsRUFBZ0RtUSxRQUFoRDtBQUNELEdBVjBCOztBQVkzQkksVUFBUSxDQUFDaUQsV0FBRCxFQUFjO0FBQ3BCLFFBQUl4RCxZQUFKLENBQWlCO0FBQ2Z0UyxTQUFHLEVBQU87QUFBRThTLFlBQUksRUFBRUM7QUFBUixPQURLLENBQ1k7QUFEWjtBQUVmZ0QsV0FBSyxFQUFLO0FBQUVqRCxZQUFJLEVBQUVDO0FBQVIsT0FGSztBQUdmL1IsY0FBUSxFQUFFO0FBQUU4UixZQUFJLEVBQUVDO0FBQVI7QUFISyxLQUFqQixFQUlHRixRQUpILENBSVlpRCxXQUpaO0FBS0Q7QUFFRDs7Ozs7Ozs7O0FBcEIyQjs7QUE4QjNCN0MsS0FBRyxDQUFDNkMsV0FBRCxFQUFjO0FBQ2YsVUFBTTlWLEdBQUcsR0FBRzZWLE1BQU0sQ0FBQ2hXLE1BQVAsQ0FBZWlXLFdBQWYsQ0FBWjs7QUFFQSxXQUFPOVYsR0FBUCxDQUhlLENBR0o7QUFDWjs7QUFsQzBCLENBQXRCO0FBc0NBLE1BQU1JLE1BQU0sR0FBRztBQUNwQnFNLE1BQUksRUFBRSxlQURjOztBQUdwQitGLE1BQUksQ0FBQ3dELFNBQUQsRUFBWXZELFFBQVosRUFBc0I7QUFDeEIsVUFBTW5RLE9BQU8sR0FBRztBQUNkb1EscUJBQWUsRUFBRSxJQURIO0FBRWRDLHlCQUFtQixFQUFFO0FBRlAsS0FBaEI7QUFLQTNFLFVBQU0sQ0FBQzRFLEtBQVAsQ0FBYSxLQUFLbkcsSUFBbEIsRUFBd0IsQ0FBQ3VKLFNBQUQsQ0FBeEIsRUFBcUMxVCxPQUFyQyxFQUE4Q21RLFFBQTlDO0FBQ0QsR0FWbUI7O0FBWXBCSSxVQUFRLENBQUNtRCxTQUFELEVBQVk7QUFDbEIsUUFBSTFELFlBQUosQ0FBaUI7QUFDZnRTLFNBQUcsRUFBTztBQUFFOFMsWUFBSSxFQUFFQztBQUFSLE9BREs7QUFFZi9SLGNBQVEsRUFBRTtBQUFFOFIsWUFBSSxFQUFFQztBQUFSLE9BRks7QUFHZmtELE9BQUMsRUFBUztBQUFFbkQsWUFBSSxFQUFFTztBQUFSLE9BSEs7QUFJZjZDLE9BQUMsRUFBUztBQUFFcEQsWUFBSSxFQUFFTztBQUFSLE9BSks7QUFLZnBULFlBQU0sRUFBSTtBQUFFNlMsWUFBSSxFQUFFSztBQUFSLE9BTEs7QUFNZmdELGNBQVEsRUFBRTtBQUFFckQsWUFBSSxFQUFFSztBQUFSLE9BTks7QUFPZmlELFdBQUssRUFBSztBQUFFdEQsWUFBSSxFQUFFL00sTUFBUjtBQUFnQmlOLGdCQUFRLEVBQUUsSUFBMUI7QUFBZ0NTLGdCQUFRLEVBQUU7QUFBMUM7QUFQSyxLQUFqQixFQVFHWixRQVJILENBUVltRCxTQVJaOztBQVVBLFFBQUlBLFNBQVMsQ0FBQ0ksS0FBZCxFQUFxQjtBQUNuQixVQUFJOUQsWUFBSixDQUFpQjtBQUNmK0QsZUFBTyxFQUFRO0FBQUV2RCxjQUFJLEVBQUVPO0FBQVIsU0FEQTtBQUVmaUQsZUFBTyxFQUFRO0FBQUV4RCxjQUFJLEVBQUVPO0FBQVIsU0FGQTtBQUdma0QscUJBQWEsRUFBRTtBQUFFekQsY0FBSSxFQUFFTztBQUFSO0FBSEEsT0FBakIsRUFJR1IsUUFKSCxDQUlZbUQsU0FBUyxDQUFDSSxLQUp0QjtBQUtEO0FBQ0YsR0E5Qm1COztBQWdDcEJuRCxLQUFHLENBQUMrQyxTQUFELEVBQVk7QUFBRTtBQUNmLFVBQU1oVyxHQUFHLEdBQUdnVyxTQUFTLENBQUNoVyxHQUF0QjtBQUNBNlYsVUFBTSxDQUFDelYsTUFBUCxDQUFjO0FBQUVKO0FBQUYsS0FBZCxFQUF1QjtBQUFFSyxVQUFJLEVBQUUyVjtBQUFSLEtBQXZCLEVBRmEsQ0FFK0I7QUFDN0M7O0FBbkNtQixDQUFmO0FBdUNBLE1BQU1sUyxjQUFjLEdBQUc7QUFDNUIySSxNQUFJLEVBQUUsdUJBRHNCOztBQUc1QitGLE1BQUksQ0FBQ3NELFdBQUQsRUFBY3JELFFBQWQsRUFBd0I7QUFDMUIsVUFBTW5RLE9BQU8sR0FBRztBQUNkb1EscUJBQWUsRUFBRSxJQURIO0FBRWRDLHlCQUFtQixFQUFFO0FBRlAsS0FBaEI7QUFLQTNFLFVBQU0sQ0FBQzRFLEtBQVAsQ0FBYSxLQUFLbkcsSUFBbEIsRUFBd0IsQ0FBQ3FKLFdBQUQsQ0FBeEIsRUFBdUN4VCxPQUF2QyxFQUFnRG1RLFFBQWhEO0FBQ0QsR0FWMkI7O0FBWTVCSSxVQUFRLENBQUNpRCxXQUFELEVBQWM7QUFDcEIsUUFBSXhELFlBQUosQ0FBaUI7QUFDZnRTLFNBQUcsRUFBTztBQUFFOFMsWUFBSSxFQUFFQztBQUFSLE9BREssQ0FDWTtBQURaO0FBRWYvUixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUjtBQUZLLEtBQWpCLEVBR0dGLFFBSEgsQ0FHWWlELFdBSFo7QUFJRCxHQWpCMkI7O0FBbUI1QjdDLEtBQUcsQ0FBQzZDLFdBQUQsRUFBYztBQUNmLFVBQU07QUFBRTlVO0FBQUYsUUFBZThVLFdBQXJCO0FBQ0EsVUFBTXhWLE1BQU0sR0FBR3VWLE1BQU0sQ0FBQ1csTUFBUCxDQUFlVixXQUFmLENBQWYsQ0FGZSxDQUlmO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQU0vVSxPQUFPLEdBQUc4VSxNQUFNLENBQUMxUyxJQUFQLENBQVk7QUFBRW5DO0FBQUYsS0FBWixFQUEwQixFQUExQixFQUE4Qm9DLEtBQTlCLEVBQWhCOztBQUNBLFFBQUlyQyxPQUFPLENBQUNxQixNQUFSLEdBQWlCLENBQXJCLEVBQXdCO0FBQ3RCeVQsWUFBTSxDQUFDVyxNQUFQLENBQWM7QUFBRXhWO0FBQUYsT0FBZDtBQUNEOztBQUVELFdBQU8sS0FBUDtBQUNEOztBQWxDMkIsQ0FBdkI7QUFzQ0EsTUFBTTRVLFdBQVcsR0FBRztBQUN6Qm5KLE1BQUksRUFBRSxjQURtQjs7QUFHekIrRixNQUFJLENBQUNzRCxXQUFELEVBQWNyRCxRQUFkLEVBQXdCO0FBQzFCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNxSixXQUFELENBQXhCLEVBQXVDeFQsT0FBdkMsRUFBZ0RtUSxRQUFoRDtBQUNELEdBVndCOztBQVl6QkksVUFBUSxHQUFHLENBQUUsQ0FaWTs7QUFjekJJLEtBQUcsQ0FBQzZDLFdBQUQsRUFBYztBQUNmLFVBQU14VixNQUFNLEdBQUd1VixNQUFNLENBQUNXLE1BQVAsQ0FBZSxFQUFmLENBQWYsQ0FEZSxDQUdmO0FBQ0E7O0FBQ0EsV0FBT2xXLE1BQVA7QUFDRDs7QUFwQndCLENBQXBCO0FBd0JQLE1BQU02VCxPQUFPLEdBQUcsQ0FDZHdCLGFBRGMsRUFFZHZWLE1BRmMsRUFHZDBELGNBSGMsRUFJZDhSLFdBSmMsQ0FJRjtBQUpFLENBQWhCO0FBUUF6QixPQUFPLENBQUN0VixPQUFSLENBQWdCdVYsTUFBTSxJQUFJO0FBQ3hCcEcsUUFBTSxDQUFDbUcsT0FBUCxDQUFlO0FBQ2IsS0FBQ0MsTUFBTSxDQUFDM0gsSUFBUixHQUFlLFVBQVU0SCxJQUFWLEVBQWdCO0FBQzdCRCxZQUFNLENBQUN2QixRQUFQLENBQWdCTCxJQUFoQixDQUFxQixJQUFyQixFQUEyQjZCLElBQTNCO0FBQ0EsYUFBT0QsTUFBTSxDQUFDbkIsR0FBUCxDQUFXVCxJQUFYLENBQWdCLElBQWhCLEVBQXNCNkIsSUFBdEIsQ0FBUDtBQUNEO0FBSlksR0FBZjtBQU1ELENBUEQ7O0FBVUEsSUFBSXJHLE1BQU0sQ0FBQ3lJLFFBQVgsRUFBcUI7QUFDbkJaLFFBQU0sR0FBRyxJQUFJN0gsTUFBTSxDQUFDZ0gsVUFBWCxDQUFzQixRQUF0QixFQUFnQztBQUFFMEIsY0FBVSxFQUFFO0FBQWQsR0FBaEMsQ0FBVDtBQUVBMUksUUFBTSxDQUFDMkksT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVTtBQUNsQztBQUNBLFVBQU1DLFlBQVksR0FBRyxJQUFyQjtBQUVBLFVBQU1DLFdBQVcsR0FBR2hCLE1BQU0sQ0FBQzFTLElBQVAsQ0FBWSxFQUFaLEVBQWdCMlQsY0FBaEIsQ0FBK0I7QUFDakRDLFdBQUssRUFBRSxVQUFVOVMsRUFBVixFQUFjaEYsTUFBZCxFQUFzQjtBQUMzQjJYLG9CQUFZLENBQUNHLEtBQWIsQ0FBbUIsUUFBbkIsRUFBNkI5UyxFQUE3QixFQUFpQ2hGLE1BQWpDO0FBQ0QsT0FIZ0Q7QUFJakQrWCxhQUFPLEVBQUUsVUFBUy9TLEVBQVQsRUFBYWhGLE1BQWIsRUFBcUI7QUFDNUIyWCxvQkFBWSxDQUFDSSxPQUFiLENBQXFCLFFBQXJCLEVBQStCL1MsRUFBL0IsRUFBbUNoRixNQUFuQztBQUNELE9BTmdEO0FBT2pEZ1ksYUFBTyxFQUFFLFVBQVVoVCxFQUFWLEVBQWM7QUFDckIyUyxvQkFBWSxDQUFDSyxPQUFiLENBQXFCLFFBQXJCLEVBQStCaFQsRUFBL0I7QUFDRDtBQVRnRCxLQUEvQixDQUFwQjtBQVlBMlMsZ0JBQVksQ0FBQ00sS0FBYjtBQUVBTixnQkFBWSxDQUFDTyxNQUFiLENBQW9CLE1BQU07QUFDeEJOLGlCQUFXLENBQUNPLElBQVo7QUFDRCxLQUZEO0FBR0QsR0FyQkQ7QUFzQkQ7O0FBR0QsSUFBSXBKLE1BQU0sQ0FBQ3FKLFFBQVgsRUFBcUI7QUFDbkJ4QixRQUFNLEdBQUcsSUFBSTdILE1BQU0sQ0FBQ2dILFVBQVgsQ0FBc0IsUUFBdEIsQ0FBVCxDQURtQixDQUNzQjs7QUFDekNoSCxRQUFNLENBQUNzSixTQUFQLENBQWlCLFNBQWpCLEVBRm1CLENBSW5COztBQUNBQyxRQUFNLENBQUMxQixNQUFQLEdBQWdCQSxNQUFoQjtBQUNBMEIsUUFBTSxDQUFDM0IsV0FBUCxHQUFxQkEsV0FBckI7QUFDRDs7QUFwT0RyWSxNQUFNLENBQUNpYSxhQUFQLENBdU9lM0IsTUF2T2YsRTs7Ozs7Ozs7Ozs7QUNBQXRZLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUM0RCxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJNE0sTUFBSjtBQUFXelEsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDb1EsUUFBTSxDQUFDblEsQ0FBRCxFQUFHO0FBQUNtUSxVQUFNLEdBQUNuUSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlpWCxLQUFKO0FBQVV2WCxNQUFNLENBQUNLLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNrWCxPQUFLLENBQUNqWCxDQUFELEVBQUc7QUFBQ2lYLFNBQUssR0FBQ2pYLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUcsV0FBSixFQUFnQjZXLGNBQWhCO0FBQStCdFgsTUFBTSxDQUFDSyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDSSxhQUFXLENBQUNILENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYyxHQUE5Qjs7QUFBK0JnWCxnQkFBYyxDQUFDaFgsQ0FBRCxFQUFHO0FBQUNnWCxrQkFBYyxHQUFDaFgsQ0FBZjtBQUFpQjs7QUFBbEUsQ0FBckIsRUFBeUYsQ0FBekY7O0FBVzFNO0FBRUEsSUFBSW1RLE1BQU0sQ0FBQ3lJLFFBQVgsRUFBcUI7QUFDbkIsT0FBS2hLLElBQUwsSUFBYXpPLFdBQWIsRUFBMEI7QUFDeEIsVUFBTW1DLE1BQU0sR0FBRzBVLGNBQWMsQ0FBQ3BJLElBQUQsQ0FBN0I7QUFDQSxVQUFNaEcsVUFBVSxHQUFHekksV0FBVyxDQUFDeU8sSUFBRCxDQUE5QixDQUZ3QixDQUl4Qjs7QUFFQUEsUUFBSSxHQUFHaEcsVUFBVSxDQUFDZ1IsS0FBbEIsQ0FOd0IsQ0FNQTtBQUV4QjtBQUNBO0FBQ0E7O0FBRUF6SixVQUFNLENBQUMySSxPQUFQLENBQWVsSyxJQUFmLEVBQXFCLFNBQVNpTCxNQUFULENBQWdCQyxNQUFoQixFQUFpQztBQUNwRDtBQUNBO0FBRUEsVUFBSUMsS0FBSyxHQUFHblIsVUFBVSxDQUFDdEQsSUFBWCxDQUFnQmhELE1BQWhCLENBQVosQ0FKb0QsQ0FJaEI7O0FBRXBDLFVBQUksT0FBT3dYLE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0M7QUFBQSwwQ0FOY0UsSUFNZDtBQU5jQSxjQU1kO0FBQUE7O0FBQzlCL08sZUFBTyxDQUFDekIsR0FBUixDQUNFLFlBREYsRUFDZ0JaLFVBQVUsQ0FBQ2dSLEtBRDNCLEVBQ2tDLEtBRGxDLEVBQ3lDRSxNQUR6QyxFQUNpRCxHQUFHRSxJQURwRCxFQUQ4QixDQUk5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7O0FBRUQsYUFBT0QsS0FBUDtBQUNELEtBbEJEO0FBbUJEO0FBQ0YsQyxDQUdEOzs7QUFDTyxNQUFNeFcsWUFBWSxHQUFJcEIsR0FBRCxJQUFTO0FBQ25DLFFBQU1rVixRQUFRLEdBQUdsWCxXQUFXLENBQUNrWCxRQUE3QjtBQUNBLE1BQUk0QyxHQUFHLEdBQUcsQ0FBVjs7QUFFQSxNQUFJOUosTUFBTSxDQUFDK0osUUFBWCxFQUFxQjtBQUNuQjdDLFlBQVEsQ0FBQzVJLE1BQVQsQ0FDRTtBQUFFdE07QUFBRixLQURGLEVBRUU7QUFBRWdZLFVBQUksRUFBRTtBQUFFelYsYUFBSyxFQUFFdVY7QUFBVDtBQUFSLEtBRkY7QUFLQUEsT0FBRyxHQUFHLENBQU47QUFDRDs7QUFFRCxRQUFNdlYsS0FBSyxHQUFJMlMsUUFBUSxDQUFDbFcsT0FBVCxDQUFpQjtBQUFFZ0I7QUFBRixHQUFqQixDQUFELElBQStCO0FBQUV1QyxTQUFLLEVBQUM7QUFBUixJQUFZQSxLQUFaLEdBQW9CdVYsR0FBakU7QUFFQSxTQUFPdlYsS0FBUDtBQUNELENBaEJNOztBQWxEUGhGLE1BQU0sQ0FBQ2lhLGFBQVAsQ0FxRWV4WixXQXJFZixFOzs7Ozs7Ozs7OztBQ0FBVCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDeWEsYUFBVyxFQUFDLE1BQUlBLFdBQWpCO0FBQTZCQyxnQkFBYyxFQUFDLE1BQUlBLGNBQWhEO0FBQStEQyxZQUFVLEVBQUMsTUFBSUEsVUFBOUU7QUFBeUZDLGVBQWEsRUFBQyxNQUFJQSxhQUEzRztBQUF5SEMsa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQTlJO0FBQStKQyxnQkFBYyxFQUFDLE1BQUlBO0FBQWxMLENBQWQ7QUFBaU4sSUFBSXRLLE1BQUo7QUFBV3pRLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ29RLFFBQU0sQ0FBQ25RLENBQUQsRUFBRztBQUFDbVEsVUFBTSxHQUFDblEsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVUsWUFBSjtBQUFpQi9VLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ3lVLGdCQUFZLEdBQUN6VSxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUExQixDQUFqRCxFQUE2RSxDQUE3RTtBQVE3VyxNQUFNO0FBQUVNO0FBQUYsSUFBWUgsV0FBbEI7QUFJTyxNQUFNaWEsV0FBVyxHQUFHO0FBQ3pCeEwsTUFBSSxFQUFFLGtCQURtQjs7QUFHekIrRixNQUFJLENBQUN5RixXQUFELEVBQWN4RixRQUFkLEVBQXdCO0FBQzFCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUN3TCxXQUFELENBQXhCLEVBQXVDM1YsT0FBdkMsRUFBZ0RtUSxRQUFoRDtBQUNELEdBVndCOztBQVl6QkksVUFBUSxDQUFDb0YsV0FBRCxFQUFjO0FBQ3BCLFFBQUkzRixZQUFKLENBQWlCO0FBQ2Z0UixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUixPQURLO0FBRWZRLFVBQUksRUFBRTtBQUFFVCxZQUFJLEVBQUUvTSxNQUFSO0FBQWdCME4sZ0JBQVEsRUFBRTtBQUExQjtBQUZTLEtBQWpCLEVBR0daLFFBSEgsQ0FHWW9GLFdBSFo7QUFJRCxHQWpCd0I7O0FBbUJ6QmhGLEtBQUcsQ0FBQ2dGLFdBQUQsRUFBYztBQUNmLFVBQU07QUFBRWpYLGNBQVEsRUFBRWhCLEdBQVo7QUFBaUJ1VDtBQUFqQixRQUEwQjBFLFdBQWhDO0FBQ0EsVUFBTTlYLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNNkUsR0FBRyxHQUFHO0FBQUV4RSxVQUFJLEVBQUU7QUFBRSxxQkFBYWtUO0FBQWY7QUFBUixLQUFaO0FBQ0FwVixTQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUIwRSxHQUFyQjtBQUNEOztBQXhCd0IsQ0FBcEI7QUE0QkEsTUFBTXFULGNBQWMsR0FBRztBQUM1QnpMLE1BQUksRUFBRSxxQkFEc0I7O0FBRzVCK0YsTUFBSSxDQUFDK0Ysa0JBQUQsRUFBcUI5RixRQUFyQixFQUErQjtBQUNqQyxVQUFNblEsT0FBTyxHQUFHO0FBQ2RvUSxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBM0UsVUFBTSxDQUFDNEUsS0FBUCxDQUFhLEtBQUtuRyxJQUFsQixFQUF3QixDQUFDOEwsa0JBQUQsQ0FBeEIsRUFBOENqVyxPQUE5QyxFQUF1RG1RLFFBQXZEO0FBQ0QsR0FWMkI7O0FBWTVCSSxVQUFRLENBQUMwRixrQkFBRCxFQUFxQjtBQUMzQixRQUFJakcsWUFBSixDQUFpQjtBQUNma0csY0FBUSxFQUFFO0FBQUUxRixZQUFJLEVBQUVLO0FBQVIsT0FESztBQUVmblMsY0FBUSxFQUFFO0FBQUU4UixZQUFJLEVBQUVDO0FBQVI7QUFGSyxLQUFqQixFQUdHRixRQUhILENBR1kwRixrQkFIWjtBQUlELEdBakIyQjs7QUFtQjVCdEYsS0FBRyxDQUFDc0Ysa0JBQUQsRUFBcUI7QUFDdEIsVUFBTTtBQUFFdlgsY0FBUSxFQUFFaEIsR0FBWjtBQUFpQndZO0FBQWpCLFFBQThCRCxrQkFBcEM7QUFDQSxVQUFNcFksTUFBTSxHQUFHO0FBQUVIO0FBQUYsS0FBZjtBQUNBLFVBQU02RSxHQUFHLEdBQUc7QUFBRXhFLFVBQUksRUFBRTtBQUFFLDhCQUFzQm1ZO0FBQXhCO0FBQVIsS0FBWjtBQUNBLFVBQU1sWSxNQUFNLEdBQUduQyxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUIwRSxHQUFyQixDQUFmLENBSnNCLENBTXRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQS9CMkIsQ0FBdkI7QUFvQ0EsTUFBTXNULFVBQVUsR0FBRztBQUN4QjFMLE1BQUksRUFBRSxpQkFEa0I7O0FBR3hCK0YsTUFBSSxDQUFDaUcsY0FBRCxFQUFpQmhHLFFBQWpCLEVBQTJCO0FBQzdCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNnTSxjQUFELENBQXhCLEVBQTBDblcsT0FBMUMsRUFBbURtUSxRQUFuRDtBQUNELEdBVnVCOztBQVl4QkksVUFBUSxDQUFDNEYsY0FBRCxFQUFpQjtBQUN2QixRQUFJbkcsWUFBSixDQUFpQjtBQUNmL1AsV0FBSyxFQUFLO0FBQUV1USxZQUFJLEVBQUVPO0FBQVIsT0FESztBQUVmclMsY0FBUSxFQUFFO0FBQUU4UixZQUFJLEVBQUVDO0FBQVI7QUFGSyxLQUFqQixFQUdHRixRQUhILENBR1k0RixjQUhaO0FBSUQsR0FqQnVCOztBQW1CeEJ4RixLQUFHLENBQUN3RixjQUFELEVBQWlCO0FBQ2xCLFVBQU07QUFBRXpYLGNBQVEsRUFBRWhCLEdBQVo7QUFBaUJ1QztBQUFqQixRQUEyQmtXLGNBQWpDO0FBQ0EsVUFBTXRZLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNNkUsR0FBRyxHQUFHO0FBQUV4RSxVQUFJLEVBQUU7QUFBRSxTQUFDLG9CQUFvQmtDLEtBQXJCLEdBQTZCO0FBQS9CO0FBQVIsS0FBWjtBQUNBLFVBQU1qQyxNQUFNLEdBQUduQyxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUIwRSxHQUFyQixDQUFmLENBSmtCLENBTWxCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQS9CdUIsQ0FBbkI7QUFtQ0EsTUFBTXVULGFBQWEsR0FBRztBQUMzQjNMLE1BQUksRUFBRSxvQkFEcUI7O0FBRzNCK0YsTUFBSSxDQUFDa0csY0FBRCxFQUFpQmpHLFFBQWpCLEVBQTJCO0FBQzdCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNpTSxjQUFELENBQXhCLEVBQTBDcFcsT0FBMUMsRUFBbURtUSxRQUFuRDtBQUNELEdBVjBCOztBQVkzQkksVUFBUSxDQUFDNkYsY0FBRCxFQUFpQjtBQUN2QixRQUFJcEcsWUFBSixDQUFpQjtBQUNmcUcsYUFBTyxFQUFHO0FBQUU3RixZQUFJLEVBQUVDO0FBQVIsT0FESyxDQUNZO0FBRFo7QUFFZjZGLFdBQUssRUFBSztBQUFFOUYsWUFBSSxFQUFFQztBQUFSLE9BRkssQ0FFWTtBQUZaO0FBR2YvUixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUixPQUhLO0FBSWZrRCxPQUFDLEVBQVM7QUFBRW5ELFlBQUksRUFBRU87QUFBUixPQUpLO0FBS2Y2QyxPQUFDLEVBQVM7QUFBRXBELFlBQUksRUFBRU87QUFBUjtBQUxLLEtBQWpCLEVBTUdSLFFBTkgsQ0FNWTZGLGNBTlo7QUFPRDtBQUVEOzs7OztBQXRCMkI7O0FBNEIzQnpGLEtBQUcsQ0FBQ3lGLGNBQUQsRUFBaUI7QUFDbEIsVUFBTTtBQUFFMVgsY0FBUSxFQUFFaEIsR0FBWjtBQUFpQjRZLFdBQWpCO0FBQXdCRCxhQUF4QjtBQUFpQzFDLE9BQWpDO0FBQW9DQztBQUFwQyxRQUEwQ3dDLGNBQWhEO0FBQ0EsVUFBTXZZLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWYsQ0FGa0IsQ0FJbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFNNkUsR0FBRyxHQUFHO0FBQ1Z4RSxVQUFJLEVBQUU7QUFDSiwyQkFBcUJ1WSxLQURqQjtBQUVKLDZCQUFxQkQsT0FGakI7QUFHSix1QkFBcUIxQyxDQUhqQjtBQUlKLHVCQUFxQkM7QUFKakIsT0FESTtBQU9WMkMsWUFBTSxFQUFFO0FBQ04sMEJBQWtCO0FBRFo7QUFQRSxLQUFaO0FBV0EsV0FBTzFhLEtBQUssQ0FBQ2lDLE1BQU4sQ0FBYUQsTUFBYixFQUFxQjBFLEdBQXJCLENBQVA7QUFDRDs7QUFyRDBCLENBQXRCO0FBeURBLE1BQU13VCxnQkFBZ0IsR0FBRztBQUM5QjVMLE1BQUksRUFBRSx1QkFEd0I7O0FBRzlCK0YsTUFBSSxDQUFDa0csY0FBRCxFQUFpQmpHLFFBQWpCLEVBQTJCO0FBQzdCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUNpTSxjQUFELENBQXhCLEVBQTBDcFcsT0FBMUMsRUFBbURtUSxRQUFuRDtBQUNELEdBVjZCOztBQVk5QkksVUFBUSxDQUFDNkYsY0FBRCxFQUFpQjtBQUN2QixRQUFJcEcsWUFBSixDQUFpQjtBQUNmdFIsY0FBUSxFQUFFO0FBQUU4UixZQUFJLEVBQUVDO0FBQVIsT0FESztBQUVmNkYsV0FBSyxFQUFLO0FBQUU5RixZQUFJLEVBQUVDO0FBQVIsT0FGSztBQUdma0QsT0FBQyxFQUFTO0FBQUVuRCxZQUFJLEVBQUVPO0FBQVIsT0FISztBQUlmNkMsT0FBQyxFQUFTO0FBQUVwRCxZQUFJLEVBQUVPO0FBQVI7QUFKSyxLQUFqQixFQUtHUixRQUxILENBS1k2RixjQUxaO0FBTUQsR0FuQjZCOztBQXFCOUJ6RixLQUFHLENBQUN5RixjQUFELEVBQWlCO0FBQ2xCLFVBQU07QUFBRTFYLGNBQVEsRUFBRWhCLEdBQVo7QUFBaUI0WSxXQUFqQjtBQUF3QjNDLE9BQXhCO0FBQTJCQztBQUEzQixRQUFpQ3dDLGNBQXZDO0FBQ0EsVUFBTXZZLE1BQU0sR0FBRztBQUFFSCxTQUFGO0FBQU8seUJBQW1CNFk7QUFBMUIsS0FBZjtBQUNBLFVBQU0vVCxHQUFHLEdBQUc7QUFDVnhFLFVBQUksRUFBRTtBQUNKLHVCQUFlNFYsQ0FEWDtBQUVKLHVCQUFlQztBQUZYO0FBREksS0FBWjtBQU1BLFdBQU8vWCxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUIwRSxHQUFyQixDQUFQO0FBQ0Q7O0FBL0I2QixDQUF6QjtBQW1DQSxNQUFNeVQsY0FBYyxHQUFHO0FBQzVCN0wsTUFBSSxFQUFFLHFCQURzQjs7QUFHNUIrRixNQUFJLENBQUNzRyxjQUFELEVBQWlCckcsUUFBakIsRUFBMkI7QUFDN0IsVUFBTW5RLE9BQU8sR0FBRztBQUNkb1EscUJBQWUsRUFBRSxJQURIO0FBRWRDLHlCQUFtQixFQUFFO0FBRlAsS0FBaEI7QUFLQTNFLFVBQU0sQ0FBQzRFLEtBQVAsQ0FBYSxLQUFLbkcsSUFBbEIsRUFBd0IsQ0FBQ3FNLGNBQUQsQ0FBeEIsRUFBMEN4VyxPQUExQyxFQUFtRG1RLFFBQW5EO0FBQ0QsR0FWMkI7O0FBWTVCSSxVQUFRLENBQUNpRyxjQUFELEVBQWlCO0FBQ3ZCLFFBQUl4RyxZQUFKLENBQWlCO0FBQ2Z0UixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUjtBQURLLEtBQWpCLEVBRUdGLFFBRkgsQ0FFWWlHLGNBRlo7QUFHRCxHQWhCMkI7O0FBa0I1QjdGLEtBQUcsQ0FBQzZGLGNBQUQsRUFBaUI7QUFDbEIsVUFBTTtBQUFFOVgsY0FBUSxFQUFFaEI7QUFBWixRQUFvQjhZLGNBQTFCO0FBQ0EsVUFBTTNZLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNK1ksS0FBSyxHQUFHO0FBQ1pGLFlBQU0sRUFBRTtBQUNOLDJCQUFxQixDQURmO0FBRU4sNkJBQXFCLENBRmY7QUFHTix1QkFBcUIsQ0FIZjtBQUlOLHVCQUFxQjtBQUpmO0FBREksS0FBZDtBQVFBLFdBQU8xYSxLQUFLLENBQUNpQyxNQUFOLENBQWFELE1BQWIsRUFBcUI0WSxLQUFyQixDQUFQO0FBQ0Q7O0FBOUIyQixDQUF2QjtBQWtDUCxNQUFNNUUsT0FBTyxHQUFHLENBQ2Q4RCxXQURjLEVBRWRFLFVBRmMsRUFHZEQsY0FIYyxFQUlkRSxhQUpjLEVBS2RDLGdCQUxjLEVBTWRDLGNBTmMsQ0FBaEI7QUFVQW5FLE9BQU8sQ0FBQ3RWLE9BQVIsQ0FBZ0J1VixNQUFNLElBQUk7QUFDeEJwRyxRQUFNLENBQUNtRyxPQUFQLENBQWU7QUFDYixLQUFDQyxNQUFNLENBQUMzSCxJQUFSLEdBQWUsVUFBVTRILElBQVYsRUFBZ0I7QUFDN0JELFlBQU0sQ0FBQ3ZCLFFBQVAsQ0FBZ0JMLElBQWhCLENBQXFCLElBQXJCLEVBQTJCNkIsSUFBM0I7QUFDQSxhQUFPRCxNQUFNLENBQUNuQixHQUFQLENBQVdULElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0I2QixJQUF0QixDQUFQO0FBQ0Q7QUFKWSxHQUFmO0FBTUQsQ0FQRCxFOzs7Ozs7Ozs7OztBQ3ZQQTlXLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUN3YixhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJaEwsTUFBSjtBQUFXelEsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDb1EsUUFBTSxDQUFDblEsQ0FBRCxFQUFHO0FBQUNtUSxVQUFNLEdBQUNuUSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5VSxZQUFKO0FBQWlCL1UsTUFBTSxDQUFDSyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDeVUsZ0JBQVksR0FBQ3pVLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUcsV0FBSjtBQUFnQlQsTUFBTSxDQUFDSyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ0csZUFBVyxHQUFDSCxDQUFaO0FBQWM7O0FBQTFCLENBQWpELEVBQTZFLENBQTdFO0FBUXpNLE1BQU07QUFBRW9iO0FBQUYsSUFBYWpiLFdBQW5CO0FBSU8sTUFBTWdiLFdBQVcsR0FBRztBQUN6QnZNLE1BQUksRUFBRSxtQkFEbUI7O0FBR3pCK0YsTUFBSSxDQUFDMEcsZUFBRCxFQUFrQnpHLFFBQWxCLEVBQTRCO0FBQzlCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUN5TSxlQUFELENBQXhCLEVBQTJDNVcsT0FBM0MsRUFBb0RtUSxRQUFwRDtBQUNELEdBVndCOztBQVl6QkksVUFBUSxDQUFDcUcsZUFBRCxFQUFrQixDQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNELEdBakJ3Qjs7QUFtQnpCakcsS0FBRyxDQUFDaUcsZUFBRCxFQUFrQixDQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQXhCd0IsQ0FBcEI7QUE0QlAsTUFBTS9FLE9BQU8sR0FBRyxDQUNkNkUsV0FEYyxDQUFoQjtBQUtBN0UsT0FBTyxDQUFDdFYsT0FBUixDQUFnQnVWLE1BQU0sSUFBSTtBQUN4QnBHLFFBQU0sQ0FBQ21HLE9BQVAsQ0FBZTtBQUNiLEtBQUNDLE1BQU0sQ0FBQzNILElBQVIsR0FBZSxVQUFVNEgsSUFBVixFQUFnQjtBQUM3QkQsWUFBTSxDQUFDdkIsUUFBUCxDQUFnQkwsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkI2QixJQUEzQjtBQUNBLGFBQU9ELE1BQU0sQ0FBQ25CLEdBQVAsQ0FBV1QsSUFBWCxDQUFnQixJQUFoQixFQUFzQjZCLElBQXRCLENBQVA7QUFDRDtBQUpZLEdBQWY7QUFNRCxDQVBELEU7Ozs7Ozs7Ozs7O0FDN0NBOVcsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzJiLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSW5MLE1BQUo7QUFBV3pRLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ29RLFFBQU0sQ0FBQ25RLENBQUQsRUFBRztBQUFDbVEsVUFBTSxHQUFDblEsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVUsWUFBSjtBQUFpQi9VLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ3lVLGdCQUFZLEdBQUN6VSxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlHLFdBQUo7QUFBZ0JULE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLDBDQUFaLEVBQXVEO0FBQUNJLGFBQVcsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLGVBQVcsR0FBQ0gsQ0FBWjtBQUFjOztBQUE5QixDQUF2RCxFQUF1RixDQUF2RjtBQVNuTSxNQUFNO0FBQUVNO0FBQUYsSUFBWUgsV0FBbEI7QUFJTyxNQUFNbWIsUUFBUSxHQUFHO0FBQ3RCMU0sTUFBSSxFQUFFLGlCQURnQjs7QUFHdEIrRixNQUFJLENBQUM0RyxZQUFELEVBQWUzRyxRQUFmLEVBQXlCO0FBQzNCLFVBQU1uUSxPQUFPLEdBQUc7QUFDZG9RLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0EzRSxVQUFNLENBQUM0RSxLQUFQLENBQWEsS0FBS25HLElBQWxCLEVBQXdCLENBQUMyTSxZQUFELENBQXhCLEVBQXdDOVcsT0FBeEMsRUFBaURtUSxRQUFqRDtBQUNELEdBVnFCOztBQVl0QkksVUFBUSxDQUFDdUcsWUFBRCxFQUFlO0FBQ3JCLFFBQUk5RyxZQUFKLENBQWlCO0FBQ2Z0UixjQUFRLEVBQUU7QUFBRThSLFlBQUksRUFBRUM7QUFBUixPQURLO0FBRWZzRyxXQUFLLEVBQUs7QUFBRXZHLFlBQUksRUFBRU87QUFBUjtBQUZLLEtBQWpCLEVBR0dSLFFBSEgsQ0FHWXVHLFlBSFo7QUFJRCxHQWpCcUI7O0FBbUJ0Qm5HLEtBQUcsQ0FBQ21HLFlBQUQsRUFBZTtBQUNoQixVQUFNO0FBQUVwWSxjQUFRLEVBQUVoQixHQUFaO0FBQWlCcVo7QUFBakIsUUFBMkJELFlBQWpDO0FBQ0EsVUFBTWpaLE1BQU0sR0FBRztBQUFFSDtBQUFGLEtBQWY7QUFDQSxVQUFNNkUsR0FBRyxHQUFNO0FBQUV4RSxVQUFJLEVBQUU7QUFBRSwyQkFBbUJnWjtBQUFyQjtBQUFSLEtBQWY7QUFDQWxiLFNBQUssQ0FBQ2lDLE1BQU4sQ0FBYUQsTUFBYixFQUFxQjBFLEdBQXJCO0FBQ0Q7O0FBeEJxQixDQUFqQjtBQTZCUDtBQUNBLE1BQU1zUCxPQUFPLEdBQUcsQ0FDZGdGLFFBRGMsQ0FBaEI7QUFJQWhGLE9BQU8sQ0FBQ3RWLE9BQVIsQ0FBZ0J1VixNQUFNLElBQUk7QUFDeEJwRyxRQUFNLENBQUNtRyxPQUFQLENBQWU7QUFDYixLQUFDQyxNQUFNLENBQUMzSCxJQUFSLEdBQWUsVUFBVTRILElBQVYsRUFBZ0I7QUFDN0JELFlBQU0sQ0FBQ3ZCLFFBQVAsQ0FBZ0JMLElBQWhCLENBQXFCLElBQXJCLEVBQTJCNkIsSUFBM0I7QUFDQSxhQUFPRCxNQUFNLENBQUNuQixHQUFQLENBQVdULElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0I2QixJQUF0QixDQUFQO0FBQ0Q7QUFKWSxHQUFmO0FBTUQsQ0FQRCxFOzs7Ozs7Ozs7OztBQy9DQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBRUE7QUFDQTtBQUlBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSzs7Ozs7Ozs7Ozs7QUNwRUE5VyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDc0osa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXRCO0FBQXVDd1MsaUJBQWUsRUFBQyxNQUFJQSxlQUEzRDtBQUEyRXZTLGVBQWEsRUFBQyxNQUFJQSxhQUE3RjtBQUEyRzRHLFlBQVUsRUFBQyxNQUFJQSxVQUExSDtBQUFxSTNHLGFBQVcsRUFBQyxNQUFJQSxXQUFySjtBQUFpS0MsWUFBVSxFQUFDLE1BQUlBLFVBQWhMO0FBQTJMc1MsV0FBUyxFQUFDLE1BQUlBLFNBQXpNO0FBQW1ON0wsVUFBUSxFQUFDLE1BQUlBO0FBQWhPLENBQWQ7QUFBeVAsSUFBSU0sTUFBSjtBQUFXelEsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDb1EsUUFBTSxDQUFDblEsQ0FBRCxFQUFHO0FBQUNtUSxVQUFNLEdBQUNuUSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBYXBRLE1BQU0yYixHQUFHLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRixHQUF4QixDLENBQ0E7QUFDQTs7QUFFQSxNQUFNRyxPQUFPLEdBQUcseUJBQWhCLEMsQ0FBMkM7O0FBQzNDLE1BQU1DLFNBQVMsR0FBRyxXQUFXRCxPQUFYLEdBQXFCLEdBQXZDLEMsQ0FBMkM7QUFFM0M7O0FBQ0EsTUFBTTdTLGdCQUFnQixHQUFHa0gsTUFBTSxDQUFDQyxhQUFQLEdBQ0F1TCxHQUFHLEdBQUcsU0FETixHQUVBQSxHQUFHLEdBQUcsMkJBRi9CO0FBSUEsTUFBTUYsZUFBZSxHQUFHeFMsZ0JBQWdCLEdBQUcsY0FBM0M7QUFDQSxNQUFNQyxhQUFhLEdBQUdELGdCQUFnQixHQUFHLFVBQXpDO0FBRUEsTUFBTTZHLFVBQVUsR0FBRyxJQUFJa00sTUFBSixDQUFXLFdBQVdELFNBQVgsR0FBdUIsV0FBbEMsQ0FBbkIsQyxDQUNBOztBQUNBLE1BQU1sTSxRQUFRLEdBQUcsSUFBSW1NLE1BQUosQ0FBVyxVQUFVRixPQUFyQixDQUFqQixDLENBQ0E7O0FBQ0EsTUFBTTNTLFdBQVcsR0FBRyxJQUFJNlMsTUFBSixDQUFXLGFBQWFELFNBQXhCLENBQXBCLEMsQ0FDQTs7QUFDQSxNQUFNM1MsVUFBVSxHQUFHLCtDQUFuQixDLENBQ0E7O0FBQ0EsTUFBTXNTLFNBQVMsR0FBRyxRQUFsQixDLENBQ0Esa0I7Ozs7Ozs7Ozs7O0FDckNBaGMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ00sa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXRCO0FBQXVDQyxhQUFXLEVBQUMsTUFBSUEsV0FBdkQ7QUFBbUUrYixZQUFVLEVBQUMsTUFBSUE7QUFBbEYsQ0FBZDtBQUE2RyxJQUFJQyxrQkFBSjtBQUF1QnhjLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNtYyxvQkFBa0IsQ0FBQ2xjLENBQUQsRUFBRztBQUFDa2Msc0JBQWtCLEdBQUNsYyxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBbkMsRUFBaUYsQ0FBakY7QUFBb0YsSUFBSW1KLFdBQUo7QUFBZ0J6SixNQUFNLENBQUNLLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNvSixhQUFXLENBQUNuSixDQUFELEVBQUc7QUFBQ21KLGVBQVcsR0FBQ25KLENBQVo7QUFBYzs7QUFBOUIsQ0FBMUIsRUFBMEQsQ0FBMUQ7QUFXeE8sTUFBTW1jLFlBQVksR0FBRyxPQUFPLElBQUluSixJQUFJLENBQUNvSixJQUFMLENBQVUsQ0FBVixDQUFYLENBQXJCO0FBQ0EsTUFBTUMsS0FBSyxHQUFVLFFBQU0sR0FBM0IsQyxDQUErQjs7QUFJeEIsTUFBTXBjLGdCQUFnQixHQUFJeUUsS0FBRCxJQUFXO0FBQ3pDLE1BQUk0WCxLQUFLLEdBQUc1WCxLQUFLLEdBQUd5WCxZQUFwQjtBQUNBRyxPQUFLLElBQUl0SixJQUFJLENBQUN1SixLQUFMLENBQVdELEtBQUssR0FBRyxHQUFuQixJQUEwQixHQUFuQyxDQUZ5QyxDQUVGOztBQUV2QyxTQUFPQSxLQUFQO0FBQ0QsQ0FMTTs7QUFTQSxNQUFNcGMsV0FBVyxHQUFJb2MsS0FBRCxJQUFXO0FBQ3BDLE1BQUlFLElBQUksR0FBR3hKLElBQUksQ0FBQ3lKLEtBQUwsQ0FBV0gsS0FBSyxHQUFHRCxLQUFuQixDQUFYLENBRG9DLENBR3BDO0FBQ0E7QUFDQTs7QUFFQSxNQUFJRyxJQUFJLEdBQUcsRUFBWCxFQUFlO0FBQ2JBLFFBQUksR0FBRyxRQUFRQSxJQUFmO0FBQ0QsR0FGRCxNQUVPLElBQUlBLElBQUksR0FBRyxHQUFYLEVBQWdCO0FBQ3JCQSxRQUFJLEdBQUcsT0FBT0EsSUFBZDtBQUNELEdBRk0sTUFFQSxJQUFJQSxJQUFJLEdBQUcsSUFBWCxFQUFpQjtBQUN0QkEsUUFBSSxHQUFHLE1BQU1BLElBQWI7QUFDRCxHQUZNLE1BRUE7QUFDTEEsUUFBSSxHQUFHLEtBQUtBLElBQVo7QUFDRDs7QUFFRCxTQUFPQSxJQUFQO0FBQ0QsQ0FsQk07O0FBOEJBLE1BQU1QLFVBQVUsR0FBRyxDQUFDUyxRQUFELEVBQVdsUSxJQUFYLEtBQW9CO0FBQzFDLE1BQUk7QUFBRU0sT0FBRjtBQUFPNkQ7QUFBUCxNQUFpQitMLFFBQXJCOztBQUVBLFFBQU1DLGFBQWEsR0FBRyxDQUFDaE0sS0FBRCxFQUFRbkUsSUFBUixLQUFpQjtBQUNyQyxXQUFPbUUsS0FBSyxDQUFDckwsSUFBTixDQUFXbUcsSUFBSSxJQUFJO0FBQ3hCLFlBQU10QixLQUFLLEdBQUdoQixXQUFXLENBQUNpQixJQUFaLENBQWlCcUIsSUFBakIsQ0FBZDs7QUFDQSxVQUFJdEIsS0FBSyxJQUFLQSxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQWFxQyxJQUEzQixFQUFrQztBQUNoQyxlQUFPLElBQVA7QUFDRDtBQUNGLEtBTE0sQ0FBUDtBQU1ELEdBUEQ7O0FBU0EsTUFBSW1FLEtBQUosRUFBVztBQUNUO0FBQ0EsUUFBSWxGLElBQUksR0FBR2tSLGFBQWEsQ0FBQ2hNLEtBQUQsRUFBUW5FLElBQVIsQ0FBeEIsQ0FGUyxDQUU2Qjs7QUFFdEMsUUFBSSxDQUFDZixJQUFMLEVBQVc7QUFDVDtBQUNBZSxVQUFJLEdBQUdBLElBQUksQ0FBQ0osT0FBTCxDQUFhLE1BQWIsRUFBcUIsRUFBckIsQ0FBUCxDQUZTLENBRXVCOztBQUNoQ1gsVUFBSSxHQUFHa1IsYUFBYSxDQUFDaE0sS0FBRCxFQUFRbkUsSUFBUixDQUFwQjtBQUNEOztBQUVELFFBQUksQ0FBQ2YsSUFBTCxFQUFXO0FBQ1Q7QUFDQTtBQUNBQSxVQUFJLEdBQUdrUixhQUFhLENBQUNoTSxLQUFELEVBQVEsSUFBUixDQUFwQjtBQUNEOztBQUVEN0QsT0FBRyxHQUFHQSxHQUFHLENBQUNWLE9BQUosQ0FBWSxJQUFaLEVBQWtCWCxJQUFsQixDQUFOO0FBQ0Q7O0FBRUQsU0FBT3FCLEdBQVA7QUFDRCxDQWhDSSxDOzs7Ozs7Ozs7OztBQ3ZEUHBOLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNpZCxRQUFNLEVBQUMsTUFBSUEsTUFBWjtBQUFtQkMsWUFBVSxFQUFDLE1BQUlBLFVBQWxDO0FBQTZDQyxXQUFTLEVBQUMsTUFBSUEsU0FBM0Q7QUFBcUVDLGFBQVcsRUFBQyxNQUFJQSxXQUFyRjtBQUFpR25OLFVBQVEsRUFBQyxNQUFJQSxRQUE5RztBQUF1SG9OLFNBQU8sRUFBQyxNQUFJQSxPQUFuSTtBQUEySWxkLFNBQU8sRUFBQyxNQUFJQSxPQUF2SjtBQUErSm1kLFVBQVEsRUFBQyxNQUFJQSxRQUE1SztBQUFxTEMsY0FBWSxFQUFDLE1BQUlBLFlBQXRNO0FBQW1ONVosWUFBVSxFQUFDLE1BQUlBLFVBQWxPO0FBQTZPNlosZ0JBQWMsRUFBQyxNQUFJQSxjQUFoUTtBQUErUUMsY0FBWSxFQUFDLE1BQUlBLFlBQWhTO0FBQTZTQyxTQUFPLEVBQUMsTUFBSUEsT0FBelQ7QUFBaVUvTCxXQUFTLEVBQUMsTUFBSUEsU0FBL1U7QUFBeVY0SyxvQkFBa0IsRUFBQyxNQUFJQSxrQkFBaFg7QUFBbVloVyxjQUFZLEVBQUMsTUFBSUEsWUFBcFo7QUFBaWFvWCxXQUFTLEVBQUMsTUFBSUEsU0FBL2E7QUFBeWJDLFdBQVMsRUFBQyxNQUFJQSxTQUF2YztBQUFpZEMsT0FBSyxFQUFDLE1BQUlBLEtBQTNkO0FBQWllQyxnQkFBYyxFQUFDLE1BQUlBLGNBQXBmO0FBQW1nQkMsa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXhoQjtBQUF5aUJDLFdBQVMsRUFBQyxNQUFJQSxTQUF2akI7QUFBaWtCQyxjQUFZLEVBQUMsTUFBSUEsWUFBbGxCO0FBQStsQkMsT0FBSyxFQUFDLE1BQUlBLEtBQXptQjtBQUErbUJDLGFBQVcsRUFBQyxNQUFJQSxXQUEvbkI7QUFBMm9CQyxTQUFPLEVBQUMsTUFBSUEsT0FBdnBCO0FBQStwQkMsYUFBVyxFQUFDLE1BQUlBLFdBQS9xQjtBQUEyckJDLGVBQWEsRUFBQyxNQUFJQSxhQUE3c0I7QUFBMnRCQyxNQUFJLEVBQUMsTUFBSUEsSUFBcHVCO0FBQXl1QkMsV0FBUyxFQUFDLE1BQUlBLFNBQXZ2QjtBQUFpd0JDLFlBQVUsRUFBQyxNQUFJQSxVQUFoeEI7QUFBMnhCQyxjQUFZLEVBQUMsTUFBSUEsWUFBNXlCO0FBQXl6QkMsVUFBUSxFQUFDLE1BQUlBLFFBQXQwQjtBQUErMEJDLGlCQUFlLEVBQUMsTUFBSUE7QUFBbjJCLENBQWQ7O0FBV08sTUFBTTNCLE1BQU0sR0FBSTFFLEtBQUQsSUFBVztBQUMvQixNQUFJQSxLQUFLLENBQUM5RixTQUFOLENBQWdCLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCdkYsV0FBdEIsT0FBd0MsS0FBNUMsRUFBb0Q7QUFDbEQsV0FBT29RLFFBQVEsQ0FBQy9FLEtBQUQsQ0FBZjtBQUNEOztBQUVELE1BQUlBLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxHQUFqQixFQUFzQjtBQUNwQkEsU0FBSyxHQUFHQSxLQUFLLENBQUNzRyxLQUFOLENBQVksQ0FBWixDQUFSO0FBQ0Q7O0FBRUQsTUFBSXRHLEtBQUssQ0FBQzNULE1BQU4sS0FBaUIsQ0FBckIsRUFBd0I7QUFDdEIyVCxTQUFLLEdBQUdBLEtBQUssQ0FBQyxDQUFELENBQUwsR0FBU0EsS0FBSyxDQUFDLENBQUQsQ0FBZCxHQUFrQkEsS0FBSyxDQUFDLENBQUQsQ0FBdkIsR0FBMkJBLEtBQUssQ0FBQyxDQUFELENBQWhDLEdBQW9DQSxLQUFLLENBQUMsQ0FBRCxDQUF6QyxHQUE2Q0EsS0FBSyxDQUFDLENBQUQsQ0FBMUQ7QUFDRDs7QUFFRCxRQUFNdUcsR0FBRyxHQUFHQyxRQUFRLENBQUN4RyxLQUFELEVBQVEsRUFBUixDQUFwQjtBQUVBLFNBQU8sQ0FDTHVHLEdBQUcsSUFBSSxFQURGLENBQ2U7QUFEZixJQUVMQSxHQUFHLElBQUssQ0FBVCxHQUFjLE1BRlIsQ0FFZTtBQUZmLElBR0xBLEdBQUcsR0FBVSxJQUhSLENBR2U7QUFIZixHQUFQO0FBS0QsQ0FwQk07O0FBd0JBLE1BQU01QixVQUFVLEdBQUcsQ0FBQzhCLE1BQUQsRUFBU0MsTUFBVCxFQUFpQi9MLEtBQWpCLEtBQTJCO0FBQ25ELFFBQU1nTSxJQUFJLEdBQUdqQyxNQUFNLENBQUMrQixNQUFELENBQW5CO0FBQ0EsUUFBTUcsSUFBSSxHQUFHbEMsTUFBTSxDQUFDZ0MsTUFBRCxDQUFuQjtBQUVBLFFBQU1ILEdBQUcsR0FBR0ksSUFBSSxDQUFDM1osR0FBTCxDQUFTLENBQUNvTCxLQUFELEVBQVE1TCxLQUFSLEtBQWtCO0FBQ3JDNEwsU0FBSyxHQUFHMEMsSUFBSSxDQUFDeUosS0FBTCxDQUFXbk0sS0FBSyxHQUFHLENBQUNBLEtBQUssR0FBR3dPLElBQUksQ0FBQ3BhLEtBQUQsQ0FBYixJQUF3Qm1PLEtBQTNDLENBQVI7QUFDQXZDLFNBQUssR0FBRzBDLElBQUksQ0FBQ0MsR0FBTCxDQUFTLENBQVQsRUFBWUQsSUFBSSxDQUFDWSxHQUFMLENBQVN0RCxLQUFULEVBQWdCLEdBQWhCLENBQVosQ0FBUjtBQUVBLFdBQU8sQ0FBRUEsS0FBSyxHQUFHLEVBQVQsR0FBZSxHQUFmLEdBQXFCLEVBQXRCLElBQTRCQSxLQUFLLENBQUN5TyxRQUFOLENBQWUsRUFBZixDQUFuQztBQUNELEdBTFcsQ0FBWjtBQU9BLFNBQU8sTUFBTU4sR0FBRyxDQUFDNVQsSUFBSixDQUFTLEVBQVQsQ0FBYjtBQUNELENBWk07O0FBZ0JBLE1BQU1pUyxTQUFTLEdBQUcsQ0FBQzVFLEtBQUQsRUFBUXJGLEtBQVIsS0FBa0I7QUFDekMsUUFBTW1NLE1BQU0sR0FBRzlHLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxHQUE1Qjs7QUFFQSxNQUFJOEcsTUFBSixFQUFZO0FBQ1Y5RyxTQUFLLEdBQUdBLEtBQUssQ0FBQ3NHLEtBQU4sQ0FBWSxDQUFaLENBQVI7QUFDRDs7QUFFRCxRQUFNUyxHQUFHLEdBQUdyQyxNQUFNLENBQUMxRSxLQUFELENBQU4sQ0FDQWhULEdBREEsQ0FDS29MLEtBQUssSUFBSTtBQUN4QkEsU0FBSyxHQUFHMEMsSUFBSSxDQUFDdUosS0FBTCxDQUFXdkosSUFBSSxDQUFDQyxHQUFMLENBQVMsQ0FBVCxFQUFZRCxJQUFJLENBQUNZLEdBQUwsQ0FBUyxHQUFULEVBQWN0RCxLQUFLLEdBQUd1QyxLQUF0QixDQUFaLENBQVgsQ0FBUjtBQUNBLFdBQU8sQ0FBRXZDLEtBQUssR0FBRyxFQUFULEdBQWUsR0FBZixHQUFxQixFQUF0QixJQUE0QkEsS0FBSyxDQUFDeU8sUUFBTixDQUFlLEVBQWYsQ0FBbkM7QUFDRCxHQUpXLENBQVo7QUFNQSxTQUFPLENBQUNDLE1BQU0sR0FBRyxHQUFILEdBQVMsRUFBaEIsSUFBc0JDLEdBQUcsQ0FBQ3BVLElBQUosQ0FBUyxFQUFULENBQTdCO0FBQ0QsQ0FkTTs7QUFrQkEsTUFBTWtTLFdBQVcsR0FBRyxDQUFDN0UsS0FBRCxFQUFRZ0gsT0FBUixLQUFvQjtBQUM3QyxNQUFJaEgsS0FBSyxDQUFDLENBQUQsQ0FBTCxLQUFhLEdBQWpCLEVBQXNCO0FBQ3BCQSxTQUFLLEdBQUdBLEtBQUssQ0FBQ3NHLEtBQU4sQ0FBWSxDQUFaLENBQVI7QUFDRDs7QUFFRCxRQUFNUyxHQUFHLEdBQUdyQyxNQUFNLENBQUMxRSxLQUFELENBQWxCO0FBRUEsd0JBQWUrRyxHQUFHLENBQUMsQ0FBRCxDQUFsQixlQUEwQkEsR0FBRyxDQUFDLENBQUQsQ0FBN0IsZUFBcUNBLEdBQUcsQ0FBQyxDQUFELENBQXhDLGVBQWdEQyxPQUFoRDtBQUNELENBUk07O0FBYUEsTUFBTXRQLFFBQVEsR0FBRyxVQUE2QztBQUFBLE1BQTVDO0FBQUVHLFVBQUY7QUFBVW9QLEtBQUMsR0FBQyxHQUFaO0FBQWlCQyxLQUFDLEdBQUMsSUFBbkI7QUFBeUJuTyxVQUFNLEdBQUM7QUFBaEMsR0FBNEM7QUFDbkUsUUFBTW9PLENBQUMsR0FBR3RQLE1BQU0sR0FBRyxZQUFuQixDQURtRSxDQUNuQzs7QUFFaENvUCxHQUFDLEdBQUduTSxJQUFJLENBQUNDLEdBQUwsQ0FBUyxDQUFULEVBQVlELElBQUksQ0FBQ1ksR0FBTCxDQUFTdUwsQ0FBVCxFQUFZLENBQVosQ0FBWixDQUFKO0FBQ0FDLEdBQUMsR0FBR3BNLElBQUksQ0FBQ0MsR0FBTCxDQUFTLENBQVQsRUFBWUQsSUFBSSxDQUFDWSxHQUFMLENBQVN3TCxDQUFULEVBQVksQ0FBWixDQUFaLENBQUo7O0FBRUEsVUFBUW5PLE1BQU0sQ0FBQ3BFLFdBQVAsRUFBUjtBQUNFLFNBQUssS0FBTDtBQUNFLGFBQU9tUSxPQUFPLENBQUNxQyxDQUFELEVBQUlGLENBQUosRUFBT0MsQ0FBUCxDQUFkOztBQUVGLFNBQUssS0FBTDtBQUNFLGFBQU90ZixPQUFPLENBQUN1ZixDQUFELEVBQUlGLENBQUMsR0FBRyxHQUFSLEVBQWFDLENBQUMsR0FBRyxHQUFqQixDQUFkOztBQUVGO0FBQVM7QUFDUCwyQkFBY0MsQ0FBZCxjQUFtQkYsQ0FBQyxHQUFDLEdBQXJCLGVBQTZCQyxDQUFDLEdBQUMsR0FBL0I7QUFSSjtBQVVELENBaEJNOztBQXFCQSxNQUFNcEMsT0FBTyxHQUFHLENBQUNxQyxDQUFELEVBQUdGLENBQUgsRUFBS0MsQ0FBTCxLQUFXO0FBQ2hDLE1BQUlFLENBQUMsR0FBQ0gsQ0FBQyxHQUFDbk0sSUFBSSxDQUFDWSxHQUFMLENBQVN3TCxDQUFULEVBQVcsSUFBRUEsQ0FBYixDQUFSOztBQUNBLE1BQUlHLENBQUMsR0FBRSxVQUFDQyxDQUFEO0FBQUEsUUFBR0MsQ0FBSCx1RUFBSyxDQUFDRCxDQUFDLEdBQUNILENBQUMsR0FBQyxFQUFMLElBQVMsRUFBZDtBQUFBLFdBQXFCRCxDQUFDLEdBQUdFLENBQUMsR0FBQ3RNLElBQUksQ0FBQ0MsR0FBTCxDQUFTRCxJQUFJLENBQUNZLEdBQUwsQ0FBUzZMLENBQUMsR0FBQyxDQUFYLEVBQWEsSUFBRUEsQ0FBZixFQUFpQixDQUFqQixDQUFULEVBQTZCLENBQUMsQ0FBOUIsQ0FBM0I7QUFBQSxHQUFQOztBQUNBLFNBQU8sQ0FBQ0YsQ0FBQyxDQUFDLENBQUQsQ0FBRixFQUFNQSxDQUFDLENBQUMsQ0FBRCxDQUFQLEVBQVdBLENBQUMsQ0FBQyxDQUFELENBQVosQ0FBUDtBQUNELENBSk07O0FBUUEsTUFBTXpmLE9BQU8sR0FBRyxDQUFDdWYsQ0FBRCxFQUFJRixDQUFKLEVBQU9DLENBQVAsS0FBYTtBQUNsQ0MsR0FBQyxJQUFJLEdBQUw7QUFDQUYsR0FBQyxJQUFJLEdBQUw7QUFDQUMsR0FBQyxJQUFJLEdBQUw7QUFDQSxNQUFJTSxDQUFKLEVBQU9DLENBQVAsRUFBVUMsQ0FBVjs7QUFDQSxNQUFJVCxDQUFDLEtBQUssQ0FBVixFQUFhO0FBQ1hPLEtBQUMsR0FBR0MsQ0FBQyxHQUFHQyxDQUFDLEdBQUdSLENBQVosQ0FEVyxDQUNJO0FBQ2hCLEdBRkQsTUFFTztBQUNMLFVBQU1TLE9BQU8sR0FBRyxDQUFDQyxDQUFELEVBQUlDLENBQUosRUFBT0MsQ0FBUCxLQUFhO0FBQzNCLFVBQUlBLENBQUMsR0FBRyxDQUFSLEVBQVdBLENBQUMsSUFBSSxDQUFMO0FBQ1gsVUFBSUEsQ0FBQyxHQUFHLENBQVIsRUFBV0EsQ0FBQyxJQUFJLENBQUw7QUFDWCxVQUFJQSxDQUFDLEdBQUcsSUFBSSxDQUFaLEVBQWUsT0FBT0YsQ0FBQyxHQUFHLENBQUNDLENBQUMsR0FBR0QsQ0FBTCxJQUFVLENBQVYsR0FBY0UsQ0FBekI7QUFDZixVQUFJQSxDQUFDLEdBQUcsSUFBSSxDQUFaLEVBQWUsT0FBT0QsQ0FBUDtBQUNmLFVBQUlDLENBQUMsR0FBRyxJQUFJLENBQVosRUFBZSxPQUFPRixDQUFDLEdBQUcsQ0FBQ0MsQ0FBQyxHQUFHRCxDQUFMLEtBQVcsSUFBSSxDQUFKLEdBQVFFLENBQW5CLElBQXdCLENBQW5DO0FBQ2YsYUFBT0YsQ0FBUDtBQUNELEtBUEQ7O0FBUUEsVUFBTUMsQ0FBQyxHQUFHWCxDQUFDLEdBQUcsR0FBSixHQUFVQSxDQUFDLElBQUksSUFBSUQsQ0FBUixDQUFYLEdBQXdCQyxDQUFDLEdBQUdELENBQUosR0FBUUMsQ0FBQyxHQUFHRCxDQUE5QztBQUNBLFVBQU1XLENBQUMsR0FBRyxJQUFJVixDQUFKLEdBQVFXLENBQWxCO0FBQ0FMLEtBQUMsR0FBR0csT0FBTyxDQUFDQyxDQUFELEVBQUlDLENBQUosRUFBT1YsQ0FBQyxHQUFHLElBQUksQ0FBZixDQUFYO0FBQ0FNLEtBQUMsR0FBR0UsT0FBTyxDQUFDQyxDQUFELEVBQUlDLENBQUosRUFBT1YsQ0FBUCxDQUFYO0FBQ0FPLEtBQUMsR0FBR0MsT0FBTyxDQUFDQyxDQUFELEVBQUlDLENBQUosRUFBT1YsQ0FBQyxHQUFHLElBQUksQ0FBZixDQUFYO0FBQ0Q7O0FBQ0QsUUFBTVksS0FBSyxHQUFHN0gsQ0FBQyxJQUFJO0FBQ2pCLFVBQU1xRyxHQUFHLEdBQUd6TCxJQUFJLENBQUN5SixLQUFMLENBQVdyRSxDQUFDLEdBQUcsR0FBZixFQUFvQjJHLFFBQXBCLENBQTZCLEVBQTdCLENBQVo7QUFDQSxXQUFPTixHQUFHLENBQUNsYSxNQUFKLEtBQWUsQ0FBZixHQUFtQixNQUFNa2EsR0FBekIsR0FBK0JBLEdBQXRDO0FBQ0QsR0FIRDs7QUFJQSxvQkFBV3dCLEtBQUssQ0FBQ1AsQ0FBRCxDQUFoQixTQUFzQk8sS0FBSyxDQUFDTixDQUFELENBQTNCLFNBQWlDTSxLQUFLLENBQUNMLENBQUQsQ0FBdEM7QUFDRCxDQTNCTTs7QUErQkEsTUFBTTNDLFFBQVEsR0FBSWlELFdBQUQsSUFBaUI7QUFDdkM7QUFDQTtBQUNBLE1BQUlqQixHQUFHLEdBQUcsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsQ0FBVjtBQUVBLFFBQU0vVSxLQUFLLEdBQUcsdUVBQWQ7QUFDQSxRQUFNQyxLQUFLLEdBQUdELEtBQUssQ0FBQ0UsSUFBTixDQUFXOFYsV0FBWCxDQUFkOztBQUVBLE1BQUkvVixLQUFKLEVBQVc7QUFDVCxRQUFJa1YsQ0FBQyxHQUFHaFMsVUFBVSxDQUFDbEQsS0FBSyxDQUFDLENBQUQsQ0FBTixFQUFXLEVBQVgsQ0FBbEI7QUFDQSxRQUFJZ1YsQ0FBQyxHQUFHOVIsVUFBVSxDQUFDbEQsS0FBSyxDQUFDLENBQUQsQ0FBTixFQUFXLEVBQVgsQ0FBbEI7QUFDQSxRQUFJaVYsQ0FBQyxHQUFHL1IsVUFBVSxDQUFDbEQsS0FBSyxDQUFDLENBQUQsQ0FBTixFQUFXLEVBQVgsQ0FBbEI7O0FBRUEsV0FBT2tWLENBQUMsR0FBRyxHQUFYLEVBQWdCO0FBQ2RBLE9BQUMsSUFBSSxHQUFMO0FBQ0Q7O0FBQ0QsV0FBT0EsQ0FBQyxHQUFHLENBQVgsRUFBYztBQUNaQSxPQUFDLElBQUksR0FBTDtBQUNEOztBQUNELFFBQUlsVixLQUFLLENBQUMsQ0FBRCxDQUFULEVBQWM7QUFDWmdWLE9BQUMsSUFBSSxHQUFMO0FBQ0Q7O0FBQ0RBLEtBQUMsR0FBR25NLElBQUksQ0FBQ0MsR0FBTCxDQUFTLENBQVQsRUFBWUQsSUFBSSxDQUFDWSxHQUFMLENBQVN1TCxDQUFULEVBQVksQ0FBWixDQUFaLENBQUo7O0FBQ0EsUUFBSWhWLEtBQUssQ0FBQyxDQUFELENBQVQsRUFBYztBQUNaaVYsT0FBQyxJQUFJLEdBQUw7QUFDRDs7QUFDREEsS0FBQyxHQUFHcE0sSUFBSSxDQUFDQyxHQUFMLENBQVMsQ0FBVCxFQUFZRCxJQUFJLENBQUNZLEdBQUwsQ0FBU3dMLENBQVQsRUFBWSxDQUFaLENBQVosQ0FBSjtBQUVBSCxPQUFHLEdBQUdqQyxPQUFPLENBQUNxQyxDQUFELEVBQUlGLENBQUosRUFBT0MsQ0FBUCxDQUFQLENBQWlCO0FBQWpCLEtBQ0FsYSxHQURBLENBQ0k2SyxNQUFNLElBQUlpRCxJQUFJLENBQUN5SixLQUFMLENBQVcxTSxNQUFNLEdBQUcsR0FBcEIsQ0FEZCxDQUFOO0FBRUQ7O0FBRUQsU0FBT2tQLEdBQVA7QUFDRCxDQWpDTTs7QUEyQ0EsTUFBTS9CLFlBQVksR0FBRyxDQUFDaEYsS0FBRCxFQUFRaUksTUFBUixLQUFtQjtBQUM3QyxRQUFNQyxNQUFNLEdBQUc7QUFDYkMsVUFBTSxFQUFNLENBREM7QUFFYkMsWUFBUSxFQUFJLEdBRkM7QUFHYkMsYUFBUyxFQUFHLElBSEM7QUFLYkMsVUFBTSxFQUFLLEdBTEU7QUFNYkMsWUFBUSxFQUFHLElBTkU7QUFPYkMsYUFBUyxFQUFFLEtBUEU7QUFTYkMsVUFBTSxFQUFLLElBVEU7QUFVYkMsWUFBUSxFQUFHLEtBVkU7QUFXYkMsYUFBUyxFQUFFO0FBWEUsR0FBZjtBQWFBLFFBQU03UixJQUFJLEdBQUc5RyxNQUFNLENBQUM4RyxJQUFQLENBQVlvUixNQUFaLENBQWI7O0FBRUMsR0FBQyxTQUFTVSxLQUFULENBQWVDLEtBQWYsRUFBc0I7QUFDdEIsUUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzdCL1IsVUFBSSxDQUFDaE8sT0FBTCxDQUFjQyxHQUFHLElBQUk7QUFDbkIsY0FBTXFQLEtBQUssR0FBR3lRLEtBQUssQ0FBQzlmLEdBQUQsQ0FBbkI7O0FBQ0EsWUFBSSxDQUFDbU0sS0FBSyxDQUFDa0QsS0FBRCxDQUFWLEVBQW1CO0FBQ2pCLGNBQUlBLEtBQUssR0FBRyxDQUFaLEVBQWU7QUFDYjhQLGtCQUFNLENBQUNuZixHQUFELENBQU4sR0FBY3FQLEtBQWQ7QUFDRDtBQUNGO0FBQ0YsT0FQRDtBQVFEO0FBQ0YsR0FYQTs7QUFhRHRCLE1BQUksQ0FBQ2hPLE9BQUwsQ0FBY0MsR0FBRyxJQUNmbWYsTUFBTSxDQUFDbmYsR0FBRCxDQUFOLEdBQWM2YixTQUFTLENBQUM1RSxLQUFELEVBQVFrSSxNQUFNLENBQUNuZixHQUFELENBQWQsQ0FEekI7QUFJQSxTQUFPbWYsTUFBUDtBQUNELENBbENNOztBQXVDQSxNQUFNOWMsVUFBVSxHQUFHLENBQUNpTSxLQUFELEVBQVE1SyxJQUFSLEVBQWNxYyxTQUFkLEtBQTRCO0FBQ3BELE1BQUk1SCxPQUFPLEdBQUcsQ0FBZDtBQUNBLE1BQUkxVSxLQUFKLEVBQ0l1YyxLQURKOztBQUdBLEtBQUc7QUFDRCxRQUFJLE9BQU90YyxJQUFQLEtBQWdCLFVBQXBCLEVBQWdDO0FBQzlCRCxXQUFLLEdBQUc2SyxLQUFLLENBQUMyUixTQUFOLENBQWdCdmMsSUFBaEIsQ0FBUjtBQUNELEtBRkQsTUFFTztBQUNMRCxXQUFLLEdBQUc2SyxLQUFLLENBQUNDLE9BQU4sQ0FBYzdLLElBQWQsQ0FBUjtBQUNEOztBQUVEc2MsU0FBSyxHQUFHLEVBQUV2YyxLQUFLLEdBQUcsQ0FBVixDQUFSOztBQUNBLFFBQUl1YyxLQUFKLEVBQVc7QUFDVDFSLFdBQUssQ0FBQzRSLE1BQU4sQ0FBYXpjLEtBQWIsRUFBb0IsQ0FBcEI7QUFDQTBVLGFBQU8sSUFBSSxDQUFYO0FBQ0Q7QUFDRixHQVpELFFBWVM0SCxTQUFTLElBQUlDLEtBWnRCOztBQWNBLFNBQU83SCxPQUFQO0FBQ0QsQ0FwQk07O0FBd0JBLE1BQU0rRCxjQUFjLEdBQUcsTUFBTTtBQUNsQyxNQUFLaUUsUUFBUSxHQUFHLEVBQWhCO0FBRUEsU0FBUTdSLEtBQUQsSUFBVztBQUNoQixVQUFNOFIsSUFBSSxHQUFHOVIsS0FBSyxDQUFDdkIsTUFBTixDQUFhckosSUFBSSxJQUFJeWMsUUFBUSxDQUFDNVIsT0FBVCxDQUFpQjdLLElBQWpCLElBQXlCLENBQTlDLENBQWI7QUFDQSxVQUFNMmMsS0FBSyxHQUFHRixRQUFRLENBQUNwVCxNQUFULENBQWdCckosSUFBSSxJQUFJNEssS0FBSyxDQUFDQyxPQUFOLENBQWM3SyxJQUFkLElBQXNCLENBQTlDLENBQWQ7QUFDQXljLFlBQVEsR0FBRyxDQUFDLEdBQUc3UixLQUFKLENBQVg7QUFFQSxXQUFPO0FBQUU4UixVQUFGO0FBQVFDO0FBQVIsS0FBUDtBQUNELEdBTkQ7QUFPRCxDQVZNOztBQWNBLE1BQU1sRSxZQUFZLEdBQUk3TixLQUFELElBQVc7QUFDckMsUUFBTWdTLE9BQU8sR0FBR2hTLEtBQWhCO0FBQ0EsTUFBSzZSLFFBQVEsR0FBRyxDQUFDLEdBQUc3UixLQUFKLENBQWhCO0FBRUEsU0FBTyxNQUFNO0FBQ1gsVUFBTThSLElBQUksR0FBRzlSLEtBQUssQ0FBQ3ZCLE1BQU4sQ0FBYXJKLElBQUksSUFBSXljLFFBQVEsQ0FBQzVSLE9BQVQsQ0FBaUI3SyxJQUFqQixJQUF5QixDQUE5QyxDQUFiO0FBQ0EsVUFBTTJjLEtBQUssR0FBR0YsUUFBUSxDQUFDcFQsTUFBVCxDQUFnQnJKLElBQUksSUFBSTRLLEtBQUssQ0FBQ0MsT0FBTixDQUFjN0ssSUFBZCxJQUFzQixDQUE5QyxDQUFkO0FBQ0F5YyxZQUFRLEdBQUcsQ0FBQyxHQUFHN1IsS0FBSixDQUFYO0FBRUEsV0FBTztBQUFFOFIsVUFBRjtBQUFRQztBQUFSLEtBQVA7QUFDRCxHQU5EO0FBT0QsQ0FYTTs7QUFlQSxNQUFNakUsT0FBTyxHQUFJaUMsQ0FBRCxJQUFPO0FBQzVCLE1BQUlrQyxFQUFFLEdBQUdsQyxDQUFDLENBQUMvYSxNQUFYOztBQUVBLFNBQU9pZCxFQUFQLEVBQVc7QUFDVCxVQUFNQyxFQUFFLEdBQUd6TyxJQUFJLENBQUN1SixLQUFMLENBQVd2SixJQUFJLENBQUMwTyxNQUFMLEtBQWdCRixFQUEzQixDQUFYO0FBQ0FBLE1BQUUsSUFBSSxDQUFOO0FBQ0EsS0FBQ2xDLENBQUMsQ0FBQ2tDLEVBQUQsQ0FBRixFQUFRbEMsQ0FBQyxDQUFDbUMsRUFBRCxDQUFULElBQWlCLENBQUNuQyxDQUFDLENBQUNtQyxFQUFELENBQUYsRUFBUW5DLENBQUMsQ0FBQ2tDLEVBQUQsQ0FBVCxDQUFqQjtBQUNEOztBQUVELFNBQU9sQyxDQUFQLENBVDRCLENBU25CO0FBQ1YsQ0FWTTs7QUFjQSxNQUFNaE8sU0FBUyxHQUFHLFVBQUMyQixHQUFELEVBQWtCO0FBQUEsTUFBWlcsR0FBWSx1RUFBTixDQUFNO0FBQ3pDLFNBQU9aLElBQUksQ0FBQ3VKLEtBQUwsQ0FBV3ZKLElBQUksQ0FBQzBPLE1BQUwsTUFBaUJ6TyxHQUFHLEdBQUdXLEdBQU4sR0FBWSxDQUE3QixDQUFYLElBQThDQSxHQUFyRDtBQUNELENBRk07O0FBTUEsTUFBTXNJLGtCQUFrQixHQUFJM00sS0FBRCxJQUFXO0FBQzNDLFNBQU9BLEtBQUssQ0FBQ3lELElBQUksQ0FBQ3VKLEtBQUwsQ0FBV3ZKLElBQUksQ0FBQzBPLE1BQUwsS0FBZ0JuUyxLQUFLLENBQUNoTCxNQUFqQyxDQUFELENBQVo7QUFDRCxDQUZNOztBQU1BLE1BQU0yQixZQUFZLEdBQUcsQ0FBQ3liLE1BQUQsRUFBU0MsTUFBVCxLQUFvQjtBQUM5QyxNQUFJLENBQUNELE1BQUQsSUFBVyxDQUFDQSxNQUFNLENBQUNwZCxNQUFuQixJQUE2QixDQUFDcWQsTUFBOUIsSUFBd0MsQ0FBQ0EsTUFBTSxDQUFDcmQsTUFBcEQsRUFBNEQ7QUFDMUQsV0FBTyxFQUFQO0FBQ0Q7O0FBRUQsU0FBT29kLE1BQU0sQ0FBQzNULE1BQVAsQ0FBZXJKLElBQUksSUFBSWlkLE1BQU0sQ0FBQ2pjLFFBQVAsQ0FBZ0JoQixJQUFoQixDQUF2QixDQUFQO0FBQ0QsQ0FOTTs7QUFVQSxNQUFNMlksU0FBUyxHQUFHLENBQUN1RSxNQUFELEVBQVNDLElBQVQsRUFBZUMsa0JBQWYsS0FBc0M7QUFDN0QsUUFBTUMsTUFBTSxHQUFHSCxNQUFNLENBQUNyRCxLQUFQLENBQWEsQ0FBYixDQUFmO0FBQ0FzRCxNQUFJLENBQUM5Z0IsT0FBTCxDQUFhMkQsSUFBSSxJQUFJckIsVUFBVSxDQUFDMGUsTUFBRCxFQUFTcmQsSUFBVCxDQUEvQjtBQUNBLE1BQUlBLElBQUksR0FBR3VYLGtCQUFrQixDQUFDOEYsTUFBRCxDQUE3Qjs7QUFFQSxNQUFJLENBQUNyZCxJQUFELElBQVNvZCxrQkFBYixFQUFpQztBQUMvQjtBQUNBO0FBQ0FwZCxRQUFJLEdBQUd1WCxrQkFBa0IsQ0FBQzJGLE1BQUQsQ0FBekI7QUFDRDs7QUFFRCxTQUFPbGQsSUFBUDtBQUNELENBWk07O0FBa0JBLE1BQU00WSxTQUFTLEdBQUkwRSxLQUFELElBQVc7QUFDbEMsTUFBSUEsS0FBSyxDQUFDQyxhQUFOLElBQXVCRCxLQUFLLENBQUNDLGFBQU4sQ0FBb0IzZCxNQUEvQyxFQUF1RDtBQUNyRDBkLFNBQUssR0FBR0EsS0FBSyxDQUFDQyxhQUFOLENBQW9CLENBQXBCLEtBQTBCLEVBQWxDO0FBQ0Q7O0FBRUQsU0FBTztBQUFFOUosS0FBQyxFQUFFNkosS0FBSyxDQUFDRSxLQUFYO0FBQWtCOUosS0FBQyxFQUFFNEosS0FBSyxDQUFDRztBQUEzQixHQUFQO0FBQ0QsQ0FOTTs7QUFTQSxNQUFNNUUsS0FBSyxHQUFHLENBQUN5RSxLQUFELEVBQVFJLEtBQVIsS0FBa0I7QUFDckMsTUFBSSxDQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFFBQW5CLEVBQTZCN1MsT0FBN0IsQ0FBcUM2UyxLQUFyQyxJQUE4QyxDQUFsRCxFQUFxRDtBQUNuREEsU0FBSyxHQUFHLFFBQVI7QUFDRDs7QUFDRCxNQUFJSixLQUFLLENBQUNDLGFBQU4sSUFBdUJELEtBQUssQ0FBQ0MsYUFBTixDQUFvQjNkLE1BQS9DLEVBQXVEO0FBQ3JEMGQsU0FBSyxHQUFHQSxLQUFLLENBQUNDLGFBQU4sQ0FBb0IsQ0FBcEIsS0FBMEIsRUFBbEM7QUFDRDs7QUFFRCxTQUFPO0FBQUU5SixLQUFDLEVBQUU2SixLQUFLLENBQUNJLEtBQUssR0FBRyxHQUFULENBQVY7QUFBeUJoSyxLQUFDLEVBQUU0SixLQUFLLENBQUNJLEtBQUssR0FBRyxHQUFUO0FBQWpDLEdBQVA7QUFDRCxDQVRNOztBQXlCQSxNQUFNNUUsY0FBYyxHQUFHLENBQUN3RSxLQUFELEVBQVFLLFlBQVIsS0FBeUI7QUFDckQsUUFBTUMsUUFBUSxHQUFHRCxZQUFZLEdBQUdBLFlBQWhDOztBQUVBLFdBQVNFLGdCQUFULENBQTBCQyxPQUExQixFQUFtQ0MsTUFBbkMsRUFBMkM7QUFDekMsVUFBTTtBQUFFdEssT0FBQyxFQUFFdUssTUFBTDtBQUFhdEssT0FBQyxFQUFFdUs7QUFBaEIsUUFBMkJyRixTQUFTLENBQUMwRSxLQUFELENBQTFDO0FBQ0EsVUFBTXhkLE9BQU8sR0FBRztBQUFFd2QsV0FBRjtBQUFTckwsVUFBVDtBQUFlaU07QUFBZixLQUFoQjtBQUNBLFVBQU1DLE1BQU0sR0FBR3BGLGdCQUFnQixDQUFDalosT0FBRCxDQUEvQixDQUh5QyxDQUl6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFDQSxhQUFTbVMsSUFBVCxDQUFjcUwsS0FBZCxFQUFxQjtBQUNuQixZQUFNO0FBQUU3SixTQUFGO0FBQUtDO0FBQUwsVUFBV2tGLFNBQVMsQ0FBQzBFLEtBQUQsQ0FBMUI7QUFDQSxZQUFNYyxNQUFNLEdBQUdKLE1BQU0sR0FBR3ZLLENBQXhCO0FBQ0EsWUFBTTRLLE1BQU0sR0FBR0osTUFBTSxHQUFHdkssQ0FBeEI7QUFDQSxZQUFNNEssTUFBTSxHQUFJRixNQUFNLEdBQUdBLE1BQVQsR0FBa0JDLE1BQU0sR0FBR0EsTUFBM0M7O0FBRUEsVUFBSUMsTUFBTSxHQUFHVixRQUFiLEVBQXVCO0FBQ3JCN0Usd0JBQWdCLENBQUNvRixNQUFELENBQWhCO0FBQ0FMLGVBQU87QUFDUjtBQUNGLEtBdEJ3QyxDQXdCekM7QUFDQTs7O0FBQ0EsYUFBU0ksSUFBVCxDQUFjWixLQUFkLEVBQXFCO0FBQ25CdkUsc0JBQWdCLENBQUNvRixNQUFELENBQWhCO0FBQ0FKLFlBQU07QUFDUDtBQUNGOztBQUVELFNBQU8sSUFBSVEsT0FBSixDQUFZVixnQkFBWixDQUFQO0FBQ0QsQ0FwQ007O0FBd0NBLE1BQU05RSxnQkFBZ0IsR0FBRyxXQUFvQztBQUFBLE1BQW5DO0FBQUV5RixXQUFGO0FBQVdsQixTQUFYO0FBQWtCckwsUUFBbEI7QUFBd0JpTTtBQUF4QixHQUFtQztBQUNsRTtBQUNBLFFBQU1PLElBQUksR0FBR0MsUUFBUSxDQUFDRCxJQUF0Qjs7QUFFQSxNQUFJbkIsS0FBSixFQUFXO0FBQ1QsUUFBSSxPQUFPa0IsT0FBUCxLQUFtQixRQUF2QixFQUFpQztBQUMvQkEsYUFBTyxHQUFHLEVBQVY7QUFDRDs7QUFFRCxRQUFJbEIsS0FBSyxDQUFDaE4sSUFBTixLQUFlLFlBQW5CLEVBQWlDO0FBQy9Ca08sYUFBTyxDQUFDRyxJQUFSLEdBQWdCLFdBQWhCO0FBQ0FILGFBQU8sQ0FBQ0ksR0FBUixHQUFnQixVQUFoQjtBQUNELEtBSEQsTUFHTztBQUNMSixhQUFPLENBQUNHLElBQVIsR0FBZ0IsV0FBaEI7QUFDQUgsYUFBTyxDQUFDSSxHQUFSLEdBQWdCLFNBQWhCO0FBQ0Q7O0FBRURILFFBQUksQ0FBQ0ksZ0JBQUwsQ0FBc0JMLE9BQU8sQ0FBQ0csSUFBOUIsRUFBb0MxTSxJQUFwQyxFQUEwQyxLQUExQztBQUNBd00sUUFBSSxDQUFDSSxnQkFBTCxDQUFzQkwsT0FBTyxDQUFDSSxHQUE5QixFQUFtQ1YsSUFBbkMsRUFBeUMsS0FBekM7QUFFRCxHQWhCRCxNQWdCTztBQUNMTyxRQUFJLENBQUNLLG1CQUFMLENBQXlCTixPQUFPLENBQUNHLElBQWpDLEVBQXVDMU0sSUFBdkMsRUFBNkMsS0FBN0M7QUFDQXdNLFFBQUksQ0FBQ0ssbUJBQUwsQ0FBeUJOLE9BQU8sQ0FBQ0ksR0FBakMsRUFBc0NWLElBQXRDLEVBQTRDLEtBQTVDO0FBQ0Q7O0FBRUQsU0FBTztBQUFFTSxXQUFGO0FBQVd2TSxRQUFYO0FBQWlCaU07QUFBakIsR0FBUDtBQUNELENBMUJNOztBQStCQSxNQUFNbEYsU0FBUyxHQUFHLENBQUMrRixLQUFELEVBQVFDLEtBQVIsS0FBa0I7QUFDekMsU0FBT0QsS0FBSyxDQUFDdEwsQ0FBTixHQUFVdUwsS0FBSyxDQUFDN1EsS0FBaEIsSUFDQTZRLEtBQUssQ0FBQ3ZMLENBQU4sR0FBVXNMLEtBQUssQ0FBQzVRLEtBRGhCLElBRUE0USxLQUFLLENBQUNyTCxDQUFOLEdBQVVzTCxLQUFLLENBQUNDLE1BRmhCLElBR0FELEtBQUssQ0FBQ3RMLENBQU4sR0FBVXFMLEtBQUssQ0FBQ0UsTUFIdkI7QUFJRCxDQUxNOztBQVNBLE1BQU1oRyxZQUFZLEdBQUcsQ0FBQzhGLEtBQUQsRUFBUUMsS0FBUixLQUFrQjtBQUM1QyxRQUFNdGIsSUFBSSxHQUFLMkssSUFBSSxDQUFDQyxHQUFMLENBQVV5USxLQUFLLENBQUNyYixJQUFOLElBQWNxYixLQUFLLENBQUN0TCxDQUFwQixJQUF5QixDQUFuQyxFQUNVdUwsS0FBSyxDQUFDdGIsSUFBTixJQUFjc2IsS0FBSyxDQUFDdkwsQ0FBcEIsSUFBeUIsQ0FEbkMsQ0FBZjtBQUdBLFFBQU10RixLQUFLLEdBQUlFLElBQUksQ0FBQ1ksR0FBTCxDQUFVOFAsS0FBSyxDQUFDNVEsS0FBTixJQUFhNFEsS0FBSyxDQUFDcmIsSUFBTixHQUFXcWIsS0FBSyxDQUFDRyxLQUE5QixJQUFxQyxDQUEvQyxFQUNVRixLQUFLLENBQUM3USxLQUFOLElBQWE2USxLQUFLLENBQUN0YixJQUFOLEdBQVdzYixLQUFLLENBQUNFLEtBQTlCLElBQXFDLENBRC9DLENBQWY7O0FBR0EsTUFBSSxFQUFFeGIsSUFBSSxHQUFHeUssS0FBVCxDQUFKLEVBQXFCO0FBQ25CLFdBQU8sQ0FBUDtBQUNEOztBQUVELFFBQU1nUixHQUFHLEdBQU05USxJQUFJLENBQUNDLEdBQUwsQ0FBVXlRLEtBQUssQ0FBQ0ksR0FBTixJQUFhSixLQUFLLENBQUNyTCxDQUFuQixJQUF3QixDQUFsQyxFQUNVc0wsS0FBSyxDQUFDRyxHQUFOLElBQWFILEtBQUssQ0FBQ3RMLENBQW5CLElBQXdCLENBRGxDLENBQWY7QUFHQSxRQUFNdUwsTUFBTSxHQUFHNVEsSUFBSSxDQUFDWSxHQUFMLENBQVU4UCxLQUFLLENBQUNFLE1BQU4sSUFBY0YsS0FBSyxDQUFDSSxHQUFOLEdBQVVKLEtBQUssQ0FBQ0ssTUFBOUIsSUFBc0MsQ0FBaEQsRUFDVUosS0FBSyxDQUFDQyxNQUFOLElBQWNELEtBQUssQ0FBQ0csR0FBTixHQUFVSCxLQUFLLENBQUNJLE1BQTlCLElBQXNDLENBRGhELENBQWY7O0FBR0EsTUFBSSxFQUFFRCxHQUFHLEdBQUdGLE1BQVIsQ0FBSixFQUFxQjtBQUNuQixXQUFPLENBQVA7QUFDRDs7QUFFRCxRQUFNeEwsQ0FBQyxHQUFHL1AsSUFBVjtBQUNBLFFBQU1nUSxDQUFDLEdBQUd5TCxHQUFWO0FBQ0EsUUFBTUQsS0FBSyxHQUFJL1EsS0FBSyxHQUFHc0YsQ0FBdkI7QUFDQSxRQUFNMkwsTUFBTSxHQUFHSCxNQUFNLEdBQUd2TCxDQUF4QjtBQUVBLFNBQU87QUFBRUQsS0FBRjtBQUFLQyxLQUFMO0FBQVFoUSxRQUFSO0FBQWN5SyxTQUFkO0FBQXFCZ1IsT0FBckI7QUFBMEJGLFVBQTFCO0FBQWtDQyxTQUFsQztBQUF5Q0U7QUFBekMsR0FBUDtBQUNELENBM0JNOztBQStCQSxNQUFNbEcsS0FBSyxHQUFJbUcsS0FBRCxJQUFXO0FBQzlCLFFBQU0sQ0FBRUMsSUFBRixFQUFRLEdBQUdDLElBQVgsSUFBb0JGLEtBQTFCO0FBQ0EsTUFBSTtBQUFFM2IsUUFBRjtBQUFReUssU0FBUjtBQUFlZ1IsT0FBZjtBQUFvQkY7QUFBcEIsTUFBK0JLLElBQW5DO0FBRUFDLE1BQUksQ0FBQ2xqQixPQUFMLENBQWNpakIsSUFBSSxJQUFJO0FBQ3BCNWIsUUFBSSxHQUFLMkssSUFBSSxDQUFDWSxHQUFMLENBQVN2TCxJQUFULEVBQWlCNGIsSUFBSSxDQUFDNWIsSUFBdEIsQ0FBVDtBQUNBeUssU0FBSyxHQUFJRSxJQUFJLENBQUNDLEdBQUwsQ0FBU0gsS0FBVCxFQUFpQm1SLElBQUksQ0FBQ25SLEtBQXRCLENBQVQ7QUFDQWdSLE9BQUcsR0FBTTlRLElBQUksQ0FBQ1ksR0FBTCxDQUFTa1EsR0FBVCxFQUFpQkcsSUFBSSxDQUFDSCxHQUF0QixDQUFUO0FBQ0FGLFVBQU0sR0FBRzVRLElBQUksQ0FBQ0MsR0FBTCxDQUFTMlEsTUFBVCxFQUFpQkssSUFBSSxDQUFDTCxNQUF0QixDQUFUO0FBQ0QsR0FMRDtBQU9BLFFBQU14TCxDQUFDLEdBQUcvUCxJQUFWO0FBQ0EsUUFBTWdRLENBQUMsR0FBR3lMLEdBQVY7QUFDQSxRQUFNRCxLQUFLLEdBQUcvUSxLQUFLLEdBQUd6SyxJQUF0QjtBQUNBLFFBQU0wYixNQUFNLEdBQUdILE1BQU0sR0FBR0UsR0FBeEI7QUFFQSxTQUFPO0FBQUUxTCxLQUFGO0FBQUtDLEtBQUw7QUFBUWhRLFFBQVI7QUFBY3lLLFNBQWQ7QUFBcUJnUixPQUFyQjtBQUEwQkYsVUFBMUI7QUFBa0NDLFNBQWxDO0FBQXlDRTtBQUF6QyxHQUFQO0FBQ0QsQ0FqQk07O0FBcUJBLE1BQU1qRyxXQUFXLEdBQUcsQ0FBRTFGLENBQUYsRUFBS0MsQ0FBTCxFQUFRNEwsSUFBUixLQUFrQjtBQUMzQyxTQUFPQSxJQUFJLENBQUM3TCxDQUFMLElBQVVBLENBQVYsSUFDQTZMLElBQUksQ0FBQzVMLENBQUwsSUFBVUEsQ0FEVixJQUVBNEwsSUFBSSxDQUFDblIsS0FBTCxHQUFhc0YsQ0FGYixJQUdBNkwsSUFBSSxDQUFDTCxNQUFMLEdBQWN2TCxDQUhyQjtBQUlELENBTE07O0FBV0EsTUFBTTBGLE9BQU8sR0FBRyxDQUFDa0csSUFBRCxFQUFPRSxTQUFQLEtBQXFCO0FBQzFDLE1BQUlwRyxPQUFPLEdBQUdILFlBQVksQ0FBQ3FHLElBQUQsRUFBT0UsU0FBUCxDQUExQixDQUQwQyxDQUNFOztBQUU1QyxNQUFJcEcsT0FBSixFQUFhO0FBQ1gsVUFBTThGLEtBQUssR0FBSUksSUFBSSxDQUFDSixLQUFMLElBQWVJLElBQUksQ0FBQzViLElBQUwsR0FBWTRiLElBQUksQ0FBQ25SLEtBQS9DO0FBQ0EsVUFBTWlSLE1BQU0sR0FBR0UsSUFBSSxDQUFDRixNQUFMLElBQWdCRSxJQUFJLENBQUNMLE1BQUwsR0FBY0ssSUFBSSxDQUFDSCxHQUFsRDtBQUNBL0YsV0FBTyxHQUFJQSxPQUFPLENBQUM4RixLQUFSLEdBQWdCOUYsT0FBTyxDQUFDZ0csTUFBekIsSUFBb0NGLEtBQUssR0FBR0UsTUFBNUMsQ0FBVjtBQUNEOztBQUVELFNBQU9oRyxPQUFQO0FBQ0QsQ0FWTTs7QUFjQSxNQUFNQyxXQUFXLEdBQUcsQ0FBQ3NCLENBQUQsRUFBSU0sQ0FBSixLQUFVO0FBQ25DLE1BQUssQ0FBQ04sQ0FBRCxJQUFNLE9BQU9BLENBQVAsS0FBYSxRQUFuQixJQUErQixDQUFDTSxDQUFoQyxJQUFxQyxPQUFPQSxDQUFQLEtBQWEsUUFBdkQsRUFBaUU7QUFDL0QsV0FBTyxLQUFQO0FBQ0Q7O0FBRUQsUUFBTXdFLE1BQU0sR0FBR2xjLE1BQU0sQ0FBQ21jLG1CQUFQLENBQTJCL0UsQ0FBM0IsQ0FBZjtBQUNBLFFBQU1nRixNQUFNLEdBQUdwYyxNQUFNLENBQUNtYyxtQkFBUCxDQUEyQnpFLENBQTNCLENBQWY7O0FBRUEsTUFBSXdFLE1BQU0sQ0FBQzdmLE1BQVAsS0FBa0I2ZixNQUFNLENBQUM3ZixNQUE3QixFQUFxQztBQUNuQyxXQUFPLEtBQVA7QUFDRDs7QUFFRCxRQUFNZ2dCLEtBQUssR0FBR0gsTUFBTSxDQUFDN2YsTUFBckI7O0FBQ0EsT0FBTSxJQUFJaWQsRUFBRSxHQUFHLENBQWYsRUFBa0JBLEVBQUUsR0FBRytDLEtBQXZCLEVBQThCL0MsRUFBRSxJQUFJLENBQXBDLEVBQXdDO0FBQ3RDLFVBQU1nRCxJQUFJLEdBQUdKLE1BQU0sQ0FBQzVDLEVBQUQsQ0FBbkI7O0FBRUEsUUFBSWxDLENBQUMsQ0FBQ2tGLElBQUQsQ0FBRCxLQUFZNUUsQ0FBQyxDQUFDNEUsSUFBRCxDQUFqQixFQUF5QjtBQUN2QixhQUFPLEtBQVA7QUFDRDs7QUFFRCxRQUFJLENBQUNsaEIsVUFBVSxDQUFDZ2hCLE1BQUQsRUFBU0UsSUFBVCxDQUFmLEVBQStCO0FBQzdCO0FBQ0EsYUFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFFRCxTQUFPLElBQVA7QUFDRCxDQTNCTTs7QUFnQ0EsTUFBTXZHLGFBQWEsR0FBSXdHLEVBQUQsSUFBUTtBQUNuQyxRQUFNakosS0FBSyxHQUFHaUosRUFBRSxDQUFDalYsT0FBSCxDQUFXLFNBQVgsQ0FBZDtBQUNBLE1BQUlnTSxLQUFLLEtBQUssQ0FBQyxDQUFmLEVBQWtCLE9BQU8sWUFBUDtBQUNsQixNQUFJK0gsR0FBRyxHQUFHa0IsRUFBRSxDQUFDalYsT0FBSCxDQUFXLEdBQVgsRUFBZ0JnTSxLQUFoQixDQUFWO0FBQ0EsTUFBRytILEdBQUcsS0FBSyxDQUFDLENBQVosRUFBZUEsR0FBRyxHQUFHaFQsU0FBTjtBQUNma1UsSUFBRSxHQUFHQSxFQUFFLENBQUNqRyxLQUFILENBQVNoRCxLQUFLLEdBQUcsQ0FBakIsRUFBb0IrSCxHQUFwQixFQUF5Qm5YLE9BQXpCLENBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLENBQUw7QUFDQXFZLElBQUUsR0FBRyxNQUFLQSxFQUFMLEdBQVUsR0FBZjtBQUNBLFNBQU9BLEVBQVAsQ0FQbUMsQ0FPekI7QUFDWCxDQVJNOztBQWNBLE1BQU12RyxJQUFJLEdBQUcsVUFBQ3dHLEdBQUQsRUFBbUI7QUFBQSxNQUFiQyxJQUFhLHVFQUFOLENBQU07QUFDckMsTUFBSUMsRUFBRSxHQUFHLGFBQWFELElBQXRCO0FBQUEsTUFBNEJFLEVBQUUsR0FBRyxhQUFhRixJQUE5Qzs7QUFDQSxPQUFLLElBQUlHLENBQUMsR0FBRyxDQUFSLEVBQVdDLEVBQWhCLEVBQW9CRCxDQUFDLEdBQUdKLEdBQUcsQ0FBQ25nQixNQUE1QixFQUFvQ3VnQixDQUFDLEVBQXJDLEVBQXlDO0FBQ3JDQyxNQUFFLEdBQUdMLEdBQUcsQ0FBQ00sVUFBSixDQUFlRixDQUFmLENBQUw7QUFDQUYsTUFBRSxHQUFHNVIsSUFBSSxDQUFDaVMsSUFBTCxDQUFVTCxFQUFFLEdBQUdHLEVBQWYsRUFBbUIsVUFBbkIsQ0FBTDtBQUNBRixNQUFFLEdBQUc3UixJQUFJLENBQUNpUyxJQUFMLENBQVVKLEVBQUUsR0FBR0UsRUFBZixFQUFtQixVQUFuQixDQUFMO0FBQ0g7O0FBQ0RILElBQUUsR0FBRzVSLElBQUksQ0FBQ2lTLElBQUwsQ0FBVUwsRUFBRSxHQUFHQSxFQUFFLEtBQUcsRUFBcEIsRUFBd0IsVUFBeEIsSUFDQTVSLElBQUksQ0FBQ2lTLElBQUwsQ0FBVUosRUFBRSxHQUFHQSxFQUFFLEtBQUcsRUFBcEIsRUFBd0IsVUFBeEIsQ0FETDtBQUVBQSxJQUFFLEdBQUc3UixJQUFJLENBQUNpUyxJQUFMLENBQVVKLEVBQUUsR0FBR0EsRUFBRSxLQUFHLEVBQXBCLEVBQXdCLFVBQXhCLElBQ0E3UixJQUFJLENBQUNpUyxJQUFMLENBQVVMLEVBQUUsR0FBR0EsRUFBRSxLQUFHLEVBQXBCLEVBQXdCLFVBQXhCLENBREw7QUFHQSxTQUFPLGNBQWMsVUFBVUMsRUFBeEIsS0FBK0JELEVBQUUsS0FBRyxDQUFwQyxDQUFQO0FBQ0QsQ0FiTTs7QUFvQkEsTUFBTXpHLFNBQVMsR0FBSXBTLEtBQUQsSUFBVztBQUNsQyxRQUFNbVosQ0FBQyxHQUFHN0IsUUFBUSxDQUFDOEIsYUFBVCxDQUF1QixRQUF2QixDQUFWO0FBQ0FELEdBQUMsQ0FBQ3JCLEtBQUYsR0FBVTlYLEtBQUssQ0FBQzhYLEtBQWhCO0FBQ0FxQixHQUFDLENBQUNuQixNQUFGLEdBQVdoWSxLQUFLLENBQUNnWSxNQUFqQjtBQUVBLFFBQU1xQixHQUFHLEdBQUdGLENBQUMsQ0FBQ0csVUFBRixDQUFhLElBQWIsQ0FBWjtBQUNBRCxLQUFHLENBQUNFLFNBQUosQ0FBY3ZaLEtBQWQsRUFBcUIsQ0FBckIsRUFBd0IsQ0FBeEI7QUFFQSxRQUFNd1osSUFBSSxHQUFHbEMsUUFBUSxDQUFDOEIsYUFBVCxDQUF1QixRQUF2QixFQUFpQ0UsVUFBakMsQ0FBNEMsSUFBNUMsQ0FBYjtBQUNBLFFBQU1HLE1BQU0sR0FBR0osR0FBRyxDQUFDSyxZQUFKLENBQWlCLENBQWpCLEVBQW9CLENBQXBCLEVBQXVCUCxDQUFDLENBQUNyQixLQUF6QixFQUFnQ3FCLENBQUMsQ0FBQ25CLE1BQWxDLENBQWY7QUFDQSxRQUFNM0UsQ0FBQyxHQUFHb0csTUFBTSxDQUFDOVAsSUFBUCxDQUFZblIsTUFBdEI7QUFDQSxRQUFNbWhCLEtBQUssR0FBRztBQUNaNUIsT0FBRyxFQUFFLElBRE87QUFFWnpiLFFBQUksRUFBRSxJQUZNO0FBR1p5SyxTQUFLLEVBQUUsSUFISztBQUlaOFEsVUFBTSxFQUFFO0FBSkksR0FBZDtBQU1BLE1BQUlwQyxFQUFKLEVBQ0lwSixDQURKLEVBRUlDLENBRkosQ0FqQmtDLENBcUJsQztBQUNBOztBQUNBLE9BQUttSixFQUFFLEdBQUcsQ0FBVixFQUFhQSxFQUFFLEdBQUdwQyxDQUFsQixFQUFxQm9DLEVBQUUsSUFBSSxDQUEzQixFQUE4QjtBQUMxQixRQUFJZ0UsTUFBTSxDQUFDOVAsSUFBUCxDQUFZOEwsRUFBRSxHQUFHLENBQWpCLE1BQXdCLENBQTVCLEVBQStCO0FBQzNCcEosT0FBQyxHQUFJb0osRUFBRSxHQUFHLENBQU4sR0FBVzBELENBQUMsQ0FBQ3JCLEtBQWpCO0FBQ0F4TCxPQUFDLEdBQUcsQ0FBQyxFQUFHbUosRUFBRSxHQUFHLENBQU4sR0FBVzBELENBQUMsQ0FBQ3JCLEtBQWYsQ0FBTDs7QUFFQSxVQUFJNkIsS0FBSyxDQUFDNUIsR0FBTixLQUFjLElBQWxCLEVBQXdCO0FBQ3BCNEIsYUFBSyxDQUFDNUIsR0FBTixHQUFZekwsQ0FBWjtBQUNIOztBQUVELFVBQUlxTixLQUFLLENBQUNyZCxJQUFOLEtBQWUsSUFBbkIsRUFBeUI7QUFDckJxZCxhQUFLLENBQUNyZCxJQUFOLEdBQWErUCxDQUFiO0FBQ0gsT0FGRCxNQUVPLElBQUlBLENBQUMsR0FBR3NOLEtBQUssQ0FBQ3JkLElBQWQsRUFBb0I7QUFDdkJxZCxhQUFLLENBQUNyZCxJQUFOLEdBQWErUCxDQUFiO0FBQ0g7O0FBRUQsVUFBSXNOLEtBQUssQ0FBQzVTLEtBQU4sS0FBZ0IsSUFBcEIsRUFBMEI7QUFDdEI0UyxhQUFLLENBQUM1UyxLQUFOLEdBQWNzRixDQUFkO0FBQ0gsT0FGRCxNQUVPLElBQUlzTixLQUFLLENBQUM1UyxLQUFOLEdBQWNzRixDQUFsQixFQUFxQjtBQUN4QnNOLGFBQUssQ0FBQzVTLEtBQU4sR0FBY3NGLENBQWQ7QUFDSDs7QUFFRCxVQUFJc04sS0FBSyxDQUFDOUIsTUFBTixLQUFpQixJQUFyQixFQUEyQjtBQUN2QjhCLGFBQUssQ0FBQzlCLE1BQU4sR0FBZXZMLENBQWY7QUFDSCxPQUZELE1BRU8sSUFBSXFOLEtBQUssQ0FBQzlCLE1BQU4sR0FBZXZMLENBQW5CLEVBQXNCO0FBQ3pCcU4sYUFBSyxDQUFDOUIsTUFBTixHQUFldkwsQ0FBZjtBQUNIO0FBQ0o7QUFDSixHQWxEaUMsQ0FvRGxDOzs7QUFDQSxRQUFNc04sVUFBVSxHQUFHRCxLQUFLLENBQUM5QixNQUFOLEdBQWU4QixLQUFLLENBQUM1QixHQUF4QztBQUNBLFFBQU04QixTQUFTLEdBQUdGLEtBQUssQ0FBQzVTLEtBQU4sR0FBYzRTLEtBQUssQ0FBQ3JkLElBQXRDO0FBQ0EsUUFBTXdkLE9BQU8sR0FBR1QsR0FBRyxDQUFDSyxZQUFKLENBQ2RDLEtBQUssQ0FBQ3JkLElBRFEsRUFFZHFkLEtBQUssQ0FBQzVCLEdBRlEsRUFHZDhCLFNBSGMsRUFJZEQsVUFKYyxDQUFoQixDQXZEa0MsQ0E4RGxDOztBQUVBSixNQUFJLENBQUNPLE1BQUwsQ0FBWWpDLEtBQVosR0FBb0IrQixTQUFwQjtBQUNBTCxNQUFJLENBQUNPLE1BQUwsQ0FBWS9CLE1BQVosR0FBcUI0QixVQUFyQjtBQUNBSixNQUFJLENBQUNRLFlBQUwsQ0FBa0JGLE9BQWxCLEVBQTJCLENBQTNCLEVBQThCLENBQTlCLEVBbEVrQyxDQW9FbEM7O0FBQ0EsUUFBTUcsWUFBWSxHQUFHLElBQUlDLEtBQUosRUFBckI7QUFDQUQsY0FBWSxDQUFDbFosR0FBYixHQUFrQnlZLElBQUksQ0FBQ08sTUFBTCxDQUFZSSxTQUFaLEVBQWxCO0FBRUEsU0FBT0YsWUFBUDtBQUNELENBekVNOztBQTJGQSxNQUFNNUgsVUFBVSxHQUFHLENBQUN2UCxNQUFELEVBQVNwSyxPQUFULEtBQXFCO0FBQzdDLE1BQUlBLE9BQU8sSUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQWxDLEVBQTRDO0FBQzFDLFFBQUksT0FBT29LLE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0M7QUFDOUJBLFlBQU0sR0FBR0EsTUFBTSxDQUFDekMsT0FBaEI7QUFDRDs7QUFFRCxTQUFLbkwsR0FBTCxJQUFZd0QsT0FBWixFQUFxQjtBQUNuQm9LLFlBQU0sR0FBR0EsTUFBTSxDQUFDekMsT0FBUCxDQUFlbkwsR0FBZixFQUFvQndELE9BQU8sQ0FBQ3hELEdBQUQsQ0FBM0IsQ0FBVDtBQUNEO0FBRUYsR0FURCxNQVNPLElBQUksT0FBTzROLE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0M7QUFDckNBLFVBQU0sR0FBR0EsTUFBTSxDQUFDc1gsTUFBaEI7QUFDRCxHQVo0QyxDQWM3Qzs7O0FBQ0F0WCxRQUFNLEdBQUdBLE1BQU0sQ0FBQ3pDLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLEdBQXJCLENBQVQ7QUFFQSxTQUFPeUMsTUFBUDtBQUNELENBbEJNOztBQWlDQSxNQUFNd1AsWUFBWSxHQUFHLFVBQUMxUCxVQUFELEVBQXNDO0FBQUEsTUFBekI2TixJQUF5Qix1RUFBbEIsSUFBa0I7QUFBQSxNQUFaL1gsT0FBWTtBQUNoRSxNQUFJb0ssTUFBTSxHQUFHRixVQUFVLENBQUM2TixJQUFELENBQXZCOztBQUVBLE1BQUksQ0FBQzNOLE1BQUwsRUFBYTtBQUNYO0FBQ0EsVUFBTXVYLFVBQVUsR0FBRyxNQUFuQjtBQUNBNUosUUFBSSxHQUFHQSxJQUFJLENBQUNwUSxPQUFMLENBQWFnYSxVQUFiLEVBQXlCLEVBQXpCLENBQVAsQ0FIVyxDQUd5Qjs7QUFDcEN2WCxVQUFNLEdBQUdGLFVBQVUsQ0FBQzZOLElBQUQsQ0FBbkI7O0FBRUEsUUFBSSxDQUFDM04sTUFBTCxFQUFhO0FBQ1g7QUFDQSxZQUFNWSxTQUFTLEdBQUd2SCxNQUFNLENBQUM4RyxJQUFQLENBQVlMLFVBQVosQ0FBbEI7QUFDQTZOLFVBQUksR0FBRy9NLFNBQVMsQ0FBQ25LLElBQVYsQ0FBZXJFLEdBQUcsSUFBSUEsR0FBRyxDQUFDbUwsT0FBSixDQUFZZ2EsVUFBWixNQUE0QixJQUFsRCxDQUFQOztBQUVBLFVBQUk1SixJQUFKLEVBQVU7QUFDUjNOLGNBQU0sR0FBR0YsVUFBVSxDQUFDNk4sSUFBRCxDQUFuQjtBQUNELE9BRkQsTUFFTztBQUNMO0FBQ0EzTixjQUFNLEdBQUdGLFVBQVUsQ0FBQ2MsU0FBUyxDQUFDLENBQUQsQ0FBVixDQUFuQjtBQUNEOztBQUVELFVBQUksQ0FBQ1osTUFBTCxFQUFhO0FBQ1hBLGNBQU0sR0FBRyxXQUFUO0FBQ0Q7QUFDRjtBQUNGOztBQUVEQSxRQUFNLEdBQUd1UCxVQUFVLENBQUN2UCxNQUFELEVBQVNwSyxPQUFULENBQW5CO0FBRUEsU0FBT29LLE1BQVA7QUFDRCxDQTlCTTs7QUFrREEsTUFBTXlQLFFBQVEsR0FBRyxDQUFDK0gsR0FBRCxFQUFNN0osSUFBTixFQUFZOEosTUFBWixFQUFvQjdoQixPQUFwQixLQUFnQztBQUN0RCxNQUFJb0ssTUFBSjtBQUVBLFFBQU1GLFVBQVUsR0FBRzJYLE1BQU0sQ0FBQ2hoQixJQUFQLENBQVl1SixNQUFNLElBQ25DQSxNQUFNLENBQUN3WCxHQUFQLEtBQWVBLEdBREUsQ0FBbkI7O0FBSUEsTUFBSTFYLFVBQUosRUFBZ0I7QUFDZEUsVUFBTSxHQUFHd1AsWUFBWSxDQUFDMVAsVUFBRCxFQUFhNk4sSUFBYixFQUFtQi9YLE9BQW5CLENBQXJCO0FBQ0Q7O0FBRUQsTUFBSSxDQUFDb0ssTUFBTCxFQUFhO0FBQ1g1RCxXQUFPLENBQUN6QixHQUFSLENBQWEsa0JBQWIsRUFBaUM2YyxHQUFqQyxFQUNhLE9BRGIsRUFDc0I3SixJQUR0QixFQUVhLGFBRmIsRUFFNEI3TixVQUY1QjtBQUlBRSxVQUFNLEdBQUcsUUFBUXdYLEdBQVIsR0FBYyxLQUF2QjtBQUNEOztBQUVELFNBQU94WCxNQUFQO0FBQ0QsQ0FwQk07O0FBd0NBLE1BQU0wUCxlQUFlLEdBQUcsQ0FBQ2dJLE9BQUQsRUFBVUMsU0FBVixLQUF3QjtBQUNyRCxNQUFJOWhCLEtBQUssR0FBRyxDQUFDLENBQWI7O0FBRUEsTUFBSTZoQixPQUFPLFlBQVlFLFdBQXZCLEVBQW9DO0FBQ2xDRCxhQUFTLEdBQUcsT0FBT0EsU0FBUCxLQUFxQixRQUFyQixHQUNBQSxTQUFTLENBQUNFLFdBQVYsRUFEQSxHQUVBLElBRlo7O0FBSUEsV0FBT0gsT0FBTyxJQUFJQSxPQUFPLENBQUNJLFVBQVIsQ0FBbUJDLE9BQW5CLEtBQStCSixTQUFqRCxFQUE0RDtBQUMxREQsYUFBTyxHQUFHQSxPQUFPLENBQUNJLFVBQWxCO0FBQ0Q7O0FBRUQsUUFBSUosT0FBSixFQUFhO0FBQ1gsWUFBTU0sUUFBUSxHQUFHLEdBQUdySSxLQUFILENBQVM3SixJQUFULENBQWM0UixPQUFPLENBQUNJLFVBQVIsQ0FBbUJHLFFBQWpDLENBQWpCO0FBQ0FwaUIsV0FBSyxHQUFHbWlCLFFBQVEsQ0FBQ3JYLE9BQVQsQ0FBaUIrVyxPQUFqQixDQUFSO0FBQ0Q7QUFDRjs7QUFFRCxTQUFPN2hCLEtBQVA7QUFDRCxDQW5CTSxDOzs7Ozs7Ozs7OztBQ2x5QlBoRixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSW1uQjtBQUFiLENBQWQ7O0FBQUE7OztBQU1BLE1BQU0xZCxFQUFFLEdBQUdDLE9BQU8sQ0FBQyxJQUFELENBQWxCOztBQUNBLE1BQU16RSxJQUFJLEdBQUd5RSxPQUFPLENBQUMsTUFBRCxDQUFwQjs7QUFJZSxNQUFNeWQsY0FBTixDQUFxQjtBQUNsQ3htQixhQUFXLENBQUN5bUIsT0FBRCxFQUFVO0FBQ25CO0FBQ0EsUUFBSUMsTUFBTSxHQUFHLHFDQUFiLENBRm1CLENBR25COztBQUVBQSxVQUFNLEdBQUdwaUIsSUFBSSxDQUFDZ0csSUFBTCxDQUFVK1EsT0FBTyxDQUFDQyxHQUFSLENBQVlGLEdBQXRCLEVBQTJCdUwsU0FBM0IsRUFBc0NELE1BQXRDLENBQVQ7QUFDQSxVQUFNRSxNQUFNLEdBQUcsS0FBS0MsU0FBTCxDQUFlSixPQUFmLENBQWY7QUFFQSxRQUFJSyxNQUFNLEdBQUcsS0FBS0MsY0FBTCxFQUFiO0FBQ0FELFVBQU0sSUFBSUYsTUFBTSxDQUFDSSxPQUFqQjtBQUNBRixVQUFNLElBQUlGLE1BQU0sQ0FBQ0ssS0FBakI7QUFFQW5lLE1BQUUsQ0FBQ29ILGFBQUgsQ0FBaUJ3VyxNQUFqQixFQUF5QkksTUFBekIsRUFabUIsQ0FhbkI7QUFDRDs7QUFHREQsV0FBUyxDQUFDSixPQUFELEVBQVU7QUFDakIsUUFBSU8sT0FBTyxHQUFHLEVBQWQ7QUFDQSxRQUFJQyxLQUFLLEdBQUcsRUFBWjtBQUVBUixXQUFPLENBQUNobUIsT0FBUixDQUFpQnFtQixNQUFNLElBQUk7QUFDekIsWUFBTTtBQUFFelksWUFBRjtBQUFRbEM7QUFBUixVQUFpQjJhLE1BQXZCO0FBRUFFLGFBQU8sdUJBQ0ozWSxJQURJLG9CQUNVbEMsSUFEVixNQUFQO0FBR0E4YSxXQUFLLGtCQUNQNVksSUFETyxDQUFMO0FBRUQsS0FSRDtBQVVBNFksU0FBSyw0QkFHTkEsS0FBSyxDQUFDcFYsU0FBTixDQUFnQixDQUFoQixDQUhNLFFBQUw7QUFNQSxXQUFPO0FBQ0xtVixhQURLO0FBRUxDO0FBRkssS0FBUDtBQUlEOztBQUdERixnQkFBYyxHQUFHO0FBQ2Y7QUFtQkQ7O0FBakVpQyxDOzs7Ozs7Ozs7OztBQ1hwQzVuQixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSTZuQjtBQUFiLENBQWQ7O0FBQUE7OztBQU1BLE1BQU1wZSxFQUFFLEdBQUdDLE9BQU8sQ0FBQyxJQUFELENBQWxCOztBQUNBLE1BQU16RSxJQUFJLEdBQUd5RSxPQUFPLENBQUMsTUFBRCxDQUFwQjs7QUFJZSxNQUFNbWUsZ0JBQU4sQ0FBdUI7QUFDcENsbkIsYUFBVyxDQUFDSixXQUFELEVBQWM7QUFDdkI7QUFDQSxRQUFJOG1CLE1BQU0sR0FBRyx1Q0FBYixDQUZ1QixDQUd2Qjs7QUFFQUEsVUFBTSxHQUFHcGlCLElBQUksQ0FBQ2dHLElBQUwsQ0FBVStRLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRixHQUF0QixFQUEyQnVMLFNBQTNCLEVBQXNDRCxNQUF0QyxDQUFUO0FBQ0EsVUFBTVMsWUFBWSxHQUFHLEtBQUtDLGVBQUwsRUFBckI7QUFDQSxVQUFNQyxZQUFZLEdBQUcsS0FBS0MsZUFBTCxDQUFxQjFuQixXQUFyQixDQUFyQjtBQUVBLFFBQUlrbkIsTUFBTSxHQUFHSyxZQUFZLENBQUMsQ0FBRCxDQUF6QjtBQUNBTCxVQUFNLElBQUlPLFlBQVksQ0FBQ0UsU0FBdkI7QUFFQVQsVUFBTSxJQUFJSyxZQUFZLENBQUMsQ0FBRCxDQUF0QjtBQUNBTCxVQUFNLElBQUlPLFlBQVksQ0FBQ0osS0FBdkI7QUFFQUgsVUFBTSxJQUFJSyxZQUFZLENBQUMsQ0FBRCxDQUF0QjtBQUNBTCxVQUFNLElBQUlPLFlBQVksQ0FBQ0csT0FBdkI7QUFFQVYsVUFBTSxJQUFJSyxZQUFZLENBQUMsQ0FBRCxDQUF0QjtBQUVBcmUsTUFBRSxDQUFDb0gsYUFBSCxDQUFpQndXLE1BQWpCLEVBQXlCSSxNQUF6QjtBQUNEOztBQUdEUSxpQkFBZSxDQUFDMW5CLFdBQUQsRUFBYztBQUMzQjtBQUNBLFFBQUkybkIsU0FBUyxHQUFHLEVBQWhCO0FBQ0EsUUFBSU4sS0FBSyxHQUFPLEVBQWhCO0FBQ0EsUUFBSU8sT0FBTyxHQUFLLEVBQWhCO0FBRUE1bkIsZUFBVyxDQUFDYSxPQUFaLENBQXFCNE4sSUFBSSxJQUFJO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFrWixlQUFTLHNCQUNQbFosSUFETyxzQ0FDeUJBLElBQUksQ0FBQy9CLFdBQUwsRUFEekIsT0FBVDtBQUdBMmEsV0FBSyxrQkFDUDVZLElBRE8sQ0FBTCxDQVoyQixDQWUzQjtBQUNBO0FBQ0E7O0FBRUFtWixhQUFPLG9CQUNSblosSUFEUSxXQUFQO0FBRUQsS0FyQkQ7QUF1QkEsV0FBTztBQUNMa1osZUFESztBQUVMTixXQUZLO0FBR0xPO0FBSEssS0FBUDtBQUtEOztBQUdESixpQkFBZSxHQUFHO0FBQ2hCLFdBQU8sdXhCQUFQO0FBc0NEOztBQXJHbUMsQzs7Ozs7Ozs7Ozs7QUNYdENqb0IsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUlvb0I7QUFBYixDQUFkOztBQUFBOzs7QUFNQSxNQUFNM2UsRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNekUsSUFBSSxHQUFHeUUsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7O0FBSWUsTUFBTTBlLFlBQU4sQ0FBbUI7QUFDaEN6bkIsYUFBVyxDQUFDK1YsT0FBRCxFQUFVO0FBQ25CO0FBQ0EsUUFBSTJRLE1BQU0sR0FBRyxtQ0FBYixDQUZtQixDQUduQjs7QUFFQUEsVUFBTSxHQUFHcGlCLElBQUksQ0FBQ2dHLElBQUwsQ0FBVStRLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRixHQUF0QixFQUEyQnVMLFNBQTNCLEVBQXNDRCxNQUF0QyxDQUFUO0FBQ0EsVUFBTVMsWUFBWSxHQUFHLEtBQUtDLGVBQUwsRUFBckI7QUFDQSxVQUFNQyxZQUFZLEdBQUcsS0FBS0MsZUFBTCxDQUFxQnZSLE9BQXJCLENBQXJCO0FBRUEsUUFBSStRLE1BQU0sR0FBR0ssWUFBWSxDQUFDLENBQUQsQ0FBekI7QUFDQUwsVUFBTSxJQUFJTyxZQUFZLENBQUNMLE9BQXZCO0FBRUFGLFVBQU0sSUFBSUssWUFBWSxDQUFDLENBQUQsQ0FBdEI7QUFDQUwsVUFBTSxJQUFJTyxZQUFZLENBQUNKLEtBQXZCO0FBRUFILFVBQU0sSUFBSUssWUFBWSxDQUFDLENBQUQsQ0FBdEI7QUFFQXJlLE1BQUUsQ0FBQ29ILGFBQUgsQ0FBaUJ3VyxNQUFqQixFQUF5QkksTUFBekI7QUFDRDs7QUFHRFEsaUJBQWUsQ0FBQ3ZSLE9BQUQsRUFBVTtBQUN2QixRQUFJaVIsT0FBTyxHQUFHLEVBQWQ7QUFDQSxRQUFJQyxLQUFLLEdBQUcsRUFBWjtBQUVBbFIsV0FBTyxDQUFDdFYsT0FBUixDQUFpQnVWLE1BQU0sSUFBSTtBQUN6QixVQUFJO0FBQUUzSCxZQUFGO0FBQVFsQztBQUFSLFVBQWlCNkosTUFBckI7QUFDQTNILFVBQUksR0FBR0EsSUFBSSxDQUFDL0IsV0FBTCxFQUFQO0FBRUEwYSxhQUFPLCtCQUNDM1ksSUFERCxvQkFDZWxDLElBRGYsTUFBUDtBQUdBOGEsV0FBSyxxQkFDSjVZLElBREksQ0FBTDtBQUVELEtBVEQ7QUFXQSxXQUFPO0FBQ0wyWSxhQURLO0FBRUxDO0FBRkssS0FBUDtBQUlEOztBQUdERyxpQkFBZSxHQUFHO0FBQ2hCLFdBQU8sOHNCQUFQO0FBOEJEOztBQTNFK0IsQzs7Ozs7Ozs7Ozs7QUNYbENqb0IsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsU0FBTyxFQUFDLE1BQUlxb0I7QUFBYixDQUFkO0FBQXlDLElBQUk5bkIsV0FBSjtBQUFnQlQsTUFBTSxDQUFDSyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ0csZUFBVyxHQUFDSCxDQUFaO0FBQWM7O0FBQTFCLENBQW5ELEVBQStFLENBQS9FOztBQWF6RCxNQUFNcUosRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNekUsSUFBSSxHQUFHeUUsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7QUFHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlZSxNQUFNMmUsV0FBTixDQUFrQjtBQUMvQjFuQixhQUFXLENBQUUybkIsUUFBRixFQUFZO0FBQ3JCLFNBQUtBLFFBQUwsR0FBZ0JBLFFBQWhCLENBRHFCLENBRXJCOztBQUVBLFNBQUtDLFVBQUwsR0FBa0IsS0FBS0EsVUFBTCxDQUFnQi9XLElBQWhCLENBQXFCLElBQXJCLENBQWxCO0FBQ0EsU0FBS2dYLFlBQUwsR0FBb0IsS0FBS0EsWUFBTCxDQUFrQmhYLElBQWxCLENBQXVCLElBQXZCLENBQXBCLENBTHFCLENBT3JCOztBQUNBLFFBQUk7QUFDRixZQUFNc0UsSUFBSSxHQUFHck0sRUFBRSxDQUFDNEcsWUFBSCxDQUFnQmlZLFFBQWhCLENBQWI7O0FBQ0EsV0FBS0MsVUFBTCxDQUFnQixJQUFoQixFQUFzQnpTLElBQXRCO0FBRUQsS0FKRCxDQUlFLE9BQU0yUyxLQUFOLEVBQWE7QUFDYnBkLGFBQU8sQ0FBQ3pCLEdBQVIsQ0FBWSxlQUFaLEVBQTZCMGUsUUFBN0IsRUFBdUNHLEtBQXZDO0FBQ0Q7QUFDRjs7QUFFREYsWUFBVSxDQUFDRSxLQUFELEVBQVEzUyxJQUFSLEVBQWM7QUFDdEIsUUFBSTJTLEtBQUosRUFBVztBQUNULGFBQU9wZCxPQUFPLENBQUN6QixHQUFSLENBQVksWUFBWixFQUEwQjZlLEtBQTFCLENBQVA7QUFDRDs7QUFFRCxRQUFJbGQsSUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLFVBQUksR0FBR2lFLElBQUksQ0FBQ2MsS0FBTCxDQUFXd0YsSUFBWCxDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU0yUyxLQUFOLEVBQWE7QUFDYixhQUFPcGQsT0FBTyxDQUFDekIsR0FBUixDQUFZLGNBQVosRUFBNEIsS0FBSzBlLFFBQWpDLEVBQTJDLElBQTNDLEVBQWlERyxLQUFqRCxDQUFQO0FBQ0QsS0FWcUIsQ0FZdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxVQUFNemYsVUFBVSxHQUFHekksV0FBVyxDQUFDZ0wsSUFBSSxDQUFDdkMsVUFBTixDQUE5Qjs7QUFDQSxRQUFJLENBQUNBLFVBQUwsRUFBaUI7QUFDZnFDLGFBQU8sQ0FBQ3pCLEdBQVIsQ0FBWSxZQUFaLEVBQTBCMkIsSUFBSSxDQUFDdkMsVUFBL0I7QUFDQSxhQUFPcUMsT0FBTyxDQUFDekIsR0FBUixDQUFZLGFBQVosRUFBMkIsS0FBSzBlLFFBQWhDLENBQVA7QUFDRDs7QUFFRCxXQUFPL2MsSUFBSSxDQUFDdkMsVUFBWjs7QUFFQSxVQUFNMGYsT0FBTyxHQUFHLEtBQUtDLGVBQUwsQ0FBcUIzZixVQUFyQixFQUFpQ3VDLElBQUksQ0FBQ3FkLEtBQXRDLENBQWhCLENBdkNzQixDQXdDdEI7OztBQUNBLFFBQUlGLE9BQUosRUFBYTtBQUNYLFlBQU1ybkIsR0FBRyxHQUFHa0ssSUFBSSxDQUFDcWQsS0FBTCxDQUFXdm5CLEdBQXZCLENBRFcsQ0FDZ0I7O0FBQzNCLFlBQU15TSxHQUFHLEdBQUd2QyxJQUFJLENBQUNxZCxLQUFMLENBQVc5YSxHQUF2QixDQUZXLENBRWdCOztBQUMzQixXQUFLK2EsaUJBQUwsQ0FBdUI3ZixVQUF2QixFQUFtQzNILEdBQW5DLEVBQXdDeU0sR0FBeEMsRUFBNkM0YSxPQUE3Qzs7QUFDQSxXQUFLSSxlQUFMLENBQXFCOWYsVUFBckIsRUFBaUN1QyxJQUFqQyxFQUF1Q21kLE9BQXZDO0FBQ0Q7QUFDRjs7QUFHREMsaUJBQWUsQ0FBQzNmLFVBQUQsRUFBYTRmLEtBQWIsRUFBb0I7QUFDakMsUUFBSXZuQixHQUFKLEVBQ0l5TSxHQURKLEVBRUk0YSxPQUZKLENBRGlDLENBS2pDO0FBQ0E7QUFDQTs7QUFDQSxRQUFJLENBQUNFLEtBQUQsSUFBVSxPQUFPQSxLQUFQLEtBQWlCLFFBQS9CLEVBQXlDO0FBQ3ZDLGFBQU8sS0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJLEVBQUVGLE9BQU8sR0FBR0UsS0FBSyxDQUFDRixPQUFsQixDQUFKLEVBQWdDO0FBQ3JDLGFBQU8sS0FBUDtBQUNELEtBWmdDLENBY2pDO0FBQ0E7OztBQUNBLFFBQUlLLGFBQWEsR0FBRztBQUFFTCxhQUFPLEVBQUU7QUFBRWxoQixlQUFPLEVBQUU7QUFBWDtBQUFYLEtBQXBCOztBQUNBLFFBQUluRyxHQUFHLEdBQUd1bkIsS0FBSyxDQUFDdm5CLEdBQWhCLEVBQXFCO0FBQ25CMG5CLG1CQUFhLEdBQUc7QUFDZEMsWUFBSSxFQUFFLENBQ0pELGFBREksRUFFSjtBQUFFMW5CO0FBQUYsU0FGSTtBQURRLE9BQWhCO0FBTUQsS0FQRCxNQU9PLElBQUl5TSxHQUFHLEdBQUc4YSxLQUFLLENBQUM5YSxHQUFoQixFQUFxQjtBQUMxQmliLG1CQUFhLEdBQUc7QUFDZEMsWUFBSSxFQUFFLENBQ0pELGFBREksRUFFSjtBQUFFamI7QUFBRixTQUZJO0FBRFEsT0FBaEI7QUFNRDs7QUFDRCxVQUFNMlYsUUFBUSxHQUFHemEsVUFBVSxDQUFDekgsT0FBWCxDQUFtQnduQixhQUFuQixDQUFqQixDQWhDaUMsQ0FpQ2pDOztBQUVBLFFBQUl0RixRQUFKLEVBQWM7QUFDWixVQUFJaUYsT0FBTyxJQUFJakYsUUFBUSxDQUFDaUYsT0FBeEIsRUFBaUM7QUFDL0IsZUFBTyxLQUFQO0FBRUQsT0FIRCxNQUdPO0FBQ0xyZCxlQUFPLENBQUN6QixHQUFSLENBQ0UsZUFERixFQUNtQjZaLFFBQVEsQ0FBQ2lGLE9BRDVCLEVBRUUsSUFGRixFQUVRcm5CLEdBQUcsSUFBRXlNLEdBQUwsSUFBVTlFLFVBQVUsQ0FBQ2dSLEtBRjdCLEVBRW9DLHdCQUZwQyxFQUdFLDJCQUhGLEVBRytCME8sT0FIL0I7QUFJRDtBQUNGOztBQUVELFdBQU9BLE9BQVA7QUFDRDs7QUFHREcsbUJBQWlCLENBQUM3ZixVQUFELEVBQWEzSCxHQUFiLEVBQWtCeU0sR0FBbEIsRUFBdUI0YSxPQUF2QixFQUFnQztBQUMvQyxRQUFJTyxZQUFZLEdBQUc7QUFBRVAsYUFBTyxFQUFFO0FBQUVRLFdBQUcsRUFBRVI7QUFBUDtBQUFYLEtBQW5COztBQUVBLFFBQUlybkIsR0FBSixFQUFTO0FBQ1A0bkIsa0JBQVksR0FBRztBQUNkRCxZQUFJLEVBQUUsQ0FDSEMsWUFERyxFQUVIO0FBQUU1bkI7QUFBRixTQUZHO0FBRFEsT0FBZjtBQU9ELEtBUkQsTUFRTyxJQUFJeU0sR0FBSixFQUFTO0FBQ2RtYixrQkFBWSxHQUFHO0FBQ2RELFlBQUksRUFBRSxDQUNIQyxZQURHLEVBRUg7QUFBRXpqQixhQUFHLEVBQUUsQ0FDSDtBQUFFc0k7QUFBRixXQURHLENBQ29CO0FBRHBCLFlBRUg7QUFBRXVILGdCQUFJLEVBQUU7QUFBRThULGlCQUFHLEVBQUVyYjtBQUFQO0FBQVIsV0FGRyxDQUVvQjtBQUZwQjtBQUFQLFNBRkc7QUFEUSxPQUFmO0FBVUQ7O0FBRUQsVUFBTXNiLGNBQWMsR0FBRy9uQixHQUFHLElBQUkySCxVQUFVLENBQUNnUixLQUF6Qzs7QUFDQSxVQUFNaEYsUUFBUSxHQUFHLENBQUNxVSxDQUFELEVBQUlDLENBQUosS0FBVSxLQUFLZCxZQUFMLENBQWtCYSxDQUFsQixFQUFxQkMsQ0FBckIsRUFBd0JGLGNBQXhCLENBQTNCOztBQUNBcGdCLGNBQVUsQ0FBQytQLE1BQVgsQ0FBa0JrUSxZQUFsQixFQUFnQ2pVLFFBQWhDO0FBQ0Q7O0FBR0Q4VCxpQkFBZSxDQUFDOWYsVUFBRCxFQUFhdUMsSUFBYixFQUFtQm1kLE9BQW5CLEVBQTRCO0FBQ3pDLFVBQU10WixJQUFJLEdBQUc5RyxNQUFNLENBQUM4RyxJQUFQLENBQVk3RCxJQUFaLENBQWI7QUFDQSxRQUFJZ2UsT0FBTyxHQUFHLENBQWQ7QUFFQW5hLFFBQUksQ0FBQ2hPLE9BQUwsQ0FBYUMsR0FBRyxJQUFJO0FBQ2xCLFlBQU1xUCxLQUFLLEdBQUduRixJQUFJLENBQUNsSyxHQUFELENBQWxCOztBQUVBLFVBQUk2TSxLQUFLLENBQUNDLE9BQU4sQ0FBY3VDLEtBQWQsQ0FBSixFQUEwQjtBQUN4QkEsYUFBSyxDQUFDdFAsT0FBTixDQUFjcWlCLFFBQVEsSUFBSTtBQUN4QkEsa0JBQVEsQ0FBQ3BPLElBQVQsR0FBZ0JoVSxHQUFoQjtBQUNBb2lCLGtCQUFRLENBQUNpRixPQUFULEdBQW1CQSxPQUFuQjtBQUNBMWYsb0JBQVUsQ0FBQzVHLE1BQVgsQ0FBa0JxaEIsUUFBbEI7QUFDQThGLGlCQUFPLElBQUksQ0FBWDtBQUNELFNBTEQ7QUFPRCxPQVJELE1BUU8sSUFBSWxvQixHQUFHLEtBQUssT0FBWixFQUFxQjtBQUMxQjJILGtCQUFVLENBQUM1RyxNQUFYLENBQW1Cc08sS0FBbkI7QUFDQTZZLGVBQU8sSUFBSSxDQUFYO0FBRUQsT0FKTSxNQUlBO0FBQUU7QUFDUHZnQixrQkFBVSxDQUFDNUcsTUFBWCxDQUFrQjtBQUFFLFdBQUNmLEdBQUQsR0FBT3FQO0FBQVQsU0FBbEI7QUFDQzZZLGVBQU8sSUFBSSxDQUFYO0FBQ0Y7QUFDRixLQW5CRDtBQXFCQWxlLFdBQU8sQ0FBQ3pCLEdBQVIsQ0FBWSxPQUFaLEVBQXFCMmYsT0FBckIsRUFBOEIsVUFBOUIsRUFBMEN2Z0IsVUFBVSxDQUFDZ1IsS0FBckQ7QUFDRDs7QUFHRHdPLGNBQVksQ0FBQ0MsS0FBRCxFQUFRM1MsSUFBUixFQUFjelUsR0FBZCxFQUFtQjtBQUM3QmdLLFdBQU8sQ0FBQ3pCLEdBQVIsQ0FBWSxTQUFaLEVBQXVCa00sSUFBdkIsRUFBNkIsWUFBN0IsRUFBMkN6VSxHQUEzQyxFQUFnRCxRQUFoRCxFQUEwRG9uQixLQUExRDtBQUNEOztBQXBMOEIsQzs7Ozs7Ozs7Ozs7QUNoQ2pDM29CLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJd3BCO0FBQWIsQ0FBZDtBQUE4QzFwQixNQUFNLENBQUNLLElBQVAsQ0FBWSwyQkFBWjtBQUF5QyxJQUFJZ0osR0FBSjtBQUFRckosTUFBTSxDQUFDSyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQytJLE9BQUcsR0FBQy9JLENBQUo7QUFBTTs7QUFBbEIsQ0FBakQsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSWdKLFFBQUo7QUFBYXRKLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNnSixZQUFRLEdBQUNoSixDQUFUO0FBQVc7O0FBQXZCLENBQW5ELEVBQTRFLENBQTVFO0FBQStFLElBQUl5YixlQUFKO0FBQW9CL2IsTUFBTSxDQUFDSyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQzBiLGlCQUFlLENBQUN6YixDQUFELEVBQUc7QUFBQ3liLG1CQUFlLEdBQUN6YixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBOUMsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSXNELFVBQUo7QUFBZTVELE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUN1RCxZQUFVLENBQUN0RCxDQUFELEVBQUc7QUFBQ3NELGNBQVUsR0FBQ3RELENBQVg7QUFBYTs7QUFBNUIsQ0FBL0MsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSUcsV0FBSjtBQUFnQlQsTUFBTSxDQUFDSyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0gsU0FBTyxDQUFDSSxDQUFELEVBQUc7QUFBQ0csZUFBVyxHQUFDSCxDQUFaO0FBQWM7O0FBQTFCLENBQXBELEVBQWdGLENBQWhGO0FBa0IvZCxNQUFNO0FBQUVzWDtBQUFGLElBQWVuWCxXQUFyQjs7QUFHQSxNQUFNa0osRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNekUsSUFBSSxHQUFHeUUsT0FBTyxDQUFDLE1BQUQsQ0FBcEIsQyxDQUdBOzs7QUFDQSxNQUFNK2YsUUFBUSxHQUFHLFdBQWpCLEMsQ0FDQTs7QUFJZSxNQUFNRCxnQkFBTixTQUErQnBnQixRQUEvQixDQUF1QztBQUNwRHpJLGFBQVcsR0FBRztBQUNaO0FBRUEsU0FBS2dKLE1BQUwsR0FBYyxJQUFJUixHQUFKLEVBQWQ7QUFDQSxTQUFLUyxHQUFMLEdBQVcsS0FBS0QsTUFBTCxDQUFZRSxRQUF2QjtBQUVBLFNBQUs2ZixtQkFBTCxHQUEyQixLQUFLQSxtQkFBTCxDQUF5QmxZLElBQXpCLENBQThCLElBQTlCLENBQTNCO0FBRUEsU0FBS21ZLFNBQUw7QUFFQSxTQUFLaGdCLE1BQUwsQ0FBWVMsSUFBWjtBQUNEOztBQUdEdWYsV0FBUyxHQUFHO0FBQ1YsVUFBTTVlLFFBQVEsR0FBR3RCLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZWtSLGVBQWYsQ0FBakIsQ0FEVSxDQUVWO0FBQ0E7QUFFQTtBQUNBOztBQUNBLFVBQU0vSyxPQUFPLEdBQUcsS0FBS2hGLFVBQUwsQ0FDZCtQLGVBRGMsRUFFZDlRLFFBRmMsQ0FBaEIsQ0FQVSxDQVlWO0FBQ0E7O0FBRUFBLFlBQVEsQ0FBQzNKLE9BQVQsQ0FBaUIsS0FBS3NvQixtQkFBdEI7QUFDRDtBQUdEOzs7Ozs7O0FBS0FBLHFCQUFtQixDQUFFMWYsUUFBRixFQUFZO0FBQzdCLFVBQU00ZixZQUFZLEdBQUcza0IsSUFBSSxDQUFDZ0csSUFBTCxDQUFVNFEsZUFBVixFQUEyQjdSLFFBQTNCLENBQXJCO0FBRUEsVUFBTW1ELEtBQUssR0FBRzFELEVBQUUsQ0FBQzJELFFBQUgsQ0FBWXdjLFlBQVosQ0FBZDs7QUFDQSxRQUFJLENBQUN6YyxLQUFLLENBQUMwYyxXQUFOLEVBQUwsRUFBMEI7QUFDeEI7QUFDRDs7QUFFRCxRQUFJOWUsUUFBUSxHQUFHdEIsRUFBRSxDQUFDa0IsV0FBSCxDQUFlaWYsWUFBZixDQUFmLENBUjZCLENBUzdCO0FBQ0E7O0FBRUEsUUFBSXRkLFNBQVMsR0FBRyxLQUFLd2QsYUFBTCxDQUFtQi9lLFFBQW5CLEVBQTZCNmUsWUFBN0IsQ0FBaEIsQ0FaNkIsQ0FhN0I7O0FBRUEsUUFBSSxDQUFDdGQsU0FBTCxFQUFnQjtBQUNkLFlBQU07QUFBRWYsWUFBRjtBQUFRRDtBQUFSLFVBQXFCLEtBQUtFLFlBQUwsRUFBbUI7QUFDNUNvZSxrQkFEeUIsRUFFekIsQ0FBQ0gsUUFBRCxDQUZ5QixDQUEzQjtBQUtBbmQsZUFBUyxHQUFHLENBQUMsQ0FBQ2YsSUFBRixHQUFTLENBQXJCLENBTmMsQ0FNUzs7QUFFdkIsVUFBSSxDQUFDZSxTQUFMLEVBQWdCO0FBQ2QsY0FBTVgsUUFBUSxHQUFHLEtBQUtvZSwwQkFBTCxDQUNmemUsUUFEZSxFQUVmdEIsUUFGZSxDQUFqQjtBQUlBc0MsaUJBQVMsR0FBRyxDQUFDWCxRQUFiOztBQUVBLFlBQUksQ0FBQ1csU0FBTCxFQUFnQjtBQUNkO0FBQ0EsZUFBSzBkLGtCQUFMLENBQ0VqZixRQURGLEVBRUVmLFFBRkYsRUFHRTRmLFlBSEYsRUFJRXJlLElBSkYsRUFLRUQsUUFMRixFQU1FSyxRQU5GO0FBUUQ7QUFDRjtBQUNGOztBQUVELFNBQUtzZSxZQUFMLENBQWtCM2QsU0FBbEI7QUFDRDtBQUdEOzs7Ozs7Ozs7Ozs7Ozs7O0FBY0F3ZCxlQUFhLENBQUMvZSxRQUFELEVBQVc2ZSxZQUFYLEVBQXlCO0FBQ3BDO0FBQ0E7QUFFQSxRQUFJLENBQUU3ZSxRQUFRLENBQUNoRixRQUFULENBQWtCMGpCLFFBQWxCLENBQU4sRUFBb0M7QUFDbEMsWUFBTXJlLE9BQU8sdUJBQ0EsS0FBS3BCLFFBREwsdUNBRUp5ZixRQUZJLDZDQUdURyxZQUhTLHdDQUlRN2UsUUFKUixjQUFiO0FBTUEsV0FBS25CLEdBQUwsQ0FBU3dCLE9BQVQ7QUFFQSxhQUFPLENBQUMsQ0FBUjtBQUNEOztBQUVELFdBQU8sQ0FBUDtBQUNEOztBQUdEMmUsNEJBQTBCLENBQUN6ZSxRQUFELEVBQVdiLFlBQVgsRUFBeUI7QUFDakQsVUFBTS9ILE1BQU0sR0FBRztBQUFFckIsU0FBRyxFQUFFb0o7QUFBUCxLQUFmO0FBRUEsVUFBTWtCLFFBQVEsR0FBRyxLQUFLQyxzQkFBTCxFQUE2QjtBQUM1Q04sWUFEZSxFQUVmb00sUUFGZSxFQUdmaFYsTUFIZSxDQUFqQixDQUhpRCxDQVNqRDs7QUFFQSxXQUFPaUosUUFBUDtBQUNEOztBQUdEcWUsb0JBQWtCLENBQ2hCamYsUUFEZ0IsRUFFaEJmLFFBRmdCLEVBR2hCNGYsWUFIZ0IsRUFJaEJyZSxJQUpnQixFQUtoQkQsUUFMZ0IsRUFNaEJLLFFBTmdCLEVBT2hCO0FBRUEsVUFBTXVlLFFBQVEsR0FBRyxJQUFJOU4sTUFBSixDQUFXcFMsUUFBUSxHQUFHLE9BQXRCLENBQWpCO0FBQ0EsVUFBTW1nQixLQUFLLEdBQUcsQ0FBQ3BmLFFBQVEsQ0FBQ3JGLElBQVQsQ0FBZW9ILElBQUksSUFBSW9kLFFBQVEsQ0FBQy9lLElBQVQsQ0FBYzJCLElBQWQsQ0FBdkIsQ0FBZixDQUhBLENBS0E7O0FBRUEsU0FBS3NkLGdCQUFMLENBQXNCcGdCLFFBQXRCLEVBQStCNGYsWUFBL0IsRUFBNENyZSxJQUE1QyxFQUFpRFIsUUFBakQsRUFBMERvZixLQUExRCxFQVBBLENBUUE7O0FBRUEsUUFBSSxDQUFDQSxLQUFMLEVBQVk7QUFDVixXQUFLRSxxQkFBTCxDQUNFOWUsSUFERixFQUVFRCxRQUZGLEVBR0VLLFFBSEY7QUFLRDtBQUNGOztBQUdEeWUsa0JBQWdCLENBQUVwZ0IsUUFBRixFQUFZNGYsWUFBWixFQUEwQnJlLElBQTFCLEVBQWdDUixRQUFoQyxFQUEwQ29mLEtBQTFDLEVBQWlEO0FBQy9ELFVBQU1sbEIsSUFBSSxHQUFHLE1BQU0rRSxRQUFuQjtBQUNBdUIsUUFBSSxDQUFDdEcsSUFBTCxHQUFhQSxJQUFiO0FBQ0FzRyxRQUFJLENBQUM0ZSxLQUFMLEdBQWFBLEtBQWIsQ0FIK0QsQ0FLL0Q7QUFDQTs7QUFDQTVlLFFBQUksQ0FBQ00sSUFBTCxHQUFZLEtBQUtDLFVBQUwsQ0FBZ0I4ZCxZQUFoQixFQUE4QjdlLFFBQTlCLENBQVo7QUFDRDtBQUdEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBc2YsdUJBQXFCLENBQUM5ZSxJQUFELEVBQU9ELFFBQVAsRUFBaUIvSSxHQUFqQixFQUFzQjtBQUN6QyxRQUFJQSxHQUFHLEtBQUssSUFBWixFQUFrQjtBQUNoQkEsU0FBRyxHQUFHZ0osSUFBSSxDQUFDaEosR0FBWCxDQURnQixDQUNEO0FBQ2hCLEtBSHdDLENBS3pDOzs7QUFFQSxRQUFJLENBQUNBLEdBQUwsRUFBVTtBQUNSO0FBQ0FBLFNBQUcsR0FBR21WLFFBQVEsQ0FBQ3RWLE1BQVQsQ0FBaUJtSixJQUFqQixDQUFOO0FBQ0FBLFVBQUksQ0FBQ2hKLEdBQUwsR0FBV0EsR0FBWCxDQUhRLENBSVI7QUFDQTs7QUFDQSxZQUFNaU0sR0FBRyxHQUFHLEtBQUtDLFNBQUwsQ0FBZW5ELFFBQWYsRUFBeUJDLElBQXpCLENBQVo7QUFDQW1NLGNBQVEsQ0FBQy9VLE1BQVQsQ0FBZ0I7QUFBRUo7QUFBRixPQUFoQixFQUF5QjtBQUFFSyxZQUFJLEVBQUU7QUFBRTRMO0FBQUY7QUFBUixPQUF6QjtBQUVELEtBVEQsTUFTTztBQUNMO0FBQ0FqRCxVQUFJLENBQUNoSixHQUFMLEdBQVdBLEdBQVgsQ0FGSyxDQUVVOztBQUNmZ0osVUFBSSxDQUFDaUQsR0FBTCxHQUFXLEtBQUtDLFNBQUwsQ0FBZW5ELFFBQWYsRUFBeUJDLElBQXpCLENBQVg7QUFDQW1NLGNBQVEsQ0FBQy9VLE1BQVQsQ0FBZ0I7QUFBRUo7QUFBRixPQUFoQixFQUF5QjtBQUFFSyxZQUFJLEVBQUUySTtBQUFSLE9BQXpCLEVBQXlDO0FBQUNzRCxjQUFNLEVBQUU7QUFBVCxPQUF6QztBQUNEO0FBQ0Y7O0FBR0RvYixjQUFZLENBQUMzZCxTQUFELEVBQVlzZCxZQUFaLEVBQTBCO0FBQ3BDLFFBQUl4ZSxPQUFKOztBQUVBLFFBQUksQ0FBQ2tCLFNBQUwsRUFBZ0I7QUFDZGxCLGFBQU8sa0VBQzJCLEtBQUtwQixRQURoQyx5QkFBUDtBQUdELEtBSkQsTUFJTyxJQUFJc0MsU0FBUyxHQUFHLENBQWhCLEVBQW1CO0FBQ3hCO0FBQ0FsQixhQUFPLDBDQUNHLEtBQUtwQixRQURSLHVFQUFQO0FBSUQsS0FOTSxNQU1BO0FBQ0w7QUFDQW9CLGFBQU8sMkNBQ0ksS0FBS3BCLFFBRFQsMktBSUg0ZixZQUpHLHNEQUFQO0FBTUQ7O0FBRUQsU0FBS2hnQixHQUFMLENBQVN3QixPQUFUO0FBQ0Q7O0FBdFBtRCxDOzs7Ozs7Ozs7OztBQy9CdEQsSUFBSWtmLFNBQUo7QUFBY3hxQixNQUFNLENBQUNLLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNILFNBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNrcUIsYUFBUyxHQUFDbHFCLENBQVY7QUFBWTs7QUFBeEIsQ0FBMUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSThJLFlBQUo7QUFBaUJwSixNQUFNLENBQUNLLElBQVAsQ0FBWSw0Q0FBWixFQUF5RDtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDOEksZ0JBQVksR0FBQzlJLENBQWI7QUFBZTs7QUFBM0IsQ0FBekQsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSW1xQixnQkFBSjtBQUFxQnpxQixNQUFNLENBQUNLLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDbXFCLG9CQUFnQixHQUFDbnFCLENBQWpCO0FBQW1COztBQUEvQixDQUFqQyxFQUFrRSxDQUFsRTtBQWFwTTtBQUNBLElBQUlrcUIsU0FBSixHLENBRUE7O0FBQ0EsSUFBSXBoQixZQUFKO0FBQ0EsSUFBSXFoQixnQkFBSixHOzs7Ozs7Ozs7OztBQ2xCQXpxQixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxTQUFPLEVBQUMsTUFBSXNxQjtBQUFiLENBQWQ7QUFBdUMsSUFBSWpDLFdBQUo7QUFBZ0J2b0IsTUFBTSxDQUFDSyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDaW9CLGVBQVcsR0FBQ2pvQixDQUFaO0FBQWM7O0FBQTFCLENBQTVCLEVBQXdELENBQXhEOztBQWF2RCxNQUFNcUosRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNekUsSUFBSSxHQUFHeUUsT0FBTyxDQUFDLE1BQUQsQ0FBcEI7O0FBR2UsTUFBTTRnQixTQUFOLENBQWU7QUFDNUIzcEIsYUFBVyxHQUFHO0FBQ1osVUFBTTZwQixTQUFTLEdBQUssV0FBcEI7QUFDQSxVQUFNQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0JILFNBQXhCLEVBQ0toZSxPQURMLENBQ2FnZSxTQURiLEVBQ3dCLEVBRHhCLENBQXBCO0FBRUEsVUFBTUksU0FBUyxHQUFHLFFBQWxCO0FBQ0EsVUFBTUMsU0FBUyxHQUFHLEtBQUtDLEtBQUwsQ0FBV0wsV0FBWCxFQUF3QkcsU0FBeEIsQ0FBbEI7QUFFQUMsYUFBUyxDQUFDenBCLE9BQVYsQ0FBa0JrbkIsUUFBUSxJQUFJO0FBQzVCLFVBQUlELFdBQUosQ0FBZ0JDLFFBQWhCO0FBQ0QsS0FGRDtBQUdEO0FBRUQ7Ozs7Ozs7Ozs7Ozs7O0FBWUF3QyxPQUFLLENBQUVqZ0IsTUFBRixFQUFVUCxLQUFWLEVBQTJCO0FBQUEsUUFBVnlnQixJQUFVLHVFQUFMLEVBQUs7QUFDOUIsVUFBTTVkLEtBQUssR0FBRzFELEVBQUUsQ0FBQzJELFFBQUgsQ0FBWXZDLE1BQVosQ0FBZDs7QUFFQSxRQUFJc0MsS0FBSyxDQUFDMGMsV0FBTixFQUFKLEVBQXdCO0FBQ3RCLFlBQU05ZSxRQUFRLEdBQUd0QixFQUFFLENBQUNrQixXQUFILENBQWVFLE1BQWYsQ0FBakI7QUFFQUUsY0FBUSxDQUFDM0osT0FBVCxDQUFpQjJELElBQUksSUFBSTtBQUN2QixjQUFNaW1CLFFBQVEsR0FBRy9sQixJQUFJLENBQUNnRyxJQUFMLENBQVVKLE1BQVYsRUFBa0I5RixJQUFsQixDQUFqQjs7QUFFQSxZQUFJdUYsS0FBSyxDQUFDYSxJQUFOLENBQVc2ZixRQUFYLENBQUosRUFBMEI7QUFDeEJELGNBQUksQ0FBQ3htQixJQUFMLENBQVV5bUIsUUFBVjtBQUVELFNBSEQsTUFHTztBQUNMLGVBQUtGLEtBQUwsQ0FBWUUsUUFBWixFQUFzQjFnQixLQUF0QixFQUE2QnlnQixJQUE3QjtBQUNEO0FBQ0YsT0FURDtBQVVEOztBQUVELFdBQU9BLElBQVA7QUFDRDs7QUE1QzJCLEM7Ozs7Ozs7Ozs7OztBQ2pCOUJFLFNBQU8sQ0FBQ2xyQixNQUFSLENBQWU7QUFBQ0MsV0FBTyxFQUFDLE1BQUlrckI7QUFBYixHQUFmO0FBQW9DLE1BQUk5QyxZQUFKO0FBQWlCNkMsU0FBTyxDQUFDOXFCLElBQVIsQ0FBYSxtQkFBYixFQUFpQztBQUFDSCxXQUFPLENBQUNJLENBQUQsRUFBRztBQUFDZ29CLGtCQUFZLEdBQUNob0IsQ0FBYjtBQUFlOztBQUEzQixHQUFqQyxFQUE4RCxDQUE5RDtBQUFpRSxNQUFJK21CLGNBQUo7QUFBbUI4RCxTQUFPLENBQUM5cUIsSUFBUixDQUFhLHNCQUFiLEVBQW9DO0FBQUNILFdBQU8sQ0FBQ0ksQ0FBRCxFQUFHO0FBQUMrbUIsb0JBQWMsR0FBQy9tQixDQUFmO0FBQWlCOztBQUE3QixHQUFwQyxFQUFtRSxDQUFuRTtBQUFzRSxNQUFJeW5CLGdCQUFKO0FBQXFCb0QsU0FBTyxDQUFDOXFCLElBQVIsQ0FBYSx1QkFBYixFQUFxQztBQUFDSCxXQUFPLENBQUNJLENBQUQsRUFBRztBQUFDeW5CLHNCQUFnQixHQUFDem5CLENBQWpCO0FBQW1COztBQUEvQixHQUFyQyxFQUFzRSxDQUF0RTtBQUF5RSxNQUFJOFAsVUFBSjtBQUFlK2EsU0FBTyxDQUFDOXFCLElBQVIsQ0FBYSxtQ0FBYixFQUFpRDtBQUFDK1AsY0FBVSxDQUFDOVAsQ0FBRCxFQUFHO0FBQUM4UCxnQkFBVSxHQUFDOVAsQ0FBWDtBQUFhOztBQUE1QixHQUFqRCxFQUErRSxDQUEvRTs7QUFZNVQsUUFBTXFKLEVBQUUsR0FBR0MsT0FBTyxDQUFDLElBQUQsQ0FBbEI7O0FBQ0EsUUFBTXpFLElBQUksR0FBR3lFLE9BQU8sQ0FBQyxNQUFELENBQXBCOztBQUllLFFBQU13aEIsS0FBTixDQUFXO0FBQ3hCdnFCLGVBQVcsR0FBRztBQUNaLFdBQUt3cUIsVUFBTCxHQUFtQixlQUFuQjtBQUNBLFdBQUtDLFdBQUwsR0FBbUIscUJBQW5CO0FBRUEsV0FBS0MsY0FBTCxDQUFvQixZQUFwQjtBQUNBLFdBQUtDLFNBQUwsQ0FBZSxRQUFmO0FBQ0Q7O0FBR0RELGtCQUFjLENBQUN4Z0IsTUFBRCxFQUFTO0FBQ3JCLFlBQU0wZ0IsVUFBVSxHQUFHLEVBQW5CO0FBRUEsWUFBTTNCLFlBQVksR0FBRzNrQixJQUFJLENBQUNnRyxJQUFMLENBQVUsS0FBS21nQixXQUFmLEVBQTRCdmdCLE1BQTVCLENBQXJCO0FBQ0EsWUFBTTJnQixhQUFhLEdBQUcvaEIsRUFBRSxDQUFDa0IsV0FBSCxDQUFlaWYsWUFBZixDQUF0QjtBQUVBNEIsbUJBQWEsQ0FBQ3BxQixPQUFkLENBQXNCNE4sSUFBSSxJQUFJO0FBQzVCLFlBQUlBLElBQUksS0FBSyxRQUFiLEVBQXVCO0FBQ3JCLGdCQUFNeWMsU0FBUyxHQUFHeG1CLElBQUksQ0FBQ2dHLElBQUwsQ0FBVTJlLFlBQVYsRUFBd0I1YSxJQUF4QixDQUFsQjtBQUNBLGdCQUFNN0IsS0FBSyxHQUFHMUQsRUFBRSxDQUFDMkQsUUFBSCxDQUFZcWUsU0FBWixDQUFkOztBQUVBLGNBQUl0ZSxLQUFLLENBQUMwYyxXQUFOLEVBQUosRUFBd0I7QUFDdEIsa0JBQU02QixZQUFZLEdBQUcsS0FBS0MsU0FBTCxDQUFlM2MsSUFBZixFQUFxQnljLFNBQXJCLENBQXJCOztBQUVBLGdCQUFJQyxZQUFKLEVBQWtCO0FBQ2hCSCx3QkFBVSxDQUFDaG5CLElBQVgsQ0FBZ0JtbkIsWUFBaEI7QUFFRCxhQUhELE1BR087QUFDTHJnQixxQkFBTyxDQUFDekIsR0FBUixDQUFZLGtCQUFaLEVBQWdDb0YsSUFBaEM7QUFDRDtBQUNGO0FBQ0Y7QUFDRixPQWhCRDtBQWtCQSxXQUFLNGMsV0FBTCxDQUFpQkwsVUFBakI7QUFDRDs7QUFHREksYUFBUyxDQUFDM2MsSUFBRCxFQUFPbkUsTUFBUCxFQUFlO0FBQ3RCLFVBQUlpTCxJQUFKO0FBQ0EsWUFBTS9LLFFBQVEsR0FBR3RCLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZUUsTUFBZixDQUFqQjtBQUNBLFlBQU11RSxJQUFJLEdBQUdyRSxRQUFRLENBQUN6RixHQUFULENBQWF3SCxJQUFJLElBQUk7QUFDaEMsY0FBTStlLFFBQVEsR0FBRzVtQixJQUFJLENBQUNzSSxRQUFMLENBQWNULElBQWQsRUFBb0I3SCxJQUFJLENBQUMrSCxPQUFMLENBQWFGLElBQWIsQ0FBcEIsQ0FBakI7O0FBRUEsWUFBSStlLFFBQVEsQ0FBQzVlLFdBQVQsT0FBMkIrQixJQUFJLENBQUMvQixXQUFMLEVBQS9CLEVBQW1EO0FBQ2pELGlCQUFPLFFBQVA7QUFFRCxTQUhELE1BR087QUFDTCxpQkFBTzRlLFFBQVA7QUFDRDtBQUNGLE9BVFksQ0FBYjs7QUFXQSxVQUFJemMsSUFBSSxDQUFDckosUUFBTCxDQUFjLFFBQWQsS0FBMkJxSixJQUFJLENBQUNySixRQUFMLENBQWMsU0FBZCxDQUEvQixFQUF5RDtBQUN2RCtQLFlBQUksR0FBRzFHLElBQUksQ0FBQzBjLE1BQUwsQ0FBWSxDQUFDeG1CLEdBQUQsRUFBTWpFLEdBQU4sRUFBV3lELEtBQVgsS0FBcUI7QUFDdEMsY0FBSWdJLElBQUksR0FBRzdILElBQUksQ0FBQ2dHLElBQUwsQ0FBVUosTUFBVixFQUFrQkUsUUFBUSxDQUFDakcsS0FBRCxDQUExQixFQUNLMEgsT0FETCxDQUNhLEtBQUs0ZSxXQURsQixFQUMrQixLQUFLRCxVQURwQyxDQUFYO0FBRUE3bEIsYUFBRyxDQUFDakUsR0FBRCxDQUFILEdBQVc7QUFDUDJOLGdCQURPO0FBRVBsQztBQUZPLFdBQVg7QUFLQSxpQkFBT3hILEdBQVA7QUFDRCxTQVRNLEVBU0osRUFUSSxDQUFQO0FBV0EsZUFBT3dRLElBQVA7QUFDRDtBQUNGOztBQUdEd1YsYUFBUyxDQUFDemdCLE1BQUQsRUFBUztBQUNoQixZQUFNdEssV0FBVyxHQUFHLEVBQXBCO0FBRUEsWUFBTXdyQixVQUFVLEdBQUc5bUIsSUFBSSxDQUFDZ0csSUFBTCxDQUFVLEtBQUttZ0IsV0FBZixFQUE0QnZnQixNQUE1QixDQUFuQjtBQUNBLFlBQU1taEIsVUFBVSxHQUFHdmlCLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZW9oQixVQUFmLENBQW5CO0FBRUFDLGdCQUFVLENBQUM1cUIsT0FBWCxDQUFtQjROLElBQUksSUFBSTtBQUN6QixjQUFNeWMsU0FBUyxHQUFHeG1CLElBQUksQ0FBQ2dHLElBQUwsQ0FBVThnQixVQUFWLEVBQXNCL2MsSUFBdEIsQ0FBbEI7QUFDQSxjQUFNN0IsS0FBSyxHQUFHMUQsRUFBRSxDQUFDMkQsUUFBSCxDQUFZcWUsU0FBWixDQUFkOztBQUVBLFlBQUl0ZSxLQUFLLENBQUMwYyxXQUFOLEVBQUosRUFBd0I7QUFDdEJ0cEIscUJBQVcsQ0FBQ2dFLElBQVosQ0FBaUJ5SyxJQUFqQjtBQUNEO0FBQ0YsT0FQRDtBQVNBLFVBQUk2WSxnQkFBSixDQUFxQnRuQixXQUFyQjtBQUNEOztBQUdEcXJCLGVBQVcsQ0FBQ0wsVUFBRCxFQUFhO0FBQ3RCLFlBQU1uRSxPQUFPLEdBQUksRUFBakI7QUFDQSxZQUFNMVEsT0FBTyxHQUFJLEVBQWpCO0FBRUE2VSxnQkFBVSxDQUFDbnFCLE9BQVgsQ0FBb0I0SSxRQUFRLElBQUk7QUFDOUIsWUFBSUEsUUFBUSxDQUFDeWQsTUFBYixFQUFxQjtBQUNuQjtBQUNBTCxpQkFBTyxDQUFDN2lCLElBQVIsQ0FBYXlGLFFBQVEsQ0FBQ3lkLE1BQXRCO0FBQ0Q7O0FBQ0QsWUFBSXpkLFFBQVEsQ0FBQzBNLE9BQWIsRUFBc0I7QUFDcEI7QUFDQUEsaUJBQU8sQ0FBQ25TLElBQVIsQ0FBYXlGLFFBQVEsQ0FBQzBNLE9BQXRCO0FBQ0Q7QUFDRixPQVREO0FBV0EsVUFBSTBSLFlBQUosQ0FBaUIxUixPQUFqQjtBQUNBLFVBQUl5USxjQUFKLENBQW1CQyxPQUFuQjtBQUNEOztBQXpHdUI7Ozs7Ozs7Ozs7OztBQ2pCMUIsSUFBSTdXLE1BQUo7QUFBV3pRLE1BQU0sQ0FBQ0ssSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ29RLFFBQU0sQ0FBQ25RLENBQUQsRUFBRztBQUFDbVEsVUFBTSxHQUFDblEsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRE4sTUFBTSxDQUFDSyxJQUFQLENBQVksbUNBQVo7QUFBaUQsSUFBSStxQixLQUFKO0FBQVVwckIsTUFBTSxDQUFDSyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDSCxTQUFPLENBQUNJLENBQUQsRUFBRztBQUFDOHFCLFNBQUssR0FBQzlxQixDQUFOO0FBQVE7O0FBQXBCLENBQXRCLEVBQTRDLENBQTVDO0FBYzNIbVEsTUFBTSxDQUFDMGIsT0FBUCxDQUFlLE1BQU07QUFDbkIsTUFBSTFiLE1BQU0sQ0FBQ0MsYUFBWCxFQUEwQjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUkwYSxLQUFKO0FBQ0QsR0FQa0IsQ0FTbkI7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeGhCLFNBQU8sQ0FBQyxhQUFELENBQVA7QUFDRCxDQWRELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogL2ltcG9ydHMvYXBpL21ldGhvZHMvYWRtaW4vYWNjb3VudC5qc1xuICovXG5cblxuaW1wb3J0IHsgaHNsMmhleCB9IGZyb20gJy4uLy4uLy4uL3Rvb2xzL2dlbmVyaWMvdXRpbGl0aWVzJ1xuaW1wb3J0IHsgZ2V0R29sZGVuQW5nbGVBdFxuICAgICAgICwgZ2V0Q29kZUZyb21cbiAgICAgICB9IGZyb20gJy4uLy4uLy4uL3Rvb2xzL2N1c3RvbS9wcm9qZWN0J1xuXG5pbXBvcnQgY29sbGVjdGlvbnMgZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMvcHVibGlzaGVyJ1xuY29uc3QgeyBVc2VyLCBUZWFjaGVyLCBHcm91cCB9ID0gY29sbGVjdGlvbnNcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIENyZWF0ZUFjY291bnQge1xuICBjb25zdHJ1Y3RvcihhY2NvdW50RGF0YSkge1xuICAgIHRoaXMuYWNjb3VudERhdGEgPSBhY2NvdW50RGF0YVxuICAgIC8vIGNvbnNvbGUubG9nKFwiQ3JlYXRlQWNjb3VudCBhY2NvdW50RGF0YTpcIiwgYWNjb3VudERhdGEpXG5cbiAgICAvLy8gPDw8IEhBUkQtQ09ERURcbiAgICB0aGlzLnNhdHVyYXRpb24gPSA2MFxuICAgIHRoaXMubHVtaW5vc2l0eSA9IDUwXG4gICAgLy8gYWNjb3VudERhdGEucGF0aCA9IFtdXG4gICAgLy8vIEhBUkQtQ09ERUTCoD4+PlxuXG4gICAgdGhpcy5jcmVhdGVVbmlxdWVRQ29kZSgpXG4gICAgdGhpcy5jcmVhdGVVc2VyKClcblxuICAgIGFjY291bnREYXRhLmFjY291bnRDcmVhdGVkID0gdHJ1ZVxuICAgIGFjY291bnREYXRhLnN0YXR1cyA9IFwiQ3JlYXRlR3JvdXBcIlxuXG4gICAgLy8gY29uc29sZS5sb2coXCJhY2NvdW50RGF0YSBhZnRlciBjcmVhdGVVc2VyOlwiLCBhY2NvdW50RGF0YSlcbiAgICAvLyBjb25zb2xlLmxvZyhcIuKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlFwiKVxuICAgIC8vXG4gICAgLy8gZF9jb2RlOiBcIkhBQklnXCJcbiAgICAvLyBuYXRpdmU6IFwiZW4tR0JcIlxuICAgIC8vIHFfY29kZTogXCIzODE5XCJcbiAgICAvLyBxX2NvbG9yOiBcIiMzM2NjNjBcIlxuICAgIC8vIHFfaW5kZXg6IDFcbiAgICAvLyBzdGF0dXM6IFwiQ3JlYXRlQWNjb3VudFwiXG4gICAgLy8gdXNlcl9pZDogXCJEY01ObmhON21lWjdobVNyNFwiXG4gICAgLy8gdXNlcm5hbWU6IFwiSmFtZXNcIlxuICAgIC8vIHBhdGg6ICBbXVxuICAgIC8vXG4gICAgLy8gPSB1c2VybmFtZTogICBcItCS0LvQsNC0XCJcbiAgICAvLyA9IHRlYWNoZXI6ICAgIFwiam5cIlxuICAgIC8vID0gZF9jb2RlOiAgICAgXCJkOVV2bFwiXG4gICAgLy8gKyBxX2NvZGU6ICAgICBcIjAzODFcIlxuICAgIC8vICsgdXNlcl9pZDogICAgXCJCcUtrTWpqQlNSemVkYXN5VFwiXG4gICAgLy8gKyBncm91cF9pZDogICBcIlBXd2tuU2lIQ0dtc2l2U1hnXCJcbiAgICAvLyArIG5ld0FjY291bnQ6IHRydWVcbiAgICAvLyArIHBhdGg6ICAgICAgIFtdXG4gICAgLy9cbiAgICAvLyAvLyBOb3QgbmVlZGVkIGluIHRoZSByZXR1cm4gdmFsdWVcbiAgICAvLyA9IGxhbmd1YWdlOiAgIFwiZW4tR0JcIlxuICAgIC8vID0gbmF0aXZlOiAgICAgXCJydVwiXG4gICAgLy8gKyBxX2NvbG9yOiAgICBcIiMzM2NjNjBcIlxuICAgIC8vICsgcV9pbmRleDogICAgMVxuICAgIC8vICsgbG9nZ2VkX2luOiAgIFtdXG5cbiAgICBjb25zdCBub3ROZWVkZWQgPSBbXG4gICAgICBcImxhbmd1YWdlXCJcbiAgICAsIFwibmF0aXZlXCJcbiAgICAsIFwicV9jb2xvclwiXG4gICAgLCBcInFfaW5kZXhcIlxuICAgICwgXCJsb2dnZWRfaW5cIlxuICAgIF1cblxuICAgIG5vdE5lZWRlZC5mb3JFYWNoKGtleSA9PiB7ZGVsZXRlIGFjY291bnREYXRhW2tleV19KVxuICB9XG5cblxuICBjcmVhdGVVbmlxdWVRQ29kZSgpIHtcbiAgICAvLyBDcmVhdGUgb3IgcmVjeWxlIGEgbnVtYmVyIGJldHdlZW4gMDAwMSBhbmQgOTk5OVxuXG4gICAgbGV0IG5ld2VzdCAgPSBVc2VyLmZpbmRPbmUoXG4gICAgICB7fVxuICAgICwgeyBmaWVsZHM6IHsgcV9pbmRleDogMSB9XG4gICAgICAsIHNvcnQ6IHsgcV9pbmRleDogLTEgfVxuICAgICAgfVxuICAgIClcblxuICAgIGxldCBxX2luZGV4ID0gbmV3ZXN0XG4gICAgICAgICAgICAgICAgPyBuZXdlc3QucV9pbmRleCArIDFcbiAgICAgICAgICAgICAgICA6IDFcbiAgICBsZXQgaHVlXG4gICAgICAsIHFfY29kZVxuICAgICAgLCBxX2NvbG9yXG5cbiAgICBpZiAocV9pbmRleCA8IDY3NjUpIHtcbiAgICAgIC8vIFVzZSB0aGUgR29sZGVuIEFuZ2xlIHRvIGdldCB0aGUgbmV4dCB2YWx1ZVxuICAgICAgaHVlID0gZ2V0R29sZGVuQW5nbGVBdChxX2luZGV4KVxuICAgICAgcV9jb2RlID0gZ2V0Q29kZUZyb20oaHVlKVxuXG4gICAgfSBlbHNlIGlmIChxX2luZGV4IDwgODkwMSkge1xuICAgICAgLy8gVE9ETzogVXNlIHRoZSBHb2xkZW4gQW5nbGUsIGJ1dCBjaGVjayBmb3IgZHVwbGljYXRlIHFfY29kZSdzXG5cbiAgICB9IGVsc2UgaWYgKHFfaW5kZXggPCAxMDAwMCkge1xuICAgICAgLy8gVE9ETzogRmluZCBhIGdhcCBpbiB0aGUgaW5kZXggbnVtYmVyc1xuXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRPRE86IFdlIGNhbid0IGhhdmUgbW9yZSB0aGFuIDk5OTkgdW5pcXVlIHFfY29kZXMuIEZpbmQgdGhlXG4gICAgICAvLyBVc2VyIHdpdGggYSBuYW1lIGRpZmZlcmVudCBmcm9tIHRoaXMuYWNjb3VudERhdGEudXNlcm5hbWVcbiAgICAgIC8vIHdobyBsb2dnZWQgaW4gbGFzdCB0aGUgbG9uZ2VzdCB0aW1lIGFnbywgYXJjaGl2ZSB0aGF0IFVzZXJcbiAgICAgIC8vIHJlY29yZCBhbmQgcmV1c2UgdGhhdCBVc2VyJ3MgcV9pbmRleCBhbmQgcV9jb2RlLiBUaGUgcV9jb2xvclxuICAgICAgLy8gd2lsbCBiZSByZXNldCBiZWxvdy5cbiAgICB9XG5cbiAgICBxX2NvbG9yID0gaHNsMmhleChodWUsIHRoaXMuc2F0dXJhdGlvbiwgdGhpcy5sdW1pbm9zaXR5KVxuXG4gICAgdGhpcy5hY2NvdW50RGF0YS5xX2luZGV4ID0gcV9pbmRleFxuICAgIHRoaXMuYWNjb3VudERhdGEucV9jb2RlICA9IHFfY29kZVxuICAgIHRoaXMuYWNjb3VudERhdGEucV9jb2xvciA9IHFfY29sb3JcbiAgfVxuXG5cbiAgY3JlYXRlVXNlcigpIHtcbiAgICBjb25zdCB7XG4gICAgICB1c2VybmFtZVxuICAgICwgbmF0aXZlXG4gICAgLCBxX2luZGV4XG4gICAgLCBxX2NvZGVcbiAgICAsIHFfY29sb3JcbiAgICAsIGRfY29kZVxuICAgIH0gPSB0aGlzLmFjY291bnREYXRhXG5cbiAgICBjb25zdCBmaWVsZHMgPSB7XG4gICAgICB1c2VybmFtZVxuICAgICwgbmF0aXZlXG4gICAgLCBxX2luZGV4XG4gICAgLCBxX2NvZGVcbiAgICAsIHFfY29sb3JcbiAgICB9XG4gICAgZmllbGRzLmhpc3RvcnkgPSB7fVxuICAgIGZpZWxkcy5sb2dnZWRfaW4gPSBbXVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJjcmVhdGVVc2VyIGFjY291bnREYXRhID0gXCIsIHRoaXMuYWNjb3VudERhdGEpXG5cbiAgICB0aGlzLmFjY291bnREYXRhLnVzZXJfaWQgID0gVXNlci5pbnNlcnQoZmllbGRzKVxuICB9XG59IiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZG1pbi9hY3RpdmF0ZS5qc1xuICovXG5cblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBUb2dnbGVBY3RpdmF0aW9uIHtcbiAgY29uc3RydWN0b3IoZ3JvdXBEYXRhKSB7XG4gICAgLy8gY29uc29sZS5sb2coXCJUb2dnbGVBY3RpdmF0aW9uIGdyb3VwRGF0YTpcIiwgZ3JvdXBEYXRhKVxuXG4gICAgY29uc3QgeyBfaWQsIGRfY29kZSwgYWN0aXZlIH0gPSBncm91cERhdGFcbiAgICBjb25zdCBhY3Rpb24gPSBhY3RpdmVcbiAgICAgICAgICAgICAgICAgPyBcIiRwdXNoXCJcbiAgICAgICAgICAgICAgICAgOiBcIiRwdWxsXCJcblxuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkIH1cbiAgICBjb25zdCB1cGRhdGUgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIGFjdGl2ZVxuICAgICAgfVxuICAgICwgW2FjdGlvbl06IHtcbiAgICAgICAgbG9nZ2VkX2luOiBkX2NvZGVcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gR3JvdXAudXBkYXRlKHNlbGVjdCwgdXBkYXRlKVxuICAgIC8vIDEgPSBzdWNjZXNzOyAwID0gbm90XG5cbiAgICAvLyBjb25zb2xlLmxvZyggXCJUb2dnbGVBY3RpdmF0aW9uOlwiLCByZXN1bHRcbiAgICAvLyAgICAgICAgICAgICwgXCJkYi5ncm91cC51cGRhdGUoXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgIC8vICAgICAgICAgICAgKyBcIiwgXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkodXBkYXRlKVxuICAgIC8vICAgICAgICAgICAgKyBcIilcIlxuICAgIC8vICAgICAgICAgICAgKVxuXG4gICAgaWYgKHJlc3VsdCkge1xuICAgICAgZ3JvdXBEYXRhLnRlYWNoZXJfbG9nZ2VkX2luID0gdHJ1ZVxuICAgIH1cbiAgfVxufSIsIi8qKlxuICogL2ltcG9ydHMvYXBpL21ldGhvZHMvYWRtaW4vZ3JvdXAuanNcbiAqL1xuXG5cbmltcG9ydCBjb2xsZWN0aW9ucyBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucy9wdWJsaXNoZXInXG5jb25zdCB7IEdyb3VwIH0gPSBjb2xsZWN0aW9uc1xuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3JlYXRlR3JvdXAge1xuICBjb25zdHJ1Y3RvcihhY2NvdW50RGF0YSkge1xuICAgIC8vIE1pbmltdW06XG4gICAgLy8geyB1c2VyX2lkOiA8PlxuICAgIC8vICwgdGVhY2hlcjogPD5cbiAgICAvLyAsIGxhbmd1YWdlOiA8PlxuICAgIC8vIH1cblxuICAgIC8vIGNvbnNvbGUubG9nKFwiYWNjb3VudERhdGEgYmVmb3JlIENyZWF0ZUdyb3VwOlwiLCBhY2NvdW50RGF0YSlcblxuICAgIGNvbnN0IGdyb3VwID0ge1xuICAgICAgb3duZXI6ICAgICAgYWNjb3VudERhdGEudGVhY2hlclxuICAgICwgbGFuZ3VhZ2U6ICAgYWNjb3VudERhdGEubGFuZ3VhZ2VcbiAgICAsIGFjdGl2ZTogICAgIGZhbHNlIC8vIGJlY29tZXMgdHJ1ZSBpZiBUZWFjaGVyIGxvZ3MgaW4gcGVyc29uYWxseVxuICAgICwgbG9iYnk6ICAgICAgXCJcIlxuICAgICwgY2hhdF9yb29tOiAgXCJcIlxuICAgICwgbWVtYmVyczogW1xuICAgICAgICBhY2NvdW50RGF0YS51c2VyX2lkXG4gICAgICAsIGFjY291bnREYXRhLnRlYWNoZXJcbiAgICAgIF1cbiAgICAsIGxvZ2dlZF9pbjogW11cbiAgICAvLyAvLyBXaWxsIGJlIGFkZGVkIGJ5IHRoZSBDbGllbnRcbiAgICAvLyAsIHZpZXdfZGF0YToge31cbiAgICAvLyAsIHZpZXdfc2l6ZTogeyB3aWR0aCwgaGVpZ2h0IH1cbiAgICB9XG4gICAgYWNjb3VudERhdGEuZ3JvdXBfaWQgPSBHcm91cC5pbnNlcnQoZ3JvdXApXG4gICAgYWNjb3VudERhdGEuZ3JvdXBDcmVhdGVkID0gdHJ1ZVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJhY2NvdW50RGF0YSBhZnRlciBDcmVhdGVHcm91cDpcIiwgYWNjb3VudERhdGEpXG4gIH1cbn0iLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2pvaW4uanNcbiAqL1xuXG5pbXBvcnQgeyByZW1vdmVGcm9tIH0gZnJvbSAnLi4vLi4vLi4vdG9vbHMvZ2VuZXJpYy91dGlsaXRpZXMnXG5pbXBvcnQgY29sbGVjdGlvbnNcbiAgICAgLCB7IGdldE5leHRJbmRleCB9XG4gICAgICAgZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMvcHVibGlzaGVyJ1xuY29uc3QgeyBVc2VyLCBHcm91cCB9ID0gY29sbGVjdGlvbnNcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEpvaW5Hcm91cCB7XG4gIGNvbnN0cnVjdG9yKGFjY291bnREYXRhKSB7XG4gICAgLyogY29uc29sZS5sb2coXCJKb2luR3JvdXBcIiwgYWNjb3VudERhdGEpXG4gICAgICpcbiAgICAgKiB7IHVzZXJfaWQ6IFwiWVoyeEpvSGY1U0R6WlBRRURcIlxuICAgICAqICwgZF9jb2RlOiBcImRtNGVOXCJcbiAgICAgKlxuICAgICAqIC8vIE1hbnVhbCBsb2cgaW4gd2lsbCB1c2UgdGVhY2hlciB0byBmaW5kIGdyb3VwX2lkLCBvciB3aWxsXG4gICAgICogLy8gY3JlYXRlIGEgbmV3IGdyb3VwIHVzaW5nIHVzZXJfaWQsIHRlYWNoZXIgYW5kIGxhbmd1YWdlXG4gICAgICogLy8gKGdyb3VwX2lkIHdpbGwgYmUgb3ZlcnJpZGRlbiwgYmVjYXVzZSBpdCBtaWdodCByZWZlciB0b1xuICAgICAqIC8vICB0aGUgbGFzdCBncm91cCB0aGUgdXNlciBqb2luZWQsIHJhdGhlciB0aGFuIHRoZSBncm91cCB3aXRoXG4gICAgICogLy8gIHRoaXMgdGVhY2hlcilcbiAgICAgKiAsIHRlYWNoZXI6ICBcImFhXCJcbiAgICAgKiAsIGxhbmd1YWdlOiBcInJ1XCJcbiAgICAgKlxuICAgICAqIC8vIGF1dG9fbG9naW4gd2lsbCBub3QgaGF2ZSB0ZWFjaGVyIG9yIGxhbmd1YWdlLCBzbyByZXF1aXJlc1xuICAgICAqIC8vIGdyb3VwX2lkXG4gICAgICogLCBncm91cF9pZDogXCI5N05TMmhERVludEVoWFhiclwiXG4gICAgICogfVxuICAgICAqL1xuXG4gICAgbGV0IHt1c2VyX2lkLCBkX2NvZGUsIHRlYWNoZXIsIGxhbmd1YWdlLCBncm91cF9pZCB9ID0gYWNjb3VudERhdGFcbiAgICBpZiAodGVhY2hlciAmJiBsYW5ndWFnZSkge1xuICAgICAgZ3JvdXBfaWQgPSB0aGlzLmdyb3VwV2l0aFRoaXNUZWFjaGVyKHVzZXJfaWQsIHRlYWNoZXIpXG4gICAgfVxuXG4gICAgaWYgKGdyb3VwX2lkKSB7XG4gICAgICAvLyBUaGUgdXNlciBtaWdodCBoYXZlIGNob3NlbiBhIGRpZmZlcmVudCBncm91cCBmcm9tIGxhc3QgdGltZVxuICAgICAgYWNjb3VudERhdGEuZ3JvdXBfaWQgPSBncm91cF9pZFxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYWNjb3VudERhdGEuc3RhdHVzID0gXCJDcmVhdGVHcm91cFwiXG4gICAgICAvLyBXZSdsbCBiZSBiYWNrXG4gICAgfVxuXG4gICAgbGV0IHN1Y2Nlc3MgPSB0aGlzLmpvaW5Hcm91cChncm91cF9pZCwgZF9jb2RlKVxuXG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgIGNvbnN0IGRfY29kZXMgPSB0aGlzLmdldExvZ2dlZEluQ29kZXMoZ3JvdXBfaWQpXG4gICAgICBhY2NvdW50RGF0YS5wYWdlID0gdGhpcy5nZXRQYWdlKGFjY291bnREYXRhLCBkX2NvZGVzKVxuICAgICAgc3VjY2VzcyA9IHRoaXMuYWRkVXNlckhpc3RvcnlJdGVtKGdyb3VwX2lkLCBkX2NvZGUsIHVzZXJfaWQpXG5cbiAgICAgIGlmIChzdWNjZXNzKSB7XG4gICAgICAgIGFjY291bnREYXRhLnN0YXR1cyA9IFwiSm9pbkdyb3VwX3N1Y2Nlc3NcIlxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWNjb3VudERhdGEuc3RhdHVzID0gXCJKb2luR3JvdXBfbm9IaXN0b3J5SXRlbVwiXG4gICAgICB9XG5cbiAgICAgIHRoaXMubW92ZVRlYWNoZXJEQ29kZVRvRW5kKGdyb3VwX2lkLCBkX2NvZGVzKVxuXG4gICAgfSBlbHNlIHtcbiAgICAgIGFjY291bnREYXRhLnN0YXR1cyA9IFwiSm9pbkdyb3VwX2ZhaWxcIlxuICAgIH1cbiAgfVxuXG5cbiAgZ3JvdXBXaXRoVGhpc1RlYWNoZXIodXNlcl9pZCwgdGVhY2hlcikge1xuICAgIGNvbnN0IHNlbGVjdCA9IHtcbiAgICAgIG1lbWJlcnM6IHtcbiAgICAgICAgJGFsbDogW1xuICAgICAgICAgIHVzZXJfaWRcbiAgICAgICAgLCB0ZWFjaGVyXG4gICAgICAgIF1cbiAgICAgICwgJHNpemU6IDJcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB7IF9pZCB9ID0gKEdyb3VwLmZpbmRPbmUoc2VsZWN0KSB8fCB7fSlcblxuICAgIHJldHVybiBfaWRcbiAgfVxuXG5cbiAgam9pbkdyb3VwKCBncm91cF9pZCwgZF9jb2RlKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0geyBfaWQ6IGdyb3VwX2lkIH1cbiAgICBjb25zdCBwdXNoID0geyAkcHVzaDogeyBsb2dnZWRfaW46IGRfY29kZSB9fVxuICAgIGNvbnN0IHN1Y2Nlc3MgPSBHcm91cC51cGRhdGUoc2VsZWN0LCBwdXNoKVxuXG4gICAgcmV0dXJuIHN1Y2Nlc3NcbiAgfVxuXG5cbiAgZ2V0UGFnZShhY2NvdW50RGF0YSwgZF9jb2Rlcykge1xuICAgIGxldCBwYWdlID0geyB2aWV3OiBcIkFjdGl2aXR5XCIgfVxuXG4gICAgbGV0IHJlYWRGcm9tR3JvdXAgPSBkX2NvZGVzLmxlbmd0aCA+IDFcbiAgICBpZiAoIXJlYWRGcm9tR3JvdXApIHtcbiAgICAgIHJlYWRGcm9tR3JvdXAgPSBhY2NvdW50RGF0YS5yZXN0b3JlX2FsbFxuICAgIH1cblxuICAgIGlmIChyZWFkRnJvbUdyb3VwKSB7XG4gICAgICBjb25zdCBzZWxlY3QgPSB7IF9pZDogYWNjb3VudERhdGEuZ3JvdXBfaWQgfVxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHsgZmllbGRzOiB7IHBhZ2U6IDEgfX1cbiAgICAgIGNvbnN0IGdyb3VwRGF0YSA9IEdyb3VwLmZpbmRPbmUoc2VsZWN0LCBvcHRpb25zKVxuICAgICAgaWYgKGdyb3VwRGF0YSAmJiBncm91cERhdGEucGFnZSkge1xuICAgICAgICBwYWdlID0gZ3JvdXBEYXRhLnBhZ2VcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBjb25zb2xlLmxvZyhcImpvaW4uanMgZ2V0UGFnZSBwYWdlOlwiLCBwYWdlKVxuXG4gICAgcmV0dXJuIHBhZ2VcbiAgfVxuXG4gIC8vIFRPRE8gaXMgdGhlIGdlbk5leHRJbmRleCB0aGluZyBuZWVkZWQ/IElzIGl0IGV2ZW4gd29ya2luZz9cblxuICBhZGRVc2VySGlzdG9yeUl0ZW0oZ3JvdXBfaWQsIGRfY29kZSwgdXNlcl9pZCkge1xuICAgIGNvbnN0IGluZGV4ID0gZ2V0TmV4dEluZGV4KFwiaGlzdG9yeVwiKSAvLyBjb3VsZCB1c2UgYSByYW5kb20gdmFsdWVcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZDogdXNlcl9pZCB9XG4gICAgY29uc3QgaXRlbSAgPSB7IGluOiBpbmRleCB9XG4gICAgY29uc3QgcGF0aCAgPSBcImhpc3RvcnkuXCIgKyBncm91cF9pZFxuICAgIC8vIHsgLi4uXG4gICAgLy8gLCBoaXN0b3J5OiB7XG4gICAgLy8gICAgIDxncm91cF9pZD46IFsgLi4uXG4gICAgLy8gICAgICwgeyBkX2NvZGU6IFwieHh4eHhcIlxuICAgIC8vICAgICAgICwgaW46ICBJU09fbG9nZ2VkSW5UaW1lXG4gICAgLy8gICAgICAgLCBvdXQ6IElTT19sb2dnZWRPdXRUaW1lXG4gICAgLy8gICAgICAgLCBzdGF0dXM6IHsgVEJEIH1cbiAgICAvLyAgICAgICB9XG4gICAgLy8gICAgIF1cbiAgICAvLyAgIH1cbiAgICAvLyAsIC4uLlxuICAgIC8vIH1cblxuICAgIC8vIEluc2VydCB0aGUgeyBpbjogPC4uLj4gfSBoaXN0b3J5IGl0ZW0gYXQgaW5kZXggcG9zaXRpb24gMCwgc29cbiAgICAvLyB0aGF0IGEgc3Vic2VxdWVudCBvcGVyYXRpb24gdG8gYWRkIGFuIG91dDogPC4uLj4gZmllbGQgdG8gdGhpc1xuICAgIC8vIGl0ZW0gd2lsbCBmaW5kIGl0LlxuXG4gICAgY29uc3QgcHVzaCA9IHtcbiAgICAgICRwdXNoOiB7XG4gICAgICAgIFtwYXRoXToge1xuICAgICAgICAgICRlYWNoOiBbaXRlbV1cbiAgICAgICAgLCAkcG9zaXRpb246IDBcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGxldCBzdWNjZXNzID0gVXNlci51cGRhdGUoc2VsZWN0LCBwdXNoKVxuXG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgIHNlbGVjdFtwYXRoICsgXCIuaW5cIl0gPSBpbmRleFxuICAgICAgY29uc3QgY3JlYXRlZCA9IHtcbiAgICAgICAgJGN1cnJlbnREYXRlOiB7IFtwYXRoICsgXCIuJC5pblwiXTogdHJ1ZSB9XG4gICAgICB9XG5cbiAgICAgIC8vIGNvbnNvbGUubG9nKCBcImRiLnVzZXIudXBkYXRlKFwiXG4gICAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgICAgLy8gICAgICAgICAgICArIFwiLCBcIlxuICAgICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KGNyZWF0ZWQpXG4gICAgICAvLyAgICAgICAgICAgICsgXCIpXCJcbiAgICAgIC8vICAgICAgICAgICAgKVxuXG4gICAgICBzdWNjZXNzID0gVXNlci51cGRhdGUoXG4gICAgICAgIHNlbGVjdFxuICAgICAgLCBjcmVhdGVkXG4gICAgICApXG4gICAgfVxuXG4gICAgcmV0dXJuIHN1Y2Nlc3NcbiAgfVxuXG5cbiAgZ2V0TG9nZ2VkSW5Db2RlcyhfaWQpIHtcbiAgICAvLyBHZXQgYSBsaXN0IG9mIGFsbCB0aGUgbG9nZ2VkX2luIGRfY29kZXNcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZCB9XG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgZmllbGRzOiB7IGxvZ2dlZF9pbjogMSB9IH1cbiAgICBjb25zdCB7IGxvZ2dlZF9pbiB9ID0gR3JvdXAuZmluZE9uZShzZWxlY3QsIG9wdGlvbnMpXG5cbiAgICAvLyBjb25zb2xlLmxvZyggXCJsb2dnZWRfaW46XCIsIGxvZ2dlZF9pblxuICAgIC8vICAgICAgICAgICAgLCBcIiAgIDw8PCAgIGRiLmdyb3VwLmZpbmRPbmUoXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgIC8vICAgICAgICAgICAgKyBcIixcIlxuICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShvcHRpb25zLmZpZWxkcylcbiAgICAvLyAgICAgICAgICAgICsgXCIpLnByZXR0eSgpXCJcbiAgICAvLyAgICAgICAgICAgIClcblxuICAgIHJldHVybiBsb2dnZWRfaW5cbiAgfVxuXG5cbiAgbW92ZVRlYWNoZXJEQ29kZVRvRW5kKF9pZCwgZF9jb2Rlcykge1xuICAgIC8vIEdldCB0aGUgX2lkcyBvZiB0aGUgVXNlcnMgd2l0aCB0aGUgZ2l2ZW4gZF9jb2Rlc1xuICAgIGNvbnN0IGxvZ2dlZF9pbiA9IGRfY29kZXMubWFwKCBkX2NvZGUgPT4gKHsgbG9nZ2VkX2luOiBkX2NvZGUgfSkgKVxuICAgIGNvbnN0IHVzZXJTZWxlY3QgPSB7XG4gICAgICAkb3I6IGxvZ2dlZF9pblxuICAgIH1cbiAgICBjb25zdCBvcHRpb25zID0geyBmaWVsZHM6IHsgbG9nZ2VkX2luOiAxIH0gfVxuICAgIGNvbnN0IHVzZXJzID0gVXNlci5maW5kKHVzZXJTZWxlY3QsIG9wdGlvbnMpLmZldGNoKClcblxuICAgIC8vIGNvbnNvbGUubG9nKCBcInVzZXI6XCIsIHVzZXJcbiAgICAvLyAgICAgICAgICAgICwgXCIgICA8PDwgICBkYi51c2VyLmZpbmQoXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkodXNlclNlbGVjdClcbiAgICAvLyAgICAgICAgICAgICsgXCIsXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkob3B0aW9ucy5maWVsZHMpXG4gICAgLy8gICAgICAgICAgICArIFwiKS5wcmV0dHkoKVwiXG4gICAgLy8gICAgICAgICAgICApXG5cbiAgICAvLyBSZW1vdmUgdGhlIGRfY29kZXMgb2Yga25vd24gdXNlcnMgZnJvbSBsb2dnZWRfaW5cbiAgICB1c2Vycy5mb3JFYWNoKCB1c2VyRGF0YSA9PiB7XG4gICAgICBjb25zdCB1c2VyX2NvZGVzID0gdXNlckRhdGEubG9nZ2VkX2luXG4gICAgICBjb25zdCByZW1vdmVGdW5jdGlvbiA9ICggaXRlbSA9PiB1c2VyX2NvZGVzLmluY2x1ZGVzKGl0ZW0pIClcbiAgICAgIHJlbW92ZUZyb20oZF9jb2RlcywgcmVtb3ZlRnVuY3Rpb24sIHRydWUpXG4gICAgfSlcblxuICAgIC8vIElmIHRoZXJlIGFyZSBhbnkgZF9jb2RlcyBsZWZ0LCB0aGV5IG11c3QgYmUgdGhlIHRlYWNoZXInc1xuICAgIC8vIGNvbnNvbGUubG9nKFwibG9nZ2VkX2luOlwiLCBsb2dnZWRfaW4pXG5cbiAgICBjb25zdCBncm91cFNlbGVjdCA9IHsgX2lkIH1cbiAgICBkX2NvZGVzLmZvckVhY2goIHRlYWNoZXJfY29kZSA9PiB7XG4gICAgICAvLyBSZW1vdmUgaXQgZnJvbSB0aGUgbG9nZ2VkX2luIGFycmF5Li4uXG4gICAgICBjb25zdCBwdWxsID0geyAkcHVsbDogeyBsb2dnZWRfaW46IHRlYWNoZXJfY29kZSB9IH1cbiAgICAgIGNvbnN0IHB1c2ggPSB7ICRwdXNoOiB7IGxvZ2dlZF9pbjogdGVhY2hlcl9jb2RlIH0gfVxuICAgICAgR3JvdXAudXBkYXRlKGdyb3VwU2VsZWN0LCBwdWxsKVxuXG4gICAgICAvLyAuLi4gYW5kIHRoZW4gYWRkIGl0IGJhY2sgYXQgdGhlIGVuZFxuICAgICAgR3JvdXAudXBkYXRlKGdyb3VwU2VsZWN0LCBwdXNoKVxuICAgIH0pXG5cbiAgICAvLyBBbHRlcm5hdGl2ZSBzb2x1dGlvbjpcbiAgICAvLyAqIEFkZCBhIGxvZ2dlZF9pbiBmaWVsZCB0byB0aGUgVGVhY2hlciByZWNvcmRzXG4gICAgLy8gKiBHZXQgdGhlIF9pZCBvZiB0aGUgb3duZXIgb2YgdGhpcyBHcm91cFxuICAgIC8vICogUmV0cmlldmUgdGhlIGRfY29kZXMgb2YgdGhhdCB0ZWFjaGVyXG4gICAgLy8gKiBGaW5kIHdoaWNoIG9mIHRob3NlIGRfY29kZXMgYXJlIHByZXNlbnQgaW4gdGhlIGxvZ2dlZF9pbiBsaXN0XG4gICAgLy8gKiBSZW1vdmUgYWxsIHRob3NlIGRfY29kZXMgZnJvbSB0aGUgbGlzdFxuICAgIC8vICogQWRkIHRoZW0gYmFjayBhdCB0aGUgZW5kXG4gIH1cbn0iLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9tZXRob2RzL2FkbWluL2xlYXZlLmpzXG4gKi9cblxuXG5pbXBvcnQgeyBkZXN0cm95VHJhY2tlciB9IGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3BvaW50cydcbmltcG9ydCB7IGFycmF5T3ZlcmxhcCB9IGZyb20gJy4uLy4uLy4uL3Rvb2xzL2dlbmVyaWMvdXRpbGl0aWVzJ1xuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgVXNlciwgVGVhY2hlciwgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMZWF2ZUdyb3VwIHtcbiAgY29uc3RydWN0b3IoZGV2aWNlRGF0YSkge1xuICAgIGxldCB7IGlkLCBkX2NvZGUsIGdyb3VwX2lkLCBkaXNtaXNzZWQ9ZmFsc2UgfSA9IGRldmljZURhdGFcblxuICAgIGlmICghZ3JvdXBfaWQpIHtcbiAgICAgIGdyb3VwX2lkID0gdGhpcy5nZXRHcm91cF9pZChkX2NvZGUpXG5cbiAgICAgIGlmICghZ3JvdXBfaWQpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ29tbW9uIGFjdGlvbnMgZm9yIGJvdGggVGVhY2hlcnMgYW5kIFVzZXJzXG4gICAgdGhpcy5yZW1vdmVEZXZpY2VGcm9tR3JvdXAoZ3JvdXBfaWQsIGRfY29kZSlcbiAgICAvLyBkZXN0cm95VHJhY2tlci5jYWxsKHsgX2lkOiBkX2NvZGUsIGdyb3VwX2lkIH0pXG5cbiAgICAvLyBTZXBhcmF0ZSBhY3Rpb25zXG4gICAgaWYgKGlkLmxlbmd0aCA8IDUpIHsvLyBcInh4eHhcIiA9PiA0NTY5NzYgdGVhY2hlciBpZGBzXG4gICAgICBjb25zdCB0ZWFjaGVyVmlld3MgPSB0aGlzLmdldFRlYWNoZXJWaWV3Q291bnQoaWQsIGdyb3VwX2lkKVxuICAgICAgaWYgKCF0ZWFjaGVyVmlld3MpIHtcbiAgICAgICAgdGhpcy5kZWFjdGl2YXRlR3JvdXAoZ3JvdXBfaWQpXG4gICAgICB9XG5cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy51c2VySXNMZWF2aW5nKGlkLCBncm91cF9pZCwgZGlzbWlzc2VkKVxuICAgIH1cbiAgfVxuXG5cbiAgZ2V0R3JvdXBfaWQoZF9jb2RlKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0geyBsb2dnZWRfaW46IGRfY29kZSB9XG4gICAgY29uc3Qgb3B0aW9ucyA9IHt9XG4gICAgY29uc3QgX2lkcyA9IEdyb3VwLmZpbmQoc2VsZWN0LCBvcHRpb25zKVxuICAgICAgICAgICAgICAgICAgICAgICAuZmV0Y2goKVxuICAgICAgICAgICAgICAgICAgICAgICAubWFwKGRvYyA9PiBkb2MuX2lkKVxuICAgIGlmIChfaWRzLmxlbmd0aCA+IDEpIHtcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwiTGVhdmluZyBtdWx0aXBsZSBncm91cHM/XCIsIF9pZHMpXG4gICAgfVxuXG4gICAgcmV0dXJuIF9pZHNbMF0gLy8gbWF5IGJlIHVuZGVmaW5lZFxuICB9XG5cblxuICAvLyBDb21tb24gYWN0aW9uc1xuICByZW1vdmVEZXZpY2VGcm9tR3JvdXAoZ3JvdXBfaWQsIGRfY29kZSkge1xuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkOiBncm91cF9pZCwgbG9nZ2VkX2luOiBkX2NvZGUgfVxuICAgIGNvbnN0IHB1bGwgICA9IHsgJHB1bGw6IHsgbG9nZ2VkX2luOiBkX2NvZGUgfX1cbiAgICBjb25zdCByZXN1bHQgPSBHcm91cC51cGRhdGUoc2VsZWN0LCBwdWxsKVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwicmVzdWx0OlwiLCByZXN1bHRcbiAgICAgICAgICAgICAgIC8vICwgXCIsIGdyb3VwX2lkXCIsIGdyb3VwX2lkXG4gICAgICAgICAgICAgICAvLyAsIFwiZGIuZ3JvdXAudXBkYXRlKFwiXG4gICAgICAgICAgICAgICAvLyAgICsgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgICAgICAgICAgICAgLy8gICArIFwiLCBcIlxuICAgICAgICAgICAgICAgLy8gICArIEpTT04uc3RyaW5naWZ5KHB1bGwpXG4gICAgICAgICAgICAgICAvLyAgICsgXCIpXCJcbiAgICAgICAgICAgICAgIC8vIClcbiAgfVxuXG5cbiAgZ2V0VGVhY2hlclZpZXdDb3VudChpZCwgZ3JvdXBfaWQpIHtcbiAgICAgbGV0IHNlbGVjdCAgPSB7IGlkIH1cbiAgICAgY29uc3Qgb3B0aW9ucyA9IHsgZmllbGRzOiB7IGxvZ2dlZF9pbjogMSB9IH1cbiAgICAgY29uc3QgdGVhY2hlciA9IFRlYWNoZXIuZmluZE9uZShzZWxlY3QsIG9wdGlvbnMpXG4gICAgICAgICAgICAgICAgICB8fCB7IGxvZ2dlZF9pbjogW10sIGZha2U6IHRydWUgfVxuICAgICBjb25zdCBkX2NvZGVzID0gdGVhY2hlci5sb2dnZWRfaW5cblxuICAgICAvLyBjb25zb2xlLmxvZyggXCJ0ZWFjaGVyXCIsIHRlYWNoZXJcbiAgICAgLy8gICAgICAgICAgICAsIFwidGVhY2hlcidzIGRfY29kZXM6XCIsIHRlYWNoZXIubG9nZ2VkX2luXG4gICAgIC8vICAgICAgICAgICAgLCBcImRiLnRlYWNoZXIuZmluZE9uZShcIlxuICAgICAvLyAgICAgICAgICAgICwgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgICAvLyAgICAgICAgICAgICwgXCIsIFwiXG4gICAgIC8vICAgICAgICAgICAgLCBKU09OLnN0cmluZ2lmeShvcHRpb25zKVxuICAgICAvLyAgICAgICAgICAgICwgXCIpXCJcbiAgICAgLy8gICAgICAgICAgICApXG5cbiAgICAgc2VsZWN0ID0geyBfaWQ6IGdyb3VwX2lkIH1cbiAgICAgY29uc3QgeyBsb2dnZWRfaW4gfSA9IEdyb3VwLmZpbmRPbmUoc2VsZWN0LCBvcHRpb25zKVxuXG4gICAgIC8vIGNvbnNvbGUubG9nKCBcImdyb3VwJ3MgZF9jb2RlczpcIiwgbG9nZ2VkX2luXG4gICAgIC8vICAgICAgICAgICAgLCBcImRiLmdyb3VwLmZpbmRPbmUoXCJcbiAgICAgLy8gICAgICAgICAgICAsIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAgLy8gICAgICAgICAgICAsIFwiLCBcIlxuICAgICAvLyAgICAgICAgICAgICwgSlNPTi5zdHJpbmdpZnkob3B0aW9ucylcbiAgICAgLy8gICAgICAgICAgICAsIFwiKVwiXG4gICAgIC8vICAgICAgICAgICAgKVxuXG4gICAgIGNvbnN0IHRfY29kZXMgPSBhcnJheU92ZXJsYXAobG9nZ2VkX2luLCBkX2NvZGVzKVxuXG4gICAgIHJldHVybiB0X2NvZGVzLmxlbmd0aFxuXG5cbiAgfVxuXG5cbiAgLy8gVGVhY2hlciBhY3Rpb25zXG4gIGRlYWN0aXZhdGVHcm91cChncm91cF9pZCkge1xuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkOiBncm91cF9pZCB9XG4gICAgY29uc3Qgc2V0ICAgID0geyAkc2V0OiB7IGFjdGl2ZTogZmFsc2UgfX1cbiAgICBjb25zdCByZXN1bHQgPSBHcm91cC51cGRhdGUoc2VsZWN0LCBzZXQpXG5cbiAgICAvLyBjb25zb2xlLmxvZyggXCJkZWFjdGl2YXRlR3JvdXA6XCIsIHJlc3VsdFxuICAgIC8vICAgICAgICAgICAgLCBcImRiLmdyb3VwLnVwZGF0ZShcIlxuICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShzZWxlY3QpXG4gICAgLy8gICAgICAgICAgICArIFwiLCBcIlxuICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShzZXQpXG4gICAgLy8gICAgICAgICAgICArIFwiKVwiKVxuICB9XG5cblxuICAvLyBVc2VyIGFjdGlvbnNcbiAgdXNlcklzTGVhdmluZyhfaWQsIGdyb3VwX2lkLCBkaXNtaXNzZWQpIHtcbiAgICB0aGlzLnVwZGF0ZVVzZXJIaXN0b3J5KF9pZCwgZ3JvdXBfaWQpXG5cbiAgICBpZiAoIWRpc21pc3NlZCkge1xuICAgICAgLy8gVGhlIFVzZXIgaXMgbGVhdmluZyBvZiB0aGVpciBvd24gYWNjb3JkLiBJZiB0aGlzIGlzIHRoZSBsYXN0XG4gICAgICAvLyB1c2VyIGluIHRoZSBncm91cCwgdGhlIFRlYWNoZXIgc2hvdWxkIHJldHVybiB0byB0aGUgVGVhY2hcbiAgICAgIC8vIHZpZXcuXG4gICAgICB0aGlzLmNsb3NlR3JvdXBJZkRvbmUoZ3JvdXBfaWQpXG4gICAgfVxuICB9XG5cblxuICB1cGRhdGVVc2VySGlzdG9yeShfaWQsIGdyb3VwX2lkKSB7XG4gICAgY29uc3QgcGF0aCA9IFwiaGlzdG9yeS5cIiArIGdyb3VwX2lkXG4gICAgY29uc3QgcGF0aE91dCA9IHBhdGggKyBcIi4kLm91dFwiXG4gICAgY29uc3Qgc2VsZWN0ID0ge1xuICAgICAgX2lkXG4gICAgLCBbcGF0aCtcIi5pblwiXTogeyAkZXhpc3RzOiB0cnVlIH1cbiAgICAsIFtwYXRoT3V0XTogICAgeyAkZXhpc3RzOiBmYWxzZSB9XG4gICAgfVxuICAgIGNvbnN0IHVwZGF0ZSA9IHtcbiAgICAgICRjdXJyZW50RGF0ZToge1xuICAgICAgICBbcGF0aE91dF06IHRydWVcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBVc2VyLnVwZGF0ZShzZWxlY3QsIHVwZGF0ZSlcblxuICAgIC8vIGNvbnNvbGUubG9nKCBcInVwZGF0ZVVzZXJIaXN0b3J5OlwiLCByZXN1bHRcbiAgICAvLyAgICAgICAgICAgICwgXCI8PDwgZGIudXNlci51cGRhdGUoXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgIC8vICAgICAgICAgICAgKyBcIiwgXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkodXBkYXRlKVxuICAgIC8vICAgICAgICAgICAgKyBcIilcIlxuICAgIC8vICAgICAgICAgICAgKVxuICB9XG5cblxuICBjbG9zZUdyb3VwSWZEb25lKGdyb3VwX2lkKSB7XG4gICAgY29uc3QgeyBsb2dnZWRfaW5cbiAgICAgICAgICAsIG93bmVyXG4gICAgICAgICAgLCBhY3RpdmUgLy8gc2hvdWxkIGFsd2F5cyBiZSB0cnVlXG4gICAgICAgICAgfSA9IHRoaXMuZ2V0R3JvdXBNZW1iZXJTdGF0dXMoZ3JvdXBfaWQpXG4gICAgY29uc3Qgb3duZXJEX2NvZGVzID0gdGhpcy5nZXRPd25lckRfY29kZXMob3duZXIsIGxvZ2dlZF9pbilcbiAgICBjb25zdCBkX2NvZGVDb3VudCA9IG93bmVyRF9jb2Rlcy5sZW5ndGhcblxuICAgIC8vIGNvbnNvbGUubG9nKFxuICAgIC8vICAgXCJjbG9zZUdyb3VwSWZEb25lIOKAlCBsb2dnZWRfaW46XCIsIGxvZ2dlZF9pblxuICAgIC8vICwgXCJvd25lcjpcIiwgb3duZXJcbiAgICAvLyAsIFwiYWN0aXZlOlwiLCBhY3RpdmVcbiAgICAvLyAsIFwib3duZXJEX2NvZGVzOlwiLCBvd25lckRfY29kZXNcbiAgICAvLyAsIFwiZF9jb2RlQ291bnQ6XCIsIGRfY29kZUNvdW50XG4gICAgLy8gKVxuXG4gICAgaWYgKGRfY29kZUNvdW50ICYmIGRfY29kZUNvdW50ID09PSBsb2dnZWRfaW4ubGVuZ3RoKSB7XG4gICAgICAvLyBUaGUgdGVhY2hlciBpcyB0aGUgb25seSBwZXJzb24gbGVmdFxuICAgICAgdGhpcy5kZWFjdGl2YXRlR3JvdXAoZ3JvdXBfaWQpXG5cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wcm9tb3RlU2xhdmUoZ3JvdXBfaWQsIGxvZ2dlZF9pbiwgb3duZXJEX2NvZGVzKVxuICAgIH1cbiAgfVxuXG5cbiAgZ2V0R3JvdXBNZW1iZXJTdGF0dXMoZ3JvdXBfaWQpIHtcbiAgICBjb25zdCBzZWxlY3QgID0geyBfaWQ6IGdyb3VwX2lkIH1cbiAgICBjb25zdCBvcHRpb25zID0geyBmaWVsZHM6IHtcbiAgICAgIGxvZ2dlZF9pbjogMVxuICAgICwgb3duZXI6IDFcbiAgICAsIGFjdGl2ZTogMVxuICAgIH19XG4gICAgY29uc3Qgc3RhdHVzICA9IEdyb3VwLmZpbmRPbmUoc2VsZWN0LCBvcHRpb25zKVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwic3RhdHVzOlwiLCBzdGF0dXNcbiAgICAvLyAgICAgICAgICAgICwgXCJkYi5ncm91cC5maW5kT25lKFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAvLyAgICAgICAgICAgICsgXCIsIFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KG9wdGlvbnMuZmllbGRzKVxuICAgIC8vICAgICAgICAgICAgKyBcIilcIilcblxuICAgIHJldHVybiBzdGF0dXNcbiAgfVxuXG5cbiAgZ2V0T3duZXJEX2NvZGVzKG93bmVyLCBkX2NvZGVzKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0geyBpZDogb3duZXIgfVxuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGZpZWxkczogeyBsb2dnZWRfaW46IDEgfSwgfVxuICAgIGNvbnN0IHsgbG9nZ2VkX2luIH0gPSBUZWFjaGVyLmZpbmRPbmUoc2VsZWN0LCBvcHRpb25zKVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwiZ2V0T3duZXJEX2NvZGVzIGxvZ2dlZF9pbjpcIiwgbG9nZ2VkX2luXG4gICAgLy8gICAgICAgICAgICAsIFwiZGIudGVhY2hlci5maW5kT25lKFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAvLyAgICAgICAgICAgICsgXCIsIFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KG9wdGlvbnMuZmllbGRzKVxuICAgIC8vICAgICAgICAgICAgKyBcIilcIlxuICAgIC8vICAgICAgICAgICAgKVxuXG4gICAgZF9jb2RlcyA9IGFycmF5T3ZlcmxhcChkX2NvZGVzLCBsb2dnZWRfaW4pXG5cbiAgICByZXR1cm4gZF9jb2Rlc1xuICB9XG5cblxuICAvLyBVTlRFU1RFRMKgLy8gVU5URVNURUTCoC8vIFVOVEVTVEVEwqAvLyBVTlRFU1RFRMKgLy8gVU5URVNURUTCoC8vXG5cbiAgcHJvbW90ZVNsYXZlKGdyb3VwX2lkLCBsb2dnZWRfaW4sIG93bmVyRF9jb2Rlcykge1xuICAgIC8vIE1ha2Ugc3VyZSB0aGUgdGVhY2hlciBpcyBub3QgbWFzdGVyICg9IGZpcnN0IGluIGxvZ2dlZF9pbilcbiAgICBsZXQgc2xhdmVcblxuICAgIGxvZ2dlZF9pbi5ldmVyeSgoZF9jb2RlLCBpbmRleCkgPT4ge1xuICAgICAgaWYgKG93bmVyRF9jb2Rlcy5pbmNsdWRlcyhkX2NvZGUpKSB7XG4gICAgICAgIHJldHVybiB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzbGF2ZSA9IGluZGV4ICYmIGRfY29kZSAvLyAwIGlmIHNsYXZlIGFscmVhZHkgYXQgaW5kZXggMFxuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgaWYgKHNsYXZlKSB7XG4gICAgICBjb25zdCBzZWxlY3QgPSB7IF9pZDogZ3JvdXBfaWQgfVxuICAgICAgY29uc3QgcHVsbCA9IHsgJHB1bGw6IHsgbG9nZ2VkX2luOiBzbGF2ZSB9fVxuICAgICAgY29uc3QgcHVzaCA9IHsgJHB1c2g6IHsgbG9nZ2VkX2luOiB7JGVhY2g6W3NsYXZlXSwkcG9zaXRpb246MH19fVxuICAgICAgbGV0IHJlc3VsdCA9IEdyb3VwLnVwZGF0ZShzZWxlY3QsIHB1bGwpXG5cbiAgICAgIC8vIGNvbnNvbGUubG9nKCBcInB1bGwgc2xhdmU6XCIsIHJlc3VsdFxuICAgICAgLy8gICAgICAgICAgICAsIFwiZGIuZ3JvdXAuZmluZE9uZShcIlxuICAgICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAgIC8vICAgICAgICAgICAgKyBcIiwgXCJcbiAgICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShwdWxsKVxuICAgICAgLy8gICAgICAgICAgICArIFwiKVwiKVxuXG4gICAgICByZXN1bHQgPSBHcm91cC51cGRhdGUoc2VsZWN0LCBwdXNoKVxuXG4gICAgICAvLyBjb25zb2xlLmxvZyggXCJwdXNoIHNsYXZlOlwiLCByZXN1bHRcbiAgICAgIC8vICAgICAgICAgICAgLCBcImRiLmdyb3VwLmZpbmRPbmUoXCJcbiAgICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShzZWxlY3QpXG4gICAgICAvLyAgICAgICAgICAgICsgXCIsIFwiXG4gICAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkocHVzaClcbiAgICAgIC8vICAgICAgICAgICAgKyBcIilcIilcbiAgICB9XG4gIH1cbn0iLCIvKipcbiAqIC9pbXBvcnQvYXBpL21ldGhvZHMvbG9naW4uanNcbiAqL1xuXG5cblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgVXNlciwgVGVhY2hlciwgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb2dJbiB7XG4gIGNvbnN0cnVjdG9yKGFjY291bnREYXRhKSB7XG4gICAgdGhpcy5hY2NvdW50RGF0YSA9IGFjY291bnREYXRhXG4gICAgLy8gY29uc29sZS5sb2coXCJhY2NvdW50RGF0YSBiZWZvcmUgTG9naW46XCIsIGFjY291bnREYXRhKVxuXG4gICAgY29uc3QgbmFtZUV4aXN0cyA9IHRoaXMudXNlcldpdGhUaGlzTmFtZUV4aXN0cygpXG5cbiAgICBpZiAoIW5hbWVFeGlzdHMpIHtcbiAgICAgIC8vIFRoaXMgbWlnaHQgYmU6XG4gICAgICAvLyBbIF0gQSBuZXcgdXNlclxuXG4gICAgICBhY2NvdW50RGF0YS5zdGF0dXMgPSBcIkNyZWF0ZUFjY291bnRcIlxuXG4gICAgfSBlbHNlIGlmICggYWNjb3VudERhdGEuc3RhdHVzID09PSBcIkNyZWF0ZUFjY291bnRcIlxuICAgICAgICAgICAgJiYgIWFjY291bnREYXRhLmFjY291bnRDcmVhdGVkXG4gICAgICAgICAgICAgICkge1xuICAgICAgLy8gVGhpcyBtaWdodCBiZTpcbiAgICAgIC8vIFsgXSBBIG5ldyB1c2VyIHdpdGggYSBjb21tb24gbmFtZVxuICAgICAgLy8gQW4gZWFybGllciBjYWxsIHRvIGxvZyBpbiB3YXMgcmVmZXJyZWQgYmFjayB0byB0aGUgQ2xpZW50XG4gICAgICAvLyBiZWNhdXNlIGEgdXNlciB3aXRoIHRoZSBnaXZlbiB1c2VybmFtZSBhbHJlYWR5IGV4aXN0cyBhbmQgdGhlXG4gICAgICAvLyBxX2NvZGUgd2FzIG1pc3Npbmcgb3IgZGlkIG5vdCBtYXRjaCwgYW5kIHRoZSB1c2VyIHByZXNzZWRcbiAgICAgIC8vIHRoZSBDcmVhdGUgTmV3IEFjY291bnQgYnV0dG9uXG5cbiAgICAgIHJldHVybiAvLyBUaGVyZSdzIG5vdGhpbmcgdG8gZG8gaGVyZSB5ZXQsIGJ1dCB3ZSdsbCBiZSBiYWNrXG4gICAgICAgICAgICAgLy8gd2l0aCBhY2NvdW50Q3JlYXRlZCBzZXQgdG8gdHJ1ZVxuXG4gICAgfSBlbHNlIGlmICghYWNjb3VudERhdGEucV9jb2RlKSB7XG4gICAgICAvLyBUaGlzIG1pZ2h0IGJlOlxuICAgICAgLy8gWyBdIEEgbmV3IHVzZXIgd2l0aCBhIGNvbW1vbiBuYW1lXG4gICAgICAvLyBbIF0gQSByZXR1cm5pbmcgdXNlclxuICAgICAgLy8gWyBdIC4uLiBvbiBhIG5ldyBkZXZpY2VcbiAgICAgIC8vIFsgXcKgLS0tIG9yIG9uIGEgZGV2aWNlIHdpdGggc29tZW9uZSBlbHNlJ3MgbG9jYWxTdG9yYWdlXG4gICAgICAvLyBXZSBuZWVkIHRvIGFzayBpZiB0aGUgdXNlciBoYXMgYSBQSU7CoGNvZGUgKHJldHVybmluZyB1c2VyIG9uXG4gICAgICAvLyBkZXZpY2Ugd2l0aCBubyBbcHJpb3JdIGxvY2FsU3RvcmFnZSkgb3Igbm90IChuZXcgdXNlcilcblxuICAgICAgYWNjb3VudERhdGEuc3RhdHVzID0gXCJSZXF1ZXN0UElOXCJcblxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBUaGlzIG1pZ2h0IGJlOlxuICAgICAgLy8gW3hdIEEgbmV3IHVzZXIgZm9yIHdob20gYSBxX2NvZGUgaGFzIGp1c3QgYmVlbiBjcmVhdGVkXG4gICAgICAvLyBbIF3CoEEgcmV0dXJuaW5nIHVzZXIgb24gYSBkZXZpY2Ugd2l0aCBzby4gZWxzZSdzIGxvY2FsU3RvcmFnZVxuICAgICAgLy8gWyBdwqBBIHJldHVybmluZyB1c2VyIGxvZ2dpbmcgaW4gbWFudWFsbHkuLi5cbiAgICAgIC8vIFsgXSAuLi4gcGVyaGFwcyB0byBzdGFydCB3aXRoIGEgbmV3IHRlYWNoZXJcbiAgICAgIC8vIFsgXcKgQSByZXR1cm5pbmcgdXNlciBsb2dnaW5nIGluIGF1dG9tYXRpY2FsbHlcblxuICAgICAgY29uc3QgZXhpc3RpbmdVc2VyID0gdGhpcy5sb2dJblVzZXJGcm9tTmFtZUFuZFFDb2RlKClcbiAgICAgIGlmICghZXhpc3RpbmdVc2VyKSB7XG4gICAgICAgIGFjY291bnREYXRhLnN0YXR1cyA9IFwiUmVxdWVzdFBJTlwiXG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFjY291bnREYXRhLnN0YXR1cyA9IFwibG9nZ2VkSW5cIlxuICAgICAgICBhY2NvdW50RGF0YS5sb2dnZWRJbiA9IHRydWVcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuXG4gIHVzZXJXaXRoVGhpc05hbWVFeGlzdHMoKSB7XG4gICAgY29uc3QgdXNlcm5hbWUgPSB0aGlzLmFjY291bnREYXRhLnVzZXJuYW1lXG4gICAgY29uc3QgbmFtZUV4aXN0cyA9IFVzZXIuZmluZE9uZSh7IHVzZXJuYW1lIH0sIHt9KVxuXG4gICAgcmV0dXJuICEhbmFtZUV4aXN0c1xuICB9XG5cblxuICBsb2dJblVzZXJGcm9tTmFtZUFuZFFDb2RlKCkge1xuICAgIGNvbnN0IHsgdXNlcm5hbWUsIHFfY29kZSwgZF9jb2RlIH0gPSB0aGlzLmFjY291bnREYXRhXG5cbiAgICBjb25zdCBzZWxlY3QgPSB7IHVzZXJuYW1lLCBxX2NvZGUgfVxuICAgIGNvbnN0IHB1c2ggPSB7ICRwdXNoOiB7IGxvZ2dlZF9pbjogZF9jb2RlIH0gfVxuICAgIGNvbnN0IHJlc3VsdCA9IFVzZXIudXBkYXRlKHNlbGVjdCwgcHVzaCkgLy8gMSA9IHN1Y2Nlc3M7IDAgPSBub3RcblxuICAgIGlmIChyZXN1bHQpIHtcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7IGZpZWxkczogeyBxX2NvbG9yOiAxIH0gfVxuICAgICAgY29uc3QgeyBfaWQ6IHVzZXJfaWQsIHFfY29sb3IgfSA9IFVzZXIuZmluZE9uZShzZWxlY3QsIG9wdGlvbnMpXG4gICAgICBPYmplY3QuYXNzaWduKCB0aGlzLmFjY291bnREYXRhLCB7IHVzZXJfaWQsIHFfY29sb3IgfSApXG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG59IiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZG1pbi9sb2dpblRlYWNoZXIuanNcbiAqXG4gKiBBIHRlYWNoZXIgaXMgY29ubmVjdGluZyBhdCB0aGUgYmVnaW5uaW5nIG9mIGEgc2Vzc2lvbiwgb3IgcmV0dXJuaW5nXG4gKiB0byB0aGUgVGVhY2ggdmlld1xuICovXG5cblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgVGVhY2hlciwgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb2dJblRlYWNoZXIge1xuICBjb25zdHJ1Y3RvcihhY2NvdW50RGF0YSkge1xuICAgIC8vIGNvbnNvbGUubG9nKFwiTG9nSW5UZWFjaGVyIGFjY291bnREYXRhOlwiLCBhY2NvdW50RGF0YSlcblxuICAgIGNvbnN0IHsgaWQsIGRfY29kZSB9ID0gYWNjb3VudERhdGFcbiAgICBjb25zdCBsZWZ0ID0gdGhpcy5sZWF2ZUFsbEdyb3VwcyhpZCwgZF9jb2RlKVxuICAgIGNvbnN0IGxvZ2dlZEluID0gdGhpcy5zZXRMb2dnZWRJbihpZCwgZF9jb2RlKVxuXG4gICAgYWNjb3VudERhdGEubG9nZ2VkSW4gPSBsb2dnZWRJblxuICB9XG5cblxuICBzZXRMb2dnZWRJbihpZCwgZF9jb2RlKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0geyBpZCB9XG4gICAgY29uc3QgYWRkVG9TZXQgPSB7XG4gICAgICAkYWRkVG9TZXQ6IHtcbiAgICAgICAgbG9nZ2VkX2luOiBkX2NvZGVcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gVGVhY2hlci51cGRhdGUoc2VsZWN0LCBhZGRUb1NldCkgLy8gMSA9IHN1Y2Nlc3M7IDAgPSBub3RcblxuICAgIC8vIGNvbnNvbGUubG9nKCBcInNldExvZ2dlZEluOlwiLCByZXN1bHRcbiAgICAvLyAgICAgICAgICAgICwgXCJkYi50ZWFjaGVyLnVwZGF0ZShcIlxuICAgIC8vICAgICAgICAgICAgK8KgSlNPTi5zdHJpbmdpZnkoc2VsZWN0KVxuICAgIC8vICAgICAgICAgICAgK8KgXCIsIFwiXG4gICAgLy8gICAgICAgICAgICArwqBKU09OLnN0cmluZ2lmeShhZGRUb1NldClcbiAgICAvLyAgICAgICAgICAgICvCoFwiKVwiXG4gICAgLy8gICAgICAgICAgICApXG5cbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuXG4gIGxlYXZlQWxsR3JvdXBzKGlkLCBkX2NvZGUpIHtcbiAgICBjb25zdCBzZWxlY3QgPSB7IG1lbWJlcnM6IGlkLCBsb2dnZWRfaW46IGRfY29kZSB9XG4gICAgY29uc3QgcHVsbCA9IHtcbiAgICAgICRwdWxsOiB7XG4gICAgICAgIGxvZ2dlZF9pbjogZF9jb2RlXG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IEdyb3VwLnVwZGF0ZShzZWxlY3QsIHB1bGwpIC8vIDEgPSBzdWNjZXNzOyAwID0gbm90XG5cbiAgICAvLyBjb25zb2xlLmxvZyggXCJsZWF2ZUFsbEdyb3VwczpcIiwgcmVzdWx0XG4gICAgLy8gICAgICAgICAgICAsIFwiZGIuZ3JvdXAudXBkYXRlKFwiXG4gICAgLy8gICAgICAgICAgICArwqBKU09OLnN0cmluZ2lmeShzZWxlY3QpXG4gICAgLy8gICAgICAgICAgICArwqBcIiwgXCJcbiAgICAvLyAgICAgICAgICAgICvCoEpTT04uc3RyaW5naWZ5KHB1bGwpXG4gICAgLy8gICAgICAgICAgICArwqBcIilcIlxuICAgIC8vICAgICAgICAgICAgKVxuXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG59IiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZG1pbi9sb2dvdXQuanNcbiAqL1xuXG5cblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgVXNlciwgVGVhY2hlciwgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTG9nT3V0IHtcbiAgY29uc3RydWN0b3IobG9nT3V0RGF0YSkge1xuICAgIGNvbnN0IHsgaWQsIGRfY29kZSB9ID0gbG9nT3V0RGF0YVxuXG4gICAgY29uc3QgdXBkYXRlID0ge1xuICAgICAgJHB1bGw6IHtcbiAgICAgICAgbG9nZ2VkX2luOiBkX2NvZGVcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQga2V5XG4gICAgICAsIGNvbGxlY3Rpb25cblxuICAgIGNvbnN0IGlzVGVhY2hlciA9IChpZC5sZW5ndGggPCA1KVxuXG4gICAgaWYgKGlzVGVhY2hlcikgey8vIFwieHh4eFwiID0+IDQ1Njk3NiB0ZWFjaGVyIGlkYHNcbiAgICAgIGtleSA9IFwiaWRcIlxuICAgICAgY29sbGVjdGlvbiA9IFRlYWNoZXJcblxuICAgIH0gZWxzZSB7XG4gICAgICBrZXkgPSBcIl9pZFwiXG4gICAgICBjb2xsZWN0aW9uID0gVXNlclxuICAgIH1cblxuICAgIGNvbnN0IHNlbGVjdCA9IHsgW2tleV06IGlkIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGNvbGxlY3Rpb24udXBkYXRlKHNlbGVjdCwgdXBkYXRlKVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwicmVzdWx0OlwiLCByZXN1bHRcbiAgICAvLyAgICAgICAgICAgICwgXCI8PDwgTG9nT3V0IGRldmljZSBkYi5cIlxuICAgIC8vICAgICAgICAgICAgICAgKyBjb2xsZWN0aW9uLl9uYW1lXG4gICAgLy8gICAgICAgICAgICAgICArIFwiLnVwZGF0ZShcIlxuICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShzZWxlY3QpXG4gICAgLy8gICAgICAgICAgICArIFwiLCBcIlxuICAgIC8vICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeSh1cGRhdGUpXG4gICAgLy8gICAgICAgICAgICArIFwiKVwiXG4gICAgLy8gICAgICAgICAgICApXG4gIH1cbn0iLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9tZXRob2RzL2Fzc2V0cy9pbXBvcnQuanNcbiAqXG4gKlxuICovXG5cblxuXG5pbXBvcnQgJy4uL21pbnQnXG5cbmltcG9ydCBMb2cgZnJvbSAnLi9sb2cuanMnXG5pbXBvcnQgSU9IZWxwZXIgZnJvbSAnLi9pb0hlbHBlcidcblxuaW1wb3J0IHsgcmVtb3ZlRnJvbSB9IGZyb20gJy4uLy4uLy4uL3Rvb2xzL2dlbmVyaWMvdXRpbGl0aWVzJ1xuXG5pbXBvcnQgeyBQVUJMSUNfRElSRUNUT1JZXG4gICAgICAgLCBBU1NFVFNfRk9MREVSXG4gICAgICAgLCBJTUFHRV9SRUdFWFxuICAgICAgICwgSlNPTl9SRUdFWFxuICAgICAgIH0gZnJvbSAnLi4vLi4vLi4vdG9vbHMvY3VzdG9tL2NvbnN0YW50cydcblxuaW1wb3J0IGNvbGxlY3Rpb25zICBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucy9wdWJsaXNoZXIuanMnXG5cblxuXG5jb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJylcbmNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJylcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEltcG9ydEFzc2V0cyBleHRlbmRzIElPSGVscGVye1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5sb2dnZXIgPSBuZXcgTG9nKClcbiAgICB0aGlzLmxvZyA9IHRoaXMubG9nZ2VyLmFkZEVudHJ5XG5cbiAgICBpZiAodHlwZW9mIG9wdGlvbnMgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGNvbnN0IHsgemlwRmlsZSwgcGFyZW50Rm9sZGVyIH0gPSBvcHRpb25zXG5cbiAgICAgIGlmIChwYXJlbnRGb2xkZXIpIHtcbiAgICAgICAgY29uc3QgYWN0aXZpdHkgPSB0aGlzLmdldEFjdGl2aXR5TmFtZUZyb20ocGFyZW50Rm9sZGVyKVxuICAgICAgICBpZiAoYWN0aXZpdHkpIHtcbiAgICAgICAgICB0aGlzLmluc3RhbGxBc3NldHMoemlwRmlsZSwgcGFyZW50Rm9sZGVyLCBhY3Rpdml0eSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgfSBlbHNlICB7IC8vIHRoZSBjYWxsIGNhbWUgZnJvbSBsYXVuY2guanNcbiAgICAgIHRoaXMuaW1wb3J0U3ViZm9sZGVyc09mKEFTU0VUU19GT0xERVIpXG4gICAgfVxuXG4gICAgdGhpcy5sb2dnZXIuc2F2ZSgpXG4gIH1cblxuXG4gIC8qKiBUT0RPOiBURVNUwqBXSVRIwqBDVVNUT03CoElNUE9SVFxuICAgKlxuICAgKiBAcmV0dXJuICB7c3RyaW5nfSAgVGhlIGFjdGl2aXR5IG5hbWUgZnJvbSBwYXJlbnQgZm9sZGVyIHBhdGguXG4gICAqL1xuICBnZXRBY3Rpdml0eU5hbWVGcm9tUGFyZW50Rm9sZGVyUGF0aCgpIHtcbiAgICAvLyBwdWJsaWMvYWN0aXZpdGllcy88QWN0aXZpdHlOYW1lPi9hc3NldHMvLi4uXG4gICAgY29uc3QgcmVnZXggPSAvXFwvcHVibGljXFwvQWN0aXZpdGllc1xcLyhcXHcrKS9cbiAgICBjb25zdCBtYXRjaCA9IHJlZ2V4LmV4ZWModGhpcy5wYXJlbnRGb2xkZXIpXG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICBjb25zdCBhY3Rpdml0eU5hbWUgPSBtYXRjaFsxXVxuICAgICAgaWYgKGFjdGl2aXR5TmFtZSkge1xuICAgICAgICByZXR1cm4gYWN0aXZpdHlOYW1lXG4gICAgICB9XG4gICAgfVxuICB9XG5cblxuICBpbnN0YWxsQXNzZXRzKGFjdGl2aXR5LCB6aXBGaWxlLCBwYXJlbnRGb2xkZXIpIHtcbiAgICAvLyBUT0RPOiB1bnppcCB6aXBGaWxlXG4gICAgY29uc3Qgc3ViRm9sZGVycyA9IGZzLnJlYWRkaXJTeW5jKHBhcmVudEZvbGRlcilcbiAgICB0aGlzLnRyZWF0Rm9sZGVyKGFjdGl2aXR5LCBwYXJlbnRGb2xkZXIsIHN1YkZvbGRlcnMpXG4gIH1cblxuXG4gIC8qKlxuICAgKiBDYWxsZWQgYnkgY29uc3RydWN0b3IgaWYgbm8gb3B0aW9ucyBhcmUgZ2l2ZW4sIGFuZCByZWN1cnNpdmVseVxuICAgKlxuICAgKiBAcGFyYW0gIHtzdHJpbmd9ICBmb2xkZXIgICAgICAgICAgICAgIGFic29sdXRlIHBhdGggdG9cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBU1NFVFNfRk9MREVSwqBvciBvbmUgb2YgaXRzXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1tZWRpYXRlIGNoaWxkcmVuXG4gICAqIEBwYXJhbSAge3VuZGVmaW5lZHxzdHJpbmd9ICBhY3Rpdml0eSAgdW5kZWZpbmVkIHdoZW4gZmlyc3QgY2FsbGVkXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlbiB0aGUgbmFtZSBvZiBvbmUgb2YgdGhlXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXMgaW4gZm9sZGVyXG4gICAqL1xuICBpbXBvcnRTdWJmb2xkZXJzT2YoZm9sZGVyLCBhY3Rpdml0eSkge1xuICAgIGNvbnN0IGV4cGxvcmVTdWJGb2xkZXJzID0gIWFjdGl2aXR5XG4gICAgY29uc3QgY29udGVudHMgPSBmcy5yZWFkZGlyU3luYyhmb2xkZXIpXG4gICAgLy8gY29uc29sZS5sb2coXCJpbXBvcnRTdWJmb2xkZXJzT2ZcIiwgZm9sZGVyLCBhY3Rpdml0eSlcbiAgICAvLyBjb25zb2xlLmxvZyhjb250ZW50cylcbiAgICAvLyBbICdDbG96ZScsICdOaW0nLCAnU3BpcmFsJywgJ1ZvY2FidWxhcnknIF1cblxuICAgIGNvbnRlbnRzLmZvckVhY2goIHN1YkZvbGRlciA9PiB7XG4gICAgICBjb25zdCBwYXJlbnRGb2xkZXIgPSBwYXRoLmpvaW4oZm9sZGVyLCBzdWJGb2xkZXIpXG4gICAgICBjb25zdCBzdWJGb2xkZXJzID0gZnMucmVhZGRpclN5bmMocGFyZW50Rm9sZGVyKVxuXG4gICAgICAvLyBjb25zb2xlLmxvZyhcInN1YmZvbGRlcnMgb2ZcIixwYXJlbnRGb2xkZXIsIHN1YkZvbGRlcnMpXG5cbiAgICAgIGNvbnN0IGhhc0pTT07CoD0gc3ViRm9sZGVycy5maW5kKGl0ZW0gPT4gSlNPTl9SRUdFWC50ZXN0KGl0ZW0pKVxuICAgICAgaWYgKGhhc0pTT04pIHtcbiAgICAgICAgaWYgKCFhY3Rpdml0eSkge1xuICAgICAgICAgIGFjdGl2aXR5ID0gc3ViRm9sZGVyXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy50cmVhdEZvbGRlcihhY3Rpdml0eSwgcGFyZW50Rm9sZGVyLCBzdWJGb2xkZXJzKVxuXG4gICAgICB9IGVsc2UgaWYgKGV4cGxvcmVTdWJGb2xkZXJzKSB7XG5cbiAgICAgICAgdGhpcy5pbXBvcnRTdWJmb2xkZXJzT2YocGFyZW50Rm9sZGVyLCBzdWJGb2xkZXIpXG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPWBObyBKU09OIGZvdW5kOiBpdGVtcyBpZ25vcmVkIGluICR7cGFyZW50Rm9sZGVyfWBcbiAgICAgICAgdGhpcy5sb2cobWVzc2FnZSlcbiAgICAgICAgY29uc29sZS5sb2cobWVzc2FnZSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cblxuICAvKiogSWYgbm8gZXJyb3JzLCB1cGRhdGVzIEpTT04gYW5kIE1vbmdvREIgd2hlcmUgSlNPTsKgaGFzIGNoYW5nZWRcbiAgICogIGNyYXdsaW5nIGFueSBzdWJmb2xkZXJzIGZyb20gYnJhbmNoIHRvIGxlYWYgcmVjdXJzaXZlbHkuXG4gICAqXG4gICAqIENhbGxlZCBieTpcbiAgICogKyBJbXBvcnRBc3NldHMuaW5zdGFsbEFzc2V0cyAgICAgICA8IHNwZWNpZmljIGZvbGRlclxuICAgKiArICAgICAgICAgICAgIC50cmVhdEFjdGl2aXR5Rm9sZGVyIDwgYWxsIGFjdGl2aXRpZXMsIGZyb20gcm9vdFxuICAgKlxuICAgKiDigJTigJQgVGhyZWUgdHlwZXMgb2YgaW5wdXQg4oCU4oCUXG4gICAqXG4gICAqIFN0YW5kYWxvbmVcbiAgICogPT09PT09PT09PVxuICAgKiBhY3Rpdml0eTogICAgIFwiTmltXCJcbiAgICogcGFyZW50Rm9sZGVyOiAnLi4uLi9wdWJsaWMvYWN0aXZpdGllcy9OaW0nXG4gICAqIGNvbnRlbnRzOiAgICAgWyAnYXVkaW8nLCAnaW1hZ2UnLCAnbDEwbi5qc29uJyBdXG4gICAqXG4gICAqIEJyYW5jaFxuICAgKiA9PT09PT1cbiAgICogYWN0aXZpdHk6ICAgICBcIlZvY2FidWxhcnlcIlxuICAgKiBwYXJlbnRGb2xkZXI6ICcuLi4uL3B1YmxpYy9hY3Rpdml0aWVzL1ZvY2FidWxhcnknXG4gICAqIGNvbnRlbnRzOiAgICAgWyAnaWNvbi5qcGcnLCAncmFuay5qc29uJywgJ2hvbWUnLCAnYmFzaWMnIF1cbiAgICpcbiAgICogTGVhZlxuICAgKiA9PT09XG4gICAqIGFjdGl2aXR5OiAgICAgXCJWb2NhYnVsYXJ5XCJcbiAgICogcGFyZW50Rm9sZGVyOiAnLi4uLi9wdWJsaWMvYWN0aXZpdGllcy9Wb2NhYnVsYXJ5L2Jhc2ljJ1xuICAgKiBjb250ZW50czogICAgIFsgJ2F1ZGlvJywgJ2ljb24uanBnJywgJ2ltYWdlJywgJ3JhY2suanNvbicgXVxuICAgKi9cbiAgdHJlYXRGb2xkZXIoYWN0aXZpdHksIHBhcmVudEZvbGRlciwgY29udGVudHMpIHtcbiAgICBjb25zdCB7IGpzb25QYXRoLCBqc29uIH0gPSB0aGlzLnJlYWRKU09ORmlsZShcbiAgICAgIHBhcmVudEZvbGRlclxuICAgICwgY29udGVudHNcbiAgICApXG5cbiAgICBpZiAoIWpzb24pIHtcbiAgICAgIC8vIEFuIGVycm9yIHdpbGwgYWxyZWFkeSBoYXZlIGJlZW4gbG9nZ2VkXG4gICAgICByZXR1cm4gLTFcbiAgICB9XG5cbiAgICBjb25zdCBsb2NhbFBhdGggID0gdGhpcy5nZXRMb2NhbFBhdGgocGFyZW50Rm9sZGVyKVxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uc1thY3Rpdml0eV1cbiAgICBjb25zdCBzZWxlY3QgICAgID0geyBsb2NhbFBhdGggfVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJ0cmVhdEZvbGRlclwiLCBhY3Rpdml0eSwgcGF0aClcbiAgICBjb25zdCB0b1VwZGF0ZSA9IHRoaXMuZGlyZWN0b3J5TmVlZHNVcGRhdGluZyggLy8gbm93IHJldHVybnMgdHJ1ZVxuICAgICAganNvblBhdGhcbiAgICAsIGNvbGxlY3Rpb25cbiAgICAsIHNlbGVjdFxuICAgIClcblxuICAgIGlmICghdG9VcGRhdGUpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPWAgICAgICAgIFNldCBpcyB1cC10by1kYXRlOiAke2xvY2FsUGF0aH1gXG4gICAgICB0aGlzLmxvZyhtZXNzYWdlKVxuICAgICAgcmV0dXJuIDEgLy8gSlNPTsKgaGFzbid0IGNoYW5nZWRcbiAgICB9XG5cbiAgICAvLyBDcmVhdGVzIGFuIGljb24gaWYgdGhlcmUgaXMgbm9uZSwgZXZlbiBpZiBub25lIGlzIG5lZWRlZFxuICAgIGNvbnN0IGljb24gPSB0aGlzLmdldEljb25NYXAocGFyZW50Rm9sZGVyLCBjb250ZW50cylcblxuICAgIGlmIChjb250ZW50cy5pbmNsdWRlcygnYXVkaW8nKcKgfHwgY29udGVudHMuaW5jbHVkZXMoJ2ltYWdlJykpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPWAgICAgICAgIEFkZGluZyBwaHJhc2VzIGZyb206ICR7bG9jYWxQYXRofWBcbiAgICAgIHRoaXMubG9nKG1lc3NhZ2UpXG5cbiAgICAgIHJldHVybiB0aGlzLmFkZFBocmFzZVNldChcbiAgICAgICAgcGFyZW50Rm9sZGVyXG4gICAgICAsIGNvbnRlbnRzXG4gICAgICAsIGljb25cbiAgICAgICwgbG9jYWxQYXRoXG4gICAgICAsIGpzb25QYXRoXG4gICAgICAsIGpzb25cbiAgICAgICwgY29sbGVjdGlvblxuICAgICAgKVxuXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPWAgICAgICAgIEFkZGluZyBhc3NldHMgZnJvbTogJHtsb2NhbFBhdGh9YFxuICAgICAgdGhpcy5sb2cobWVzc2FnZSlcblxuICAgICAgdGhpcy5jcmF3bFN1YkZvbGRlcnMoXG4gICAgICAgIHBhcmVudEZvbGRlclxuICAgICAgLCBjb250ZW50c1xuICAgICAgLCBpY29uXG4gICAgICAsIGxvY2FsUGF0aFxuICAgICAgLCBqc29uUGF0aFxuICAgICAgLCBqc29uXG4gICAgICAsIGNvbGxlY3Rpb25cbiAgICAgICwgYWN0aXZpdHlcbiAgICAgIClcbiAgICB9XG4gIH1cblxuXG4gIGFkZFBocmFzZVNldChcbiAgICAgIHBhcmVudEZvbGRlclxuICAgICwgY29udGVudHNcbiAgICAsIGljb25cbiAgICAsIGxvY2FsUGF0aFxuICAgICwganNvblBhdGhcbiAgICAsIGpzb25cbiAgICAsIGNvbGxlY3Rpb25cbiAgICApIHtcblxuICAgIGNvbnN0IGFzc2V0cyA9IHtcbiAgICAgIGF1ZGlvOiB7fVxuICAgICwgaW1hZ2U6IHt9XG4gICAgLCBpY29uXG4gICAgfVxuXG4gICAgLy8gQWRkIGF1ZGlvIGFuZCBpbWFnZSBhc3NldHNcbiAgICB0aGlzLmNyYXdsQXVkaW9Gb2xkZXIocGFyZW50Rm9sZGVyLCBjb250ZW50cywgYXNzZXRzLmF1ZGlvKVxuICAgIHRoaXMuY3Jhd2xJbWFnZUZvbGRlcihwYXJlbnRGb2xkZXIsIGNvbnRlbnRzLCBhc3NldHMuaW1hZ2UpXG5cbiAgICBjb25zdCBjYW5jZWxsZWQgPSB0aGlzLnRyZWF0SlNPTiggLy8gY2FuY2VsIGlmIHRhZyBwcmVzZW50K2ludmFsaWRcbiAgICAgIGxvY2FsUGF0aFxuICAgICwganNvblBhdGhcbiAgICAsIGpzb25cbiAgICAsIGNvbGxlY3Rpb25cbiAgICAsIGFzc2V0c1xuICAgIClcblxuICAgIHJldHVybiBjYW5jZWxsZWRcbiAgfVxuXG5cbiAgLyoqIFJldHVybnMgYSBzdHJpbmcgbGlrZSBcIi9BY3Rpdml0eS9mb2xkZXIvLi4uL2V4ZXJjaXNlXCJcbiAgICogIHdoaWNoIGlzIGEgdmVyc2lvbiBvZiBwYXJlbnRGb2xkZXIgZnJvbSB3aGljaCB0aGUgcGF0aFxuICAgKiAgdG8gdGhlIGAuLi4vcHVibGljL0FjdGl2aXRpZXMvYCBmb2xkZXIgaGFzIGJlZW5cbiAgICogIHRyaW1tZWQuIFRoZXJlIHNob3VsZCBiZSBubyB0cmFpbGluZyBcIi9cIlxuICAgKlxuICAgKiBAcGFyYW0gICAge3N0cmluZ30gICAgcGFyZW50Rm9sZGVyICBhYnNvbHV0ZSBwYXRoIHRvIHBhcmVudFxuICAgKiBAcmV0dXJuICAge3N0cmluZ30gICAgbGlrZSAnL0FjdGl2aXR5L2ZvbGRlci8uLi4vZXhlcmNpc2UnXG4gICAqL1xuICBnZXRMb2NhbFBhdGgocGFyZW50Rm9sZGVyKSB7XG4gICAgY29uc3QgbG9jYWxQYXRoID0gcGFyZW50Rm9sZGVyLnJlcGxhY2UoQVNTRVRTX0ZPTERFUiwgXCIvXCIpXG5cbiAgICByZXR1cm4gbG9jYWxQYXRoXG4gIH1cblxuXG4gIGNyYXdsQXVkaW9Gb2xkZXIocGFyZW50Rm9sZGVyLCBjb250ZW50cywgYXVkaW9NYXApe1xuICAgIGxldCBhdWRpbyA9IFwiYXVkaW9cIlxuICAgIGlmICghY29udGVudHMuaW5jbHVkZXMoYXVkaW8pKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBhdWRpbyA9IHBhdGguam9pbihwYXJlbnRGb2xkZXIsIGF1ZGlvKVxuICAgIGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoYXVkaW8pXG4gICAgLy8gY29uc29sZS5sb2coXCJhdWRpby8gY29udGVudHM6XCIsIGNvbnRlbnRzKVxuICAgIC8vIGF1ZGlvLyBjb250ZW50czogWyAncnUnIF1cblxuICAgIGNvbnRlbnRzLmZvckVhY2goIGZvbGRlciA9PiB7XG4gICAgICB0aGlzLmNyYXdsQXVkaW9TdWJGb2xkZXIoYXVkaW8sIGZvbGRlciwgYXVkaW9NYXApXG4gICAgfSlcbiAgfVxuXG5cbiAgY3Jhd2xBdWRpb1N1YkZvbGRlcihhdWRpb0ZvbGRlciwgbGFuZywgYXVkaW9NYXApIHtcbiAgICBjb25zdCBmb2xkZXJQYXRoID0gcGF0aC5qb2luKGF1ZGlvRm9sZGVyLCBsYW5nKVxuICAgIGNvbnN0IGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoZm9sZGVyUGF0aClcbiAgICAvLyBjb25zb2xlLmxvZyhcImF1ZGlvL1wiICsgbGFuZyArIFwiLyBjb250ZW50czpcIiwgY29udGVudHMpXG4gICAgLy8gYXVkaW8vcnUvIGNvbnRlbnRzOiBbICcwMS5tcDMnLCAnMDIubXAzJywgJzAzLm1wMycsIC4uLiBdXG5cbiAgICAvLyBBc3N1bWUgdGhhdCBhbGwgYXVkaW8gZmlsZXMgd2lsbCBiZSBpbiBNUDMgZm9ybWF0LiBBbnlcbiAgICAvLyBmaWxlIHRoYXQgZG9lcyBub3QgaGF2ZSB0aGUgTVAzIGZvcm1hdCBtYXkgYmUgYSBmb2xkZXJcbiAgICAvLyB3aXRoIGFkZGl0aW9uYWwgYXVkaW8gYXNzZXRzIGZvciBhIGdpdmVuIHBocmFzZS5cbiAgICAvL1xuICAgIC8vIFRPRE86IERlYWwgd2l0aCBhZGRpdGlvbmFsIGF1ZGlvIGFzc2V0c1xuICAgIC8vIFRPRE86IEFkZCBjcmVkaXRzIGFuZCB0cmFuc2NyaXB0aW9uIGRhdGEgZnJvbSBqc29uIGZpbGVcblxuICAgIGNvbnRlbnRzLmZvckVhY2goZmlsZSA9PiB7XG4gICAgICBjb25zdCBleHRlbnNpb24gPSBwYXRoLmV4dG5hbWUoZmlsZSlcblxuICAgICAgaWYgKGV4dGVuc2lvbi50b0xvd2VyQ2FzZSgpID09PSBcIi5tcDNcIinCoHtcbiAgICAgICAgbGV0IHNyYyA9IHBhdGguam9pbihmb2xkZXJQYXRoLCBmaWxlKVxuICAgICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKHNyYylcbiAgICAgICAgY29uc3Qgc2l6ZSA9IHN0YXRzLnNpemVcbiAgICAgICAgc3JjID0gc3JjLnJlcGxhY2UoUFVCTElDX0RJUkVDVE9SWSwgXCJcIilcblxuICAgICAgICBsZXQgZmlsZU5hbWUgPSBwYXRoLmJhc2VuYW1lKGZpbGUsIGV4dGVuc2lvbilcbiAgICAgICAgaWYgKCFpc05hTihmaWxlTmFtZSkpIHtcbiAgICAgICAgICAvLyBSZW1vdmUgYW55IGxlYWRpbmcgemVyb3NcbiAgICAgICAgICBmaWxlTmFtZSA9IFwiXCIgKyBwYXJzZUZsb2F0KGZpbGVOYW1lKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcGhyYXNlQXVkaW8gPSBhdWRpb01hcFtmaWxlTmFtZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICB8fCAoIGF1ZGlvTWFwW2ZpbGVOYW1lXSA9IHt9IClcbiAgICAgICAgY29uc3QgbG9jYWxpemVkICAgPSBwaHJhc2VBdWRpb1tsYW5nXVxuICAgICAgICAgICAgICAgICAgICAgICAgIHx8ICggcGhyYXNlQXVkaW9bbGFuZ10gPSBbXSApXG5cbiAgICAgICAgbG9jYWxpemVkLnB1c2goe1xuICAgICAgICAgIHNyY1xuICAgICAgICAsIHNpemVcbiAgICAgICAgfSlcblxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVE9ETzogRGVhbCB3aXRoIGFkZGl0aW9uYWwgYXVkaW8gYXNzZXRzXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG5cbiAgY3Jhd2xJbWFnZUZvbGRlcihwYXJlbnRGb2xkZXIsIGNvbnRlbnRzLCBpbWFnZU1hcCkge1xuICAgIGxldCBpbWFnZSA9IFwiaW1hZ2VcIlxuICAgIGlmICghY29udGVudHMuaW5jbHVkZXMoaW1hZ2UpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBmb2xkZXJQYXRoID0gcGF0aC5qb2luKHBhcmVudEZvbGRlciwgaW1hZ2UpXG4gICAgY29udGVudHMgPSBmcy5yZWFkZGlyU3luYyhmb2xkZXJQYXRoKVxuICAgIC8vIGNvbnNvbGUubG9nKFwiaW1hZ2UvIGNvbnRlbnRzOlwiLCBjb250ZW50cylcbiAgICAvLyBpbWFnZS8gY29udGVudHM6IFsgMDMuZ2lmJywnMDQucG5nJywnMS5qcGcnLCcyMC5wbmcnIC4uLl1cblxuICAgIGNvbnRlbnRzLmZvckVhY2goZmlsZSA9PiB7XG4gICAgICBpZiAoSU1BR0VfUkVHRVgudGVzdChmaWxlKSnCoHtcbiAgICAgICAgbGV0IHNyYyA9IHBhdGguam9pbihmb2xkZXJQYXRoLCBmaWxlKVxuICAgICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKHNyYylcbiAgICAgICAgY29uc3Qgc2l6ZSA9IHN0YXRzLnNpemVcbiAgICAgICAgc3JjID0gc3JjLnJlcGxhY2UoUFVCTElDX0RJUkVDVE9SWSwgXCJcIilcblxuICAgICAgICBjb25zdCBleHRlbnNpb24gPSBwYXRoLmV4dG5hbWUoZmlsZSlcbiAgICAgICAgbGV0IGZpbGVOYW1lID0gcGF0aC5iYXNlbmFtZShmaWxlLCBleHRlbnNpb24pXG5cbiAgICAgICAgaWYgKCFpc05hTihmaWxlTmFtZSkpIHtcbiAgICAgICAgICAvLyBSZW1vdmUgYW55IGxlYWRpbmcgemVyb3NcbiAgICAgICAgICBmaWxlTmFtZSA9IFwiXCIgKyBwYXJzZUZsb2F0KGZpbGVOYW1lKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcGhyYXNlSW1hZ2VzID0gaW1hZ2VNYXBbZmlsZU5hbWVdXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHx8ICggaW1hZ2VNYXBbZmlsZU5hbWVdID0gW10gKVxuXG4gICAgICAgIHBocmFzZUltYWdlcy5wdXNoKHtcbiAgICAgICAgICBzcmNcbiAgICAgICAgLCBzaXplXG4gICAgICAgIH0pXG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFRPRE86IERlYWwgd2l0aCBhZGRpdGlvbmFsIGltYWdlIGFzc2V0c1xuICAgICAgfVxuICAgIH0pXG4gIH1cblxuXG4gIC8qKiBDaGVjayBmb3IgdmFsaWQgdGFnOyB1cGRhdGUgTW9uZ29EQsKgc2V0ICgrIHBocmFzZXMpOyBzYXZlIEpTT05cbiAgICpcbiAgICogQ2FsbGVkIGJ5IHRyZWF0Rm9sZGVyKCkgaWYgSlNPTsKgZmlsZSB3YXMgdXBkYXRlZFxuICAgKlxuICAgKiBAcGFyYW0gICAge3N0cmluZ30gIGxvY2FsUGF0aCAgIFwiL0FjdGl2aXR5L2ZvbGRlci8uLi4vZXhlcmNpc2VcIlxuICAgKiBAcGFyYW0gICAge3N0cmluZ30gIGpzb25QYXRoICAgIGFic29sdXRlIHBhdGggdG8gSlNPTiBmaWxlXG4gICAqIEBwYXJhbSAgICB7b2JqZWN0fSAganNvbiAgICAgICAgb2JqZWN0IHJlYWQgZnJvbSBKU09OwqBmaWxlXG4gICAqIEBwYXJhbSAgICB7b2JqZWN0fSAgYXNzZXRzICAgICAgeyBhdWRpbzoge31cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIGltYWdlOiB7fVxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWywgaWNvbjogIDxzdHJpbmc+XVxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICogQHBhcmFtICAgIHtvYmplY3R9ICBjb2xsZWN0aW9uICBNb25nb0RCIGNvbGxlY3Rpb25cbiAgICpcbiAgICogQHJldHVybiAgIHtudW1iZXJ9ICAtMTogdGFnIHZhbHVlIGluIGpzb24gb3IganNvbi5zZXQgaW52YWxpZFxuICAgKiAgICAgICAgICAgICAgICAgICAgICAwOiBzZXQgZG9jdW1lbnQgKGFuZCBwaHJhc2UgZG9jdW1lbnRzKVxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICBzdWNjZXNzZnVsbHkgdXBkYXRlZCwgSlNPTiBzYXZlZFxuICAgKi9cbiAgdHJlYXRKU09OKGxvY2FsUGF0aCwganNvblBhdGgsIGpzb24sIGNvbGxlY3Rpb24sIGFzc2V0cywgYWN0aXZpdHkpIHtcbiAgICBjb25zdCBzZXQgPSBqc29uLnNldCB8fCBqc29uXG4gICAgbGV0IHsgdGFnLCBpZ25vcmVfbWlzc2luZ19maWxlcyB9ID0gc2V0XG4gICAgbGV0IGFkZFBocmFzZXMgPSBmYWxzZVxuICAgIGxldCBwaHJhc2VzXG5cbiAgICBpZiAodGFnKSB7IC8vIHNob3VsZCBiZSBzdHJpbmcsIHN0cmluZ1tdIG9yIHNlbGVjdCBvYmplY3RcbiAgICAgIGlmICh0eXBlb2YgdGFnID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHRhZyA9IFsgdGFnIF1cbiAgICAgICAgYWRkUGhyYXNlcyA9IHRydWVcblxuICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHRhZykpIHtcbiAgICAgICAgdGFnID0gdGFnLmZpbHRlciggaXRlbSA9PiB0eXBlb2YgaXRlbSA9PT0gXCJzdHJpbmdcIiApXG4gICAgICAgIGFkZFBocmFzZXMgPSB0YWcubGVuZ3RoXG5cbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHRhZyA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICAvLyBUT0RPOiBDaGVjayB0aGF0IHRoaXMgaXMgYSB2YWxpZCBzZWxlY3RvciBvYmplY3RcbiAgICAgICAgLy8gQWxsb3cgdGhlIHNldCB0byBiZSBhZGRlZCwgYnV0IGRvbid0IGFkZCBhbnkgcGhyYXNlc1xuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyB0YWcgZXhpc3RzIGJ1dCBpcyBpbnZhbGlkXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBgRVJST1IgaW4gYWN0aXZpdHkgJHthY3Rpdml0eX1cbiAgICAgICAgSW52YWxpZCB0YWcgZm91bmQgaW4gZmlsZSBhdFxuICAgICAgICAke2pzb25QYXRofVxuICAgICAgICBObyBzZXQgdHJlYXRlZCwgbm8gcGhyYXNlcyB1cGRhdGVkLlxuICAgICAgICBgXG4gICAgICAgIHRoaXMubG9nKG1lc3NhZ2UpXG4gICAgICAgIHJldHVybiAtMVxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHNlbGVjdCA9IHsgcGF0aDogbG9jYWxQYXRoIH1cbiAgICBjb25zdCB0b1VwZGF0ZSA9IHRoaXMuZGlyZWN0b3J5TmVlZHNVcGRhdGluZyhcbiAgICAgIGpzb25QYXRoXG4gICAgLCBjb2xsZWN0aW9uXG4gICAgLCBzZWxlY3RcbiAgICApXG4gICAgdGhpcy5nZXRTZXQoc2V0LCBsb2NhbFBhdGgsIGFzc2V0cy5pY29uLCBjb2xsZWN0aW9uLCB0b1VwZGF0ZSlcbiAgICAvLyBDcmVhdGVzIGEgcmVjb3JkIGluIGNvbGxlY3Rpb24gYW5kIHJldHJpZXZlcyBpdHMgX2lkIGlmXG4gICAgLy8gbm8gcmVjb3JkIGV4aXN0cyB5ZXQ6IHNldC5faWQgd2lsbCBub3cgZXhpc3RcblxuICAgIGlmIChhZGRQaHJhc2VzICYmIChwaHJhc2VzID0ganNvbi5waHJhc2VzKSkge1xuICAgICAgLy8gVXBkYXRlIGpzb24gd2l0aCBkZXRhaWxzIG9mIGF2YWlsYWJsZSBhc3NldHNcbiAgICAgIHRoaXMuYWRkQXNzZXRzVG9QaHJhc2VzKFxuICAgICAgICBwaHJhc2VzXG4gICAgICAsIGFzc2V0c1xuICAgICAgLCB0YWdcbiAgICAgICwgaWdub3JlX21pc3NpbmdfZmlsZXNcbiAgICAgIClcblxuICAgICAgLy8gSW5zZXJ0IG9yIHVwZGF0ZSBwaHJhc2UgZG9jdW1lbnRzIGluIE1vbmdvREJcbiAgICAgIHRoaXMudHJlYXRQaHJhc2VzKHBocmFzZXMsIGNvbGxlY3Rpb24pXG4gICAgICAvLyBFYWNoIHBocmFzZSB3aWxsIG5vdyBoYXZlIGl0cyBvd24gX2lkXG4gICAgfVxuXG4gICAgY29uc3QgbW9kID0gdGhpcy53cml0ZUpTT04oanNvblBhdGgsIGpzb24pXG5cbiAgICBjb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogc2V0Ll9pZCB9LCB7ICRzZXQ6IHsgbW9kIH19KVxuXG4gICAgcmV0dXJuIDAgLy8gbm90IGNhbmNlbGxlZFxuICB9XG5cblxuICBnZXRTZXQoc2V0LCBsb2NhbFBhdGgsIGljb24sIGNvbGxlY3Rpb24sIF9pZCkge1xuICAgIGlmIChfaWQgPT09IHRydWUpIHtcbiAgICAgIF9pZCA9IHNldC5faWRcbiAgICB9XG5cbiAgICBpZiAoaWNvbikge1xuICAgICAgc2V0Lmljb24gPSBpY29uXG4gICAgfVxuXG4gICAgc2V0LnBhdGggPSBsb2NhbFBhdGhcbiAgICBjb25zdCBwYXJlbnQgPSBsb2NhbFBhdGguc3BsaXQoXCIvXCIpXG4gICAgcGFyZW50LnBvcCgpXG4gICAgc2V0LnBhcmVudCA9IHBhcmVudC5qb2luKFwiL1wiKVxuXG4gICAgaWYgKF9pZCkge1xuICAgICAgY29sbGVjdGlvbi51cGRhdGUoeyBfaWQgfSwgc2V0LCB7IHVwc2VydDogdHJ1ZSB9KVxuXG4gICAgfSBlbHNlIHtcbiAgICAgIF9pZCA9IGNvbGxlY3Rpb24uaW5zZXJ0KHNldClcbiAgICAgIHNldC5faWQgPSBfaWRcbiAgICB9XG4gIH1cblxuXG4gIGFkZEFzc2V0c1RvUGhyYXNlcyhwaHJhc2VzLGFzc2V0cyx0YWdBcnJheSxpZ25vcmVfbWlzc2luZ19maWxlcykge1xuICAgIGNvbnN0IGF1ZGlvID0gYXNzZXRzLmF1ZGlvXG4gICAgY29uc3QgaW1hZ2UgPSBhc3NldHMuaW1hZ2VcblxuICAgIHBocmFzZXMuZm9yRWFjaCggcGhyYXNlRGF0YSA9PiB7XG4gICAgICBsZXQgbmFtZSA9IHBocmFzZURhdGEubmFtZVxuICAgICAgbGV0IHBocmFzZSA9IHBocmFzZURhdGEucGhyYXNlXG5cbiAgICAgIC8vIFNvbWUgYWN0aXZpdGllcyBoYXZlIG5vIFwicGhyYXNlXCIgZW50cnkgKGUuZy4gU3BpcmFsKVxuICAgICAgLy8gQXMgYSByZXN1bHQsIHRoZXkgZG9uJ3QgaGF2ZSBhbnkgYXVkaW8gZWl0aGVyXG4gICAgICBjb25zdCBoYXNQaHJhc2VzID0gKHR5cGVvZiBwaHJhc2UgPT09IFwib2JqZWN0XCIpXG4gICAgICBjb25zdCBsYW5ndWFnZXMgPSBoYXNQaHJhc2VzXG4gICAgICAgICAgICAgICAgICAgICAgPyBPYmplY3Qua2V5cyhwaHJhc2UpXG4gICAgICAgICAgICAgICAgICAgICAgOiBbIFwiaWdub3JlX3BocmFzZVwiIF1cbiAgICAgIGNvbnN0IGxhbmcgPSBsYW5ndWFnZXNbMF1cblxuICAgICAgaWYgKCFpc05hTihuYW1lKSkge1xuICAgICAgICBuYW1lID0gXCJcIiArIHBhcnNlRmxvYXQobmFtZSlcbiAgICAgIH1cblxuICAgICAgbGV0IGZpbGVzXG4gICAgICBpZiAoaGFzUGhyYXNlcykge1xuICAgICAgICBmaWxlcyA9IGF1ZGlvW25hbWVdXG4gICAgICAgIGlmIChmaWxlcykge1xuICAgICAgICAgIHBocmFzZURhdGEuYXVkaW8gPSBmaWxlc1xuXG4gICAgICAgICAgaWYgKCFpZ25vcmVfbWlzc2luZ19maWxlcykge1xuICAgICAgICAgICAgY29uc3QgbWlzc2luZ0xhbmd1YWdlcyA9IHRoaXMuZ2V0TWlzc2luZyhsYW5ndWFnZXMsIGZpbGVzKVxuICAgICAgICAgICAgaWYgKG1pc3NpbmdMYW5ndWFnZXMpIHtcbiAgICAgICAgICAgICAgdGhpcy5sb2coXCJNaXNzaW5nICAgICAgIExBTkcgIGZvciBwaHJhc2UgXCJcbiAgICAgICAgICAgICAgICAgICAgICArIHBocmFzZURhdGEubmFtZVxuICAgICAgICAgICAgICAgICAgICAgICsgXCI6IFwiICsgSlNPTi5zdHJpbmdpZnkobWlzc2luZ0xhbmd1YWdlcylcbiAgICAgICAgICAgICAgICAgICAgICArIFwiIFxcXCJcIiArIHBocmFzZVtsYW5nXSArIFwiXFxcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICB9IGVsc2UgaWYgKCFpZ25vcmVfbWlzc2luZ19maWxlcykge1xuICAgICAgICAgIHRoaXMubG9nKFwiTWlzc2luZyAgICAgICBhdWRpbyBmb3IgcGhyYXNlIFwiXG4gICAgICAgICAgICAgICAgICArIHBocmFzZURhdGEubmFtZVxuICAgICAgICAgICAgICAgICAgKyBcIjogICAgICAgIFxcXCJcIiArIHBocmFzZVtsYW5nXSArIFwiXFxcIlwiXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFByb3ZpZGUgYSBwbGFjZWhvbGRlciBwaHJhc2Ugd2l0aCBhIGBsYW5nYCBlbnRyeSwgaW4gY2FzZVxuICAgICAgICAvLyB0aGUgaW1hZ2UgaXMgbWlzc2luZ1xuICAgICAgICBwaHJhc2UgPSB7IFwiaWdub3JlX3BocmFzZVwiOiBcIlwiIH1cbiAgICAgIH1cblxuICAgICAgZmlsZXMgPSBpbWFnZVtuYW1lXVxuICAgICAgaWYgKGZpbGVzKSB7XG4gICAgICAgIHBocmFzZURhdGEuaW1hZ2UgPSBmaWxlc1xuICAgICAgfSBlbHNlIGlmICghaWdub3JlX21pc3NpbmdfZmlsZXMpIHtcbiAgICAgICAgdGhpcy5sb2coIFwiTWlzc2luZyBpbWFnZSAgICAgICBmb3IgcGhyYXNlIFwiXG4gICAgICAgICAgICAgICAgKyBwaHJhc2VEYXRhLm5hbWVcbiAgICAgICAgICAgICAgICArIFwiOiAgICAgICAgXFxcIlwiICsgcGhyYXNlW2xhbmddICsgXCJcXFwiXCJcbiAgICAgICAgICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHBocmFzZURhdGEudGFncyA9IFsgLi4uKHBocmFzZURhdGEudGFncyB8fCBbXSksIC4uLnRhZ0FycmF5IF1cbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKCB0YWcsIGluZGV4LCBhcnJheSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhcnJheS5pbmRleE9mKHRhZykgPT09IGluZGV4XG4gICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgIH0pXG4gIH1cblxuXG4gIGdldE1pc3NpbmcobGFuZ3VhZ2VzLCBmaWxlcykge1xuICAgIGNvbnN0IGF2YWlsYWJsZSA9IE9iamVjdC5rZXlzKGZpbGVzKVxuICAgIGNvbnN0IG1pc3NpbmcgPSBsYW5ndWFnZXMuZmlsdGVyKCBsYW5nID0+IChcbiAgICAgICFhdmFpbGFibGUuaW5jbHVkZXMobGFuZylcbiAgICApKVxuXG4gICAgaWYgKCFtaXNzaW5nLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIDBcbiAgICB9XG5cbiAgICByZXR1cm4gbWlzc2luZ1xuICB9XG5cblxuICB0cmVhdFBocmFzZXMocGhyYXNlcywgY29sbGVjdGlvbikge1xuICAgIHBocmFzZXMuZm9yRWFjaCggcGhyYXNlRGF0YSA9PiB7XG4gICAgICBsZXQgeyBfaWQgfSA9IHBocmFzZURhdGFcblxuICAgICAgaWYgKF9pZCkge1xuICAgICAgICBjb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZCB9LCBwaHJhc2VEYXRhLCB7IHVwc2VydDogdHJ1ZSB9IClcblxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgX2lkID0gY29sbGVjdGlvbi5pbnNlcnQoIHBocmFzZURhdGEgKVxuICAgICAgICBwaHJhc2VEYXRhLl9pZCA9IF9pZFxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuXG4gIGNyYXdsU3ViRm9sZGVycyhcbiAgICAgICAgcGFyZW50Rm9sZGVyXG4gICAgICAsIHN1YkZvbGRlcnNcbiAgICAgICwgaWNvblxuICAgICAgLCBsb2NhbFBhdGhcbiAgICAgICwganNvblBhdGhcbiAgICAgICwganNvblxuICAgICAgLCBjb2xsZWN0aW9uXG4gICAgICAsIGFjdGl2aXR5XG4gICAgICApIHtcblxuICAgIC8vIGNvbnNvbGUubG9nKFwiY3Jhd2xTdWJGb2xkZXJzOlwiLHBhcmVudEZvbGRlcilcbiAgICAvLyBjb25zb2xlLmxvZyhzdWJGb2xkZXJzKVxuXG4gICAgLy8gVHJlYXQgcmFuay5qc29uIGZpbGVzXG4gICAgY29uc3QganNvbkZpbGVzID0gc3ViRm9sZGVycy5maWx0ZXIoaXRlbSA9PiBKU09OX1JFR0VYLnRlc3QoaXRlbSkpXG4gICAgcmVtb3ZlRnJvbShzdWJGb2xkZXJzLCBpdGVtID0+IGpzb25GaWxlcy5pbmNsdWRlcyhpdGVtKSwgdHJ1ZSlcblxuICAgIHRoaXMudHJlYXRKU09OKGxvY2FsUGF0aCwganNvblBhdGgsIGpzb24sIGNvbGxlY3Rpb24sIHsgaWNvbiB9LCBhY3Rpdml0eSlcblxuICAgIHN1YkZvbGRlcnMuZm9yRWFjaChmb2xkZXIgPT4ge1xuICAgICAgZm9sZGVyID0gcGF0aC5qb2luKHBhcmVudEZvbGRlciwgZm9sZGVyKVxuXG4gICAgICAvLyB0cnkge1xuICAgICAgICBjb25zdCBjb250ZW50cyA9IGZzLnJlYWRkaXJTeW5jKGZvbGRlcilcbiAgICAgICAgdGhpcy50cmVhdEZvbGRlcihhY3Rpdml0eSwgZm9sZGVyLCBjb250ZW50cylcblxuICAgICAgLy8gfSBjYXRjaChlcnJvcinCoHtcbiAgICAgIC8vICAgY29uc3QgbWVzc2FnZSA9IGA8PDw8PDwqPj4+Pj4+XG4gICAgICAvLyAgIEVSUk9SwqB0cnlpbmcgdG8gaW1wb3J0IGFzc2V0IGZvbGRlciBmb3IgJHthY3Rpdml0eX1cbiAgICAgIC8vICAgJHtlcnJvcn1cbiAgICAgIC8vICAgYFxuICAgICAgLy8gICB0aGlzLmxvZyhtZXNzYWdlKVxuICAgICAgLy8gfVxuICAgIH0pXG4gIH1cbn0iLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9tZXRob2RzL2Fzc2V0cy9pb0hlbHBlci5qc1xuICovXG5cblxuaW1wb3J0IHsgZ2V0Q29sb3IgICAgLy8gZm9yIGNyZWF0aW5nIHBsYWNlaG9sZGVyIGljb25zXG4gICAgICAgLCByZW1vdmVGcm9tXG4gICAgICAgfSBmcm9tICcuLi8uLi8uLi90b29scy9nZW5lcmljL3V0aWxpdGllcydcbmltcG9ydCB7IFBVQkxJQ19ESVJFQ1RPUllcbiAgICAgICAsIEVOX1JFR0VYXG4gICAgICAgLCBKU09OX1JFR0VYXG4gICAgICAgLCBJQ09OX1JFR0VYXG4gICAgICAgfSBmcm9tICcuLi8uLi8uLi90b29scy9jdXN0b20vY29uc3RhbnRzJ1xuXG5cblxuY29uc3QgZnMgPSByZXF1aXJlKCdmcycpXG5jb25zdCBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG5cblxuXG4vLyBVc2VkIHRvIGdlbmVyYXRlIGljb24uc3ZnIGZpbGVzIGluIGRpZmZlcmVudCBjb2xvdXJzXG5sZXQgbnVtYmVyID0gMFxuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSU9IZWxwZXIge1xuICBjb25zdHJ1Y3Rvcihsb2cpIHtcbiAgICB0aGlzLmxvZyA9IGxvZ1xuICB9XG5cblxuICAvKiogQ29tcGFyZXMgbW9kIGRhdGUgb2YgSlNPTsKgZmlsZSB3aXRoIHRoZSBNb25nb0RCIGRvY3VtZW50XG4gICAqICBhc3NvY2lhdGVkIHdpdGggdGhpcyBmaWxlLiBSZXR1cm5zIEJvb2xlYW4gb3Igc3RyaW5nIF9pZC5cbiAgICpcbiAgICogIENhbGxlZCBieSBBY3Rpdml0eUluc3RhbGxlci51cGRhdGVBY3Rpdml0eVJlY29yZElmTmVlZGVkKClcbiAgICogICAgICAgICAgICBJbXBvcnRBc3NldEZvbGRlci50cmVhdEZvbGRlcigpXG4gICAqXG4gICAqIEBwYXJhbSAgIHtzdHJpbmd9ICAganNvblBhdGggICAgYXBzb2x1dGUgcGF0aCB0byBKU09OIGZpbGVcbiAgICogQHBhcmFtICAge29iamVjdH0gICBjb2xsZWN0aW9uICBNb25nb0RCIGNvbGxlY3Rpb25cbiAgICogQHBhcmFtICAge29iamVjdH0gICBzZWxlY3QgICAgICB7IF9pZDogPD4gfVxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiA8YWN0aXZpdHkgbmFtZT4gfVxuICAgKlxuICAgKiBAcmV0dXJuICB7Ym9vbGVhbn0gID4gZmFsc2UgICAgICBNb25nb0RCIG1vZCBpcyBpZGVudGljYWxcbiAgICogICAgICAgICAgICAgICAgICAgICA+IHRydWUgICAgICAgbm8gTW9uZ29EQiBkb2N1bWVudCBleGlzdHNcbiAgICogICAgICAgICAgICAgICAgICAgICA+IHN0cmluZyBfaWQgb2Ygb3V0LW9mLWRhdGUgTW9uZ29EQiBkb2N1bWVudFxuICAgKi9cbiAgZGlyZWN0b3J5TmVlZHNVcGRhdGluZyhqc29uUGF0aCwgY29sbGVjdGlvbiwgc2VsZWN0KSB7XG4gICAgLy8gcmV0dXJuIHRydWVcblxuICAgIGNvbnN0IHN0YXRzICAgPSBmcy5zdGF0U3luYyhqc29uUGF0aClcbiAgICBjb25zdCBtb2QgICAgID0gc3RhdHMubXRpbWVNc1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGZpZWxkczogeyBtb2Q6IDEgfX1cbiAgICBjb25zdCBkb2MgICAgID0gY29sbGVjdGlvbi5maW5kT25lKHNlbGVjdCwgb3B0aW9ucylcblxuICAgIC8vIGNvbnNvbGUubG9nKFwiZGlyZWN0b3J5TmVlZHNVcGRhdGluZ1wiLCBqc29uUGF0aCwgZG9jKVxuXG4gICAgcmV0dXJuIHRydWVcblxuICAgIGlmIChkb2MpwqB7XG4gICAgICBpZiAoZG9jLm1vZCA9PT0gbW9kKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZG9jLl9pZFxuICAgIH1cblxuICAgIHJldHVybiB0cnVlXG4gIH1cblxuXG4gIC8qKlxuICAgKlxuICAgKiBDYWxsZWQgYnkgQWN0aXZpdHlJbnN0YWxsZXIuZG9BY3Rpdml0eVVwZGF0ZSgpXG4gICAqICAgICAgICAgICBJbXBvcnRBc3NldEZvbGRlci50cmVhdEZvbGRlcigpXG4gICAqXG4gICAqIEBwYXJhbSAge3N0cmluZ30gICBwYXJlbnRGb2xkZXIgIGFic29sdXRlIHBhdGggdG8gcGFyZW50IGZvbGRlclxuICAgKiBAcGFyYW0gIHtzdHJpbmdbXX0gY29udGVudHMgICAgICBuYW1lcyBvZiBpdGVtcyBpbiBmb2xkZXJcbiAgICpcbiAgICogQHJldHVybiB7T2JqZWN0fSAgIHsganNvblBhdGg6IDxhYnNvbHV0ZSBwYXRoIHRvIGpzb24gZmlsZT5cbiAgICogICAgICAgICAgICAgICAgICAgICwganNvbjogICAgIHsgLi4uIH1cbiAgICogICAgICAgICAgICAgICAgICAgIH1cbiAgICovXG4gIHJlYWRKU09ORmlsZShwYXJlbnRGb2xkZXIsIGNvbnRlbnRzKSB7XG4gICAgY29uc3QganNvbkZpbGVzID0gY29udGVudHMuZmlsdGVyKFxuICAgICAgZmlsZSA9PiBKU09OX1JFR0VYLnRlc3QoZmlsZSlcbiAgICApXG5cbiAgICAvLyBjb25zb2xlLmxvZyhcbiAgICAvLyAgIFwicmVhZEpTT05GaWxlXCJcbiAgICAvLyAsIHBhcmVudEZvbGRlclxuICAgIC8vICwgY29udGVudHNcbiAgICAvLyAsIEpTT05fUkVHRVhcbiAgICAvLyAsIGpzb25GaWxlc1xuICAgIC8vIClcblxuICAgIGlmIChqc29uRmlsZXMubGVuZ3RoICE9PSAxKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgIGBFUlJPUiBpbiBJbXBvcnRBc3NldEZvbGRlciAke3RoaXMuYWN0aXZpdHl9XG4gICAgICBUaGVyZSBzaG91bGQgYmUgb25lIGFuZCBvbmx5IG9uZSBKU09OIGZpbGU6XG4gICAgICAgICR7SlNPTi5zdHJpbmdpZnkoanNvbkZpbGVzKX1cbiAgICAgIEFib3J0aW5nLmBcbiAgICAgIHRoaXMubG9nKG1lc3NhZ2UpXG4gICAgICAvLyBjb25zb2xlLmxvZyhtZXNzYWdlKVxuICAgICAgcmV0dXJuIHt9XG4gICAgfVxuXG4gICAgLy8gSEFDSzogUmVtb3ZlIEpTT07CoGZpbGUgZnJvbSBjb250ZW50cywgYXMgd2UgZG9uJ3Qgd2FudCBpdFxuICAgIC8vIGFyb3VuZCB3aGVuIHdlIHN0YXJ0IGltcG9ydGluZyBhc3NldHMuXG4gICAgcmVtb3ZlRnJvbShjb250ZW50cywgaXRlbSA9PiBqc29uRmlsZXMuaW5jbHVkZXMoaXRlbSksIHRydWUpXG4gICAgLy8gY29uc29sZS5sb2coXCJjb250ZW50cyBhZnRlciBqc29uIHJlbW92ZWQ6XCIsIGNvbnRlbnRzKVxuXG4gICAgY29uc3QganNvblBhdGggPSBwYXRoLmpvaW4ocGFyZW50Rm9sZGVyLCBqc29uRmlsZXNbMF0pXG5cbiAgICBsZXQganNvblxuICAgIC8vIHRyeSB7XG4gICAgICBqc29uID0gZnMucmVhZEZpbGVTeW5jKGpzb25QYXRoKVxuICAgICAganNvbiA9IEpTT04ucGFyc2UoanNvbilcblxuICAgIC8vIH0gY2F0Y2goZXJyb3IpIHtcbiAgICAvLyAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgIC8vICAgYEVycm9yIHJlYWRpbmcgSlNPTiBmaWxlICR7anNvblBhdGh9OlxuICAgIC8vICAgJHtlcnJvcn0gIGBcblxuICAgIC8vICAgdGhpcy5sb2cobWVzc2FnZSlcblxuICAgIC8vICAgcmV0dXJuIHt9IC8vIGRvYyB3aWxsIG5vdCBiZSB1cGRhdGVkXG4gICAgLy8gfVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJqc29uUGF0aDpcIiwganNvblBhdGgpXG4gICAgLy8gY29uc29sZS5sb2coXCJqc29uOlwiLCBqc29uKVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGpzb25QYXRoXG4gICAgLCBqc29uXG4gICAgfVxuICB9XG5cblxuICB3cml0ZUpTT04oanNvblBhdGgsIGpzb24pIHtcbiAgICAvLyBSZW1vdmUgdGhlIG1vZCBwcm9wZXJ0eSBmcm9tIHRoZSBKU09OwqBzdHJpbmcsIHNpbmNlIGl0IHdpbGxcbiAgICAvLyBiZSBvYnNvbGV0ZSBhcyBzb29uIGFzIHRoZSBmaWxlIGlzIG1vZGlmaWVkLCBhbmQgd2Ugd2lsbCBiZVxuICAgIC8vIHJldHVybmluZyB0aGUgbmV3IG1vZGlmaWNhdGlvbiBkYXRlIHRvIE1vbmdvREJcblxuICAgIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgICAgY29uc3QgcmVwbGFjZXIgPSAoa2V5LCB2YWx1ZSkgPT4gKCBrZXkgPT09IFwibW9kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICBjb25zdCBqc29uU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkoanNvbiwgcmVwbGFjZXIsICdcXHQnKVxuXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGpzb25QYXRoLCBqc29uU3RyaW5nKVxuICAgIH1cbiAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKGpzb25QYXRoKVxuICAgIGNvbnN0IG1vZCA9IHN0YXRzLm10aW1lTXNcblxuICAgIHJldHVybiBtb2RcbiAgfVxuXG5cbiAgLyoqIFJldHVybnMgYWJzb2x1dGUgcGF0aCB0byBpY29uLCBvciBzaG9ydCBpY29uIG5hbWUsIGFzIGFza2VkXG4gICAqXG4gICAqIENhbGxlZCBieTpcbiAgICogKyBpbXBvcnRBbGwoKSAgICAgICAgLSBkZWFscyB3aXRoIHJvb3QgQWN0aXZpdHkgaWNvblxuICAgKiArIGRvQWN0aXZpdHlVcGRhdGUoKSAtIGRlYWxzIHdpdGggaWNvbiBhdCByb290IG9mIGVhY2ggYWN0aXZpdHlcbiAgICogKyB0cmVhdEZvbGRlcigpICAgICAgLSBkZWFscyB3aXRoIGljb24gZm9yIGVhY2ggc2V0XG4gICAqXG4gICAqIEBwYXJhbSAge3N0cmluZ30gICAgcGFyZW50Rm9sZGVyICBhYnNvbHV0ZSBwYXRoIHRvIHBhcmVudCBmb2xkZXJcbiAgICogQHBhcmFtICB7c3RyaW5nW119ICBjb250ZW50cyAgICAgIGFycmF5IG9mIGZpbGUgc2hvcnQgbmFtZXNcbiAgICpcbiAgICogQHJldHVybiB7c3RyaW5nfSAgICByZWxhdGl2ZSBwYXRoIGZyb20gL3B1YmxpYy9cbiAgICovXG4gIGdldEljb25NYXAocGFyZW50Rm9sZGVyLCBjb250ZW50cykge1xuICAgIGNvbnN0IGljb25NYXAgPSB7fVxuXG4gICAgbGV0IGljb25zID0gY29udGVudHMuZmlsdGVyKGZpbGUgPT4gSUNPTl9SRUdFWC50ZXN0KGZpbGUpKVxuXG4gICAgLy8gSEFDSzogUmVtb3ZlIGljb24gaXRlbXMgZnJvbSBjb250ZW50cywgYXMgdGhleSB3aWxsIG5vdCBiZVxuICAgIC8vIHJlcXVpcmVkIGJ5IGltcG9ydEFzc2V0c1xuICAgIHJlbW92ZUZyb20oY29udGVudHMsIGl0ZW0gPT4gaWNvbnMuaW5jbHVkZXMoaXRlbSksIHRydWUpXG5cbiAgICBsZXQgaWNvblxuICAgICAgLCBpY29uUGF0aFxuXG4gICAgaWYgKCFpY29ucy5sZW5ndGgpIHtcbiAgICAgIGljb25zLnB1c2godGhpcy5fY3JlYXRlUGxhY2Vob2xkZXJJY29uKHBhcmVudEZvbGRlcikpXG4gICAgfVxuXG4gICAgaWYgKGljb25zLmluY2x1ZGVzKFwiaWNvblwiKSkge1xuICAgICAgLy8gVXNlIGxvY2FsaXplZCBpY29ucyBpZiB0aGV5IGFyZSBwcm92aWRlZC5cbiAgICAgIC8vIENoZWNrIHRoYXQgdGhpcyBpY29uIGZvbGRlciBjb250YWlucyBhbiBpY29uIHdpdGggdGhlIG5hbWVcbiAgICAgIC8vIFwiZW5cIi4gT25seSBmaWxlcyB3aGljaCBzaGFyZSB0aGUgc2FtZSBleHRlbnNpb24gYXMgdGhlIFwiZW5cIlxuICAgICAgLy8gaWNvbiBjYW4gYmUgZGlzcGxheWVkLlxuXG4gICAgICBpY29uID0gXCJpY29uXCJcbiAgICAgIGljb25QYXRoID0gcGF0aC5qb2luKHBhcmVudEZvbGRlciwgaWNvbilcbiAgICAgIGljb25zID0gZnMucmVhZGRpclN5bmMoaWNvblBhdGgpXG5cbiAgICAgIGxldCBlbkljb24gPSBpY29ucy5maWx0ZXIoaWNvbiA9PiBFTl9SRUdFWC50ZXN0KGljb24pKVxuXG4gICAgICBpZiAoZW5JY29uLmxlbmd0aCkge1xuICAgICAgICAvLyBlbkljb24gPSBlbkljb25bMF1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBgXG4gICAgICAgIFdBUk5JTkc6IERlZmF1bHQgaWNvbiAoXCJlblwiKSBub3QgZm91bmQgYXQgJHtpY29uUGF0aH1cbiAgICAgICAgQXZhaWxhYmxlIGljb25zOiAke0pTT04uc3RyaW5naWZ5KGljb25zKX1cbiAgICAgICAgQSBwbGFjZWhvbGRlciBlbi5zdmcgd2lsbCBiZSB1c2VkIGluc3RlYWRcbiAgICAgICAgYFxuICAgICAgICB0aGlzLmxvZyhtZXNzYWdlKVxuXG4gICAgICAgIGljb25zLnB1c2godGhpcy5fY3JlYXRlUGxhY2Vob2xkZXJJY29uKGljb25QYXRoLCBcImVuXCIpKVxuICAgICAgfVxuXG4gICAgICBpY29uUGF0aCArPSBcIi9eMFwiIC8vICsgZXh0ZW5zaW9uXG4gICAgICBpY29uTWFwLmljb25zID0gaWNvbnNcblxuICAgIH0gZWxzZSB7XG4gICAgICBpY29uUGF0aCA9IHBhdGguam9pbihwYXJlbnRGb2xkZXIsIGljb25zWzBdKVxuICAgIH1cblxuICAgIGljb25NYXAuc3JjID0gaWNvblBhdGgucmVwbGFjZShQVUJMSUNfRElSRUNUT1JZLCBcIlwiKVxuXG4gICAgcmV0dXJuIGljb25NYXBcbiAgfVxuXG5cbiAgLyoqIENyZWF0ZXMgYW4gU1ZHIGZpbGUgaW4gcGFyZW50Rm9sZGVyOyByZXR1cm5zIHNob3J0IGZpbGUgbmFtZVxuICAgKlxuICAgKiBDYWxsZWQgYnkgZ2V0SWNvbk1hcCgpXG4gICAqXG4gICAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICAgIHBhcmVudEZvbGRlciAgIGFic29sdXRlIHBhdGggdG8gZm9sZGVyXG4gICAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICAgIFtuYW1lPVwiaWNvblwiXSAgXCJlblwiIHwgdW5kZWZpbmVkXG4gICAqXG4gICAqIEByZXR1cm5zICAgIHtzdHJpbmd9ICAgIFwiZW4uc3ZnXCIgfCBcImljb24uc3ZnXCJcbiAgICovXG4gIF9jcmVhdGVQbGFjZWhvbGRlckljb24ocGFyZW50Rm9sZGVyLCBuYW1lPVwiaWNvblwiKSB7XG4gICAgY29uc3QgaWNvbk5hbWUgPSBuYW1lICsgXCIuc3ZnXCJcbiAgICBjb25zdCBjb2xvdXIgPSBnZXRDb2xvcih7IG51bWJlcjogbnVtYmVyKyssIGZvcm1hdDogXCJoZXhcIiB9KVxuICAgIGNvbnN0IHN2ZyA9IGA8P3htbCB2ZXJzaW9uPVwiMS4wXCJcbiAgZW5jb2Rpbmc9XCJVVEYtOFwiXG4gIHN0YW5kYWxvbmU9XCJub1wiXG4/PlxuXG48c3ZnXG4gIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICB2aWV3Qm94PVwiMCAwIDQwMCA0MDBcIlxuICBoZWlnaHQ9XCI0MDBcIlxuICB3aWR0aD1cIjQwMFwiXG4gIGZpbGw9XCIke2NvbG91cn1cIlxuICBzdHJva2U9XCJub25lXCJcbj5cbiAgPHJlY3RcbiAgICB4PVwiMFwiXG4gICAgd2lkdGg9XCI0MDBcIlxuICAgIGhlaWdodD1cIjQwMFwiXG4gICAgcng9XCI4MFwiXG4gIC8+XG48L3N2Zz5gXG5cbiAgICBjb25zdCBpY29uUGF0aCA9IHBhdGguam9pbihwYXJlbnRGb2xkZXIsIGljb25OYW1lKVxuICAgIGZzLndyaXRlRmlsZVN5bmMoaWNvblBhdGgsIHN2ZylcblxuICAgIHJldHVybiBpY29uTmFtZVxuICB9XG59IiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvbG9nLmpzXG4gKlxuICogQSBzaW5nbGV0b24gTG9nIGluc3RhbmNlIGlzIGluc3RhbnRpYXRlZCBieSAuL2ltcG9ydC5qc1xuICogSW1wb3J0QXNzZXRzIGFuZCBwYXNzZWQgdG8gZWFjaCBpbnN0YW5jZSB0aGF0IGl0IGNyZWF0ZXMuXG4gKlxuICogVXNlOlxuICpcbiAqICAgY29uc3QgbG9nZ2VyID0gbmV3IExvZygpXG4gKiAgIHRoaXMubG9nID0gbG9nZ2VyLmFkZEVudHJ5XG4gKiAgIC4uLlxuICogICB0aGlzLmxvZyhtZXNzYWdlKVxuICogICAuLi5cbiAqICAgbG9nZ2VyLnNhdmUoKVxuICovXG5cblxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMb2d7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMubG9nU2hlZXQgPSBcIlwiXG4gICAgdGhpcy5hZGRFbnRyeSA9IHRoaXMuYWRkRW50cnkuYmluZCh0aGlzKVxuICAgIHRoaXMuc2F2ZSA9IHRoaXMuc2F2ZS5iaW5kKHRoaXMpXG4gIH1cblxuICBhZGRFbnRyeShtZXNzYWdlKSB7XG4gICAgdGhpcy5sb2dTaGVldCArPSBcIlxcblwiICsgbWVzc2FnZVxuICB9XG5cbiAgc2F2ZSgpIHtcbiAgICAvL2NvbnNvbGUubG9nKCBcIkxPR1wiLCB0aGlzLmxvZ1NoZWV0ICsgXCJcXG5+fn5+fn5+fn5+fn5+fn5+fn5cIilcbiAgfVxufSIsIi8qKlxuICogL2ltcG9ydHMvYXBpL21ldGhvZHMvZmx1ZW5jeS9zY2hlZHVsZXIuanNcbiAqL1xuXG5cblxuaW1wb3J0IHsgZ2V0UmFuZG9tIH0gZnJvbSAnL2ltcG9ydHMvdG9vbHMvZ2VuZXJpYy91dGlsaXRpZXMnXG5cbmltcG9ydCBjb2xsZWN0aW9ucyBmcm9tICcvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvcHVibGlzaGVyJ1xuY29uc3QgeyBGbHVlbmN5IH0gPSBjb2xsZWN0aW9uc1xuXG5cbi8vLyA8PDwgSEFSRC1DT0RFRFxuY29uc3QgTUlOX1NQQUNJTkcgICAgPSA1IC8vIG1pbmltdW0gb2YgNSBpdGVtcyBiZXR3ZWVuIHJlcGV0aXRpb25zXG5jb25zdCBGT1VSX0RBWVMgICAgICA9IDU3NjAgLy8gNCBkYXlzIGluIG1pbnV0ZXNcbmNvbnN0IMKgTUlOVVRFU19UT19NUyA9IDYwICogMTAwMFxuLy8vIEhBUkQtQ09ERUTCoD4+PlxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNjaGVkdWxlciB7XG4gIGNvbnN0cnVjdG9yKHsgdXNlcl9pZCwgZ3JvdXBfaWQsIGNvcnJlY3QsIHRpbWVTdGFtcCB9KSB7XG4gICAgdGhpcy51c2VyX2lkICAgPSB1c2VyX2lkXG4gICAgdGhpcy5ncm91cF9pZCAgPSBncm91cF9pZFxuICAgIHRoaXMuY29ycmVjdCAgID0gY29ycmVjdFxuICAgIHRoaXMudGltZVN0YW1wID0gdGltZVN0YW1wXG5cbiAgICB0aGlzLnNldE5leHRTZWVuID0gdGhpcy5zZXROZXh0U2Vlbi5iaW5kKHRoaXMpXG4gICAgY29uc3QgaWRzID0gT2JqZWN0LmtleXMoY29ycmVjdClcbiAgICB0aGlzLmNvdW50ID0gaWRzLmxlbmd0aFxuXG4gICAgaWRzLmZvckVhY2godGhpcy5zZXROZXh0U2VlbilcbiAgfVxuXG5cbiAgZ2V0VGltZShzdGFtcCkge1xuICAgIGlmICghc3RhbXApIHtcbiAgICAgIHN0YW1wID0gKyBuZXcgRGF0ZSgpXG4gICAgfVxuICAgIHJldHVybiBuZXcgRGF0ZShzdGFtcCkudG9UaW1lU3RyaW5nKCkuc3Vic3RyaW5nKDAsOClcbiAgfVxuXG5cbiAgc2V0TmV4dFNlZW4ocGhyYXNlX2lkKSB7XG5cbiAgICBjb25zdCBzZWxlY3QgPSB7XG4gICAgICB1c2VyX2lkOiB0aGlzLnVzZXJfaWRcbiAgICAsIGdyb3VwX2lkOiB0aGlzLmdyb3VwX2lkXG4gICAgLCBwaHJhc2VfaWRcbiAgICB9XG5cbiAgICBjb25zdCBmbHVlbmN5RG9jID0gRmx1ZW5jeS5maW5kT25lKHNlbGVjdClcbiAgICAvKiB7XG4gICAgICogICBcIl9pZFwiICAgICAgICA6IFwiN25Ub3hUdjdpTlEzZ2UzempcIixcbiAgICAgKiAgIFwicGhyYXNlX2lkXCIgIDogXCJUWWh2cmN0eHZpOWJIRHV2a1wiLFxuICAgICAqICAgXCJuZXh0X3NlZW5cIiAgOiAxNTk1NTc3NjE0MzgxLFxuICAgICAqXG4gICAgICogICBcInVzZXJfaWRcIiAgICA6IFwiU1d2WVBlM1hodDhBdUJnS2lcIixcbiAgICAgKiAgIFwiZ3JvdXBfaWRcIiAgIDogXCJNdGhEUWhyNnc0SzV5SlhyU1wiLFxuICAgICAqXG4gICAgICogICBcInRpbWVzX3NlZW5cIiA6IDAsXG4gICAgICogICBcImZpcnN0X3NlZW5cIiA6IDAsXG4gICAgICogICBcImxhc3Rfc2VlblwiICA6IDAsXG4gICAgICogICBcImZsb3BzXCIgICAgICA6IDQsXG4gICAgICogICBcInNjb3JlXCIgICAgICA6IDAsXG4gICAgICogICBcInNwYWNpbmdcIiAgICA6IDUsXG4gICAgICogICBcImNvbGxlY3Rpb25cIiA6IFwiVm9jYWJ1bGFyeVwiLFxuICAgICAqICAgXCJsZXZlbFwiICAgICAgOiBcIlRPRE9cIlxuICAgICAqIH1cbiAgICAgKi9cblxuICAgIC8vIFN0YW5kYXJkIGhvdXNla2VlcGluZ1xuICAgIGNvbnN0IGNvcnJlY3QgPSB0aGlzLmNvcnJlY3RbcGhyYXNlX2lkXVxuICAgIGNvbnN0IGxhc3Rfc2VlbiA9ICsgbmV3IERhdGUoKVxuICAgIGxldCBuZXh0X3NlZW5cblxuICAgIGxldCB7IGZsb3BzLCB0aW1lc19zZWVuLCBmaXJzdF9zZWVuLCBzcGFjaW5nIH0gPSBmbHVlbmN5RG9jXG5cbiAgICBmbG9wcyA9ICgxNiAqICFjb3JyZWN0KSArIChmbG9wcyA+PiAxKVxuXG4gICAgaWYgKCF0aW1lc19zZWVuKSB7XG4gICAgICBmaXJzdF9zZWVuID0gbGFzdF9zZWVuXG5cbiAgICAgIGlmIChjb3JyZWN0KSB7XG4gICAgICAgIHNwYWNpbmcgPSBGT1VSX0RBWVMgKiBNSU5fU1BBQ0lOR1xuICAgICAgICBuZXh0X3NlZW4gPSBmaXJzdF9zZWVuICsgKEZPVVJfREFZUyAqIE1JTlVURVNfVE9fTVMpXG4gICAgICAgIC8vIDQgZGF5cyA9PiAyMCBkYXlzID0+IDEwMCBkYXlzID0gMyBtb250aHMgK1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHJhdGlvID0gY29ycmVjdFxuICAgICAgICAgICAgICAgID8gZmx1ZW5jeURvYy5yaWdodCB8fCA1XG4gICAgICAgICAgICAgICAgOiBmbHVlbmN5RG9jLndyb25nIHx8IDEvMlxuICAgIHNwYWNpbmcgPSBNYXRoLm1heCggTUlOX1NQQUNJTkcsIHJhdGlvICogc3BhY2luZyApXG5cbiAgICBpZiAoIW5leHRfc2Vlbikge1xuICAgICAgbmV4dF9zZWVuID0gdGhpcy5yZXNjaGVkdWxlKGxhc3Rfc2Vlbiwgc3BhY2luZylcbiAgICB9XG4gICAgdGltZXNfc2VlbiArPSAxXG5cbiAgICBjb25zdCBzZXQgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIGZsb3BzXG4gICAgICAsIHRpbWVzX3NlZW5cbiAgICAgICwgZmlyc3Rfc2VlbiAvLyBtYXkgYmUgcmVzZXQgdG8gaXRzIGN1cnJlbnQgdmFsdWVcbiAgICAgICwgbGFzdF9zZWVuICAvLyByZWFsIHRpbWVcbiAgICAgICwgbmV4dF9zZWVuXG4gICAgICAsIHNwYWNpbmdcbiAgICAgIH1cbiAgICB9XG4gICAgRmx1ZW5jeS51cGRhdGUoc2VsZWN0LCBzZXQpXG4gIH1cblxuXG4gIC8qKlxuICAgKiB7IGZ1bmN0aW9uX2Rlc2NyaXB0aW9uIH1cbiAgICpcbiAgICogQHBhcmFtICB7dGltZVN0YW1wfSBub3cgICAgICBtaWxsaXNlY29uZHMgc2luY2UgdGhlIGVwb2NoXG4gICAqIEBwYXJhbSAge251bWJlcn0gICAgc3BhY2luZyAgbWluaW11bSBudW1iZXIgb2YgaW50ZXJ2ZW5pbmcgaXRlbXNcbiAgICogQHBhcmFtICB7bnVtYmVyfSAgICByYXRpbyAgICBob3cgc3BhY2luZyBzaG91bGQgY2hhbmdlXG4gICAqXG4gICAqIEByZXR1cm4ge251bWJlcn0gICAgbmV4dF9zZWVuIHRpbWVzdGFtcFxuICAgKi9cbiAgcmVzY2hlZHVsZShub3csIHNwYWNpbmcsIHJhdGlvKSB7XG4gICAgbGV0IG5leHRfc2VlblxuICAgIGxldCBzdGFydFRpbWUgPSB0aGlzLnRpbWVTdGFtcFxuXG4gICAgY29uc3Qgc2VsZWN0ID0ge31cbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgc29ydDogeyBuZXh0X3NlZW46IDEgfVxuICAgICwgbGltaXQ6IDFcbiAgICAsIHNraXA6IHRoaXMuY291bnQgKyBzcGFjaW5nXG4gICAgLCBmaWVsZHM6IHsgbmV4dF9zZWVuOiAxLCBwaHJhc2U6IDEgfVxuICAgIH1cblxuICAgIC8vIEFzc3VtZSB0aGF0IE1JTl9TUEFDSU5HIGl0ZW1zIHRha2UgYWJvdXQgMSBtaW51dGUsIGFuZFxuICAgIC8vIGNhbGN1bGF0ZSB0aGUgdGltZSBpbiBtaW51dGVzIGJlZm9yZSB0aGUgaXRlbSBzaG91bGQgYmVcbiAgICAvLyByZXBlYXRlZC5cbiAgICBjb25zdCBzcGFjZVRpbWUgPSAoc3BhY2luZyAvIE1JTl9TUEFDSU5HKcKgKsKgTUlOVVRFU19UT19NU1xuXG4gICAgLy8gRGV0ZXJtaW5lIHdoZW4gdGhlIGl0ZW0gY3VycmVudGx5IHRoYXQgbWFueSBwbGFjZXMgZnVydGhlclxuICAgIC8vIGRvd24gdGhlIHF1ZXVlIGlzIHNjaGVkdWxlZCB0byByZXBlYXQsIGFuZCB3aGVuIHdlIGV4cGVjdFxuICAgIC8vIHRoYXQgc2hvdWxkIGhhcHBlbi5cbiAgICBjb25zdCBmaXJzdCAgICAgPSBGbHVlbmN5LmZpbmQoc2VsZWN0LCBvcHRpb25zKS5mZXRjaCgpWzBdXG4gICAgbGV0IGZpcnN0VGltZSA9IHRoaXMudGltZVN0YW1wICsgc3BhY2VUaW1lXG5cbiAgICBjb25zb2xlLmxvZyggXCJmaXJzdDpcIiwgZmlyc3RcbiAgICAgICAgICAgICAgICwgXCIgICA8PDwgICBkYi5mbHVlbmN5LmZpbmQoe30sXCJcbiAgICAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkob3B0aW9ucy5maWVsZHMpXG4gICAgICAgICAgICAgICArIFwiKS5zb3J0KFwiXG4gICAgICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KG9wdGlvbnMuc29ydClcbiAgICAgICAgICAgICAgICsgXCIpLnNraXAoXCJcbiAgICAgICAgICAgICAgICsgb3B0aW9ucy5za2lwXG4gICAgICAgICAgICAgICArIFwiKS5saW1pdChcIlxuICAgICAgICAgICAgICAgKyBvcHRpb25zLmxpbWl0XG4gICAgICAgICAgICAgICArIFwiKVwiXG4gICAgICAgICAgICAgICApXG5cbiAgICAvLyBXZSB3YW50IHRvIHJhbmRvbWl6ZSB0aGUgc3BhY2luZyBhIGJpdCwgc28gbm93IHdlIGNhbGN1bGF0ZVxuICAgIC8vIHRoZSB0aW1pbmcgZXhwZWN0ZWQgZm9yIHRoZSBpdGVtIHR3aWNlIGFzIGZhciBhd2F5XG4gICAgb3B0aW9ucy5za2lwID0gdGhpcy5jb3VudCArIDEgKyBzcGFjaW5nICogMlxuICAgIGNvbnN0IGxhc3QgPSBGbHVlbmN5LmZpbmQoc2VsZWN0LCBvcHRpb25zKS5mZXRjaCgpWzBdXG4gICAgbGV0IGxhc3RUaW1lID0gdGhpcy50aW1lU3RhbXAgKyBzcGFjZVRpbWUgKsKgMlxuXG4gICAgLy8gY29uc29sZS5sb2coXCJub3c6XCIsIHRoaXMuZ2V0VGltZShub3cpKVxuICAgIC8vIGNvbnNvbGUubG9nKFwiY3VycmVudDpcIiwgdGhpcy5nZXRUaW1lKHRoaXMudGltZVN0YW1wKSlcbiAgICAvLyBpZiAoZmlyc3QpIHtcbiAgICAvLyAgIGNvbnNvbGUubG9nKFwiZmlyc3Q6XCIsIHRoaXMuZ2V0VGltZShmaXJzdC5uZXh0X3NlZW4pKVxuICAgIC8vIH0gZWxzZSB7XG4gICAgLy8gICBjb25zb2xlLmxvZyhcImZpcnN0XCIsIHVuZGVmaW5lZClcbiAgICAvLyB9XG4gICAgLy8gY29uc29sZS5sb2coXCJmaXJzdFRpbWU6XCIsIHRoaXMuZ2V0VGltZShmaXJzdFRpbWUpKVxuICAgIC8vIGlmIChsYXN0KSB7XG4gICAgLy8gICBjb25zb2xlLmxvZyhcImxhc3Q6XCIsIHRoaXMuZ2V0VGltZShsYXN0Lm5leHRfc2VlbikpXG4gICAgLy8gfSBlbHNlIHtcbiAgICAvLyAgIGNvbnNvbGUubG9nKFwibGFzdFwiLCB1bmRlZmluZWQpXG4gICAgLy8gfVxuICAgIC8vIGNvbnNvbGUubG9nKFwibGFzdFRpbWU6XCIsIHRoaXMuZ2V0VGltZShsYXN0VGltZSkpXG5cbiAgICBpZiAoZmlyc3QpIHtcbiAgICAgIGlmIChsYXN0KSB7XG4gICAgICAgIGlmIChsYXN0VGltZSA+IGxhc3QubmV4dF9zZWVuKSB7XG4gICAgICAgICAgLy8gSXRlbXMgYXJlIHNjaGVkdWxlZCBjbG9zZXIgdG9nZXRoZXIgdGhhbiB0aGV5IGNhbiBiZVxuICAgICAgICAgIC8vIHJldmlld2VkLiBVc2UgdGhlIG51bWJlciBvZiBpbnRlcnZlbmluZyBpdGVtcyBhcyBhXG4gICAgICAgICAgLy8gZ3VpZGUgdG8gd2hlbiB0byByZXNjaGVkdWxlLiBNYWtlIHRoZSBlbmQgdGltZSBlYXJsaWVyLlxuICAgICAgICAgIGxhc3RUaW1lID0gbGFzdC5uZXh0X3NlZW5cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoZmlyc3RUaW1lID4gZmlyc3QubmV4dF9zZWVuKSB7XG4gICAgICAgIC8vIEl0ZW1zIGFyZSBzY2hlZHVsZWQgY2xvc2VyIHRvZ2V0aGVyIHRoYW4gdGhleSBjYW4gYmVcbiAgICAgICAgLy8gcmV2aWV3ZWQuIFVzZSB0aGUgbnVtYmVyIG9mIGludGVydmVuaW5nIGl0ZW1zIGFzIGFcbiAgICAgICAgLy8gZ3VpZGUgdG8gd2hlbiB0byByZXNjaGVkdWxlLiBNYWtlIHRoZSBzdGFydCB0aW1lXG4gICAgICAgIC8vIGVhcmxpZXIuXG4gICAgICAgIGZpcnN0VGltZSA9IGZpcnN0Lm5leHRfc2VlblxuXG4gICAgICB9IGVsc2UgaWYgKGZpcnN0VGltZSA8IG5vdykge1xuICAgICAgICAvLyBBbGwgaXRlbXMgYmVmb3JlIG5vdyB3aWxsIGJlIHNlcnZlZCB3aXRoIG5vIGdhcHMuIEJ1dFxuICAgICAgICAvLyB0aGVyZSBpcyBhIGdhcCwgYW5kIHdlIGRvbid0IHdhbnQgdGhpcyBpdGVtIHRvIGJlXG4gICAgICAgIC8vIHJlc2VydmVkIHRvbyBzb29uLiBEZWxheSBpdCB1bnRpbCBlbm91Z2ggaXRlbXMgaGF2ZVxuICAgICAgICAvLyBiZWVuIHNlcnZlZC5cbiAgICAgICAgZmlyc3RUaW1lID0gZmlyc3QubmV4dF9zZWVuXG5cbiAgICAgICAgLy8gTm93IGl0J3MgX2p1c3RfIHBvc3NpYmxlIHRoYXQgbGFzdFRpbWUgaXMgYmVmb3JlXG4gICAgICAgIC8vIGZpcnN0VGltZSwgYmVjYXVzZSBvZiB0aGUgZ2FwLlxuICAgICAgICBpZiAobGFzdFRpbWUgPCBmaXJzdFRpbWUpIHtcbiAgICAgICAgICBsYXN0VGltZSA9IGZpcnN0VGltZSArIHNwYWNlVGltZVxuICAgICAgICB9XG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFRoZXJlIG1heSBub3QgYmUgZW5vdWdoIGludGVydmVuaW5nIGl0ZW1zIGJlZm9yZSB3ZSBjYW5cbiAgICAgICAgLy8gc2hvdyB0aGlzIGl0ZW0gYWdhaW4uIFVzaW5nIHRoZSBjYWxjdWxhdGVkIHRpbWUsIHN0YXJ0aW5nXG4gICAgICAgIC8vIGZyb20gbm93LCB3aWxsIGNyZWF0ZSBhIGdhcCBmb3IgbmV3IGl0ZW1zIHRvIGJlIHNlcnZlZCxcbiAgICAgICAgLy8gaWYgdGhhdCBpcyBuZWNlc3NhcnkuXG4gICAgICAgIGZpcnN0VGltZSA9IE1hdGgubWluKG5vdyArIHNwYWNlVGltZSwgZmlyc3QubmV4dF9zZWVuKVxuICAgICAgICBsYXN0VGltZSAgPSBNYXRoLm1pbihub3cgKyBzcGFjZVRpbWUgKsKgMiwgbGFzdC5uZXh0X3NlZW4pXG4gICAgICB9XG5cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlcmUgYXJlbid0IGVub3VnaCBpdGVtcyBzY2hlZHVsZWQgdG8gdXNlIHBsYWNpbmcuXG4gICAgICAvLyBSZXNjaGVkdWxlIGZyb20gbm93LlxuICAgICAgZmlyc3RUaW1lID0gbm93ICsgc3BhY2VUaW1lXG4gICAgICBsYXN0VGltZSAgPSBub3cgKyBzcGFjZVRpbWUgKsKgMlxuICAgIH1cblxuICAgIC8vIG5leHRfc2VlbiA9IGZpcnN0VGltZSAvLyAobGFzdFRpbWUgKyBmaXJzdFRpbWUpIC8gMlxuICAgIG5leHRfc2VlbiA9IGdldFJhbmRvbShsYXN0VGltZSwgZmlyc3RUaW1lKVxuXG4gICAgcmV0dXJuIG5leHRfc2VlblxuICB9XG59IiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hZG1pbi5qc1xuICpcbiAqIEJhc2VkIG9uLi4uXG4gKiAgIGh0dHBzOi8vZ3VpZGUubWV0ZW9yLmNvbS9tZXRob2RzLmh0bWwjYWR2YW5jZWQtYm9pbGVycGxhdGVcbiAqIC4uLiB3aXRoIHRoZSBpbXBvcnRhbnQgYWRkaXRpb24gb2YgYSBgcmV0dXJuYCBzdGF0ZW1lbnQgaW4gZWFjaFxuICogZW50cnkgZm9yIE1ldGVvci5tZXRob2RzKClcbiAqXG4gKiBjcmVhdGVBY2NvdW50KCkgaXMgY2FsbGVkIGZyb20gdGhlIFN1Ym1pdCB2aWV3IGFmdGVyIHRoZSB1c2VyIGhhc1xuICogICBzZWxlY3RlZCBhIG5hdGl2ZSBsYW5ndWFnZSwgYSB1c2VybmFtZSBhbmQgYSB0ZWFjaGVyLiBJdCBjcmVhdGVzXG4gKiAgIGEgVXNlciByZWNvcmQgYW5kIGEgR3JvdXAgcmVjb3JkIHdpdGggdGhlIGNob3NlbiB0ZWFjaGVyLCBhbmRcbiAqICAgaW5kaWNhdGVzIGEgbG9nZ2VkX2luIHN0YXR1cyBpbiBib3RoLlxuICpcbiAqICAgVXNlcjogIHsgJHNldDogeyBsb2dnZWRfaW46IHRydWUgfSB9XG4gKiAgIEdyb3VwOiB7ICRwdXNoIHsgbG9nZ2VkX2luOiB1c2VyX2lkIH0gfVxuICpcbiAqICAgSWYgaXQgaXMgY2FsbGVkIG1vcmUgdGhhbiBvbmNlIHdpdGggdGhlIHNhbWUgdXNlcm5hbWUgYW5kIG5hdGl2ZVxuICogICBsYW5ndWFnZS90ZWFjaGVyLCB0aGUgIGV4aXN0aW5nIHJlY29yZHMgYXJlIHVzZWQuIElmIHRoZSB1c2VyXG4gKiAgIGNoYW5nZXMgbGFuZ3VhZ2Ugb3IgdGVhY2hlciwgYSBuZXcgVXNlciByZWNvcmQgb3IgYSBuZXcgR3JvdXBcbiAqICAgcmVjb3JkIHdpbGwgYmUgY3JlYXRlZC5cbiAqXG4gKiAgIE5PVEU6IG9uZSB0ZWFjaGVyIHdobyB3b3JrcyB3aXRoIHR3byBkaWZmZXJlbnQgbGFuZ3VhZ2VzIHdpbGxcbiAqICAgaGF2ZSB0d28gZGlmZmVyZW50IHRlYWNoZXIgaWRzXG4gKlxuICogbG9nKCkgY29tYmluZXMgbG9naW4gYW5kIGxvZ291dFxuICogICBDYWxsZWQgZnJvbSBUZWFjaCAoY29uc3RydWN0b3IgPT4gbG9nVGVhY2hlckluKSBhbmQgTWVudVxuICogICAoYmVmb3JldW5sb2FkID0+IGxvZ091dClcbiAqXG4gKiAgIFdoZW4gYW55b25lIGxvZ3MgaW4sIHRoZSBsb2dnZWRfaW4gc3RhdHVzIG9mIHRoZWlyIHByb2ZpbGUgcmVjb3JkXG4gKiAgIChUZWFjaGVyIG9yIFVzZXIpIGlzIHNldCB0byB0cnVlXG4gKiAgIFdoZW4gYW55b25lIGxvZ3Mgb3V0LCB0aGVpciBsb2dnZWRfaW4gc3RhdHVzIGlzIHNldCB0byBmYWxzZSBhbmRcbiAqICAgdGhlaXIgbG9nZ2VkT3V0IHN0YXR1cyBpcyBzZXQgdG8gYW4gSVNPRGF0ZSwgc28gdGhhdCB3ZSBjYW5cbiAqICAgY2FsY3VsYXRlZCBob3cgbG9uZyBhZ28gdGhleSB3ZXJlIGxhc3Qgc2VlblxuICogICBXaGVuIHVzZXJzIGxvZyBpbiBvciBvdXQsIHRoZWlyIGlkIGlzIHB1c2ggdG8gb3IgcHVsbGVkIGZyb21cbiAqICAgdGhlIGxvZ2dlZF9pbiBhcnJheSBvZiBhbGwgdGhlIGdyb3VwIHRoZXkgYmVsb25nIHRvXG4gKiAgIFdoZW4gdGVhY2hlcnMgbG9nIG91dCwgdGhlIGFjdGl2ZSBzdGF0ZSBvZiB0aGVpciBjdXJyZW50IGdyb3VwXG4gKiAgIGlzIHNldCB0byBmYWxzZS5cbiAqXG4gKiByZUdyb3VwKCkgY29tYmluZXMgam9pbiBncm91cCBhbmQgbGVhdmUgZ3JvdXBcbiAqICAgQ2FsbGVkIGZvciB1c2VycyBmcm9tIHRoZSBDb25uZWN0IHZpZXdcbiAqXG4gKiBOT1RFID4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+XG4gKiBNZXRob2RzIHNwZWNpZmljIHRvIHRoZSBQb2ludHMgY29sbGVjdGlvbiBhcmUgZGVmaW5lZCBzZXBhcmF0ZWx5IGluXG4gKiAvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvcG9pbnRzLmpzXG4gKiA8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8XG4gKlxuICovXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSdcblxuaW1wb3J0IExvZ0luIGZyb20gJy4vYWRtaW4vbG9naW4nXG5pbXBvcnQgTG9nT3V0IGZyb20gJy4vYWRtaW4vbG9nb3V0J1xuaW1wb3J0IEpvaW5Hcm91cCBmcm9tICcuL2FkbWluL2pvaW4nXG5pbXBvcnQgTGVhdmVHcm91cCBmcm9tICcuL2FkbWluL2xlYXZlJ1xuaW1wb3J0IENyZWF0ZUdyb3VwIGZyb20gJy4vYWRtaW4vZ3JvdXAnXG5pbXBvcnQgTG9nSW5UZWFjaGVyIGZyb20gJy4vYWRtaW4vbG9naW5UZWFjaGVyJ1xuaW1wb3J0IENyZWF0ZUFjY291bnQgZnJvbSAnLi9hZG1pbi9hY2NvdW50J1xuaW1wb3J0IFRvZ2dsZUFjdGl2YXRpb24gZnJvbSAnLi9hZG1pbi9hY3RpdmF0ZSdcblxuaW1wb3J0IFNjaGVkdWxlciBmcm9tICcuL2ZsdWVuY3kvc2NoZWR1bGVyJ1xuXG5pbXBvcnQgY29sbGVjdGlvbnMgZnJvbSAnLi4vY29sbGVjdGlvbnMvcHVibGlzaGVyJ1xuY29uc3QgeyBHcm91cCwgRmx1ZW5jeSwgVm9jYWJ1bGFyeSB9ID0gY29sbGVjdGlvbnNcbi8vIHVzZWQgYnkgc2hhcmUsIHNldFBhZ2UgYW5kIHNldEluZGV4XG5cblxuLyoqIENyZWF0ZXMgb3IgdXBkYXRlcyBhIFVzZXIgcmVjb3JkIGFmdGVyIHByb2ZpbGluZ1xuICogIENhbGxpbmcgdGhlIG1ldGhvZCBhIHNlY29uZCB0aW1lIHJldXNlcyB0aGUgZXhpc3RpbmcgcmVjb3Jkc1xuICovXG5leHBvcnQgY29uc3QgY3JlYXRlQWNjb3VudCA9IHtcbiAgbmFtZTogJ3Zkdm95b20uY3JlYXRlQWNjb3VudCdcblxuLCBjYWxsKGFjY291bnREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbYWNjb3VudERhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKGFjY291bnREYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICB1c2VybmFtZTogeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgbmF0aXZlOiAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIHRlYWNoZXI6ICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBsYW5ndWFnZTogeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgZF9jb2RlOiAgIHsgdHlwZTogU3RyaW5nIH1cblxuICAgIC8vIGFjdGlvbiB3aWxsIGhhdmUgYmVlbiBhZGRlZCBpZiB0aGUgb3JpZ2luYWwgY2FsbCB3YXMgdG8gbG9nSW5cbiAgICAsIGFjdGlvbjogICB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfVxuICAgIH0pLnZhbGlkYXRlKGFjY291bnREYXRhKVxuICB9XG5cbiwgcnVuKGFjY291bnREYXRhKSB7XG4gICAgbmV3IENyZWF0ZUFjY291bnQoYWNjb3VudERhdGEpIC8vIG1vZGlmaWVzIGFjY291bnREYXRhXG5cbiAgICAvLyBjb25zb2xlLmxvZyhcIkFmdGVyIENyZWF0ZUFjY291bnQgYWNjb3VudERhdGEgaXNcIiwgYWNjb3VudERhdGEpXG5cbiAgICBuZXcgTG9nSW4oYWNjb3VudERhdGEpICAgICAvLyAsIGFjdGlvbjogXCJsb2dnZWRJblwiXG5cbiAgICAvLyBjb25zb2xlLmxvZyhcIkRhdGEgdG8gcmV0dXJuIGZyb20gQ3JlYXRlQWNjb3VudFwiLCBhY2NvdW50RGF0YSlcblxuICAgIHJldHVybiBhY2NvdW50RGF0YVxuICB9XG59XG5cblxuXG4vKiogQ3JlYXRlcyBvciB1cGRhdGVzIGEgR3JvdXAgcmVjb3JkIHdpdGggYSB0ZWFjaGVyIGFmdGVyIHByb2ZpbGluZ1xuICogIENhbGxpbmcgdGhlIG1ldGhvZCBhIHNlY29uZCB0aW1lIHJldXNlcyB0aGUgZXhpc3RpbmcgZ3JvdXBcbiAqL1xuZXhwb3J0IGNvbnN0IGNyZWF0ZUdyb3VwID0ge1xuICBuYW1lOiAndmR2b3lvbS5jcmVhdGVHcm91cCdcblxuLCBjYWxsKGFjY291bnREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbYWNjb3VudERhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKGFjY291bnREYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICB1c2VyX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCB0ZWFjaGVyOiAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgbGFuZ3VhZ2U6IHsgdHlwZTogU3RyaW5nIH1cblxuICAgIC8vIE90aGVyIHByb3BlcnRpZXMgbWF5IGV4aXN0IGJ1dCB3aWxsIG5vdCBiZSB1c2VkXG4gICAgLCB1c2VybmFtZTogeyB0eXBlOiBTdHJpbmcsIG9wdGlvbmFsOiB0cnVlIH1cbiAgICAsIG5hdGl2ZTogICB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfVxuICAgICwgZF9jb2RlOiAgIHsgdHlwZTogU3RyaW5nLCBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLCBhY3Rpb246ICAgeyB0eXBlOiBTdHJpbmcsIG9wdGlvbmFsOiB0cnVlIH1cbiAgICB9KS52YWxpZGF0ZShhY2NvdW50RGF0YSlcbiAgfVxuXG4sIHJ1bihhY2NvdW50RGF0YSkge1xuICAgIG5ldyBDcmVhdGVHcm91cChhY2NvdW50RGF0YSkgLy8gbW9kaWZpZXMgYWNjb3VudERhdGFcbiAgICBuZXcgSm9pbkdyb3VwKGFjY291bnREYXRhKSAgIC8vIGFjdGlvblxuXG4gICAgcmV0dXJuIGFjY291bnREYXRhXG4gIH1cbn1cblxuXG5cbi8qKiBMb2dzIGEgdXNlcidzIGRldmljZSBpbnRvIGl0cyBHcm91cCBhbmQgVXNlciByZWNvcmRzXG4gKlxuICogIENyZWF0ZXMgYSBuZXcgYWNjb3VudCBpZiBuZWNlc3NhcnksIG9yIGFza3MgZm9yIGNvbmZpcm1hdGlvbiBieVxuICogIFBJTsKgbnVtYmVyIGlmIG93bmVyc2hpcCBvZiBhIG5hbWUgaXMgdW5jZXJ0YWluXG4gKi9cbmV4cG9ydCBjb25zdCBsb2dJbiA9IHtcbiAgbmFtZTogJ3Zkdm95b20ubG9nSW4nXG5cbiwgY2FsbChsb2dJbkRhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtsb2dJbkRhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKGxvZ0luRGF0YSkge1xuICAgIC8vIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGxvZ0luRGF0YSwgbnVsbCwgXCIgIFwiKSlcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIHVzZXJuYW1lOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBkX2NvZGU6ICAgeyB0eXBlOiBTdHJpbmcgfVxuXG4gICAgLCByZXN0b3JlX2FsbDogeyB0eXBlOiBCb29sZWFuLCBvcHRpb25hbDogdHJ1ZSB9XG5cbiAgICAvLyBTZW50IG9ubHkgaWYgYXV0b21hdGljIGxvZ2luIGlzIE5PVMKgdXNlZFxuICAgICwgbmF0aXZlOiAgIHsgdHlwZTogU3RyaW5nLCBvcHRpb25hbDogdHJ1ZSB9IC8vIGZvciBVc2VyIGRvY1xuICAgICwgdGVhY2hlcjogIHsgdHlwZTogU3RyaW5nLCBvcHRpb25hbDogdHJ1ZSB9IC8vIGZvciBHcm91cCBkb2NcbiAgICAsIGxhbmd1YWdlOiB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfSAvLyAgICAgIOKAlOKrteKAlFxuXG4gICAgLCBxX2NvZGU6ICAgeyB0eXBlOiBTdHJpbmcsIG9wdGlvbmFsOiB0cnVlIH0gLy8gY3JlYXRlZCBvbiBzZXJ2ZXJcbiAgICAvLyBpZiBxX2NvZGUgaXMgbWlzc2luZyBvciBkb2VzIG5vdCBtYXRjaCB1c2VybmFtZSwgQ2xpZW50IG1heSBiZVxuICAgIC8vIGFza2VkIHRvIHByb3ZpZGUgYSBQSU4sIGFuZCB0aGVuIGxvZ0luIHdpbGwgYmUgY2FsbGVkIGFnYWluLlxuICAgIC8vIEluIHRoYXQgY2FzZSwgc3RhdHVzIHdpbGwgYmUgc2V0IHRvIFwiUmVxdWVzdFBJTlwiIHdoaWNoIG1heSBiZVxuICAgIC8vIGFsdGVyZWQgdG8gXCJDcmVhdGVBY2NvdW50XCIgaWYgdXNlciBoYXMgbm8gUElOLCBhbmQgcGluX2dpdmVuXG4gICAgLy8gd2lsbCBiZSBzZXQgdG8gdHJ1ZVxuICAgICwgcGluX2dpdmVuOnsgdHlwZTogQm9vbGVhbiwgb3B0aW9uYWw6IHRydWUgfVxuICAgICwgc3RhdHVzIDogIHsgdHlwZTogU3RyaW5nLCBvcHRpb25hbDogdHJ1ZSB9XG5cbiAgICAvLyBTZW50IG9ubHkgaWYgbG9jYWxTdG9yYWdlIGlzIGF2YWlsYWJsZSBvbiBDbGllbnRcbiAgICAsIHVzZXJfaWQ6ICB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfVxuICAgICwgZ3JvdXBfaWQ6IHsgdHlwZTogU3RyaW5nLCBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLCBxX2NvbG9yOiAgeyB0eXBlOiBTdHJpbmcsIG9wdGlvbmFsOiB0cnVlIH1cblxuICAgIC8vIE1heSBub3QgYmUgdXNlZnVsIG9uIENsaWVudCwgc28gbm90IGF2YWlsYWJsZVxuICAgICwgcV9pbmRleDogIHsgdHlwZTogTnVtYmVyLCBvcHRpb25hbDogdHJ1ZSB9XG4gICAgfSkudmFsaWRhdGUobG9nSW5EYXRhKVxuICB9XG5cbiwgcnVuKGxvZ0luRGF0YSkge1xuICAgIG5ldyBMb2dJbihsb2dJbkRhdGEpXG5cbiAgICBsZXQgeyBzdGF0dXMgfSA9IGxvZ0luRGF0YVxuXG4gICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgIC8vIE5ldyB1c2VyXG4gICAgICBjYXNlIFwiQ3JlYXRlQWNjb3VudFwiOlxuICAgICAgICBjcmVhdGVBY2NvdW50LnJ1bihsb2dJbkRhdGEpIC8vIGZhbGwgdGhyb3VnaCB0byBjcmVhdGVHcm91cFxuICAgICAgY2FzZSBcIkNyZWF0ZUdyb3VwXCI6XG4gICAgICAgIGNyZWF0ZUdyb3VwLnJ1bihsb2dJbkRhdGEpICAgLy8gbG9nSW5EYXRhIG1vZGlmaWVkXG4gICAgICAgIHJldHVybiBsb2dJbkRhdGFcblxuICAgICAgLy8gRXhpc3RpbmcgdXNlciwgcGVyaGFwcyB3aXRoIGEgbmV3IHRlYWNoZXJcbiAgICAgIGNhc2UgXCJsb2dnZWRJblwiOlxuICAgICAgICBuZXcgSm9pbkdyb3VwKGxvZ0luRGF0YSkgLy8gZmFsbCB0aHJvdWdoOyBhY3Rpb246IGxvZ2dlZEluXG4gICAgICAgIGlmIChsb2dJbkRhdGEuc3RhdHVzID09PSBcIkNyZWF0ZUdyb3VwXCIpIHtcbiAgICAgICAgICBjcmVhdGVHcm91cC5ydW4obG9nSW5EYXRhKVxuICAgICAgICB9XG5cbiAgICAgIC8vIE5hbWUgdGhhdCBtYXRjaGVzIGFuIGV4aXN0aW5nIHVzZXIsIGJ1dCBpbnZhbGlkIHFfY29kZVxuICAgICAgY2FzZSBcIlJlcXVlc3RQSU5cIjpcbiAgICAgICAgcmV0dXJuIGxvZ0luRGF0YVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBcIlVua25vd24gYWN0aW9uIGluIHZkdm95b20ubG9nSW46ICdcIiArIGFjdGlvbiArIFwiJ1wiXG4gICAgfVxuICB9XG59XG5cblxuXG4vKiogTG9ncyBhIHRlYWNoZXIncyBkZXZpY2UgaW50byBpdHMgR3JvdXAgYW5kIFVzZXIgcmVjb3Jkc1xuICpcbiAqICBBXG4gKi9cbmV4cG9ydCBjb25zdCBsb2dJblRlYWNoZXIgPSB7XG4gIG5hbWU6ICd2ZHZveW9tLmxvZ0luVGVhY2hlcidcblxuLCBjYWxsKGxvZ0luRGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2xvZ0luRGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUobG9nSW5EYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBpZDogICAgICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgZF9jb2RlOiAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICB9KS52YWxpZGF0ZShsb2dJbkRhdGEpXG4gIH1cblxuLCBydW4obG9nSW5EYXRhKSB7XG4gICAgbmV3IExvZ0luVGVhY2hlcihsb2dJbkRhdGEpXG4gICAgcmV0dXJuIGxvZ0luRGF0YVxuICB9XG59XG5cblxuXG4vKiogTG9ncyBhIHRlYWNoZXIncyBkZXZpY2UgaW50byBpdHMgR3JvdXAgYW5kIFVzZXIgcmVjb3Jkc1xuICpcbiAqICBBXG4gKi9cbmV4cG9ydCBjb25zdCB0b2dnbGVBY3RpdmF0aW9uID0ge1xuICBuYW1lOiAndmR2b3lvbS50b2dnbGVBY3RpdmF0aW9uJ1xuXG4sIGNhbGwoZ3JvdXBEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbZ3JvdXBEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShncm91cERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIF9pZDogICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgZF9jb2RlOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBhY3RpdmU6IHsgdHlwZTogQm9vbGVhbiB9XG4gICAgfSkudmFsaWRhdGUoZ3JvdXBEYXRhKVxuICB9XG5cbiwgcnVuKGdyb3VwRGF0YSkge1xuICAgIG5ldyBUb2dnbGVBY3RpdmF0aW9uKGdyb3VwRGF0YSlcbiAgICByZXR1cm4gZ3JvdXBEYXRhXG4gIH1cbn1cblxuXG5cbi8qKiBMb2dzIGEgdXNlcidzIGRldmljZSBvdXQgb2YgaXRzIEdyb3VwIGFuZCBVc2VyIHJlY29yZHNcbiAqXG4gKlxuICovXG5leHBvcnQgY29uc3QgbG9nT3V0ID0ge1xuICBuYW1lOiAndmR2b3lvbS5sb2cnXG5cbiwgY2FsbChsb2dPdXREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbbG9nT3V0RGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUobG9nT3V0RGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgaWQ6ICAgICAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICAgIC8vIDwgNSBjaGFycyA9IHRlYWNoZXI7ID4gNSBjaGFycyA9IHVzZXJcbiAgICAgIC8vICd4eHh4JyA9PiA0NTY5NzYgY29tYmluYXRpb25zXG4gICAgLCBkX2NvZGU6ICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICAgLy8gQSBUZWFjaGVyIG1pZ2h0IGxvZyBvdXQgd2l0aG91dCBiZWluZyBwYXJ0IG9mIGEgZ3JvdXBcbiAgICAvLyAsIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfVxuICAgIH0pLnZhbGlkYXRlKGxvZ091dERhdGEpXG4gIH1cblxuLCBydW4obG9nT3V0RGF0YSkge1xuICAgIG5ldyBMZWF2ZUdyb3VwKGxvZ091dERhdGEpIC8vIGFkZHMgLmxlZnRHcm91cCA9IFs8aWQ+LCAuLi5dXG4gICAgbmV3IExvZ091dChsb2dPdXREYXRhKVxuXG4gICAgcmV0dXJuIGxvZ091dERhdGFcbiAgfVxufVxuXG5cblxuLyoqIEFsbG93cyB0aGUgbWFzdGVyIHRvIHNoYXJlIHZpZXdfc2l6ZSB3aXRoIHNsYXZlc1xuICovXG5leHBvcnQgY29uc3Qgc2hhcmUgPSB7XG4gIG5hbWU6ICd2ZHZveW9tLnNoYXJlJ1xuXG4sIGNhbGwoc2hhcmVEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbc2hhcmVEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShzaGFyZURhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIF9pZDogIHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIGtleTogIHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIGRhdGE6IFNpbXBsZVNjaGVtYS5vbmVPZihcbiAgICAgICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICAgLCB7IHR5cGU6IE9iamVjdCwgYmxhY2tib3g6IHRydWUgfVxuICAgICAgKVxuICAgIH0pLnZhbGlkYXRlKHNoYXJlRGF0YSlcbiAgfVxuXG4sIHJ1bihzaGFyZURhdGEpIHtcbiAgICBjb25zdCB7IF9pZCwga2V5LCBkYXRhIH0gPSBzaGFyZURhdGFcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZCB9XG4gICAgY29uc3Qgc2V0ICAgID0geyAkc2V0OiB7IFtrZXldOiBkYXRhIH0gfVxuICAgIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHNldClcblxuICAgIC8vIGNvbnNvbGUubG9nKCBzaGFyZURhdGEsIEpTT04uc3RyaW5naWZ5KHNlbGVjdCksIEpTT04uc3RyaW5naWZ5KHNldCkpXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3Qgc2V0UGFnZSA9IHtcbiAgbmFtZTogJ3Zkdm95b20uc2V0UGFnZSdcblxuLCBjYWxsKHNldFBhZ2VEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbc2V0UGFnZURhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKHNldFBhZ2VEYXRhKSB7XG4gICAgLy8gVE9ETzpcbiAgICAvLyBFbnN1cmUgdGhhdCBlaXRoZXIgdmlldyBvciBwYXRoIChvciBib3RoKSBhcmUgcHJlc2VudFxuICAgIC8vIEVuc3VyZSB0aGF0IGluZGV4IChpZiBwcmVzZW50KSBpcyBub3QgZ3JlYXRlciB0aGFuXG4gICAgLy8gICBwYXRoLmxlbmd0aCAtIDFcblxuICAgIGNvbnN0IHRhZ1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEub25lT2YoXG4gICAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCB7IHR5cGU6IEFycmF5IH1cbiAgICApXG5cbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIGdyb3VwX2lkOiAgICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgcGFnZTogICAgICAgICB7IHR5cGU6IE9iamVjdCB9XG4gICAgLCBcInBhZ2Uudmlld1wiOiAgeyB0eXBlOiBTdHJpbmcsICBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLCBcInBhZ2UucGF0aFwiOiAgeyB0eXBlOiBTdHJpbmcsICBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLCBcInBhZ2UuaW5kZXhcIjogeyB0eXBlOiBOdW1iZXIsICBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLy8gLCBcInBhZ2UuYWN0aXZpdHlcIjogeyB0eXBlOiBTdHJpbmcsICBvcHRpb25hbDogdHJ1ZSB9XG4gICAgLCBcInBhZ2UudGFnXCI6ICAgeyB0eXBlOiB0YWdTY2hlbWEsIG9wdGlvbmFsOiB0cnVlIH1cbiAgICAsIFwicGFnZS50YWcuJFwiOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBcInBhZ2UuZGF0YVwiOiAge1xuICAgICAgICB0eXBlOiBPYmplY3RcbiAgICAgICwgb3B0aW9uYWw6IHRydWVcbiAgICAgICwgYmxhY2tib3g6IHRydWVcbiAgICAgIH1cbiAgICB9KS52YWxpZGF0ZShzZXRQYWdlRGF0YSlcbiAgfVxuXG4sIHJ1bihzZXRQYWdlRGF0YSkge1xuICAgIGNvbnN0IHsgZ3JvdXBfaWQ6IF9pZCwgcGFnZSB9ID0gc2V0UGFnZURhdGFcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZCB9XG4gICAgY29uc3Qgc2V0ICAgID0geyAkc2V0OiB7IHBhZ2UgfSB9XG4gICAgR3JvdXAudXBkYXRlKHNlbGVjdCwgc2V0KVxuXG4gICAgLy8gY29uc29sZS5sb2coXG4gICAgLy8gICAnZGIuZ3JvdXAudXBkYXRlKCdcbiAgICAvLyArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAvLyArIFwiLCBcIlxuICAgIC8vICsgSlNPTi5zdHJpbmdpZnkoc2V0KVxuICAgIC8vICsgXCIpXCJcbiAgICAvLyAvLyAsIHNldFBhZ2VEYXRhXG4gICAgLy8gKVxuICB9XG59XG5cblxuZXhwb3J0IGNvbnN0IHNldEluZGV4ID0ge1xuICBuYW1lOiBcInZkdm95b20uc2V0SW5kZXhcIlxuXG4sIGNhbGwoc2V0SW5kZXhEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbc2V0SW5kZXhEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShzZXRJbmRleERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBpbmRleDogICAgeyB0eXBlOiBOdW1iZXIgfVxuICAgIH0pLnZhbGlkYXRlKHNldEluZGV4RGF0YSlcbiAgfVxuXG4sIHJ1bihzZXRJbmRleERhdGEpIHtcbiAgICBjb25zdCB7IGdyb3VwX2lkOiBfaWQsIGluZGV4IH0gPSBzZXRJbmRleERhdGFcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZCB9XG4gICAgY29uc3Qgc2V0ID0geyAkc2V0OiB7IFwicGFnZS5pbmRleFwiOiBpbmRleCB9IH1cbiAgICBHcm91cC51cGRhdGUoc2VsZWN0LCBzZXQpXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3QgYWRkVG9GbHVlbmN5ID0ge1xuICBuYW1lOiAndm9jYWJ1bGFyeS5hZGRUb0ZsdWVuY3knXG5cbiwgY2FsbChmbHVlbmN5SXRlbUFycmF5LCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbZmx1ZW5jeUl0ZW1BcnJheV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUoZmx1ZW5jeUl0ZW1BcnJheSkge1xuICAgIGZsdWVuY3lJdGVtQXJyYXkuZm9yRWFjaCggaXRlbSA9PiB7XG4gICAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgICAgICBwaHJhc2VfaWQ6ICB7IHR5cGU6IFN0cmluZyB9XG4gICAgICAgICwgdXNlcl9pZDogICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICAgICAsIGdyb3VwX2lkOiAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICAgICAgLCBuZXh0X3NlZW46ICB7IHR5cGU6IE51bWJlciB9XG4gICAgICB9KS52YWxpZGF0ZShpdGVtKVxuICAgIH0pXG4gIH1cblxuLCBydW4oZmx1ZW5jeUl0ZW1BcnJheSkge1xuICAgIGNvbnN0IGZpbGxlcnMgPSB7XG4gICAgICB0aW1lc19zZWVuOiAwXG4gICAgLCBmaXJzdF9zZWVuOiAwXG4gICAgLCBsYXN0X3NlZW46ICAwXG4gICAgLCBmbG9wczogICAgICA0XG4gICAgLCBzY29yZTogICAgICAwXG4gICAgLCBzcGFjaW5nOiAgICA1IC8vIHNob3cgNSBvdGhlcnMgYmVmb3JlIGEgcmVwZWF0IHwg4omIIDEgbWludXRlXG4gICAgLy8gLCByaWdodDogICAgICA1XG4gICAgLy8gLCB3cm9uZzogICAgICAxLzJcbiAgICAsIGNvbGxlY3Rpb246IFwiVm9jYWJ1bGFyeVwiXG4gICAgLCBsZXZlbDogICAgICBcIlRPRE9cIlxuICAgIH1cblxuICAgIGZsdWVuY3lJdGVtQXJyYXkuZm9yRWFjaCggZmx1ZW5jeU9iamVjdCA9PiB7XG4gICAgICBmbHVlbmN5T2JqZWN0ID0gey4uLmZsdWVuY3lPYmplY3QsIC4uLmZpbGxlcnN9XG4gICAgICBGbHVlbmN5Lmluc2VydChmbHVlbmN5T2JqZWN0KVxuICAgIH0pXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3Qgc2V0Rmx1ZW5jeSA9IHtcbiAgbmFtZTogXCJ2ZHZveW9tLnNldEZsdWVuY3lcIlxuXG4sIGNhbGwoc2V0Rmx1ZW5jeURhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtzZXRGbHVlbmN5RGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUoc2V0Rmx1ZW5jeURhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIHVzZXJfaWQ6ICAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgZ3JvdXBfaWQ6ICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBjb3JyZWN0OiAgIHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9XG4gICAgLCB0aW1lU3RhbXA6IHsgdHlwZTogTnVtYmVyIH1cbiAgICB9KS52YWxpZGF0ZShzZXRGbHVlbmN5RGF0YSlcbiAgfVxuXG4sIHJ1bihzZXRGbHVlbmN5RGF0YSkge1xuICAgIG5ldyBTY2hlZHVsZXIoc2V0Rmx1ZW5jeURhdGEpXG4gIH1cbn1cblxuXG5cbi8vIFRvIHJlZ2lzdGVyIGEgbmV3IG1ldGhvZCB3aXRoIE1ldGVvcidzIEREUCBzeXN0ZW0sIGFkZCBpdCBoZXJlXG5jb25zdCBtZXRob2RzID0gW1xuICBjcmVhdGVBY2NvdW50XG4gICwgY3JlYXRlR3JvdXBcbiAgLCBsb2dJblxuICAsIGxvZ091dFxuICAsIGxvZ0luVGVhY2hlclxuICAsIHRvZ2dsZUFjdGl2YXRpb25cbiAgLCBzaGFyZVxuICAsIHNldFBhZ2VcbiAgLCBzZXRJbmRleFxuICAsIGFkZFRvRmx1ZW5jeVxuICAsIHNldEZsdWVuY3lcbl1cblxuXG5cbm1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1ldGhvZC52YWxpZGF0ZS5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgICByZXR1cm4gbWV0aG9kLnJ1bi5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgfVxuICB9KVxufSkiLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9tZXRob2RzL2Fzc2V0cy5qc1xuICpcbiAqL1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnXG5cbmltcG9ydCBJbXBvcnRBc3NldHMgZnJvbSAnLi9hc3NldHMvaW1wb3J0QXNzZXRzJ1xuXG5pbXBvcnQgY29sbGVjdGlvbnMgZnJvbSAnLi4vY29sbGVjdGlvbnMvcHVibGlzaGVyJ1xuY29uc3QgeyBHcm91cCB9ID0gY29sbGVjdGlvbnNcbi8vIHVzZWQgYnkgc2hhcmUsIHNldFBhZ2UgYW5kIHNldEluZGV4XG5cblxuLyoqIENyZWF0ZXMgb3IgdXBkYXRlcyBhIFVzZXIgcmVjb3JkIGFmdGVyIHByb2ZpbGluZ1xuICogIENhbGxpbmcgdGhlIG1ldGhvZCBhIHNlY29uZCB0aW1lIHJldXNlcyB0aGUgZXhpc3RpbmcgcmVjb3Jkc1xuICovXG5leHBvcnQgY29uc3QgaW1wb3J0Rm9sZGVyID0ge1xuICBuYW1lOiAnYXNzZXRzLmltcG9ydEZvbGRlcidcblxuLCBjYWxsKGltcG9ydERhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtpbXBvcnREYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShpbXBvcnREYXRhKSB7XG4gICAgLy8gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgLy8gICB1c2VybmFtZTogeyB0eXBlOiBTdHJpbmcgfVxuICAgIC8vICwgbmF0aXZlOiAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICAvLyAsIHRlYWNoZXI6ICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLy8gLCBsYW5ndWFnZTogeyB0eXBlOiBTdHJpbmcgfVxuICAgIC8vICwgZF9jb2RlOiAgIHsgdHlwZTogU3RyaW5nIH1cblxuICAgIC8vIC8vIGFjdGlvbiB3aWxsIGhhdmUgYmVlbiBhZGRlZCBpZiB0aGUgb3JpZ2luYWwgY2FsbCB3YXMgdG8gbG9nSW5cbiAgICAvLyAsIGFjdGlvbjogICB7IHR5cGU6IFN0cmluZywgb3B0aW9uYWw6IHRydWUgfVxuICAgIC8vIH0pLnZhbGlkYXRlKGltcG9ydERhdGEpXG4gIH1cblxuLCBydW4oaW1wb3J0RGF0YSkge1xuICAgIG5ldyBJbXBvcnRBc3NldHMoaW1wb3J0RGF0YSlcbiAgfVxufVxuXG5cbi8vIFRvIHJlZ2lzdGVyIGEgbmV3IG1ldGhvZCB3aXRoIE1ldGVvcidzIEREUCBzeXN0ZW0sIGFkZCBpdCBoZXJlXG5jb25zdCBtZXRob2RzID0gW1xuICBpbXBvcnRGb2xkZXJcbl1cblxubWV0aG9kcy5mb3JFYWNoKG1ldGhvZCA9PiB7XG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICBbbWV0aG9kLm5hbWVdOiBmdW5jdGlvbiAoYXJncykge1xuICAgICAgbWV0aG9kLnZhbGlkYXRlLmNhbGwodGhpcywgYXJncylcbiAgICAgIHJldHVybiBtZXRob2QucnVuLmNhbGwodGhpcywgYXJncylcbiAgICB9XG4gIH0pXG59KSIsIi8qKlxuICogL2ltcG9ydHMvYXBpL21ldGhvZHMvbWludC5qc1xuICpcbiAqICoqIERPwqBOT1TCoEVESVTCoFRISVPCoFNDUklQVCAqKlxuICogSVTCoElTwqBHRU5FUkFURUTCoEFVVE9NQVRJQ0FMTFlcbiAqwqBFQUNIwqBUSU1FIFRIRcKgU0VSVkVSwqBSRVNUQVJUU1xuICpcbiAqIE1PRElGWcKgVEhJU8KgRklMRcKgSU5TVEVBRDpcbiAqICAvc2VydmVyL21pbnRlcnMvbWV0aG9kcy5qc1xuICogKioqKiAqKioqICoqKiogKioqKiAqKioqICoqKipcbiAqXG4gKiBUaGlzIHNjcmlwdCBnYXRoZXJzIHRvZ2V0aGVyIGRldGFpbHMgb2YgYWxsIHRoZSBtZXRob2RzXG4gKiBmcm9tICcuL2FkbWluLmpzJyBhbmQgdGhlIHZhcmlvdXMgbWV0aG9kcy5qcyBmaWxlcyBmb3VuZFxuICogaW4gdGhlICcvcHVibGljL2FjdGl2aXRpZXMvPEFjdGl2aXR5TmFtZT4vJyBmb2xkZXJzLlxuICpcbiAqIFRoZSBtZXRob2RzIGV4cG9ydGVkIGhlcmUgYXJlIGltcG9ydGVkIGJ5ICcvc2VydmVyL21haW4uanMnXG4gKiBhbmQgdmFyaW91cyBjbGllbnQtc2lkZSBzY3JpcHRzLlxuICovXG5cbmltcG9ydCAqIGFzIGFkbWluIGZyb20gJy4vYWRtaW4nXG5pbXBvcnQgKiBhcyBhc3NldHMgZnJvbSAnLi9hc3NldHMnXG5pbXBvcnQgKsKgYXMgZHJhZyBmcm9tICcuLi8uLi9wdWJsaWMvQWN0aXZpdGllcy9EcmFnL21ldGhvZHMuanMnXG5pbXBvcnQgKsKgYXMgZmxhc2ggZnJvbSAnLi4vLi4vcHVibGljL0FjdGl2aXRpZXMvRmxhc2gvbWV0aG9kcy5qcydcbmltcG9ydCAqwqBhcyBzcGlyYWwgZnJvbSAnLi4vLi4vcHVibGljL0FjdGl2aXRpZXMvU3BpcmFsL21ldGhvZHMuanMnXG5pbXBvcnQgKsKgYXMgdm9jYWJ1bGFyeSBmcm9tICcuLi8uLi9wdWJsaWMvQWN0aXZpdGllcy9Wb2NhYnVsYXJ5L21ldGhvZHMuanMnXG5cbmV4cG9ydCBjb25zdCBtZXRob2RzID0ge1xuICAuLi5hZG1pblxuLCAuLi5hc3NldHNcbiwgLi4uZHJhZ1xuLCAuLi5mbGFzaFxuLCAuLi5zcGlyYWxcbiwgLi4udm9jYWJ1bGFyeVxufVxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG4vLyBFeHBvcnQgY29sbGVjdGlvbnMgaW5kaXZpZHVhbGx5OiBpbXBvcnQgeyBOYW1lIH0gZnJvbSAnLi4uJ1xuY29uc3QgQ2hhdCAgICAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhdCcpXG5jb25zdCBVc2VyICAgICA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1c2VyJylcbmNvbnN0IEdyb3VwICAgID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwJylcbmNvbnN0IEZsdWVuY3kgID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZsdWVuY3knKVxuY29uc3QgVUlUZXh0ICAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndWl0ZXh0JylcbmNvbnN0IENvdW50ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvdW50ZXJzJylcbmNvbnN0IFRlYWNoZXIgID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RlYWNoZXInKVxuY29uc3QgQWN0aXZpdHkgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYWN0aXZpdHknKVxuXG5cbi8vIERlZmluZSB0aGUgcXVlcmllcyB0aGF0IHdpbGwgYmUgdXNlZCB0byBwdWJsaXNoIHRoZXNlIGNvbGxlY3Rpb25zXG4vLyBpbiB0aGUgc3RhbmRhcmQgd2F5XG5leHBvcnQgY29uc3QgcHVibGlzaFF1ZXJpZXMgPSB7XG4gIENoYXQ6ICAgICAge31cbiwgVXNlcjogICAgICB7fVxuLCBHcm91cDogICAgIHt9XG4sIEZsdWVuY3k6ICAge31cbiwgVUlUZXh0OiAgICB7fVxuLCBDb3VudGVyczogIHt9XG4sIFRlYWNoZXI6ICAgeyAkb3I6IFtcbiAgICAgICAgICAgICAgICAgIHsgZmlsZTogeyAkZXhpc3RzOiBmYWxzZSB9IH1cbiAgICAgICAgICAgICAgICAsIHsgZmlsZTogeyAkbmU6IFwieHh4eFwiIH0gfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgfVxuLCBBY3Rpdml0eToge31cbn1cblxuLy8gRXhwb3J0IGEgY29sbGVjdGlvbnMgbWFwXG5leHBvcnQgY29uc3QgY29sbGVjdGlvbnMgPSB7XG4gIENoYXRcbiwgVXNlclxuLCBHcm91cFxuLCBGbHVlbmN5XG4sIFVJVGV4dFxuLCBDb3VudGVyc1xuLCBUZWFjaGVyXG4sIEFjdGl2aXR5XG59XG4iLCIvKipcbiAqICoqIERPwqBOT1TCoEVESVTCoFRISVPCoFNDUklQVCAqKlxuICogSVTCoElTwqBHRU5FUkFURUTCoEFVVE9NQVRJQ0FMTFlcbiAqwqBFQUNIwqBUSU1FIFRIRcKgU0VSVkVSwqBSRVNUQVJUU1xuICpcbiAqIE1PRElGWcKgVEhJU8KgRklMRcKgSU5TVEVBRDpcbiAqIC9zZXJ2ZXIvbWludGVycy9jb2xsZWN0aW9ucy5qc1xuICogKioqKiAqKioqICoqKioqKioqKiogKioqKiAqKioqXG4gKlxuICogVGhpcyBzY3JpcHQgY3JlYXRlcyBhIE1vbmdvRELCoGNvbGxlY3Rpb24gbmFtZWQgYWZ0ZXIgZWFjaCBvZiB0aGVcbiAqIGZvbGRlcnMgZm91bmQgYXQgJy9wdWJsaWMvY29sbGVjdGlvbnMvJy5cbiAqXG4gKiBUaGUgY29sbGVjdGlvbnMgYW5kIHB1Ymxpc2ggcXVlcmllcyBleHBvcnRlZCBoZXJlIGFyZVxuICogaW1wb3J0ZWQgYnkgJy4vcHVibGlzaGVyLmpzJywgd2hpY2ggcHVibGlzaGVzIHRoZW0gYWxsLlxuICovXG5cblxuXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjb2xsZWN0aW9ucyBhcyBhZG1pbkNvbGxlY3Rpb25zXG4gICAgICAgLCBwdWJsaXNoUXVlcmllcyBhcyBhZG1pblF1ZXJpZXNcbiAgICAgICB9IGZyb20gJy4vYWRtaW4nXG5cblxuY29uc3QgQ2xvemUgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2xvemUnKVxuY29uc3QgTmltID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ25pbScpXG5jb25zdCBTcGlyYWwgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc3BpcmFsJylcbmNvbnN0IFN0b3JpZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc3RvcmllcycpXG5jb25zdCBWb2NhYnVsYXJ5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZvY2FidWxhcnknKVxuXG5cbmV4cG9ydCBjb25zdCBjb2xsZWN0aW9ucyA9IHtcbiAgLi4uYWRtaW5Db2xsZWN0aW9uc1xuLCBDbG96ZVxuLCBOaW1cbiwgU3BpcmFsXG4sIFN0b3JpZXNcbiwgVm9jYWJ1bGFyeVxufVxuXG5cbmV4cG9ydCBjb25zdCBwdWJsaXNoUXVlcmllcyA9IHtcbiAgLi4uYWRtaW5RdWVyaWVzXG4sIFwiQ2xvemVcIjoge31cbiwgXCJOaW1cIjoge31cbiwgXCJTcGlyYWxcIjoge31cbiwgXCJTdG9yaWVzXCI6IHt9XG4sIFwiVm9jYWJ1bGFyeVwiOiB7fVxufSIsIi8qKlxuICogL2ltcG9ydHMvYXBpL2NvbGxlY3Rpb25zL3BvaW50cy5qc1xuICpcbiAqIFRoaXMgc2NyaXB0IG1hbmFnZXMgdGhlIFBvaW50cyBjb2xsZWN0aW9uLCB3aGljaCBzaGFyZXMgdGhlXG4gKiBwb3NpdGlvbnMgb2YgZWFjaCB1c2VyJ3MgbW91c2Ugb3IgdG91Y2ggYWN0aW9ucy4gVGhlIGNvbGxlY3Rpb25cbiAqIGJ5cGFzc2VzIHRoZSBNb25nb0RCIGRhdGFiYXNlLiBBcyBhIHJlc3VsdCwgaXQgY2Fubm90IHVzZSB0aGVcbiAqIGJ1aWx0LWluIGNvbGxlY3Rpb24gbWV0aG9kcyBzdWNoIGFzIGluc2VydCgpIGFuZCByZW1vdmUoKS5cbiAqXG4gKiBQb2ludHMgaXMgZXhwb3J0ZWQgZGlmZmVyZW50bHkgb24gdGhlIHNlcnZlciBhbmQgb24gdGhlIGNsaWVudC5cbiAqIFRoZSBzZXJ2ZXIgdXNlcyBhIG51bGwgY29ubmVjdGlvbiB0byBwcmV2ZW50IGl0IGZyb20gc3luY2hyb25pemluZ1xuICogd2l0aCBNb25nb0RCLCBidXQgdGhlIGNsaWVudCBuZWVkcyBpdHMgZGVmYXVsdCBjb25uZWN0aW9uIGluIG9yZGVyXG4gKiB0byBjb21tdW5pY2F0ZSB3aXRoIHRoZSBzZXJ2ZXIgKHsgY29ubmVjdGlvbjogdW5kZWZpbmVkIH0pXG4gKlxuICogU2VlLi4uXG4gKiAgIGh0dHA6Ly9yaWNoc2lsdi5naXRodWIuaW8vbWV0ZW9yL21ldGVvci1sb3ctbGV2ZWwtcHVibGljYXRpb25zL1xuICogLi4uIGZvciBtb3JlIGRldGFpbHMuXG4gKlxuICogSW1wb3J0ZWQgYnk6XG4gKiAgIFNlcnZlcjogL3NlcnZlci9tYWluLmpzXG4gKiAgIENsaWVudDogL2ltcG9ydHMvdWkvUG9pbnRzLmpzeFxuICovXG5cblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJ1xuXG5cbi8vLy8vIENPTExFQ1RJT07CoC8vLy8gQ09MTEVDVElPTsKgLy8vLyBDT0xMRUNUSU9OwqAvLy8vIENPTExFQ1RJT07CoC8vLy8vXG5cbmxldCBQb2ludHMgLy8gTW9uZ29EQi1mcmVlIGNvbGxlY3Rpb25cblxuXG5cbi8vLyBNRVRIT0RTwqAvLyBNRVRIT0RTwqAvLyBNRVRIT0RTwqAvLyBNRVRIT0RTwqAvLyBNRVRIT0RTwqAvLyBNRVRIT0RTwqAvLy9cblxuXG5leHBvcnQgY29uc3QgY3JlYXRlVHJhY2tlciA9IHtcbiAgbmFtZTogXCJwb2ludHMuY3JlYXRlVHJhY2tlclwiXG5cbiwgY2FsbCh0cmFja2VyRGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW3RyYWNrZXJEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZSh0cmFja2VyRGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgX2lkOiAgICAgIHsgdHlwZTogU3RyaW5nIH0gLy8gZF9jb2RlIGZvciB1c2VyfHRlYWNoZXIncyBkZXZpY2VcbiAgICAsIGNvbG9yOiAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBncm91cF9pZDogeyB0eXBlOiBTdHJpbmcgfVxuICAgIH0pLnZhbGlkYXRlKHRyYWNrZXJEYXRhKVxuICB9XG5cbiAgLyoqIENyZWF0ZSBhIGRvY3VtZW50IGZvciB0aGUgY3VycmVudCBVc2VyIGluIGdyb3VwIGdyb3VwX2lkXG4gICAqXG4gICAqICBUaGUgX2lkIG9mIHRoZSBuZXcgZG9jdW1lbnQgd2lsbCBiZSBzdG9yZWQgaW4gdGhlIENsaWVudC4gRWFjaFxuICAgKiAgdGltZSB0aGUgVXNlciBtb3ZlcyB0aGUgbW91c2Ugb3IgZHJhZ3MgdGhlIG1vdXNlIG9yIGEgdG91Y2hcbiAgICogIHBvaW50IG9uIHRoZSBzY3JlZW4sIHRoZSB4LCB5IGFuZCBvdGhlciBwcm9wZXJ0aWVzIG9mIHRoaXNcbiAgICogIGRvY3VtZW50IHdpbGwgYmUgdXBkYXRlZC4gQWxsIFVzZXJzIGFuZCBUZWFjaGVycyBjb25uZWN0ZWQgdG9cbiAgICogIGdyb3VwIGdyb3VwX2lkIHdpbGwgYmUgYWJsZSB0byBkaXNwbGF5IHRoZSBjdXJzb3IvdG91Y2ggcG9zaXRpb25cbiAgICogIG9mIHRoaXMgVXNlciBvbiB0aGVpciBzY3JlZW4uXG4gICAqL1xuXG4sIHJ1bih0cmFja2VyRGF0YSkge1xuICAgIGNvbnN0IF9pZCA9IFBvaW50cy5pbnNlcnQoIHRyYWNrZXJEYXRhIClcblxuICAgIHJldHVybiBfaWQgLy8gc2hvdWxkIGJlIHNhbWUgYXMgdHJhY2tlckRhdGEuX2lkXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3QgdXBkYXRlID0ge1xuICBuYW1lOiBcInBvaW50cy51cGRhdGVcIlxuXG4sIGNhbGwocG9pbnREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbcG9pbnREYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShwb2ludERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIF9pZDogICAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBncm91cF9pZDogeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgeDogICAgICAgIHsgdHlwZTogTnVtYmVyIH1cbiAgICAsIHk6ICAgICAgICB7IHR5cGU6IE51bWJlciB9XG4gICAgLCBhY3RpdmU6ICAgeyB0eXBlOiBCb29sZWFuIH1cbiAgICAsIHRvdWNoZW5kOiB7IHR5cGU6IEJvb2xlYW4gfVxuICAgICwgdG91Y2g6ICAgIHsgdHlwZTogT2JqZWN0LCBvcHRpb25hbDogdHJ1ZSwgYmxhY2tib3g6IHRydWUgfVxuICAgIH0pLnZhbGlkYXRlKHBvaW50RGF0YSlcblxuICAgIGlmIChwb2ludERhdGEudG91Y2gpIHtcbiAgICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgICByYWRpdXNYOiAgICAgICB7IHR5cGU6IE51bWJlciB9XG4gICAgICAsIHJhZGl1c1k6ICAgICAgIHsgdHlwZTogTnVtYmVyIH1cbiAgICAgICwgcm90YXRpb25BbmdsZTogeyB0eXBlOiBOdW1iZXIgfVxuICAgICAgfSkudmFsaWRhdGUocG9pbnREYXRhLnRvdWNoKVxuICAgIH1cbiAgfVxuXG4sIHJ1bihwb2ludERhdGEpIHsgLy8ge19pZCwgZ3JvdXBfaWQsIHgsIHksIGFjdGl2ZSB9XG4gICAgY29uc3QgX2lkID0gcG9pbnREYXRhLl9pZFxuICAgIFBvaW50cy51cGRhdGUoeyBfaWQgfSwgeyAkc2V0OiBwb2ludERhdGEgfSkgLy8gbm90IF9pZCwgbnVtYmVyXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZGVzdHJveVRyYWNrZXIgPSB7XG4gIG5hbWU6IFwicG9pbnRzLmRlc3Ryb3lUcmFja2VyXCJcblxuLCBjYWxsKHRyYWNrZXJEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbdHJhY2tlckRhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKHRyYWNrZXJEYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBfaWQ6ICAgICAgeyB0eXBlOiBTdHJpbmcgfSAvLyBkX2NvZGUgZm9yIHVzZXJ8dGVhY2hlcidzIGRldmljZVxuICAgICwgZ3JvdXBfaWQ6IHsgdHlwZTogU3RyaW5nIH1cbiAgICB9KS52YWxpZGF0ZSh0cmFja2VyRGF0YSlcbiAgfVxuXG4sIHJ1bih0cmFja2VyRGF0YSkge1xuICAgIGNvbnN0IHsgZ3JvdXBfaWQgfSA9IHRyYWNrZXJEYXRhXG4gICAgY29uc3QgcmVzdWx0ID0gUG9pbnRzLnJlbW92ZSggdHJhY2tlckRhdGEgKVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJQb2ludHMucmVtb3ZlKFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHRyYWNrZXJEYXRhKVxuICAgIC8vICAgICAgICAgICAgKyBcIikgPT5cIlxuICAgIC8vICAgICAgICAgICAgKyBcInJlc3VsdDpcIiwgcmVzdWx0KVxuXG4gICAgY29uc3QgbWVtYmVycyA9IFBvaW50cy5maW5kKHsgZ3JvdXBfaWQgfSwge30pLmZldGNoKClcbiAgICBpZiAobWVtYmVycy5sZW5ndGggPCAyKSB7XG4gICAgICBQb2ludHMucmVtb3ZlKHsgZ3JvdXBfaWQgfSlcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxufVxuXG5cbmV4cG9ydCBjb25zdCBjbGVhclBvaW50cyA9IHtcbiAgbmFtZTogXCJwb2ludHMuY2xlYXJcIlxuXG4sIGNhbGwodHJhY2tlckRhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFt0cmFja2VyRGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUoKSB7fVxuXG4sIHJ1bih0cmFja2VyRGF0YSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFBvaW50cy5yZW1vdmUoIHt9IClcblxuICAgIC8vIGNvbnNvbGUubG9nKFwiUG9pbnRzLnJlbW92ZSgge30gKSA9PlwiXG4gICAgLy8gICAgICAgICAgICArIFwicmVzdWx0OlwiLCByZXN1bHQpXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG59XG5cblxuY29uc3QgbWV0aG9kcyA9IFtcbiAgY3JlYXRlVHJhY2tlclxuLCB1cGRhdGVcbiwgZGVzdHJveVRyYWNrZXJcbiwgY2xlYXJQb2ludHMgLy8gRGVidWcgb25seVxuXVxuXG5cbm1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1ldGhvZC52YWxpZGF0ZS5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgICByZXR1cm4gbWV0aG9kLnJ1bi5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgfVxuICB9KVxufSlcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIFBvaW50cyA9IG5ldyBNZXRlb3IuQ29sbGVjdGlvbigncG9pbnRzJywgeyBjb25uZWN0aW9uOiBudWxsIH0pXG5cbiAgTWV0ZW9yLnB1Ymxpc2goJ292ZXJEUFAnLCBmdW5jdGlvbigpe1xuICAgIC8vIGBwdWJsaXNoYCByZXF1aXJlcyB0aGUgY2xhc3NpYyBmdW5jdGlvbigpIHt9IHN5bnRheCBmb3IgYHRoaXNgXG4gICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gdGhpc1xuXG4gICAgY29uc3QgcHVibGljYXRpb24gPSBQb2ludHMuZmluZCh7fSkub2JzZXJ2ZUNoYW5nZXMoe1xuICAgICAgYWRkZWQ6IGZ1bmN0aW9uIChpZCwgZmllbGRzKSB7XG4gICAgICAgIHN1YnNjcmlwdGlvbi5hZGRlZChcInBvaW50c1wiLCBpZCwgZmllbGRzKVxuICAgICAgfSxcbiAgICAgIGNoYW5nZWQ6IGZ1bmN0aW9uKGlkLCBmaWVsZHMpIHtcbiAgICAgICAgc3Vic2NyaXB0aW9uLmNoYW5nZWQoXCJwb2ludHNcIiwgaWQsIGZpZWxkcylcbiAgICAgIH0sXG4gICAgICByZW1vdmVkOiBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgc3Vic2NyaXB0aW9uLnJlbW92ZWQoXCJwb2ludHNcIiwgaWQpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHN1YnNjcmlwdGlvbi5yZWFkeSgpXG5cbiAgICBzdWJzY3JpcHRpb24ub25TdG9wKCgpID0+IHtcbiAgICAgIHB1YmxpY2F0aW9uLnN0b3AoKVxuICAgIH0pXG4gIH0pXG59XG5cblxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICBQb2ludHMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oJ3BvaW50cycpIC8vIGNvbm5lY3Rpb24gdW5kZWZpbmVkXG4gIE1ldGVvci5zdWJzY3JpYmUoJ292ZXJEUFAnKVxuXG4gIC8vIFJFTU9WRcKgRGVidWcgT25seSAvLyBSRU1PVkXCoERlYnVnIE9ubHkgLy8gUkVNT1ZFwqBEZWJ1ZyBPbmx5IC8vXG4gIHdpbmRvdy5Qb2ludHMgPSBQb2ludHNcbiAgd2luZG93LmNsZWFyUG9pbnRzID0gY2xlYXJQb2ludHNcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBQb2ludHMiLCIvKipcbiAqIC9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9wdWJsaXNoZXIuanNcbiAqL1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5pbXBvcnQgeyBjb2xsZWN0aW9uc1xuICAgICAgICwgcHVibGlzaFF1ZXJpZXNcbiAgICAgICB9IGZyb20gJy4vbWludCdcblxuLy8gY29uc29sZS5sb2coXCJjb2xsZWN0aW9uc1wiLCBPYmplY3Qua2V5cyhjb2xsZWN0aW9ucykpXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgZm9yIChuYW1lIGluIGNvbGxlY3Rpb25zKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0gcHVibGlzaFF1ZXJpZXNbbmFtZV1cbiAgICBjb25zdCBjb2xsZWN0aW9uID0gY29sbGVjdGlvbnNbbmFtZV1cblxuICAgIC8vIGNvbnNvbGUubG9nKG5hbWUsIHNlbGVjdClcblxuICAgIG5hbWUgPSBjb2xsZWN0aW9uLl9uYW1lIC8vIG5hbWUudG9Mb3dlckNhc2UoKVxuXG4gICAgLy8gVGhlIHB1YmxpY2F0aW9uIG1ldGhvZCBpcyBydW4gZWFjaCB0aW1lIGEgY2xpZW50IHN1YnNjcmliZXMgdG9cbiAgICAvLyB0aGUgbmFtZWQgY29sbGVjdGlvbi4gVGhlIHN1YnNjcmlwdGlvbiBtYXkgYmUgbWFkZSBkaXJlY3RseSBvclxuICAgIC8vIHRocm91Z2ggdGhlIC9pbXBvcnRzL2FwaS9tZXRob2RzL21pbnQuanMgc2NyaXB0XG5cbiAgICBNZXRlb3IucHVibGlzaChuYW1lLCBmdW5jdGlvbiBwdWJsaWMoY2FsbGVyLCAuLi5tb3JlKSB7XG4gICAgICAvLyBXZSBuZWVkIHRvIHVzZSB0aGUgY2xhc3NpYyBmdW5jdGlvbiAoKSBzeW50YXggc28gdGhhdCB3ZSBjYW5cbiAgICAgIC8vIHVzZSB0aGlzIHRvIGFjY2VzcyB0aGUgTWV0ZW9yIGNvbm5lY3Rpb24gYW5kIHVzZSB0aGlzLnVzZXJfaWRcblxuICAgICAgbGV0IGl0ZW1zID0gY29sbGVjdGlvbi5maW5kKHNlbGVjdCkgLy8gKGN1c3RvbVNlbGVjdCB8fMKgc2VsZWN0KVxuXG4gICAgICBpZiAodHlwZW9mIGNhbGxlciA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBcIlB1Ymxpc2hpbmdcIiwgY29sbGVjdGlvbi5fbmFtZSwgXCJmb3JcIiwgY2FsbGVyLCAuLi5tb3JlXG4gICAgICAgIClcbiAgICAgICAgLy8gY29uc29sZS5sb2coXG4gICAgICAgIC8vICAgXCJJdGVtcyAxIC0gNCAvXCJcbiAgICAgICAgLy8gLCBjb2xsZWN0aW9uLmZpbmQoc2VsZWN0KS5jb3VudCgpXG4gICAgICAgIC8vICwgY29sbGVjdGlvbi5maW5kKHNlbGVjdCwgeyBsaW1pdDogNCB9KS5mZXRjaCgpXG4gICAgICAgIC8vIClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGl0ZW1zXG4gICAgfSlcbiAgfVxufVxuXG5cbi8vIENhbGxlZCBieSBhZGRVc2VySGlzdG9yeUl0ZW0oKSBpbiBqb2luLmpzXG5leHBvcnQgY29uc3QgZ2V0TmV4dEluZGV4ID0gKF9pZCkgPT4ge1xuICBjb25zdCBDb3VudGVycyA9IGNvbGxlY3Rpb25zLkNvdW50ZXJzXG4gIGxldCBpbmMgPSAxXG5cbiAgaWYgKE1ldGVvci5pc01ldGVvcikge1xuICAgIENvdW50ZXJzLnVwc2VydChcbiAgICAgIHsgX2lkIH1cbiAgICAsIHsgJGluYzogeyBpbmRleDogaW5jIH19XG4gICAgKVxuXG4gICAgaW5jID0gMFxuICB9XG5cbiAgY29uc3QgaW5kZXggPSAoQ291bnRlcnMuZmluZE9uZSh7IF9pZCB9KSkgfHwgeyBpbmRleDowIH0uaW5kZXggKyBpbmNcblxuICByZXR1cm4gaW5kZXhcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBjb2xsZWN0aW9uc1xuIiwiLyoqXG4gKiAvcHVibGljL2FjdGl2aXRpZXMvRHJhZy9qcy9tZXRob2RzLmpzXG4gKi9cblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJ1xuXG5pbXBvcnQgY29sbGVjdGlvbnMgZnJvbSAnL2ltcG9ydHMvYXBpL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcbmNvbnN0IHsgR3JvdXAgfSA9IGNvbGxlY3Rpb25zXG5cblxuXG5leHBvcnQgY29uc3Qgc2V0Vmlld0RhdGEgPSB7XG4gIG5hbWU6IFwiZHJhZy5zZXRWaWV3RGF0YVwiXG5cbiwgY2FsbChzZXRWaWV3RGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW3NldFZpZXdEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShzZXRWaWV3RGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgZ3JvdXBfaWQ6IHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIGRhdGE6IHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9XG4gICAgfSkudmFsaWRhdGUoc2V0Vmlld0RhdGEpXG4gIH1cblxuLCBydW4oc2V0Vmlld0RhdGEpIHtcbiAgICBjb25zdCB7IGdyb3VwX2lkOiBfaWQsIGRhdGEgfSA9IHNldFZpZXdEYXRhXG4gICAgY29uc3Qgc2VsZWN0ID0geyBfaWQgfVxuICAgIGNvbnN0IHNldCA9IHsgJHNldDogeyBcInBhZ2UuZGF0YVwiOiBkYXRhIH0gfVxuICAgIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHNldClcbiAgfVxufVxuXG5cbmV4cG9ydCBjb25zdCB0b2dnbGVDb21wbGV0ZSA9IHtcbiAgbmFtZTogXCJkcmFnLnRvZ2dsZUNvbXBsZXRlXCJcblxuLCBjYWxsKHRvZ2dsZUNvbXBsZXRlRGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW3RvZ2dsZUNvbXBsZXRlRGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUodG9nZ2xlQ29tcGxldGVEYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBjb21wbGV0ZTogeyB0eXBlOiBCb29sZWFuIH1cbiAgICAsIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgfSkudmFsaWRhdGUodG9nZ2xlQ29tcGxldGVEYXRhKVxuICB9XG5cbiwgcnVuKHRvZ2dsZUNvbXBsZXRlRGF0YSkge1xuICAgIGNvbnN0IHsgZ3JvdXBfaWQ6IF9pZCwgY29tcGxldGUgfSA9IHRvZ2dsZUNvbXBsZXRlRGF0YVxuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkIH1cbiAgICBjb25zdCBzZXQgPSB7ICRzZXQ6IHsgXCJwYWdlLmRhdGEuY29tcGxldGVcIjogY29tcGxldGUgfSB9XG4gICAgY29uc3QgcmVzdWx0ID0gR3JvdXAudXBkYXRlKHNlbGVjdCwgc2V0KVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwiZGIuZ3JvdXAudXBkYXRlKFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAvLyAgICAgICAgICAgICsgXCIsXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2V0KVxuICAgIC8vICAgICAgICAgICAgKyBcIikgPj4+IHJlc3VsdDpcIiwgcmVzdWx0XG4gICAgLy8gICAgICAgICAgICApXG4gIH1cbn1cblxuXG5cbmV4cG9ydCBjb25zdCB0b2dnbGVTaG93ID0ge1xuICBuYW1lOiBcImRyYWcudG9nZ2xlU2hvd1wiXG5cbiwgY2FsbCh0b2dnbGVTaG93RGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW3RvZ2dsZVNob3dEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZSh0b2dnbGVTaG93RGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgaW5kZXg6ICAgIHsgdHlwZTogTnVtYmVyIH1cbiAgICAsIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgfSkudmFsaWRhdGUodG9nZ2xlU2hvd0RhdGEpXG4gIH1cblxuLCBydW4odG9nZ2xlU2hvd0RhdGEpIHtcbiAgICBjb25zdCB7IGdyb3VwX2lkOiBfaWQsIGluZGV4IH0gPSB0b2dnbGVTaG93RGF0YVxuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkIH1cbiAgICBjb25zdCBzZXQgPSB7ICRzZXQ6IHsgW1wicGFnZS5kYXRhLnNob3cuXCIgKyBpbmRleF06IHRydWUgfSB9XG4gICAgY29uc3QgcmVzdWx0ID0gR3JvdXAudXBkYXRlKHNlbGVjdCwgc2V0KVxuXG4gICAgLy8gY29uc29sZS5sb2coIFwiZGIuZ3JvdXAudXBkYXRlKFwiXG4gICAgLy8gICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHNlbGVjdClcbiAgICAvLyAgICAgICAgICAgICsgXCIsXCJcbiAgICAvLyAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkoc2V0KVxuICAgIC8vICAgICAgICAgICAgKyBcIikgPj4+IHJlc3VsdDpcIiwgcmVzdWx0XG4gICAgLy8gICAgICAgICAgICApXG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3Qgc2V0RHJhZ1RhcmdldCA9IHtcbiAgbmFtZTogXCJkcmFnLnNldERyYWdUYXJnZXRcIlxuXG4sIGNhbGwoZHJhZ1RhcmdldERhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtkcmFnVGFyZ2V0RGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG5cbiwgdmFsaWRhdGUoZHJhZ1RhcmdldERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIGRyYWdfaWQ6ICB7IHR5cGU6IFN0cmluZyB9IC8vIGlkIG9mIEhUTUwgZWxlbWVudFxuICAgICwgcGlsb3Q6ICAgIHsgdHlwZTogU3RyaW5nIH0gLy8gZF9jb2RlIGZvciB1c2VyfHRlYWNoZXIncyBkZXZpY2VcbiAgICAsIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCB4OiAgICAgICAgeyB0eXBlOiBOdW1iZXIgfVxuICAgICwgeTogICAgICAgIHsgdHlwZTogTnVtYmVyIH1cbiAgICB9KS52YWxpZGF0ZShkcmFnVGFyZ2V0RGF0YSlcbiAgfVxuXG4gIC8qIENhbGwgd2lsbCB0aHJvdyBhbiBlcnJvciBpZiBhbnkgdXNlciAoaW5jbHVkaW5nIHBpbG90KSBzdGFydGVkIGFuXG4gICAqIGFjdGlvbiBidXQgZGlkIG5vdCBjb21wbGV0ZSBpdC5cbiAgICogVE9ETzogRW5zdXJlIHRoYXQgYWxsIHBpbG90IGFjdGlvbnMgYXJlIHJlbW92ZWQgd2hlbiB0aGUgcGlsb3RcbiAgICogbG9ncyBvdXQuXG4gICAqL1xuXG4sIHJ1bihkcmFnVGFyZ2V0RGF0YSkge1xuICAgIGNvbnN0IHsgZ3JvdXBfaWQ6IF9pZCwgcGlsb3QsIGRyYWdfaWQsIHgsIHkgfSA9IGRyYWdUYXJnZXREYXRhXG4gICAgY29uc3Qgc2VsZWN0ID0geyBfaWQgfVxuXG4gICAgLy8gY29uc3Qgb3B0aW9ucyA9IHsgZmllbGRzOiB7IFwicGFnZS5kYXRhXCI6IDEgfSB9XG4gICAgLy8gY29uc3QgeyBwYWdlIH0gPSBHcm91cC5maW5kT25lKHNlbGVjdCwgb3B0aW9ucylcbiAgICAvLyAgICAgICAgICAgICAgIHx8IHsgcGFnZToge30gfSAvLyBpZiBncm91cCBoYXMgbm8gcGFnZS5kYXRhIHlldFxuICAgIC8vIGNvbnN0IGRhdGEgPSBwYWdlLmRhdGEgfHwge31cbiAgICAvLyBpZiAoZGF0YS5waWxvdCkge1xuICAgIC8vICAgLy8gVGhlcmUgaXMgYWxyZWFkeSBhbiBvcGVyYXRpb24gaW4gcHJvZ3Jlc3NcbiAgICAvLyAgIHRocm93IChcIkdyb3VwIFwiICsgX2lkICsgXCIgbG9ja2VkIGJ5IGEgcHJvY2VzcyBmcm9tIFwiICsgZGF0YS5waWxvdClcbiAgICAvLyB9XG5cbiAgICBjb25zdCBzZXQgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIFwicGFnZS5kYXRhLnBpbG90XCI6ICAgcGlsb3RcbiAgICAgICwgXCJwYWdlLmRhdGEuZHJhZ19pZFwiOiBkcmFnX2lkXG4gICAgICAsIFwicGFnZS5kYXRhLnhcIjogICAgICAgeFxuICAgICAgLCBcInBhZ2UuZGF0YS55XCI6ICAgICAgIHlcbiAgICAgIH1cbiAgICAsICR1bnNldDoge1xuICAgICAgICBcInBhZ2UuZGF0YS5kcm9wXCI6IDBcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHNldClcbiAgfVxufVxuXG5cbmV4cG9ydCBjb25zdCB1cGRhdGVEcmFnVGFyZ2V0ID0ge1xuICBuYW1lOiBcImRyYWcudXBkYXRlRHJhZ1RhcmdldFwiXG5cbiwgY2FsbChkcmFnVGFyZ2V0RGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2RyYWdUYXJnZXREYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShkcmFnVGFyZ2V0RGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgZ3JvdXBfaWQ6IHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIHBpbG90OiAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCB4OiAgICAgICAgeyB0eXBlOiBOdW1iZXIgfVxuICAgICwgeTogICAgICAgIHsgdHlwZTogTnVtYmVyIH1cbiAgICB9KS52YWxpZGF0ZShkcmFnVGFyZ2V0RGF0YSlcbiAgfVxuXG4sIHJ1bihkcmFnVGFyZ2V0RGF0YSkge1xuICAgIGNvbnN0IHsgZ3JvdXBfaWQ6IF9pZCwgcGlsb3QsIHgsIHkgfSA9IGRyYWdUYXJnZXREYXRhXG4gICAgY29uc3Qgc2VsZWN0ID0geyBfaWQsIFwicGFnZS5kYXRhLnBpbG90XCI6IHBpbG90IH1cbiAgICBjb25zdCBzZXQgPSB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIFwicGFnZS5kYXRhLnhcIjogeFxuICAgICAgLCBcInBhZ2UuZGF0YS55XCI6IHlcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHNldClcbiAgfVxufVxuXG5cbmV4cG9ydCBjb25zdCBkcm9wRHJhZ1RhcmdldCA9IHtcbiAgbmFtZTogXCJkcmFnLmRyb3BEcmFnVGFyZ2V0XCJcblxuLCBjYWxsKGRyb3BUYXJnZXREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbZHJvcFRhcmdldERhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKGRyb3BUYXJnZXREYXRhKSB7XG4gICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICBncm91cF9pZDogeyB0eXBlOiBTdHJpbmcgfVxuICAgIH0pLnZhbGlkYXRlKGRyb3BUYXJnZXREYXRhKVxuICB9XG5cbiwgcnVuKGRyb3BUYXJnZXREYXRhKSB7XG4gICAgY29uc3QgeyBncm91cF9pZDogX2lkIH0gPSBkcm9wVGFyZ2V0RGF0YVxuICAgIGNvbnN0IHNlbGVjdCA9IHsgX2lkIH1cbiAgICBjb25zdCB1bnNldCA9IHtcbiAgICAgICR1bnNldDoge1xuICAgICAgICBcInBhZ2UuZGF0YS5waWxvdFwiOiAgIDBcbiAgICAgICwgXCJwYWdlLmRhdGEuZHJhZ19pZFwiOiAwXG4gICAgICAsIFwicGFnZS5kYXRhLnhcIjogICAgICAgMFxuICAgICAgLCBcInBhZ2UuZGF0YS55XCI6ICAgICAgIDBcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHVuc2V0KVxuICB9XG59XG5cblxuY29uc3QgbWV0aG9kcyA9IFtcbiAgc2V0Vmlld0RhdGFcbiwgdG9nZ2xlU2hvd1xuLCB0b2dnbGVDb21wbGV0ZVxuLCBzZXREcmFnVGFyZ2V0XG4sIHVwZGF0ZURyYWdUYXJnZXRcbiwgZHJvcERyYWdUYXJnZXRcbl1cblxuXG5tZXRob2RzLmZvckVhY2gobWV0aG9kID0+IHtcbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgIFttZXRob2QubmFtZV06IGZ1bmN0aW9uIChhcmdzKSB7XG4gICAgICBtZXRob2QudmFsaWRhdGUuY2FsbCh0aGlzLCBhcmdzKVxuICAgICAgcmV0dXJuIG1ldGhvZC5ydW4uY2FsbCh0aGlzLCBhcmdzKVxuICAgIH1cbiAgfSlcbn0pIiwiLyoqXG4gKiAvcHVibGljL2FjdGl2aXRpZXMvRmxhc2gvbWV0aG9kcy5qc1xuICovXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSdcblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9wdWJsaXNoZXInXG5jb25zdCB7IEdyb3VwcyB9ID0gY29sbGVjdGlvbnNcblxuXG5cbmV4cG9ydCBjb25zdCBwbGFjZWhvbGRlciA9IHtcbiAgbmFtZTogXCJmbGFzaC5wbGFjZWhvbGRlclwiXG5cbiwgY2FsbChwbGFjZWhvbGRlckRhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtwbGFjZWhvbGRlckRhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxuXG4sIHZhbGlkYXRlKHBsYWNlaG9sZGVyRGF0YSkge1xuICAgIC8vIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIC8vICAgZ3JvdXBfaWQ6IHsgdHlwZTogU3RyaW5nIH1cbiAgICAvLyAsIGRhdGE6IHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9XG4gICAgLy8gfSkudmFsaWRhdGUocGxhY2Vob2xkZXJEYXRhKVxuICB9XG5cbiwgcnVuKHBsYWNlaG9sZGVyRGF0YSkge1xuICAgIC8vIGNvbnN0IHsgZ3JvdXBfaWQ6IF9pZCwgZGF0YSB9ID0gcGxhY2Vob2xkZXJEYXRhXG4gICAgLy8gY29uc3Qgc2VsZWN0ID0geyBfaWQgfVxuICAgIC8vIGNvbnN0IHNldCA9IHsgJHNldDogeyBcInBhZ2UuZGF0YVwiOiBkYXRhIH0gfVxuICAgIC8vIEdyb3Vwcy51cGRhdGUoc2VsZWN0LCBzZXQpXG4gIH1cbn1cblxuXG5jb25zdCBtZXRob2RzID0gW1xuICBwbGFjZWhvbGRlclxuXVxuXG5cbm1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1ldGhvZC52YWxpZGF0ZS5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgICByZXR1cm4gbWV0aG9kLnJ1bi5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgfVxuICB9KVxufSkiLCIvKipcbiAqIC9wdWJsaWMvYWN0aXZpdGllcy9TcGlyYWwvbWV0aG9kcy5qc1xuICovXG5cblxuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnXG5pbXBvcnQgeyBjb2xsZWN0aW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL2ltcG9ydHMvYXBpL2NvbGxlY3Rpb25zL21pbnQnXG5jb25zdCB7IEdyb3VwIH0gPSBjb2xsZWN0aW9uc1xuXG5cblxuZXhwb3J0IGNvbnN0IHNldFN0YXJ0ID0ge1xuICBuYW1lOiAnc3BpcmFsLnNldFN0YXJ0J1xuXG4sIGNhbGwoc2V0U3RhcnREYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbc2V0U3RhcnREYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cblxuLCB2YWxpZGF0ZShzZXRTdGFydERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIGdyb3VwX2lkOiB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBzdGFydDogICAgeyB0eXBlOiBOdW1iZXIgfVxuICAgIH0pLnZhbGlkYXRlKHNldFN0YXJ0RGF0YSlcbiAgfVxuXG4sIHJ1bihzZXRTdGFydERhdGEpIHtcbiAgICBjb25zdCB7IGdyb3VwX2lkOiBfaWQsIHN0YXJ0IH0gPSBzZXRTdGFydERhdGFcbiAgICBjb25zdCBzZWxlY3QgPSB7IF9pZCB9XG4gICAgY29uc3Qgc2V0ICAgID0geyAkc2V0OiB7IFwicGFnZS5kYXRhLnN0YXJ0XCI6IHN0YXJ0IH0gfVxuICAgIEdyb3VwLnVwZGF0ZShzZWxlY3QsIHNldClcbiAgfVxufVxuXG5cblxuLy8gVG8gcmVnaXN0ZXIgYSBuZXcgbWV0aG9kIHdpdGggTWV0ZW9yJ3MgRERQIHN5c3RlbSwgYWRkIGl0IGhlcmVcbmNvbnN0IG1ldGhvZHMgPSBbXG4gIHNldFN0YXJ0XG5dXG5cbm1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1ldGhvZC52YWxpZGF0ZS5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgICByZXR1cm4gbWV0aG9kLnJ1bi5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgfVxuICB9KVxufSkiLCIvLyAvKipcbi8vICAqIC9wdWJsaWMvYWN0aXZpdGllcy9Wb2NhYnVsYXJ5L21ldGhvZHMuanNcbi8vICAqL1xuXG5cblxuLy8gaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbi8vIGltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJ1xuXG4vLyBpbXBvcnQgeyBjb2xsZWN0aW9ucyB9IGZyb20gJy9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9taW50J1xuLy8gY29uc3QgeyBGbHVlbmN5LCBHcm91cCB9ID0gY29sbGVjdGlvbnNcblxuXG5cbi8vIGV4cG9ydCBjb25zdCBhZGRUb0ZsdWVuY3kgPSB7XG4vLyAgIG5hbWU6ICd2b2NhYnVsYXJ5LmFkZFRvRmx1ZW5jeSdcblxuLy8gLCBjYWxsKGZsdWVuY3lJdGVtQXJyYXksIGNhbGxiYWNrKSB7XG4vLyAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbi8vICAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuLy8gICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuLy8gICAgIH1cblxuLy8gICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtmbHVlbmN5SXRlbUFycmF5XSwgb3B0aW9ucywgY2FsbGJhY2spXG4vLyAgIH1cblxuLy8gLCB2YWxpZGF0ZShmbHVlbmN5SXRlbUFycmF5KSB7XG4vLyAgICAgZmx1ZW5jeUl0ZW1BcnJheS5mb3JFYWNoKCBpdGVtID0+IHtcbi8vICAgICAgIG5ldyBTaW1wbGVTY2hlbWEoeyAgICBcbi8vICAgICAgICAgICBwaHJhc2VfaWQ6ICB7IHR5cGU6IFN0cmluZyB9XG4vLyAgICAgICAgICwgdXNlcl9pZDogICAgeyB0eXBlOiBTdHJpbmcgfVxuLy8gICAgICAgICAsIGdyb3VwX2lkOiAgIHsgdHlwZTogU3RyaW5nIH1cbi8vICAgICAgICAgLCBuZXh0X3NlZW46ICB7IHR5cGU6IE51bWJlciB9XG4vLyAgICAgICB9KS52YWxpZGF0ZShpdGVtKVxuLy8gICAgIH0pXG4vLyAgIH1cblxuLy8gLCBydW4oZmx1ZW5jeUl0ZW1BcnJheSkge1xuLy8gICAgIGNvbnN0IGZpbGxlcnMgPSB7XG4vLyAgICAgICB0aW1lc19zZWVuOiAwXG4vLyAgICAgLCBmaXJzdF9zZWVuOiAwXG4vLyAgICAgLCBsYXN0X3NlZW46ICAwXG4vLyAgICAgLCBmbG9wczogICAgICA0XG4vLyAgICAgLCBzY29yZTogICAgICAwXG4vLyAgICAgLCBjb2xsZWN0aW9uOiBcIlZvY2FidWxhcnlcIlxuLy8gICAgICwgbGV2ZWw6ICAgICAgXCJUT0RPXCJcbi8vICAgICB9XG4vLyAgICAgZmx1ZW5jeUl0ZW1BcnJheS5mb3JFYWNoKCBmbHVlbmN5T2JqZWN0ID0+IHtcbi8vICAgICAgIGZsdWVuY3lPYmplY3QgPSB7Li4uZmx1ZW5jeU9iamVjdCwgLi4uZmlsbGVyc31cbi8vICAgICAgIEZsdWVuY3kuaW5zZXJ0KGZsdWVuY3lPYmplY3QpXG4vLyAgICAgfSlcbi8vICAgfVxuLy8gfVxuXG5cblxuLy8gLy8gVG8gcmVnaXN0ZXIgYSBuZXcgbWV0aG9kIHdpdGggTWV0ZW9yJ3MgRERQIHN5c3RlbSwgYWRkIGl0IGhlcmVcbi8vIGNvbnN0IG1ldGhvZHMgPSBbXG4vLyAgIGFkZFRvRmx1ZW5jeVxuLy8gXVxuXG4vLyBtZXRob2RzLmZvckVhY2gobWV0aG9kID0+IHtcbi8vICAgTWV0ZW9yLm1ldGhvZHMoe1xuLy8gICAgIFttZXRob2QubmFtZV06IGZ1bmN0aW9uIChhcmdzKSB7XG4vLyAgICAgICBtZXRob2QudmFsaWRhdGUuY2FsbCh0aGlzLCBhcmdzKVxuLy8gICAgICAgcmV0dXJuIG1ldGhvZC5ydW4uY2FsbCh0aGlzLCBhcmdzKVxuLy8gICAgIH1cbi8vICAgfSlcbi8vIH0pIiwiLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvY29uc3RhbnRzLmpzXG4gKlxuICogVGhlIGNvbnN0YW50cyBiZWxvdyBhcmUgdXNlZCBieSBvdGhlciBzY3JpcHRzIGluIHRoZVxuICogL2ltcG9ydHMvYXBpL21ldGhvZHMvYXNzZXRzLyBmb2xkZXJcbiAqL1xuXG5cblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcblxuXG5cbmNvbnN0IFBXRCA9IHByb2Nlc3MuZW52LlBXRFxuLy8gRGV2ZWxvcG1lbnQ6IC9ob21lL2JsYWNrc2xhdGUvUmVwb3MvamF6eXgvQWN0aXZpdGllc1xuLy8gUHJvZHVjdGlvbjogIC92YXIvd3d3L2phenl4LzxzdWJkb21haW4+L2J1bmRsZVxuXG5jb25zdCBmb3JtYXRzID0gXCJqcGU/Z3xwbmd8c3ZnfGdpZnx3ZWJtKVwiICAvLyB0cmFpbGluZyApIGRlbGliZXJhdGVcbmNvbnN0IGxvb2tBaGVhZCA9IFwiXFxcXC4oPzpcIiArIGZvcm1hdHMgKyBcIiRcIiAvLyBsZWFkaW5nICjCoG9ubHlcblxuLy8vIDw8PCBIQVJELUNPREVEXG5jb25zdCBQVUJMSUNfRElSRUNUT1JZID0gTWV0ZW9yLmlzRGV2ZWxvcG1lbnRcbiAgICAgICAgICAgICAgICAgICAgICAgPyBQV0QgKyBcIi9wdWJsaWNcIlxuICAgICAgICAgICAgICAgICAgICAgICA6IFBXRMKgKyBcIi9wcm9ncmFtcy93ZWIuYnJvd3Nlci9hcHBcIlxuXG5jb25zdCBBQ1RJVklUWV9GT0xERVIgPSBQVUJMSUNfRElSRUNUT1JZICsgJy9BY3Rpdml0aWVzLydcbmNvbnN0IEFTU0VUU19GT0xERVIgPSBQVUJMSUNfRElSRUNUT1JZwqArICcvQXNzZXRzLydcblxuY29uc3QgSUNPTl9SRUdFWCA9IG5ldyBSZWdFeHAoXCJeKGljb25cIiArIGxvb2tBaGVhZCArIFwiKXwoaWNvbikkXCIpXG4vLyBVc2VkIHRvIGZpbmQgZGVmYXVsdCBpY29uIGluIC9pY29uLyBmb2xkZXJzOiAvaWNvbi9lbi54eHhcbmNvbnN0IEVOX1JFR0VYID0gbmV3IFJlZ0V4cChcImVuXFwuKFwiICsgZm9ybWF0cylcbi8vIFVzZWQgdG8gaWRlbnRpZnkgaW1hZ2UgZmlsZXMgaW4gaW1hZ2UvIGZvbGRlclxuY29uc3QgSU1BR0VfUkVHRVggPSBuZXcgUmVnRXhwKFwiKFteLy5dKylcIiArIGxvb2tBaGVhZClcbi8vIGZvdXItbGV0dGVyICsgLmpzb25cbmNvbnN0IEpTT05fUkVHRVggPSAvXigoPzpyb290KXwoPzpyYW5rKXwoPzpyYWNrKXwoPzpsMTBuKSlcXC5qc29uJC9cbi8vIFNwbGl0cyBQQVRIX1JFR0VYIGludG8gY2h1bmtzIGxpa2UgXCIvQWN0aXZpdHlcIiBhbmQgXCIvZXhlcmNpc2VcIlxuY29uc3QgU0VUX1JFR0VYID0gLyg/PVxcLykvXG4vLy8gSEFSRC1DT0RFRMKgPj4+XG5cblxuXG5leHBvcnQge1xuICBQVUJMSUNfRElSRUNUT1JZXG4sIEFDVElWSVRZX0ZPTERFUlxuLCBBU1NFVFNfRk9MREVSXG5cbiwgSUNPTl9SRUdFWFxuLCBJTUFHRV9SRUdFWFxuLCBKU09OX1JFR0VYXG4sIFNFVF9SRUdFWFxuLCBFTl9SRUdFWFxufSIsIi8qKlxuICogL2ltcG9ydHMvYXBpL3Rvb2xzL2N1c3RvbS9wcm9qZWN0LmpzXG4gKi9cblxuXG5cbmltcG9ydCB7IGdldFJhbmRvbUZyb21BcnJheSB9IGZyb20gJy4uL2dlbmVyaWMvdXRpbGl0aWVzJ1xuaW1wb3J0IHsgSU1BR0VfUkVHRVggfSBmcm9tICcuL2NvbnN0YW50cydcblxuXG5cbmNvbnN0IEdPTERFTl9BTkdMRcKgPSAxODAgKiAoMyAtIE1hdGguc3FydCg1KSlcbmNvbnN0IFJBVElPICAgICAgICA9IDE0MjIxLzUxMiAvLyBzdHJldGNoZXMgMzYwIHRvIDk5OTkuMTQwXG5cblxuXG5leHBvcnQgY29uc3QgZ2V0R29sZGVuQW5nbGVBdCA9IChpbmRleCkgPT4ge1xuICBsZXQgYW5nbGUgPSBpbmRleCAqIEdPTERFTl9BTkdMRVxuICBhbmdsZSAtPSBNYXRoLmZsb29yKGFuZ2xlIC8gMzYwKSAqIDM2MCAvLyAwLjAg4omkIGFuZ2xlIDwgMzYwLjBcblxuICByZXR1cm4gYW5nbGVcbn1cblxuXG5cbmV4cG9ydCBjb25zdCBnZXRDb2RlRnJvbSA9IChhbmdsZSkgPT4ge1xuICBsZXQgY29kZSA9IE1hdGgucm91bmQoYW5nbGUgKiBSQVRJTylcblxuICAvLyBUaGUgZm9sbG93aW5nIGxpbmVzIGRlcGVuZCBvbiAwIOKJpCAgY29kZSDiiaQgOTk5OSwgYmVjYXVzZSBvZiB0aGVcbiAgLy8gdmFsdWVzIG9mIFJBVElPLiBJZiBSQVRJT8KgaXMgbXVsdGlwbGllZCBieSAxMCwgZm9yIGV4YW1wbGUsXG4gIC8vIHdlJ2xsIG5lZWQgYW4gZXh0cmEgemVybyBhbmQgYW4gZXh0cmEgfSBlbHNlIGlmIHsgc3RhdGVtZW50LlxuXG4gIGlmIChjb2RlIDwgMTApIHtcbiAgICBjb2RlID0gXCIwMDBcIiArIGNvZGVcbiAgfSBlbHNlIGlmIChjb2RlIDwgMTAwKSB7XG4gICAgY29kZSA9IFwiMDBcIiArIGNvZGVcbiAgfSBlbHNlIGlmIChjb2RlIDwgMTAwMCkge1xuICAgIGNvZGUgPSBcIjBcIiArIGNvZGVcbiAgfSBlbHNlIHtcbiAgICBjb2RlID0gXCJcIiArIGNvZGVcbiAgfVxuXG4gIHJldHVybiBjb2RlXG59XG5cblxuXG4vKiogUmV0dXJucyBhbiBhYnNvbHV0ZSBwYXRoIHRvIGEgKGxvY2FsaXplZCkgaWNvbilcbiAqXG4gKiBAcGFyYW0gICB7b2JqZWN0fSAgaWNvbkRhdGEgICB7IHNyYzogXCJwYXRoL3RvL2ljb24ueHhnXCIgfVxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgT1IgeyBzcmM6IFwicGF0aC90by9pY29uL14wXCJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgaWNvbnM6IFtcImVuLnh4Z1wiLCBcImZyLm9vZ1wiLCAuLi5dXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gKiBAcmV0dXJuICB7c3RyaW5nfSAgIC9wYXRoL3RvL2ljb24ueHhnIE9SIC9wYXRoL3RvL2ljb24vZW4ueHhnXG4gKi9cbmV4cG9ydCBjb25zdCBnZXRJY29uU3JjID0gKGljb25EYXRhLCBsYW5nKSA9PiB7XG4gICAgbGV0IHsgc3JjLCBpY29ucyB9ID0gaWNvbkRhdGFcblxuICAgIGNvbnN0IGxhbmd1YWdlTWF0Y2ggPSAoaWNvbnMsIGxhbmcpID0+wqB7XG4gICAgICByZXR1cm4gaWNvbnMuZmluZChpY29uID0+IHtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSBJTUFHRV9SRUdFWC5leGVjKGljb24pXG4gICAgICAgIGlmIChtYXRjaCAmJiAobWF0Y2hbMV0gPT09IGxhbmcpKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICBpZiAoaWNvbnMpIHtcbiAgICAgIC8vIHNyYyB3aWxsIGJlIG9mIHRoZSBmb3JtYXQgXCIvcGF0aC90by9pY29uL14wXCJcbiAgICAgIGxldCBpY29uID0gbGFuZ3VhZ2VNYXRjaChpY29ucywgbGFuZykgLy8gbWF5IGJlIGRpYWxlY3QgeHgtWFhcblxuICAgICAgaWYgKCFpY29uKSB7XG4gICAgICAgIC8vIFVzZSBhIGdlbmVyaWMgbGFuZ3VhZ2UgaWNvblxuICAgICAgICBsYW5nID0gbGFuZy5yZXBsYWNlKC8tLiokLywgXCJcIikgLy8gXCJ4eC1YWFwiID0+IFwieHhcIlxuICAgICAgICBpY29uID0gbGFuZ3VhZ2VNYXRjaChpY29ucywgbGFuZylcbiAgICAgIH1cblxuICAgICAgaWYgKCFpY29uKSB7XG4gICAgICAgIC8vIEFuIFwiZW5cIiBpY29uIHdhcyBjcmVhdGVkIGF1dG9tYXRpY2FsbHkgYXQgc3RhcnRVcCBpZiBpdFxuICAgICAgICAvLyBkaWRuJ3QgYWxyZWFkeSBleGlzdC4gVXNlIHRoaXMgbGFuZ3VhZ2UgYXMgYSBmYWxsYmFjay5cbiAgICAgICAgaWNvbiA9IGxhbmd1YWdlTWF0Y2goaWNvbnMsIFwiZW5cIilcbiAgICAgIH1cblxuICAgICAgc3JjID0gc3JjLnJlcGxhY2UoXCJeMFwiLCBpY29uKVxuICAgIH1cblxuICAgIHJldHVybiBzcmNcbiAgfSIsIi8qKlxuICogL2ltcG9ydHMvdG9vbHMvZ2VuZXJpYy91dGlsaXRpZXMuanNcbiAqXG4gKiBQcm92aWRlcyBhIHNldCBvZiByZS11c2FibGUgZnVuY3Rpb25zIHdoaWNoIGNhbiBiZSBpbXBvcnRlZFxuICogYW55d2hlcmVcbiAqL1xuXG5cblxuLy8vIENPTE9SwqBGVU5DVElPTlPCoC8vXG5cbmV4cG9ydCBjb25zdCByZ2JpZnkgPSAoY29sb3IpID0+IHtcbiAgaWYgKGNvbG9yLnN1YnN0cmluZygwLCAzKS50b0xvd2VyQ2FzZSgpID09PSBcImhzbFwiICkge1xuICAgIHJldHVybiBIU0x0b1JHQihjb2xvcilcbiAgfVxuXG4gIGlmIChjb2xvclswXSA9PT0gXCIjXCIpIHtcbiAgICBjb2xvciA9IGNvbG9yLnNsaWNlKDEpXG4gIH1cblxuICBpZiAoY29sb3IubGVuZ3RoID09PSAzKSB7XG4gICAgY29sb3IgPSBjb2xvclswXStjb2xvclswXStjb2xvclsxXStjb2xvclsxXStjb2xvclsyXStjb2xvclsyXVxuICB9XG5cbiAgY29uc3QgaGV4ID0gcGFyc2VJbnQoY29sb3IsIDE2KVxuXG4gIHJldHVybiBbXG4gICAgaGV4ID4+IDE2ICAgICAgICAgICAvLyByZWRcbiAgLChoZXggPj4gIDgpICYgMHgwMEZGIC8vIGdyZWVuXG4gICwgaGV4ICAgICAgICAmIDB4RkYgICAvLyBibHVlXG4gIF1cbn1cblxuXG5cbmV4cG9ydCBjb25zdCB0d2VlbkNvbG9yID0gKGNvbG9yMSwgY29sb3IyLCByYXRpbykgPT4ge1xuICBjb25zdCByZ2IxID0gcmdiaWZ5KGNvbG9yMSlcbiAgY29uc3QgcmdiMiA9IHJnYmlmeShjb2xvcjIpXG5cbiAgY29uc3QgaGV4ID0gcmdiMS5tYXAoKHZhbHVlLCBpbmRleCkgPT4ge1xuICAgIHZhbHVlID0gTWF0aC5yb3VuZCh2YWx1ZSAtICh2YWx1ZSAtIHJnYjJbaW5kZXhdKSAqIHJhdGlvKVxuICAgIHZhbHVlID0gTWF0aC5tYXgoMCwgTWF0aC5taW4odmFsdWUsIDI1NSkpXG5cbiAgICByZXR1cm4gKCh2YWx1ZSA8IDE2KSA/IFwiMFwiIDogXCJcIikgKyB2YWx1ZS50b1N0cmluZygxNilcbiAgfSlcblxuICByZXR1cm4gXCIjXCIgKyBoZXguam9pbihcIlwiKVxufVxuXG5cblxuZXhwb3J0IGNvbnN0IHRvbmVDb2xvciA9IChjb2xvciwgcmF0aW8pID0+IHtcbiAgY29uc3QgcHJlZml4ID0gY29sb3JbMF0gPT09IFwiI1wiXG5cbiAgaWYgKHByZWZpeCkge1xuICAgIGNvbG9yID0gY29sb3Iuc2xpY2UoMSlcbiAgfVxuXG4gIGNvbnN0IHJnYiA9IHJnYmlmeShjb2xvcilcbiAgICAgICAgICAgICAubWFwKCB2YWx1ZSA9PiB7XG4gICAgdmFsdWUgPSBNYXRoLmZsb29yKE1hdGgubWF4KDAsIE1hdGgubWluKDI1NSwgdmFsdWUgKiByYXRpbykpKVxuICAgIHJldHVybiAoKHZhbHVlIDwgMTYpID8gXCIwXCIgOiBcIlwiKSArIHZhbHVlLnRvU3RyaW5nKDE2KVxuICB9KVxuXG4gIHJldHVybiAocHJlZml4ID8gXCIjXCIgOiBcIlwiKSArIHJnYi5qb2luKFwiXCIpXG59XG5cblxuXG5leHBvcnQgY29uc3QgdHJhbnNsdWNpZnkgPSAoY29sb3IsIG9wYWNpdHkpID0+IHtcbiAgaWYgKGNvbG9yWzBdID09PSBcIiNcIikge1xuICAgIGNvbG9yID0gY29sb3Iuc2xpY2UoMSlcbiAgfVxuXG4gIGNvbnN0IHJnYiA9IHJnYmlmeShjb2xvcilcblxuICByZXR1cm4gYHJnYmEoJHtyZ2JbMF19LCAke3JnYlsxXX0sICR7cmdiWzJdfSwgJHtvcGFjaXR5fSlgXG59XG5cblxuLy8gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIwMTI5NTk0LzE5Mjc1ODlcbi8vIGh0dHBzOi8vcXBoLmZzLnF1b3JhY2RuLm5ldC9tYWluLXFpbWctYWFhOWE1NDRkNzk3ZjExMDliMjljNTU4MTQzMTkxOTUud2VicFxuZXhwb3J0IGNvbnN0IGdldENvbG9yID0gKHsgbnVtYmVyLCBzPTAuNSwgbD0wLjMzLCBmb3JtYXQ9XCJoc2xcIiB9KSA9PiB7XG4gIGNvbnN0IGggPSBudW1iZXIgKiAxMzcuNTA3NzY0MDUgLy8g4omIIGdvbGRlbiBhbmdsZTogMTgwKigzLeKImjUpXG5cbiAgcyA9IE1hdGgubWF4KDAsIE1hdGgubWluKHMsIDEpKVxuICBsID0gTWF0aC5tYXgoMCwgTWF0aC5taW4obCwgMSkpXG5cbiAgc3dpdGNoIChmb3JtYXQudG9Mb3dlckNhc2UoKSkge1xuICAgIGNhc2UgXCJyZ2JcIjpcbiAgICAgIHJldHVybiBoc2wycmdiKGgsIHMsIGwpXG5cbiAgICBjYXNlIFwiaGV4XCI6XG4gICAgICByZXR1cm4gaHNsMmhleChoLCBzICogMTAwLCBsICogMTAwKVxuXG4gICAgZGVmYXVsdDogLy8gXCJoc2xcIlxuICAgICAgcmV0dXJuIGBoc2woJHtofSwke3MqMTAwfSUsJHtsKjEwMH0lKWA7XG4gIH1cbn1cblxuXG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvNTQwMTQ0MjgvMTkyNzU4OVxuLy8gaW5wdXQ6IGggaW4gWzAsMzYwXSBhbmQgcyx2IGluIFswLDFdIC0gb3V0cHV0OiByLGcsYiBpbiBbMCwxXVxuZXhwb3J0IGNvbnN0IGhzbDJyZ2IgPSAoaCxzLGwpID0+IHtcbiAgbGV0IGE9cypNYXRoLm1pbihsLDEtbCk7XG4gIGxldCBmPSAobixrPShuK2gvMzApJTEyKSA9PiBsIC0gYSpNYXRoLm1heChNYXRoLm1pbihrLTMsOS1rLDEpLC0xKTtcbiAgcmV0dXJuIFtmKDApLGYoOCksZig0KV1cbn1cblxuXG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvNDQxMzQzMjgvMTkyNzU4OVxuZXhwb3J0IGNvbnN0IGhzbDJoZXggPSAoaCwgcywgbCkgPT4ge1xuICBoIC89IDM2MDtcbiAgcyAvPSAxMDA7XG4gIGwgLz0gMTAwO1xuICBsZXQgciwgZywgYjtcbiAgaWYgKHMgPT09IDApIHtcbiAgICByID0gZyA9IGIgPSBsOyAvLyBhY2hyb21hdGljXG4gIH0gZWxzZSB7XG4gICAgY29uc3QgaHVlMnJnYiA9IChwLCBxLCB0KSA9PiB7XG4gICAgICBpZiAodCA8IDApIHQgKz0gMTtcbiAgICAgIGlmICh0ID4gMSkgdCAtPSAxO1xuICAgICAgaWYgKHQgPCAxIC8gNikgcmV0dXJuIHAgKyAocSAtIHApICogNiAqIHQ7XG4gICAgICBpZiAodCA8IDEgLyAyKSByZXR1cm4gcTtcbiAgICAgIGlmICh0IDwgMiAvIDMpIHJldHVybiBwICsgKHEgLSBwKSAqICgyIC8gMyAtIHQpICogNjtcbiAgICAgIHJldHVybiBwO1xuICAgIH07XG4gICAgY29uc3QgcSA9IGwgPCAwLjUgPyBsICogKDEgKyBzKSA6IGwgKyBzIC0gbCAqIHM7XG4gICAgY29uc3QgcCA9IDIgKiBsIC0gcTtcbiAgICByID0gaHVlMnJnYihwLCBxLCBoICsgMSAvIDMpO1xuICAgIGcgPSBodWUycmdiKHAsIHEsIGgpO1xuICAgIGIgPSBodWUycmdiKHAsIHEsIGggLSAxIC8gMyk7XG4gIH1cbiAgY29uc3QgdG9IZXggPSB4ID0+IHtcbiAgICBjb25zdCBoZXggPSBNYXRoLnJvdW5kKHggKiAyNTUpLnRvU3RyaW5nKDE2KTtcbiAgICByZXR1cm4gaGV4Lmxlbmd0aCA9PT0gMSA/ICcwJyArIGhleCA6IGhleDtcbiAgfTtcbiAgcmV0dXJuIGAjJHt0b0hleChyKX0ke3RvSGV4KGcpfSR7dG9IZXgoYil9YDtcbn1cblxuXG5cbmV4cG9ydCBjb25zdCBIU0x0b1JHQiA9IChjb2xvclN0cmluZyApPT4ge1xuICAvLyBcImhzbCg0MTIuNTIzLDUwJSw0MCUpXCIgPDw8IHBlcmNlbnRhZ2VzXG4gIC8vIFwiNDEyLjUyMywgMC41LCAwLjRcIiAgICA8PDwgcmF0aW9zXG4gIGxldCByZ2IgPSBbMCwgMCwgMF1cblxuICBjb25zdCByZWdleCA9IC8oaHNsXFxzKlxcKFxccyopPyhbMC05Ll0rKVxccyosXFxzKihbMC05Ll0rKSglPylcXHMqLFxccyooWzAtOS5dKykoJT8pXFxzKlxcKT8vXG4gIGNvbnN0IG1hdGNoID0gcmVnZXguZXhlYyhjb2xvclN0cmluZylcblxuICBpZiAobWF0Y2gpIHtcbiAgICBsZXQgaCA9IHBhcnNlRmxvYXQobWF0Y2hbMl0sIDEwKVxuICAgIGxldCBzID0gcGFyc2VGbG9hdChtYXRjaFszXSwgMTApXG4gICAgbGV0IGwgPSBwYXJzZUZsb2F0KG1hdGNoWzVdLCAxMClcblxuICAgIHdoaWxlIChoID4gMzYwKSB7XG4gICAgICBoIC09IDM2MFxuICAgIH1cbiAgICB3aGlsZSAoaCA8IDApIHtcbiAgICAgIGggKz0gMzYwXG4gICAgfVxuICAgIGlmIChtYXRjaFs0XSkge1xuICAgICAgcyAvPSAxMDBcbiAgICB9XG4gICAgcyA9IE1hdGgubWF4KDAsIE1hdGgubWluKHMsIDEpKVxuICAgIGlmIChtYXRjaFs2XSkge1xuICAgICAgbCAvPSAxMDBcbiAgICB9XG4gICAgbCA9IE1hdGgubWF4KDAsIE1hdGgubWluKGwsIDEpKVxuXG4gICAgcmdiID0gaHNsMnJnYihoLCBzLCBsKSAvLyBbPDAuMC0xLjA+LCA8MC4wLTEuMD4sIDwwLjAtMS4wPl1cbiAgICAgICAgIC5tYXAobnVtYmVyID0+IE1hdGgucm91bmQobnVtYmVyICogMjU1KSlcbiAgfVxuXG4gIHJldHVybiByZ2Jcbn1cblxuXG4vKipcbiAqIEBwYXJhbSAgIHs8dHlwZT59ICBjb2xvciAgIE11c3QgYmUgYSBjb2xvciAocmdiIG9yIGhleClcbiAqIEBwYXJhbSAgIHtvYmplY3R9ICB2YWx1ZXMgIE1heSBiZSBhbiBvYmplY3Qgd2l0aCB0aGUgc2FtZVxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RydWN0dXJlIGFzIGRlZmF1bHRzXG4gKiBAcmV0dXJuICB7b2JqZWN0fSAgUmV0dXJucyBhbiBvYmplY3Qgd2l0aCB0aGUgc2FtZSBzdHJ1Y3R1cmUgYXNcbiAqICAgICAgICAgICAgICAgICAgICBkZWZhdWx0cywgYnV0IHdoZXJlIGVhY2ggdmFsdWUgaXMgYSBjb2xvclxuICovXG5leHBvcnQgY29uc3QgYnV0dG9uQ29sb3JzID0gKGNvbG9yLCB2YWx1ZXMpID0+IHtcbiAgY29uc3Qgb3V0cHV0ID0ge1xuICAgIHJlc3RCZzogICAgIDFcbiAgLCByZXN0VGludDogICAxLjVcbiAgLCByZXN0U2hhZGU6ICAwLjc1XG5cbiAgLCBvdmVyQmc6ICAgIDEuMVxuICAsIG92ZXJUaW50OiAgMS42NVxuICAsIG92ZXJTaGFkZTogMC42NjdcblxuICAsIGRvd25CZzogICAgMC45NVxuICAsIGRvd25UaW50OiAgMS4zMzNcbiAgLCBkb3duU2hhZGU6IDAuNlxuICB9XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvdXRwdXQpXG5cbiAgOyhmdW5jdGlvbiBtZXJnZShpbnB1dCkge1xuICAgIGlmICh0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGtleXMuZm9yRWFjaCgga2V5ID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBpbnB1dFtrZXldXG4gICAgICAgIGlmICghaXNOYU4odmFsdWUpKSB7XG4gICAgICAgICAgaWYgKHZhbHVlID4gMCkge1xuICAgICAgICAgICAgb3V0cHV0W2tleV0gPSB2YWx1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0pKClcblxuICBrZXlzLmZvckVhY2goIGtleSA9PiAoXG4gICAgb3V0cHV0W2tleV0gPSB0b25lQ29sb3IoY29sb3IsIG91dHB1dFtrZXldKVxuICApKVxuXG4gIHJldHVybiBvdXRwdXRcbn1cblxuXG4vLy8gQVJSQVnCoEZVTkNUSU9OU8KgLy8vXG5cbmV4cG9ydCBjb25zdCByZW1vdmVGcm9tID0gKGFycmF5LCBpdGVtLCByZW1vdmVBbGwpID0+IHtcbiAgbGV0IHJlbW92ZWQgPSAwXG4gIGxldCBpbmRleFxuICAgICwgZm91bmRcblxuICBkbyB7XG4gICAgaWYgKHR5cGVvZiBpdGVtID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGluZGV4ID0gYXJyYXkuZmluZEluZGV4KGl0ZW0pXG4gICAgfSBlbHNlIHtcbiAgICAgIGluZGV4ID0gYXJyYXkuaW5kZXhPZihpdGVtKVxuICAgIH1cblxuICAgIGZvdW5kID0gIShpbmRleCA8IDApXG4gICAgaWYgKGZvdW5kKSB7XG4gICAgICBhcnJheS5zcGxpY2UoaW5kZXgsIDEpXG4gICAgICByZW1vdmVkICs9IDFcbiAgICB9XG4gIH0gd2hpbGUgKHJlbW92ZUFsbCAmJiBmb3VuZClcblxuICByZXR1cm4gcmVtb3ZlZFxufVxuXG5cblxuZXhwb3J0IGNvbnN0IGdldERpZmZlcmVuY2VzID0gKCkgPT4ge1xuICBsZXQgIHByZXZpb3VzID0gW11cblxuICByZXR1cm4gKGFycmF5KSA9PiB7XG4gICAgY29uc3QgcGx1cyA9IGFycmF5LmZpbHRlcihpdGVtID0+IHByZXZpb3VzLmluZGV4T2YoaXRlbSkgPCAwKVxuICAgIGNvbnN0IG1pbnVzID0gcHJldmlvdXMuZmlsdGVyKGl0ZW0gPT4gYXJyYXkuaW5kZXhPZihpdGVtKSA8IDApXG4gICAgcHJldmlvdXMgPSBbLi4uYXJyYXldXG5cbiAgICByZXR1cm4geyBwbHVzLCBtaW51cyB9XG4gIH1cbn1cblxuXG5cbmV4cG9ydCBjb25zdCB0cmFja0NoYW5nZXMgPSAoYXJyYXkpID0+IHtcbiAgY29uc3QgY3VycmVudCA9IGFycmF5XG4gIGxldCAgcHJldmlvdXMgPSBbLi4uYXJyYXldXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBjb25zdCBwbHVzID0gYXJyYXkuZmlsdGVyKGl0ZW0gPT4gcHJldmlvdXMuaW5kZXhPZihpdGVtKSA8IDApXG4gICAgY29uc3QgbWludXMgPSBwcmV2aW91cy5maWx0ZXIoaXRlbSA9PiBhcnJheS5pbmRleE9mKGl0ZW0pIDwgMClcbiAgICBwcmV2aW91cyA9IFsuLi5hcnJheV1cblxuICAgIHJldHVybiB7IHBsdXMsIG1pbnVzIH1cbiAgfVxufVxuXG5cblxuZXhwb3J0IGNvbnN0IHNodWZmbGUgPSAoYSkgPT4ge1xuICBsZXQgaWkgPSBhLmxlbmd0aFxuXG4gIHdoaWxlIChpaSkge1xuICAgIGNvbnN0IGpqID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogaWkpXG4gICAgaWkgLT0gMTtcbiAgICBbYVtpaV0sIGFbampdXSA9IFthW2pqXSwgYVtpaV1dXG4gIH1cblxuICByZXR1cm4gYSAvLyBmb3IgY2hhaW5pbmdcbn1cblxuXG5cbmV4cG9ydCBjb25zdCBnZXRSYW5kb20gPSAobWF4LCBtaW4gPSAwKSA9PiB7XG4gIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkpICsgbWluXG59XG5cblxuXG5leHBvcnQgY29uc3QgZ2V0UmFuZG9tRnJvbUFycmF5ID0gKGFycmF5KSA9PiB7XG4gIHJldHVybiBhcnJheVtNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKsKgYXJyYXkubGVuZ3RoKV1cbn1cblxuXG5cbmV4cG9ydCBjb25zdCBhcnJheU92ZXJsYXAgPSAoYXJyYXkxLCBhcnJheTIpID0+IHtcbiAgaWYgKCFhcnJheTEgfHwgIWFycmF5MS5sZW5ndGggfHwgIWFycmF5MiB8fCAhYXJyYXkyLmxlbmd0aCkge1xuICAgIHJldHVybiBbXVxuICB9XG5cbiAgcmV0dXJuIGFycmF5MS5maWx0ZXIoIGl0ZW0gPT4gYXJyYXkyLmluY2x1ZGVzKGl0ZW0pIClcbn1cblxuXG5cbmV4cG9ydCBjb25zdCBnZXRVbnVzZWQgPSAoc291cmNlLCB1c2VkLCB0b2xlcmF0ZUR1cGxpY2F0ZXMpID0+IHtcbiAgY29uc3QgdW51c2VkID0gc291cmNlLnNsaWNlKDApXG4gIHVzZWQuZm9yRWFjaChpdGVtID0+IHJlbW92ZUZyb20odW51c2VkLCBpdGVtKSlcbiAgbGV0IGl0ZW0gPSBnZXRSYW5kb21Gcm9tQXJyYXkodW51c2VkKVxuXG4gIGlmICghaXRlbSAmJiB0b2xlcmF0ZUR1cGxpY2F0ZXMpIHtcbiAgICAvLyBNYXkgcmV0dXJuIHRoZSBzYW1lIGl0ZW0gbXVsdGlwbGUgdGltZXMsXG4gICAgLy8gcmF0aGVyIHRoYW4gY3JlYXRpbmcgYSBzbW9vdGggc3ByZWFkXG4gICAgaXRlbSA9IGdldFJhbmRvbUZyb21BcnJheShzb3VyY2UpXG4gIH1cblxuICByZXR1cm4gaXRlbVxufVxuXG5cblxuLy8vIE1PVVNFL1RPVUNIwqBFVkVOVMKgRlVOQ1RJT05TIC8vL1xuXG5leHBvcnQgY29uc3QgZ2V0UGFnZVhZID0gKGV2ZW50KSA9PiB7XG4gIGlmIChldmVudC50YXJnZXRUb3VjaGVzICYmwqBldmVudC50YXJnZXRUb3VjaGVzLmxlbmd0aCkge1xuICAgIGV2ZW50ID0gZXZlbnQudGFyZ2V0VG91Y2hlc1swXSB8fCB7fVxuICB9XG5cbiAgcmV0dXJuIHsgeDogZXZlbnQucGFnZVgsIHk6IGV2ZW50LnBhZ2VZIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZ2V0WFkgPSAoZXZlbnQsIGZyYW1lKSA9PiB7XG4gIGlmIChbXCJjbGllbnRcIiwgXCJwYWdlXCIsIFwib2Zmc2V0XCJdLmluZGV4T2YoZnJhbWUpIDwgMCkge1xuICAgIGZyYW1lID0gXCJjbGllbnRcIlxuICB9XG4gIGlmIChldmVudC50YXJnZXRUb3VjaGVzICYmwqBldmVudC50YXJnZXRUb3VjaGVzLmxlbmd0aCkge1xuICAgIGV2ZW50ID0gZXZlbnQudGFyZ2V0VG91Y2hlc1swXSB8fCB7fVxuICB9XG5cbiAgcmV0dXJuIHsgeDogZXZlbnRbZnJhbWUgKyBcIlhcIl0sIHk6IGV2ZW50W2ZyYW1lICsgXCJZXCJdIH1cbn1cblxuXG5cbi8qKlxuICogUmV0dXJucyBhIHByb21pc2Ugd2hpY2ggd2lsbCBiZTpcbiAqICogcmVzb2x2ZWQgaWYgdGhlIG1vdXNlIG9yIHRvdWNoIG1vdmVzIG1vcmUgdGhhbiB0cmlnZ2VyRGVsdGFcbiAqICAgcGl4ZWxzIGluIGFueSBkaXJlY3Rpb25cbiAqICogcmVqZWN0ZWQgaWYgdGhlIG1vdXNlIGlzIHJlbGVhc2VkL3RvdWNoIGdlc3R1cmUgZW5kcyBiZWZvcmVcbiAqICAgbW92aW5nIHRoYXQgZmFyXG4gKlxuICogQHBhcmFtICB7ZXZlbnR9ICBldmVudCBzaG91bGQgYmUgYSBtb3VzZWRvd24gb3IgdG91Y2hzdGFydCBldmVudFxuICogQHBhcmFtICB7bnVtYmVyfSB0cmlnZ2VyRGVsdGEgc2hvdWxkIGJlIGEgcG9zaXRpdmUgbnVtYmVyIG9mIHBpeGVsc1xuICpcbiAqIEByZXR1cm4gIHtwcm9taXNlfVxuICovXG5leHBvcnQgY29uc3QgZGV0ZWN0TW92ZW1lbnQgPSAoZXZlbnQsIHRyaWdnZXJEZWx0YSkgPT4ge1xuICBjb25zdCB0cmlnZ2VyMiA9IHRyaWdnZXJEZWx0YSAqIHRyaWdnZXJEZWx0YVxuXG4gIGZ1bmN0aW9uIG1vdmVtZW50RGV0ZWN0ZWQocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgY29uc3QgeyB4OiBzdGFydFgsIHk6IHN0YXJ0WSB9ID0gZ2V0UGFnZVhZKGV2ZW50KVxuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGV2ZW50LCBkcmFnLCBkcm9wIH1cbiAgICBjb25zdCBjYW5jZWwgPSBzZXRUcmFja2VkRXZlbnRzKG9wdGlvbnMpXG4gICAgLy8geyBhY3Rpb25zOiB7IG1vdmU6IDxcInRvdWNobW92ZVwiIHwgXCJtb3VzZW1vdmVcIj5cbiAgICAvLyAgICAgICAgICAgICAgZW5kOiAgPFwidG91Y2hlZW5kXCIgfCBcIm1vdXNldXBcIj5cbiAgICAvLyAsIGRyYWc6IGZ1bmN0aW9uXG4gICAgLy8gLCBkcm9wOiBmdW5jdGlvblxuICAgIC8vIH1cblxuICAgIC8vIENoZWNrIGlmIHRoZSBtb3VzZS90b3VjaCBoYXMgbW92ZWQgbW9yZSB0aGFuIHRyaWdnZXJEZWx0YVxuICAgIC8vIHBpeGVscyBpbiBhbnkgZGlyZWN0aW9uLCBhbmQgcmVzb2x2ZSBwcm9taXNlIGlmIHNvLlxuICAgIGZ1bmN0aW9uIGRyYWcoZXZlbnQpIHtcbiAgICAgIGNvbnN0IHsgeCwgeSB9ID0gZ2V0UGFnZVhZKGV2ZW50KVxuICAgICAgY29uc3QgZGVsdGFYID0gc3RhcnRYIC0geFxuICAgICAgY29uc3QgZGVsdGFZID0gc3RhcnRZIC0geVxuICAgICAgY29uc3QgZGVsdGEyID0gKGRlbHRhWCAqIGRlbHRhWCArIGRlbHRhWSAqIGRlbHRhWSlcblxuICAgICAgaWYgKGRlbHRhMiA+IHRyaWdnZXIyKSB7XG4gICAgICAgIHNldFRyYWNrZWRFdmVudHMoY2FuY2VsKVxuICAgICAgICByZXNvbHZlKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBSZWplY3QgcHJvbWlzZSBpZiB0aGUgbW91c2UgaXMgcmVsZWFzZSBiZWZvcmUgdGhlIG1vdXNlL3RvdWNoXG4gICAgLy8gbW92ZWQgdHJpZ2dlckRlbHRhIHBpeGVscyBpbiBhbnkgZGlyZWN0aW9uLlxuICAgIGZ1bmN0aW9uIGRyb3AoZXZlbnQpIHtcbiAgICAgIHNldFRyYWNrZWRFdmVudHMoY2FuY2VsKVxuICAgICAgcmVqZWN0KClcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbmV3IFByb21pc2UobW92ZW1lbnREZXRlY3RlZClcbn1cblxuXG5cbmV4cG9ydCBjb25zdCBzZXRUcmFja2VkRXZlbnRzID0gKHsgYWN0aW9ucywgZXZlbnQsIGRyYWcsIGRyb3AgfSkgPT4ge1xuICAvLyBPbWl0IGV2ZW50IHRvIGNhbmNlbCB0cmFja2luZ1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuYm9keVxuXG4gIGlmIChldmVudCkge1xuICAgIGlmICh0eXBlb2YgYWN0aW9ucyAhPT0gXCJvYmplY3RcIikge1xuICAgICAgYWN0aW9ucyA9IHt9XG4gICAgfVxuXG4gICAgaWYgKGV2ZW50LnR5cGUgPT09IFwidG91Y2hzdGFydFwiKSB7XG4gICAgICBhY3Rpb25zLm1vdmUgID0gXCJ0b3VjaG1vdmVcIlxuICAgICAgYWN0aW9ucy5lbmQgICA9IFwidG91Y2hlbmRcIlxuICAgIH0gZWxzZSB7XG4gICAgICBhY3Rpb25zLm1vdmUgID0gXCJtb3VzZW1vdmVcIlxuICAgICAgYWN0aW9ucy5lbmQgICA9IFwibW91c2V1cFwiXG4gICAgfVxuXG4gICAgYm9keS5hZGRFdmVudExpc3RlbmVyKGFjdGlvbnMubW92ZSwgZHJhZywgZmFsc2UpXG4gICAgYm9keS5hZGRFdmVudExpc3RlbmVyKGFjdGlvbnMuZW5kLCBkcm9wLCBmYWxzZSlcblxuICB9IGVsc2Uge1xuICAgIGJvZHkucmVtb3ZlRXZlbnRMaXN0ZW5lcihhY3Rpb25zLm1vdmUsIGRyYWcsIGZhbHNlKVxuICAgIGJvZHkucmVtb3ZlRXZlbnRMaXN0ZW5lcihhY3Rpb25zLmVuZCwgZHJvcCwgZmFsc2UpXG4gIH1cblxuICByZXR1cm4geyBhY3Rpb25zLCBkcmFnLCBkcm9wIH1cbn1cblxuXG4vLy8gUkVDVMKgJiBPQkpFQ1QgRlVOQ1RJT05TwqAvLy9cblxuZXhwb3J0IGNvbnN0IGludGVyc2VjdCA9IChyZWN0MSwgcmVjdDIpID0+IHtcbiAgcmV0dXJuIHJlY3QxLnggPCByZWN0Mi5yaWdodFxuICAgICAgJiYgcmVjdDIueCA8IHJlY3QxLnJpZ2h0XG4gICAgICAmJsKgcmVjdDEueSA8IHJlY3QyLmJvdHRvbVxuICAgICAgJiYgcmVjdDIueSA8IHJlY3QxLmJvdHRvbVxufVxuXG5cblxuZXhwb3J0IGNvbnN0IGludGVyc2VjdGlvbiA9IChyZWN0MSwgcmVjdDIpID0+IHtcbiAgY29uc3QgbGVmdCAgID0gTWF0aC5tYXgoIHJlY3QxLmxlZnQgfHwgcmVjdDEueCB8fCAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgLCByZWN0Mi5sZWZ0IHx8wqByZWN0Mi54IHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICApXG4gIGNvbnN0IHJpZ2h0ICA9IE1hdGgubWluKCByZWN0MS5yaWdodHx8cmVjdDEubGVmdCtyZWN0MS53aWR0aHx8MFxuICAgICAgICAgICAgICAgICAgICAgICAgICwgcmVjdDIucmlnaHR8fHJlY3QyLmxlZnQrcmVjdDIud2lkdGh8fDBcbiAgICAgICAgICAgICAgICAgICAgICAgICApXG4gIGlmICghKGxlZnQgPCByaWdodCkpIHtcbiAgICByZXR1cm4gMFxuICB9XG5cbiAgY29uc3QgdG9wICAgID0gTWF0aC5tYXgoIHJlY3QxLnRvcCB8fCByZWN0MS55IHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAsIHJlY3QyLnRvcCB8fMKgcmVjdDIueSB8fCAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgKVxuICBjb25zdCBib3R0b20gPSBNYXRoLm1pbiggcmVjdDEuYm90dG9tfHxyZWN0MS50b3ArcmVjdDEuaGVpZ2h0fHwwXG4gICAgICAgICAgICAgICAgICAgICAgICAgLCByZWN0Mi5ib3R0b218fHJlY3QyLnRvcCtyZWN0Mi5oZWlnaHR8fDBcbiAgICAgICAgICAgICAgICAgICAgICAgICApXG4gIGlmICghKHRvcCA8IGJvdHRvbSkpIHtcbiAgICByZXR1cm4gMFxuICB9XG5cbiAgY29uc3QgeCA9IGxlZnRcbiAgY29uc3QgeSA9IHRvcFxuICBjb25zdCB3aWR0aCAgPSByaWdodCAtIHhcbiAgY29uc3QgaGVpZ2h0ID0gYm90dG9tIC0geVxuXG4gIHJldHVybiB7IHgsIHksIGxlZnQsIHJpZ2h0LCB0b3AsIGJvdHRvbSwgd2lkdGgsIGhlaWdodCB9XG59XG5cblxuXG5leHBvcnQgY29uc3QgdW5pb24gPSAocmVjdHMpID0+IHtcbiAgY29uc3QgWyByZWN0LCAuLi5yZXN0IF0gPSByZWN0c1xuICBsZXQgeyBsZWZ0LCByaWdodCwgdG9wLCBib3R0b20gfSA9IHJlY3RcblxuICByZXN0LmZvckVhY2goIHJlY3QgPT4ge1xuICAgIGxlZnQgICA9IE1hdGgubWluKGxlZnQsICAgcmVjdC5sZWZ0KVxuICAgIHJpZ2h0ICA9IE1hdGgubWF4KHJpZ2h0LCAgcmVjdC5yaWdodClcbiAgICB0b3AgICAgPSBNYXRoLm1pbih0b3AsICAgIHJlY3QudG9wKVxuICAgIGJvdHRvbSA9IE1hdGgubWF4KGJvdHRvbSwgcmVjdC5ib3R0b20pXG4gIH0pXG5cbiAgY29uc3QgeCA9IGxlZnRcbiAgY29uc3QgeSA9IHRvcFxuICBjb25zdCB3aWR0aCA9IHJpZ2h0IC0gbGVmdFxuICBjb25zdCBoZWlnaHQgPSBib3R0b20gLSB0b3BcblxuICByZXR1cm4geyB4LCB5LCBsZWZ0LCByaWdodCwgdG9wLCBib3R0b20sIHdpZHRoLCBoZWlnaHQgfVxufVxuXG5cblxuZXhwb3J0IGNvbnN0IHBvaW50V2l0aGluID0gKCB4LCB5LCByZWN0ICkgPT4ge1xuICByZXR1cm4gcmVjdC54IDw9IHhcbiAgICAgICYmIHJlY3QueSA8PSB5XG4gICAgICAmJiByZWN0LnJpZ2h0ID4geFxuICAgICAgJiYgcmVjdC5ib3R0b20gPiB5XG59XG5cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHdoaWNoIGZyYWN0aW9uIG9mIHJlY3Qgc2hhcmVzIGl0IGFyZWEgd2l0aCBjb250YWluZXJcbiAqL1xuZXhwb3J0IGNvbnN0IG92ZXJsYXAgPSAocmVjdCwgY29udGFpbmVyKSA9PiB7XG4gIGxldCBvdmVybGFwID0gaW50ZXJzZWN0aW9uKHJlY3QsIGNvbnRhaW5lcikgLy8gMCBvciByZWN0IG9iamVjdFxuXG4gIGlmIChvdmVybGFwKSB7XG4gICAgY29uc3Qgd2lkdGggID0gcmVjdC53aWR0aCB8fMKgKHJlY3QubGVmdCAtIHJlY3QucmlnaHQpXG4gICAgY29uc3QgaGVpZ2h0ID0gcmVjdC5oZWlnaHQgfHzCoChyZWN0LmJvdHRvbSAtIHJlY3QudG9wKVxuICAgIG92ZXJsYXAgPSAob3ZlcmxhcC53aWR0aCAqIG92ZXJsYXAuaGVpZ2h0KSAvICh3aWR0aCAqIGhlaWdodClcbiAgfVxuXG4gIHJldHVybiBvdmVybGFwXG59XG5cblxuXG5leHBvcnQgY29uc3QgdmFsdWVzTWF0Y2ggPSAoYSwgYikgPT4ge1xuICBpZiAoICFhIHx8IHR5cGVvZiBhICE9PSBcIm9iamVjdFwiIHx8ICFiIHx8IHR5cGVvZiBiICE9PSBcIm9iamVjdFwiKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBjb25zdCBwcm9wc0EgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhhKVxuICBjb25zdCBwcm9wc0IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhiKVxuXG4gIGlmIChwcm9wc0EubGVuZ3RoICE9PSBwcm9wc0EubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBjb25zdCB0b3RhbCA9IHByb3BzQS5sZW5ndGhcbiAgZm9yICggbGV0IGlpID0gMDsgaWkgPCB0b3RhbDsgaWkgKz0gMSApIHtcbiAgICBjb25zdCBwcm9wID0gcHJvcHNBW2lpXVxuXG4gICAgaWYgKGFbcHJvcF0gIT09IGJbcHJvcF0pIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIGlmICghcmVtb3ZlRnJvbShwcm9wc0IsIHByb3ApKSB7XG4gICAgICAvLyBwcm9wIGlzIHVuZGVmaW5lZCBpbiBhIGFuZCBtaXNzaW5nIGluIGJcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0cnVlXG59XG5cblxuLy8gRk9OVFMgLy9cblxuZXhwb3J0IGNvbnN0IGdldEZvbnRGYW1pbHkgPSAoZmYpID0+IHtcbiAgY29uc3Qgc3RhcnQgPSBmZi5pbmRleE9mKCdmYW1pbHk9JylcbiAgaWYgKHN0YXJ0ID09PSAtMSkgcmV0dXJuICdzYW5zLXNlcmlmJ1xuICBsZXQgZW5kID0gZmYuaW5kZXhPZignJicsIHN0YXJ0KVxuICBpZihlbmQgPT09IC0xKSBlbmQgPSB1bmRlZmluZWRcbiAgZmYgPSBmZi5zbGljZShzdGFydCArIDcsIGVuZCkucmVwbGFjZShcIitcIiwgXCIgXCIpXG4gIGZmID0gJ1wiJysgZmYgKyAnXCInXG4gIHJldHVybiBmZiAvLyArICcsIHNhbnMtc2VyaWYnXG59XG5cblxuLy8gRU5DUllQVElPTlxuXG4vLyBieSBicnljIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS81MjE3MTQ4MC8xOTI3NTg5XG5leHBvcnQgY29uc3QgaGFzaCA9IChzdHIsIHNlZWQgPSAwKSA9PiB7XG4gIGxldCBoMSA9IDB4ZGVhZGJlZWYgXiBzZWVkLCBoMiA9IDB4NDFjNmNlNTcgXiBzZWVkXG4gIGZvciAobGV0IGkgPSAwLCBjaDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgY2ggPSBzdHIuY2hhckNvZGVBdChpKVxuICAgICAgaDEgPSBNYXRoLmltdWwoaDEgXiBjaCwgMjY1NDQzNTc2MSlcbiAgICAgIGgyID0gTWF0aC5pbXVsKGgyIF4gY2gsIDE1OTczMzQ2NzcpXG4gIH1cbiAgaDEgPSBNYXRoLmltdWwoaDEgXiBoMT4+PjE2LCAyMjQ2ODIyNTA3KVxuICAgICBeIE1hdGguaW11bChoMiBeIGgyPj4+MTMsIDMyNjY0ODk5MDkpXG4gIGgyID0gTWF0aC5pbXVsKGgyIF4gaDI+Pj4xNiwgMjI0NjgyMjUwNylcbiAgICAgXiBNYXRoLmltdWwoaDEgXiBoMT4+PjEzLCAzMjY2NDg5OTA5KVxuXG4gIHJldHVybiA0Mjk0OTY3Mjk2ICogKDIwOTcxNTEgJiBoMikgKyAoaDE+Pj4wKVxufVxuXG5cbi8vIElNQUdFU8KgLy9cblxuLy8gSW5zcGlyZWQgYnkgaHR0cHM6Ly9vdXJjb2Rld29ybGQuY29tL2FydGljbGVzL3JlYWQvNjgzL2hvdy10by1yZW1vdmUtdGhlLXRyYW5zcGFyZW50LXBpeGVscy10aGF0LXN1cnJvdW5kcy1hLWNhbnZhcy1pbi1qYXZhc2NyaXB0XG4vLyBNSVQgaHR0cDovL3JlbS5taXQtbGljZW5zZS5vcmdcbmV4cG9ydCBjb25zdCB0cmltSW1hZ2UgPSAoaW1hZ2UpID0+IHtcbiAgY29uc3QgYyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIilcbiAgYy53aWR0aCA9IGltYWdlLndpZHRoXG4gIGMuaGVpZ2h0ID0gaW1hZ2UuaGVpZ2h0XG5cbiAgY29uc3QgY3R4ID0gYy5nZXRDb250ZXh0KCcyZCcpXG4gIGN0eC5kcmF3SW1hZ2UoaW1hZ2UsIDAsIDApXG5cbiAgY29uc3QgY29weSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpLmdldENvbnRleHQoJzJkJylcbiAgY29uc3QgcGl4ZWxzID0gY3R4LmdldEltYWdlRGF0YSgwLCAwLCBjLndpZHRoLCBjLmhlaWdodClcbiAgY29uc3QgbCA9IHBpeGVscy5kYXRhLmxlbmd0aFxuICBjb25zdCBib3VuZCA9IHtcbiAgICB0b3A6IG51bGxcbiAgLCBsZWZ0OiBudWxsXG4gICwgcmlnaHQ6IG51bGxcbiAgLCBib3R0b206IG51bGxcbiAgfVxuICBsZXQgaWlcbiAgICAsIHhcbiAgICAsIHlcblxuICAvLyBJdGVyYXRlIG92ZXIgZXZlcnkgcGl4ZWwgdG8gZmluZCB0aGUgaGlnaGVzdFxuICAvLyBhbmQgd2hlcmUgaXQgZW5kcyBvbiBldmVyeSBheGlzICgpXG4gIGZvciAoaWkgPSAwOyBpaSA8IGw7IGlpICs9IDQpIHtcbiAgICAgIGlmIChwaXhlbHMuZGF0YVtpaSArIDNdICE9PSAwKSB7XG4gICAgICAgICAgeCA9IChpaSAvIDQpICUgYy53aWR0aFxuICAgICAgICAgIHkgPSB+figoaWkgLyA0KSAvIGMud2lkdGgpXG5cbiAgICAgICAgICBpZiAoYm91bmQudG9wID09PSBudWxsKSB7XG4gICAgICAgICAgICAgIGJvdW5kLnRvcCA9IHlcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoYm91bmQubGVmdCA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICBib3VuZC5sZWZ0ID0geFxuICAgICAgICAgIH0gZWxzZSBpZiAoeCA8IGJvdW5kLmxlZnQpIHtcbiAgICAgICAgICAgICAgYm91bmQubGVmdCA9IHhcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoYm91bmQucmlnaHQgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgYm91bmQucmlnaHQgPSB4XG4gICAgICAgICAgfSBlbHNlIGlmIChib3VuZC5yaWdodCA8IHgpIHtcbiAgICAgICAgICAgICAgYm91bmQucmlnaHQgPSB4XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGJvdW5kLmJvdHRvbSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICBib3VuZC5ib3R0b20gPSB5XG4gICAgICAgICAgfSBlbHNlIGlmIChib3VuZC5ib3R0b20gPCB5KSB7XG4gICAgICAgICAgICAgIGJvdW5kLmJvdHRvbSA9IHlcbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cblxuICAvLyBDYWxjdWxhdGUgdGhlIGhlaWdodCBhbmQgd2lkdGggb2YgdGhlIGNvbnRlbnRcbiAgY29uc3QgdHJpbUhlaWdodCA9IGJvdW5kLmJvdHRvbSAtIGJvdW5kLnRvcFxuICBjb25zdCB0cmltV2lkdGggPSBib3VuZC5yaWdodCAtIGJvdW5kLmxlZnRcbiAgY29uc3QgdHJpbW1lZCA9IGN0eC5nZXRJbWFnZURhdGEoXG4gICAgYm91bmQubGVmdFxuICAsIGJvdW5kLnRvcFxuICAsIHRyaW1XaWR0aFxuICAsIHRyaW1IZWlnaHRcbiAgKVxuXG4gIC8vIGNvbnNvbGUubG9nKGJvdW5kKVxuXG4gIGNvcHkuY2FudmFzLndpZHRoID0gdHJpbVdpZHRoXG4gIGNvcHkuY2FudmFzLmhlaWdodCA9IHRyaW1IZWlnaHRcbiAgY29weS5wdXRJbWFnZURhdGEodHJpbW1lZCwgMCwgMClcblxuICAvLyBSZXR1cm4gYW4gaW1hZ2VcbiAgY29uc3QgdHJpbW1lZEltYWdlID0gbmV3IEltYWdlKClcbiAgdHJpbW1lZEltYWdlLnNyYyA9Y29weS5jYW52YXMudG9EYXRhVVJMKClcblxuICByZXR1cm4gdHJpbW1lZEltYWdlXG59XG4vL1xuLy8gd2luZG93LnRyaW1JbWFnZSA9IHRyaW1JbWFnZVxuXG5cblxuLy8gU1RSSU5HU8KgLy9cblxuLyoqIEFkZHMgY3VzdG9taXphYmxlIGluc2VydHMgdG8gYSBzdHJpbmcgKGUuZy4gV2VsY29tZSA8dXNlcm5hbWU+KVxuICpcbiAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICBwaHJhc2UgICBzdHJpbmcgT1JcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHNpbXBsZTogIFwiTG9nIGluXCJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIHJlcGxhY2U6IFwiTG9nIGluIGFzIF4wXCJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gKiBAcGFyYW0gICAgIHtvYmplY3R9ICAgb3B0aW9ucyAgeyBcIl4wXCI6IFwiYWRtaW5cIiwgLi4ufVxuICpcbiAqIEByZXR1cm4gICAge3N0cmluZ30gICBzdHJpbmcgKHdpdGggY3VzdG9taXplZCBpbnNlcnRzKVxuICovXG5leHBvcnQgY29uc3Qgc3Vic3RpdHV0ZSA9IChwaHJhc2UsIG9wdGlvbnMpID0+IHtcbiAgaWYgKG9wdGlvbnMgJibCoHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiKSB7XG4gICAgaWYgKHR5cGVvZiBwaHJhc2UgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIHBocmFzZSA9IHBocmFzZS5yZXBsYWNlXG4gICAgfVxuXG4gICAgZm9yIChrZXkgaW4gb3B0aW9ucykge1xuICAgICAgcGhyYXNlID0gcGhyYXNlLnJlcGxhY2Uoa2V5LCBvcHRpb25zW2tleV0pXG4gICAgfVxuXG4gIH0gZWxzZSBpZiAodHlwZW9mIHBocmFzZSA9PT0gXCJvYmplY3RcIikge1xuICAgIHBocmFzZSA9IHBocmFzZS5zaW1wbGVcbiAgfVxuXG4gIC8vIFJlcGxhY2UgdW5kZXJzY29yZXMgd2l0aCBub24tYnJlYWtpbmcgc3BhY2VzXG4gIHBocmFzZSA9IHBocmFzZS5yZXBsYWNlKC9fL2csIFwiwqBcIilcblxuICByZXR1cm4gcGhyYXNlXG59XG5cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBiZXN0IGxvY2FsaXplZCBzdHJpbmcgZnJvbSBhIG1hcCBvZiBwaHJhc2VzXG4gKlxuICogQHBhcmFtICAgICAge29iamVjdH0gIHBocmFzZURhdGEgICB7IC4uLlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFwiY28tREVcIjogXCJyZWdpb25hbCBzdHJpbmdcIlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFwiY29cIjogXCJnZW5lcmljIHN0cmluZ1wiXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgLi4uXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICBbY29kZT1cImVuXCJdICBsYW5ndWFnZSBjb2RlIOKJiCBcImNvXCIgb3IgXCJjby1ERVwiXG4gKlxuICogQHJldHVybiAgICAge3N0cmluZ30gIFwiPE1pc3Npbmc+XCIgb3IgdGhlIGxvY2FsaXplZCBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGdldExvY2FsaXplZCA9IChwaHJhc2VEYXRhLCBjb2RlID0gXCJlblwiLCBvcHRpb25zKSA9PiB7XG4gIGxldCBwaHJhc2UgPSBwaHJhc2VEYXRhW2NvZGVdXG5cbiAgaWYgKCFwaHJhc2UpIHtcbiAgICAvLyBDaGVjayBpZiB0aGVyZSBpcyBhIG1vcmUgZ2VuZXJpYyBwaHJhc2Ugd2l0aG91dCB0aGUgcmVnaW9uXG4gICAgY29uc3Qgc3RyaXBSZWdleCA9IC8tXFx3Ky9cbiAgICBjb2RlID0gY29kZS5yZXBsYWNlKHN0cmlwUmVnZXgsIFwiXCIpIC8vIFwiY28tREVcIiA9PiBcImNvXCJcbiAgICBwaHJhc2UgPSBwaHJhc2VEYXRhW2NvZGVdXG5cbiAgICBpZiAoIXBocmFzZSkge1xuICAgICAgLy8gVXNlIGFueSByZWdpb25hbCBkaWFsZWN0IG9mIEVuZ2xpc2ggYXMgYSBmYWxsYmFja1xuICAgICAgY29uc3QgYXZhaWxhYmxlID0gT2JqZWN0LmtleXMocGhyYXNlRGF0YSlcbiAgICAgIGNvZGUgPSBhdmFpbGFibGUuZmluZChrZXkgPT4ga2V5LnJlcGxhY2Uoc3RyaXBSZWdleCkgPT09IFwiZW5cIilcblxuICAgICAgaWYgKGNvZGUpIHtcbiAgICAgICAgcGhyYXNlID0gcGhyYXNlRGF0YVtjb2RlXVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVXNlIHRoZSBmaXJzdCBhdmFpbGFibGUgbGFuZ3VhZ2VcbiAgICAgICAgcGhyYXNlID0gcGhyYXNlRGF0YVthdmFpbGFibGVbMF1dXG4gICAgICB9XG5cbiAgICAgIGlmICghcGhyYXNlKSB7XG4gICAgICAgIHBocmFzZSA9IFwiPE1pc3Npbmc+XCJcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwaHJhc2UgPSBzdWJzdGl0dXRlKHBocmFzZSwgb3B0aW9ucylcblxuICByZXR1cm4gcGhyYXNlXG59XG5cblxuLyoqIFNlbGVjdHMgYSBsb2NhbGl6ZWQgc3RyaW5nIGZyb20gYW4gYXJyYXkgYW5kIGN1c3RvbWl6ZXMgaXRcbiAqICByZXBsYWNpbmcgYW55ICh2aXNpYmxlKSB1bmRlcnNjb3JlcyB3aXRoIChpbnZpc2libGUpXG4gKiAgbm9uLWJyZWFraW5nIHNwYWNlc1xuICpcbiAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICBjdWUgICAgIHN0cmluZyBjdWUgdmFsdWUgZnJvbSBjb3JwdXNcbiAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICBjb2RlICAgIHN0cmluZyBsYW5ndWFnZSBjb2RlLCBsaWtlIFwiY28tREVcIlxuICogQHBhcmFtICAgICAge2FycmF5fSAgIGNvcnB1cyAgWyB7IFwiY3VlXCI6IFwidW5pcXVlX3N0cmluZ1wiXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgXCJjby1ERVwiOiBcImZpeGVkIHN0cmluZ1wiXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgXCJjb1wiOiAgICBcInZhcmlhYmxlIHN0cmluZyBeMFwiXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgLi4uXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgLi4uXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gKiBAcGFyYW0gICAgIHtvYmplY3R9ICAgb3B0aW9ucyAgeyBcIl4wXCI6IFwiY2hhbmdlYWJsZSBwYXJ0XCIsIC4uLn1cbiAqXG4gKiBAcmV0dXJuICAgIHtzdHJpbmd9ICAgJyoqKmN1ZSoqKicgb3IgbG9jYWxpemVkIHN0cmluZyB3aXRoICZuYnNwO1xuICovXG5leHBvcnQgY29uc3QgbG9jYWxpemUgPSAoY3VlLCBjb2RlLCBjb3JwdXMsIG9wdGlvbnMpID0+IHtcbiAgbGV0IHBocmFzZVxuXG4gIGNvbnN0IHBocmFzZURhdGEgPSBjb3JwdXMuZmluZChwaHJhc2UgPT4gKFxuICAgIHBocmFzZS5jdWUgPT09IGN1ZVxuICApKVxuXG4gIGlmIChwaHJhc2VEYXRhKSB7XG4gICAgcGhyYXNlID0gZ2V0TG9jYWxpemVkKHBocmFzZURhdGEsIGNvZGUsIG9wdGlvbnMpXG4gIH1cblxuICBpZiAoIXBocmFzZSkge1xuICAgIGNvbnNvbGUubG9nKCBcIk5vdCBmb3VuZCDigJQgY3VlOlwiLCBjdWVcbiAgICAgICAgICAgICAgICwgXCJjb2RlOlwiLCBjb2RlXG4gICAgICAgICAgICAgICAsIFwicGhyYXNlRGF0YTpcIiwgcGhyYXNlRGF0YVxuICAgICAgICAgICAgICAgKVxuICAgIHBocmFzZSA9IFwiKioqXCIgKyBjdWUgKyBcIioqKlwiXG4gIH1cblxuICByZXR1cm4gcGhyYXNlXG59XG5cblxuLy8gSFRNTMKgRUxFTUVOVFPCoC8vXG5cblxuLyoqIFJldHVybnMgaW5kZXggb2YgdGhlIGNoaWxkIG9mIHBhcmVudFRhZyB0aGF0IGNvbnRhaW5zIGVsZW1lbnRcbiAqXG4gKiBUaGlzIGlzIHVzZWZ1bCB3aGVuIHlvdSB3YW50IHRvIGZpbmQgKGZvciBpbnN0YW5jZSkgd2hpY2ggbGlzdFxuICogaXRlbSB3YXMgc2VsZWN0ZWQsIGdpdmVuIHRoYXQgdGhlIGV2ZW50IG9jY3VycmVkIG9uIGEgY2hpbGQgb2YgdGhlXG4gKiBsaXN0IGl0ZW0uXG4gKlxuICogQHBhcmFtICAgIHs8dHlwZT59ICAgICAgICAgIGVsZW1lbnQgICAgQW4gSFRNTMKgZWxlbWVudFxuICogQHBhcmFtICAgIHtzdHJpbmd9ICAgICAgICAgIHBhcmVudFRhZyAgVGhlIHN0cmluZyB0YWcgb2YgdGhlIHBhcmVudFxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2YgdGhlIGVsZW1lbnQgdGhhdCBjb250YWluc1xuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGVsZW1lbnRgLiBcIlVMXCIgYnkgZGVmYXVsdC5cbiAqIEByZXR1cm4gICB7aW50ZWdlcn0gIC0xIGlmIGVsZW1lbnQgaXMgbm90IHZhbGlkIG9yIGlmIGl0IGRvZXMgbm90XG4gKiAgICAgICAgICAgICAgICAgICAgICBoYXZlIGEgcGFyZW50IHdpdGggdGhlIGdpdmVuIHRhZywgTm9uLW5lZ2F0aXZlXG4gKiAgICAgICAgICAgICAgICAgICAgICBpbnRlZ2VyIGlmIHRoZSBlbGVtZW50J3MgcGFyZW50IGlzIGZvdW5kLlxuICovXG5leHBvcnQgY29uc3QgZ2V0RWxlbWVudEluZGV4ID0gKGVsZW1lbnQsIHBhcmVudFRhZykgPT4ge1xuICBsZXQgaW5kZXggPSAtMVxuXG4gIGlmIChlbGVtZW50IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpIHtcbiAgICBwYXJlbnRUYWcgPSB0eXBlb2YgcGFyZW50VGFnID09PSBcInN0cmluZ1wiXG4gICAgICAgICAgICAgID8gcGFyZW50VGFnLnRvVXBwZXJDYXNlKClcbiAgICAgICAgICAgICAgOiBcIlVMXCJcblxuICAgIHdoaWxlIChlbGVtZW50ICYmIGVsZW1lbnQucGFyZW50Tm9kZS50YWdOYW1lICE9PSBwYXJlbnRUYWcpIHtcbiAgICAgIGVsZW1lbnQgPSBlbGVtZW50LnBhcmVudE5vZGVcbiAgICB9XG5cbiAgICBpZiAoZWxlbWVudCkge1xuICAgICAgY29uc3Qgc2libGluZ3MgPSBbXS5zbGljZS5jYWxsKGVsZW1lbnQucGFyZW50Tm9kZS5jaGlsZHJlbilcbiAgICAgIGluZGV4ID0gc2libGluZ3MuaW5kZXhPZihlbGVtZW50KVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBpbmRleFxufVxuIiwiLyoqXG4gKiAvc2VydmVyL21pbnRlcnMvYWN0aXZpdGllcy5qc1xuICovXG5cblxuXG5jb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJylcbmNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJylcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFjdGl2aXR5TWludGVyIHtcbiAgY29uc3RydWN0b3Ioc2NyaXB0cykge1xuICAgIC8vLyA8PDwgSEFSRC1DT0RFRFxuICAgIGxldCB0YXJnZXQgPSAnLi4vLi4vaW1wb3J0cy91aS9hY3Rpdml0aWVzL21pbnQuanMnXG4gICAgLy8vIEhBUkQtQ09ERUTCoD4+PlxuXG4gICAgdGFyZ2V0ID0gcGF0aC5qb2luKHByb2Nlc3MuZW52LlBXRCwgX19kaXJuYW1lLCB0YXJnZXQpXG4gICAgY29uc3QgY2h1bmtzID0gdGhpcy5nZXRDaHVua3Moc2NyaXB0cylcblxuICAgIGxldCBzY3JpcHQgPSB0aGlzLmdldFNjcmlwdENodW5rKClcbiAgICBzY3JpcHQgKz0gY2h1bmtzLmltcG9ydHNcbiAgICBzY3JpcHQgKz0gY2h1bmtzLm5hbWVzXG5cbiAgICBmcy53cml0ZUZpbGVTeW5jKHRhcmdldCwgc2NyaXB0KVxuICAgIC8vICcuLi8uLi9wdWJsaWMvYWN0aXZpdGllcy9EcmFnL2pzL0RyYWcuanN4J1xuICB9XG5cblxuICBnZXRDaHVua3Moc2NyaXB0cykge1xuICAgIGxldCBpbXBvcnRzID0gXCJcIlxuICAgIGxldCBuYW1lcyA9IFwiXCJcblxuICAgIHNjcmlwdHMuZm9yRWFjaCggc2NyaXB0ID0+IHtcbiAgICAgIGNvbnN0IHsgbmFtZSwgZmlsZSB9ID0gc2NyaXB0XG5cbiAgICAgIGltcG9ydHMgKz0gYFxuaW1wb3J0ICR7bmFtZX0gZnJvbSAnJHtmaWxlfSdgXG5cbiAgICAgIG5hbWVzICs9IGBcbiwgJHtuYW1lfWBcbiAgICB9KVxuXG4gICAgbmFtZXMgPSBgXG5cbmV4cG9ydCB7XG4gJHtuYW1lcy5zdWJzdHJpbmcoMil9XG59YFxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGltcG9ydHNcbiAgICAsIG5hbWVzXG4gICAgfVxuICB9XG5cblxuICBnZXRTY3JpcHRDaHVuaygpIHtcbiAgICByZXR1cm4gYC8qKlxuICogKiogRE/CoE5PVMKgRURJVMKgVEhJU8KgU0NSSVBUICoqXG4gKiBJVMKgSVPCoEdFTkVSQVRFRMKgQVVUT01BVElDQUxMWVxuICrCoEVBQ0jCoFRJTUUgVEhFwqBTRVJWRVLCoFJFU1RBUlRTXG4gKlxuICogTU9ESUZZwqBUSElTwqBGSUxFwqBJTlNURUFEOlxuICogL3NlcnZlci9taW50ZXJzL2FjdGl2aXRpZXMuanNcbiAqICoqKiogKioqKiAqKioqICoqKiogKioqKiAqKioqXG4gKlxuICogVGhpcyBzY3JpcHQgZ2F0aGVycyB0b2dldGhlciBkZXRhaWxzIG9mIGFsbCB0aGUgPEFjdGl2aXR5TmFtZT4uanN4XG4gKiBzY3JpcHRzIGZvdW5kIGluIHRoZSAnL3B1YmxpYy9hY3Rpdml0aWVzLzxBY3Rpdml0eU5hbWU+LycgZm9sZGVycy5cbiAqIEpTWMKgc2NyaXB0cyB3aGljaCBkbyBub3QgaGF2ZSB0aGUgc2FtZSBuYW1lIGFzIHRoZSBmb2xkZXIgaXRzZWxmXG4gKiB3aWxsIGJlIGlnbm9yZWQuIFRoZXkgY2FuIHN0aWxsIGJlIHVzZWQgYXMgc2Vjb25kYXJ5IHZpZXdzIGJ5IG90aGVyXG4gKiBhY3Rpdml0eSBjb21wb25lbnRzLlxuICpcbiAqIFRoZSBjbGFzc2VzIGV4cG9ydGVkIGhlcmUgYXJlIGltcG9ydGVkIGFzICd2aWV3cycgYnlcbiAqICcvaW1wb3J0cy91aS9BcHAuanN4J1xuICovXG5gXG4gIH1cbn1cbiIsIi8qKlxuICogL3NlcnZlci9taW50ZXJzL2NvbGxlY3Rpb25zLmpzXG4gKi9cblxuXG5cbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxuY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29sbGVjdGlvbk1pbnRlciB7XG4gIGNvbnN0cnVjdG9yKGNvbGxlY3Rpb25zKSB7XG4gICAgLy8vIDw8PCBIQVJELUNPREVEXG4gICAgbGV0IHRhcmdldCA9ICcuLi8uLi9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9taW50LmpzJ1xuICAgIC8vLyBIQVJELUNPREVEwqA+Pj5cblxuICAgIHRhcmdldCA9IHBhdGguam9pbihwcm9jZXNzLmVudi5QV0QsIF9fZGlybmFtZSwgdGFyZ2V0KVxuICAgIGNvbnN0IHNjcmlwdENodW5rcyA9IHRoaXMuZ2V0U2NyaXB0Q2h1bmtzKClcbiAgICBjb25zdCBpbXBvcnRDaHVua3MgPSB0aGlzLmdldEltcG9ydENodW5rcyhjb2xsZWN0aW9ucylcblxuICAgIGxldCBzY3JpcHQgPSBzY3JpcHRDaHVua3NbMF1cbiAgICBzY3JpcHQgKz0gaW1wb3J0Q2h1bmtzLmNyZWF0aW9uc1xuXG4gICAgc2NyaXB0ICs9IHNjcmlwdENodW5rc1sxXVxuICAgIHNjcmlwdCArPSBpbXBvcnRDaHVua3MubmFtZXNcblxuICAgIHNjcmlwdCArPSBzY3JpcHRDaHVua3NbMl1cbiAgICBzY3JpcHQgKz0gaW1wb3J0Q2h1bmtzLnF1ZXJpZXNcblxuICAgIHNjcmlwdCArPSBzY3JpcHRDaHVua3NbM11cblxuICAgIGZzLndyaXRlRmlsZVN5bmModGFyZ2V0LCBzY3JpcHQpXG4gIH1cblxuXG4gIGdldEltcG9ydENodW5rcyhjb2xsZWN0aW9ucykge1xuICAgIC8vIGxldCBpbXBvcnRzICAgPSBcIlwiXG4gICAgbGV0IGNyZWF0aW9ucyA9IFwiXCJcbiAgICBsZXQgbmFtZXMgICAgID0gXCJcIlxuICAgIGxldCBxdWVyaWVzICAgPSBcIlwiXG5cbiAgICBjb2xsZWN0aW9ucy5mb3JFYWNoKCBuYW1lID0+IHtcbiAgICAgIC8vIGlmIChjb2xsZWN0aW9uKSB7XG4gICAgICAvLyAgIGNvbnN0IHsgbmFtZSwgZmlsZSB9ID0gY29sbGVjdGlvblxuICAgICAgLy8gICBjb25zdCBxdWVyeT1uYW1lWzBdLnRvTG93ZXJDYXNlKCkrbmFtZS5zdWJzdHJpbmcoMSkrXCJRdWVyeVwiXG4gICAgICAvLyAgIGltcG9ydHMgKz0gYFxuICAgICAgLy8gaW1wb3J0IHsgJHtuYW1lfVxuICAgICAgLy8gICwgcHVibGlzaFF1ZXJ5IGFzICR7cXVlcnl9XG4gICAgICAvLyAgfSBmcm9tICcke2ZpbGV9J2BcblxuICAgICAgY3JlYXRpb25zICs9IGBcbmNvbnN0ICR7bmFtZX0gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignJHtuYW1lLnRvTG93ZXJDYXNlKCl9JylgXG5cbiAgICAgIG5hbWVzICs9IGBcbiwgJHtuYW1lfWBcblxuICAgICAgLy8gICAgICAgIHF1ZXJpZXMgKz0gYFxuICAgICAgLy8gLCBcIiR7bmFtZX1cIjogJHtxdWVyeX1gXG4gICAgICAvLyAtICAgICAgfVxuXG4gICAgICBxdWVyaWVzICs9IGBcbiwgXCIke25hbWV9XCI6IHt9YFxuICAgIH0pXG5cbiAgICByZXR1cm4ge1xuICAgICAgY3JlYXRpb25zXG4gICAgLCBuYW1lc1xuICAgICwgcXVlcmllc1xuICAgIH1cbiAgfVxuXG5cbiAgZ2V0U2NyaXB0Q2h1bmtzKCkge1xuICAgIHJldHVybiBbYC8qKlxuICogKiogRE/CoE5PVMKgRURJVMKgVEhJU8KgU0NSSVBUICoqXG4gKiBJVMKgSVPCoEdFTkVSQVRFRMKgQVVUT01BVElDQUxMWVxuICrCoEVBQ0jCoFRJTUUgVEhFwqBTRVJWRVLCoFJFU1RBUlRTXG4gKlxuICogTU9ESUZZwqBUSElTwqBGSUxFwqBJTlNURUFEOlxuICogL3NlcnZlci9taW50ZXJzL2NvbGxlY3Rpb25zLmpzXG4gKiAqKioqICoqKiogKioqKioqKioqKiAqKioqICoqKipcbiAqXG4gKiBUaGlzIHNjcmlwdCBjcmVhdGVzIGEgTW9uZ29EQsKgY29sbGVjdGlvbiBuYW1lZCBhZnRlciBlYWNoIG9mIHRoZVxuICogZm9sZGVycyBmb3VuZCBhdCAnL3B1YmxpYy9jb2xsZWN0aW9ucy8nLlxuICpcbiAqIFRoZSBjb2xsZWN0aW9ucyBhbmQgcHVibGlzaCBxdWVyaWVzIGV4cG9ydGVkIGhlcmUgYXJlXG4gKiBpbXBvcnRlZCBieSAnLi9wdWJsaXNoZXIuanMnLCB3aGljaCBwdWJsaXNoZXMgdGhlbSBhbGwuXG4gKi9cblxuXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNvbGxlY3Rpb25zIGFzIGFkbWluQ29sbGVjdGlvbnNcbiAgICAgICAsIHB1Ymxpc2hRdWVyaWVzIGFzIGFkbWluUXVlcmllc1xuICAgICAgIH0gZnJvbSAnLi9hZG1pbidcblxuYCxcbmBcblxuXG5leHBvcnQgY29uc3QgY29sbGVjdGlvbnMgPSB7XG4gIC4uLmFkbWluQ29sbGVjdGlvbnNgLFxuYFxufVxuXG5cbmV4cG9ydCBjb25zdCBwdWJsaXNoUXVlcmllcyA9IHtcbiAgLi4uYWRtaW5RdWVyaWVzYCxcbmBcbn1gXG5dXG4gIH1cbn0iLCIvKipcbiAqIC9zZXJ2ZXIvbWludGVycy9tZXRob2RzLmpzXG4gKi9cblxuXG5cbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxuY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTWV0aG9kTWludGVyIHtcbiAgY29uc3RydWN0b3IobWV0aG9kcykge1xuICAgIC8vLyA8PDwgSEFSRC1DT0RFRFxuICAgIGxldCB0YXJnZXQgPSAnLi4vLi4vaW1wb3J0cy9hcGkvbWV0aG9kcy9taW50LmpzJ1xuICAgIC8vLyBIQVJELUNPREVEwqA+Pj5cblxuICAgIHRhcmdldCA9IHBhdGguam9pbihwcm9jZXNzLmVudi5QV0QsIF9fZGlybmFtZSwgdGFyZ2V0KVxuICAgIGNvbnN0IHNjcmlwdENodW5rcyA9IHRoaXMuZ2V0U2NyaXB0Q2h1bmtzKClcbiAgICBjb25zdCBpbXBvcnRDaHVua3MgPSB0aGlzLmdldEltcG9ydENodW5rcyhtZXRob2RzKVxuXG4gICAgbGV0IHNjcmlwdCA9IHNjcmlwdENodW5rc1swXVxuICAgIHNjcmlwdCArPSBpbXBvcnRDaHVua3MuaW1wb3J0c1xuXG4gICAgc2NyaXB0ICs9IHNjcmlwdENodW5rc1sxXVxuICAgIHNjcmlwdCArPSBpbXBvcnRDaHVua3MubmFtZXNcblxuICAgIHNjcmlwdCArPSBzY3JpcHRDaHVua3NbMl1cblxuICAgIGZzLndyaXRlRmlsZVN5bmModGFyZ2V0LCBzY3JpcHQpXG4gIH1cblxuXG4gIGdldEltcG9ydENodW5rcyhtZXRob2RzKSB7XG4gICAgbGV0IGltcG9ydHMgPSBcIlwiXG4gICAgbGV0IG5hbWVzID0gXCJcIlxuXG4gICAgbWV0aG9kcy5mb3JFYWNoKCBtZXRob2QgPT4ge1xuICAgICAgbGV0IHsgbmFtZSwgZmlsZSB9ID0gbWV0aG9kXG4gICAgICBuYW1lID0gbmFtZS50b0xvd2VyQ2FzZSgpXG5cbiAgICAgIGltcG9ydHMgKz0gYFxuaW1wb3J0ICrCoGFzICR7bmFtZX0gZnJvbSAnJHtmaWxlfSdgXG5cbiAgICAgIG5hbWVzICs9IGBcbiwgLi4uJHtuYW1lfWBcbiAgICB9KVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGltcG9ydHNcbiAgICAsIG5hbWVzXG4gICAgfVxuICB9XG5cblxuICBnZXRTY3JpcHRDaHVua3MoKSB7XG4gICAgcmV0dXJuIFtgLyoqXG4gKiAvaW1wb3J0cy9hcGkvbWV0aG9kcy9taW50LmpzXG4gKlxuICogKiogRE/CoE5PVMKgRURJVMKgVEhJU8KgU0NSSVBUICoqXG4gKiBJVMKgSVPCoEdFTkVSQVRFRMKgQVVUT01BVElDQUxMWVxuICrCoEVBQ0jCoFRJTUUgVEhFwqBTRVJWRVLCoFJFU1RBUlRTXG4gKlxuICogTU9ESUZZwqBUSElTwqBGSUxFwqBJTlNURUFEOlxuICogIC9zZXJ2ZXIvbWludGVycy9tZXRob2RzLmpzXG4gKiAqKioqICoqKiogKioqKiAqKioqICoqKiogKioqKlxuICpcbiAqIFRoaXMgc2NyaXB0IGdhdGhlcnMgdG9nZXRoZXIgZGV0YWlscyBvZiBhbGwgdGhlIG1ldGhvZHNcbiAqIGZyb20gJy4vYWRtaW4uanMnIGFuZCB0aGUgdmFyaW91cyBtZXRob2RzLmpzIGZpbGVzIGZvdW5kXG4gKiBpbiB0aGUgJy9wdWJsaWMvYWN0aXZpdGllcy88QWN0aXZpdHlOYW1lPi8nIGZvbGRlcnMuXG4gKlxuICogVGhlIG1ldGhvZHMgZXhwb3J0ZWQgaGVyZSBhcmUgaW1wb3J0ZWQgYnkgJy9zZXJ2ZXIvbWFpbi5qcydcbiAqIGFuZCB2YXJpb3VzIGNsaWVudC1zaWRlIHNjcmlwdHMuXG4gKi9cblxuaW1wb3J0ICogYXMgYWRtaW4gZnJvbSAnLi9hZG1pbidcbmltcG9ydCAqIGFzIGFzc2V0cyBmcm9tICcuL2Fzc2V0cydgXG4sYFxuXG5leHBvcnQgY29uc3QgbWV0aG9kcyA9IHtcbiAgLi4uYWRtaW5cbiwgLi4uYXNzZXRzYFxuLGBcbn1cbmBcbiAgICBdXG4gIH1cbn0iLCIvKipcbiAqIC9zZXJ2ZXIvY29sbGVjdEpTT04uanNcbiAqL1xuXG5cbi8vIFRoZSBmb2xsb3dpbmcgZmlsZSB3aWxsIGJlIHJld3JpdHRlbiBvbiBNZXRlb3Iuc3RhcnR1cCgpLiBXaGVuIG5ld1xuLy8gbW9kdWxlcyBhcmUgYWRkZWQsIHRoZSBleGlzdGluZyBjb250ZW50cyBvZiB0aGlzIGZpbGUgd2lsbCBiZVxuLy8gcmVhZCBpbiBCRUZPUkUgdGhlIGZpbGVzIGFyZSByZXdyaXR0ZW4gdG8gaW5jbHVkZSB0aGUgY29sbGVjdGlvblxuLy8gYW5kIG1ldGhvZHMgdXNlZCBieSB0aGUgbmV3IG1vZHVsZXMuIEluIG90aGVyIHdvcmRzLCBkdXJpbmdcbi8vIGRldmVsb3BtZW50LCB0aGUgc2VydmVyIHdpbGwgbmVlZCB0byBiZSByZXN0YXJ0ZWQgdHdpY2UgKG9uY2Vcbi8vIGF1dG9tYXRpY2FsbHkgYW5kIG9uY2UgbWFudWFsbHkpLlxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uL2ltcG9ydHMvYXBpL2NvbGxlY3Rpb25zL3B1Ymxpc2hlcidcblxuY29uc3QgZnMgPSByZXF1aXJlKCdmcycpXG5jb25zdCBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG5cblxuLyoqXG4gKiBAY2xhc3MgIENvbGxlY3RKU09OIChuYW1lKVxuICpcbiAqIEEgQ29sbGVjdEpTT07CoGluc3RhbmNlIGV4cGVjdHMgdG8gcmVjZWl2ZSBhIHBhdGggdG8gYWZpbGUgZWl0aGVyXG4gKiBpbiB0aGUgL3B1YmxpYyBvciB0aGUgL3ByaXZhdGUgZm9sZGVyLiBUaGlzIHBhdGggc2hvdWxkIGxlYWQgdG8gYVxuICogSlNPTiBmaWxlLCB3aXRoIHRoZSBmb3JtYXQgc2hvd24gaW4gdGhlIF90cmVhdEpTT07CoG1ldGhvZC5cbiAqXG4gKiDigKIgVGhlIHZhbHVlIG9mIGNvbGxlY3Rpb24gc2hvdWxkIGJlIG9uZSBvZiB0aGUgY2FwaXRhbGl6ZWRcbiAqICAgY29sbGVjdGlvbiBuYW1lcyBkZWZpbmVkIGluIEFwcE5hbWUvaW1wb3J0cy9hcGkvY29sbGVjdGlvbi5qc1xuICog4oCiIEFuIGFzX2lzIG9iamVjdCB3aXRoIGF0IGxlYXN0IGEgdmVyc2lvbiBudW1iZXIgbXVzdCBiZSBpbmNsdWRlZFxuICog4oCiIElmIHRoZSB2ZXJzaW9uIGluZGljYXRlZCBpbiB0aGUgYGFzX2lzYCBlbnRyeSBpcyBncmVhdGVyIHRoYW4gdGhlXG4gKiAgIHZlcnNpb24gbnVtYmVyIGN1cnJlbnRseSBzdG9yZWQgaW4gdGhlIGdpdmVuIGNvbGxlY3Rpb24sIGFsbCB0aGVcbiAqICAgZXhpc3RpbmcgdmFsdWVzIHdpbGwgYmUgcmVtb3ZlZCBhbmQgd2lsbCBiZSByZXBsYWNlZCBieSB0aGVcbiAqICAgbmV3IG9uZXMuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIENvbGxlY3RKU09OIHtcbiAgY29uc3RydWN0b3IgKGpzb25GaWxlKSB7XG4gICAgdGhpcy5qc29uRmlsZSA9IGpzb25GaWxlXG4gICAgLy8gY29uc29sZS5sb2coXCJDb2xsZWN0SlNPTlwiLCBqc29uRmlsZSlcblxuICAgIHRoaXMuX3RyZWF0SlNPTiA9IHRoaXMuX3RyZWF0SlNPTi5iaW5kKHRoaXMpXG4gICAgdGhpcy5fY2hlY2tSZXN1bHQgPSB0aGlzLl9jaGVja1Jlc3VsdC5iaW5kKHRoaXMpXG5cbiAgICAvLyBBc3NldHMuZ2V0VGV4dChqc29uRmlsZSwgdGhpcy5fdHJlYXRKU09OKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gZnMucmVhZEZpbGVTeW5jKGpzb25GaWxlKVxuICAgICAgdGhpcy5fdHJlYXRKU09OKG51bGwsIGRhdGEpXG5cbiAgICB9IGNhdGNoKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkVycm9yIHJlYWRpbmdcIiwganNvbkZpbGUsIGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIF90cmVhdEpTT04oZXJyb3IsIGRhdGEpIHtcbiAgICBpZiAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBjb25zb2xlLmxvZyhcIl90cmVhdEpTT05cIiwgZXJyb3IpXG4gICAgfVxuXG4gICAgbGV0IGpzb25cbiAgICB0cnkge1xuICAgICAganNvbiA9IEpTT04ucGFyc2UoZGF0YSlcbiAgICB9IGNhdGNoKGVycm9yKSB7XG4gICAgICByZXR1cm4gY29uc29sZS5sb2coXCJKU09OLnBhcnNlXFxuXCIsIHRoaXMuanNvbkZpbGUsIFwiXFxuXCIsIGVycm9yKVxuICAgIH1cblxuICAgIC8vIGNvbnNvbGUubG9nKGpzb24pXG4gICAgLy8geyBcImNvbGxlY3Rpb25cIjogXCJDb2xsZWN0aW9uXCIgLy8gdGFyZ2V0IGZvciBuZXcgZG9jdW1lbnRzXG4gICAgLy9cbiAgICAvLyAsIFwiYXNfaXNcIjogeyAvLyBkb2N1bWVudCB3aWxsIGJlIGFkZGVkIGFzIGlzXG4gICAgLy8gICAgIFwidmVyc2lvblwiOiA8bnVtYmVyPlxuICAgIC8vIFsgLCBcImtleVwifFwidGFnXCI6IFwiPHR5cGUgb2YgZG9jdW1lbnRzIHRvIGJlIGFkZGVkPlwiIF1cbiAgICAvLyAgICwgLi4uXG4gICAgLy8gICB9XG4gICAgLy9cbiAgICAvLyAsIFwiPHR5cGU+OiBbICAgICAgICAgLy8gZWFjaCBlbnRyeSB3aWxsIGJlIGFkZGVkIGFzIGEgc2VwYXJhdGVcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICAvLyBkb2N1bWVudCB3aXRoIHRoZSB0eXBlIFwiPHR5cGU+XCIgYW5kXG4gICAgLy8gICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIHZlcnNpb24gPGFzX2lzLnZlcnNpb24+XG4gICAgLy8gICAgIHsgXCI8a2V5PlwiOiBcIjx2YWx1ZT5cIlxuICAgIC8vICAgICAsIC4uLlxuICAgIC8vICAgICB9XG4gICAgLy8gICAsIC4uLlxuICAgIC8vICAgXVxuICAgIC8vIF1cblxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uc1tqc29uLmNvbGxlY3Rpb25dXG4gICAgaWYgKCFjb2xsZWN0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkNvbGxlY3Rpb25cIiwganNvbi5jb2xsZWN0aW9uKVxuICAgICAgcmV0dXJuIGNvbnNvbGUubG9nKFwibWlzc2luZyBmb3JcIiwgdGhpcy5qc29uRmlsZSlcbiAgICB9XG5cbiAgICBkZWxldGUganNvbi5jb2xsZWN0aW9uXG5cbiAgICBjb25zdCB2ZXJzaW9uID0gdGhpcy5fdmVyc2lvbklzTmV3ZXIoY29sbGVjdGlvbiwganNvbi5hc19pcylcbiAgICAvLyBjb25zb2xlLmxvZyhcInZlcnNpb246XCIsIHZlcnNpb24sIGpzb24uY29sbGVjdGlvbiwganNvbi5hc19pcylcbiAgICBpZiAodmVyc2lvbikge1xuICAgICAgY29uc3Qga2V5ID0ganNvbi5hc19pcy5rZXkgLy8gQ29sbGVjdGlvbk5hbWUgfCBTdWJzZXRcbiAgICAgIGNvbnN0IHRhZyA9IGpzb24uYXNfaXMudGFnIC8vIGltYWdlIHR5cGVcbiAgICAgIHRoaXMuX2RlbGV0ZU9sZGVySXRlbXMoY29sbGVjdGlvbiwga2V5LCB0YWcsIHZlcnNpb24pXG4gICAgICB0aGlzLl9pbnNlcnROZXdJdGVtcyhjb2xsZWN0aW9uLCBqc29uLCB2ZXJzaW9uKVxuICAgIH1cbiAgfVxuXG5cbiAgX3ZlcnNpb25Jc05ld2VyKGNvbGxlY3Rpb24sIGFzX2lzKSB7XG4gICAgbGV0IGtleVxuICAgICAgLCB0YWdcbiAgICAgICwgdmVyc2lvblxuXG4gICAgLy8gUmVmdXNlIHRvIGltcG9ydCBkb2N1bWVudHMgdW5sZXNzOlxuICAgIC8vICogVGhlcmUgaXMgYW4gYXNfaXMgb2JqZWN0Li4uXG4gICAgLy8gKiAuLi4gd2hpY2ggY29udGFpbnMgYSBub24temVybyB2ZXJzaW9uXG4gICAgaWYgKCFhc19pcyB8fCB0eXBlb2YgYXNfaXMgIT09IFwib2JqZWN0XCIpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gZWxzZSBpZiAoISh2ZXJzaW9uID0gYXNfaXMudmVyc2lvbikpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIC8vIENoZWNrIHRoZSBleGlzdGluZyB2ZXJzaW9uIG51bWJlciBmb3IgdGhpcyBwYXJ0aWN1bGFyIGtleSBvclxuICAgIC8vIHRhZywgYXMgYWRkZWQgZnJvbSBhIHByZXZpb3VzIGFzLWlzIGRvY3VtZW50LlxuICAgIGxldCB2ZXJzaW9uU2VsZWN0ID0geyB2ZXJzaW9uOiB7ICRleGlzdHM6IHRydWUgfX1cbiAgICBpZiAoa2V5ID0gYXNfaXMua2V5KSB7XG4gICAgICB2ZXJzaW9uU2VsZWN0ID0ge1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgdmVyc2lvblNlbGVjdFxuICAgICAgICAsIHsga2V5IH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodGFnID0gYXNfaXMudGFnKSB7XG4gICAgICB2ZXJzaW9uU2VsZWN0ID0ge1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgdmVyc2lvblNlbGVjdFxuICAgICAgICAsIHsgdGFnIH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBkb2N1bWVudCA9IGNvbGxlY3Rpb24uZmluZE9uZSh2ZXJzaW9uU2VsZWN0KVxuICAgIC8vIGNvbnNvbGUubG9nKFwiKipcIixjb2xsZWN0aW9uLl9uYW1lKVxuXG4gICAgaWYgKGRvY3VtZW50KSB7XG4gICAgICBpZiAodmVyc2lvbiA8PSBkb2N1bWVudC52ZXJzaW9uKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBcIk9sZGVyIHZlcnNpb25cIiwgZG9jdW1lbnQudmVyc2lvblxuICAgICAgICAsIFwib2ZcIiwga2V5fHx0YWd8fGNvbGxlY3Rpb24uX25hbWUsIFwiaXMgYWJvdXQgdG8gYmUgcmVtb3ZlZFwiXG4gICAgICAgICwgXCJhbmQgcmVwbGFjZWQgd2l0aCB2ZXJzaW9uXCIsIHZlcnNpb24pXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHZlcnNpb25cbiAgfVxuXG5cbiAgX2RlbGV0ZU9sZGVySXRlbXMoY29sbGVjdGlvbiwga2V5LCB0YWcsIHZlcnNpb24pIHtcbiAgICBsZXQgZGVsZXRlU2VsZWN0ID0geyB2ZXJzaW9uOiB7ICRsdDogdmVyc2lvbiB9IH1cblxuICAgIGlmIChrZXkpIHtcbiAgICAgIGRlbGV0ZVNlbGVjdCA9IHtcbiAgICAgICAkYW5kOiBbXG4gICAgICAgICAgZGVsZXRlU2VsZWN0XG4gICAgICAgICwgeyBrZXkgfVxuICAgICAgICBdXG4gICAgICB9XG5cbiAgICB9IGVsc2UgaWYgKHRhZykge1xuICAgICAgZGVsZXRlU2VsZWN0ID0ge1xuICAgICAgICRhbmQ6IFtcbiAgICAgICAgICBkZWxldGVTZWxlY3RcbiAgICAgICAgLCB7ICRvcjogW1xuICAgICAgICAgICAgICB7IHRhZyB9ICAgICAgICAgICAgICAgIC8vIGRlbGV0ZXMgYXNfaXMgZW50cnlcbiAgICAgICAgICAgICwgeyB0eXBlOiB7ICRlcTogdGFnIH19ICAvLyBkZWxldGVzIGFsbCBhc3NvY2lhdGVkIGltYWdlc1xuICAgICAgICAgICAgXVxuICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IGNvbGxlY3Rpb25OYW1lID0ga2V5IHx8IGNvbGxlY3Rpb24uX25hbWVcbiAgICBjb25zdCBjYWxsYmFjayA9IChlLCBkKSA9PiB0aGlzLl9jaGVja1Jlc3VsdChlLCBkLCBjb2xsZWN0aW9uTmFtZSlcbiAgICBjb2xsZWN0aW9uLnJlbW92ZShkZWxldGVTZWxlY3QsIGNhbGxiYWNrKVxuICB9XG5cblxuICBfaW5zZXJ0TmV3SXRlbXMoY29sbGVjdGlvbiwganNvbiwgdmVyc2lvbikge1xuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhqc29uKVxuICAgIGxldCBjb3VudGVyID0gMFxuXG4gICAga2V5cy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICBjb25zdCB2YWx1ZSA9IGpzb25ba2V5XVxuXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgdmFsdWUuZm9yRWFjaChkb2N1bWVudCA9PiB7XG4gICAgICAgICAgZG9jdW1lbnQudHlwZSA9IGtleVxuICAgICAgICAgIGRvY3VtZW50LnZlcnNpb24gPSB2ZXJzaW9uXG4gICAgICAgICAgY29sbGVjdGlvbi5pbnNlcnQoZG9jdW1lbnQpXG4gICAgICAgICAgY291bnRlciArPSAxXG4gICAgICAgIH0pXG5cbiAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcImFzX2lzXCIpIHtcbiAgICAgICAgY29sbGVjdGlvbi5pbnNlcnQoIHZhbHVlIClcbiAgICAgICAgY291bnRlciArPSAxXG5cbiAgICAgIH0gZWxzZSB7IC8vIFVzZSB3aXRoIGNhdXRpb24uIE9sZCBkb2N1bWVudHMgd2lsbCBub3QgYmUgY2xlYXJlZC5cbiAgICAgICAgY29sbGVjdGlvbi5pbnNlcnQoeyBba2V5XTogdmFsdWUgfSlcbiAgICAgICAgIGNvdW50ZXIgKz0gMVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBjb25zb2xlLmxvZyhcIkFkZGVkXCIsIGNvdW50ZXIsIFwiaXRlbXMgdG9cIiwgY29sbGVjdGlvbi5fbmFtZSlcbiAgfVxuXG5cbiAgX2NoZWNrUmVzdWx0KGVycm9yLCBkYXRhLCBrZXkpIHtcbiAgICBjb25zb2xlLmxvZyhcIlJlbW92ZWRcIiwgZGF0YSwgXCJpdGVtcyBmcm9tXCIsIGtleSwgXCJlcnJvcjpcIiwgZXJyb3IpXG4gIH1cbn1cbiIsIi8qKlxuICogL3NlcnZlci9pbXBvcnQuanNcbiAqXG4gKlxuICovXG5cblxuXG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9tZXRob2RzL21pbnQnXG5cbmltcG9ydCBMb2cgZnJvbSAnL2ltcG9ydHMvYXBpL21ldGhvZHMvYXNzZXRzL2xvZy5qcydcbmltcG9ydCBJT0hlbHBlciBmcm9tICcvaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvaW9IZWxwZXInXG5cbmltcG9ydCB7IEFDVElWSVRZX0ZPTERFUiB9IGZyb20gJy9pbXBvcnRzL3Rvb2xzL2N1c3RvbS9jb25zdGFudHMnXG5pbXBvcnQgeyByZW1vdmVGcm9tIH0gZnJvbSAnL2ltcG9ydHMvdG9vbHMvZ2VuZXJpYy91dGlsaXRpZXMnXG5cblxuaW1wb3J0IGNvbGxlY3Rpb25zICBmcm9tICcvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvcHVibGlzaGVyLmpzJ1xuY29uc3QgeyBBY3Rpdml0eSB9ID0gY29sbGVjdGlvbnNcblxuXG5jb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJylcbmNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJylcblxuXG4vLy8gPDw8IEhBUkQtQ09ERURcbmNvbnN0IGpzb25OYW1lID0gXCJyb290Lmpzb25cIlxuLy8vIEhBUkQtQ09ERUTCoD4+PlxuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgaW1wb3J0QWN0aXZpdGllcyBleHRlbmRzIElPSGVscGVye1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLmxvZ2dlciA9IG5ldyBMb2coKVxuICAgIHRoaXMubG9nID0gdGhpcy5sb2dnZXIuYWRkRW50cnlcblxuICAgIHRoaXMudHJlYXRBY3Rpdml0eUZvbGRlciA9IHRoaXMudHJlYXRBY3Rpdml0eUZvbGRlci5iaW5kKHRoaXMpXG5cbiAgICB0aGlzLmltcG9ydEFsbCgpXG5cbiAgICB0aGlzLmxvZ2dlci5zYXZlKClcbiAgfVxuXG5cbiAgaW1wb3J0QWxsKCkge1xuICAgIGNvbnN0IGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoQUNUSVZJVFlfRk9MREVSKVxuICAgIC8vIGNvbnNvbGUubG9nKFwiaW1wb3J0QWxsIGNvbnRlbnRzOlwiLCBjb250ZW50cylcbiAgICAvLyBbICdDbG96ZScsICdEcmFnJywgJ0ZsYXNoJywgJ1NwaXJhbCcsICdWb2NhYnVsYXJ5JywgJ2ljb24uanBnJyBdXG5cbiAgICAvLyBFbnN1cmUgdGhhdCB0aGVyZSBpcyBhbiBpY29uIHRoYXQgcmVwcmVzZW50cyBhbGwgYWN0aXZpdGllc1xuICAgIC8vIGZvciB0aGUgdG9wLW1vc3QgTWVudSBpdGVtXG4gICAgY29uc3QgaWNvbk1hcCA9IHRoaXMuZ2V0SWNvbk1hcChcbiAgICAgIEFDVElWSVRZX0ZPTERFUlxuICAgICwgY29udGVudHNcbiAgICApXG5cbiAgICAvLyBnZXRJY29uTWFwKCkgcmVtb3ZlcyBpY29uIG5hbWUgZnJvbSBjb250ZW50cy4gIEFsbCB0aGVcbiAgICAvLyByZW1haW5pbmcgbmFtZXMgc2hvdWxkIGJlIGFjdGl2aXR5IGZvbGRlcnNcblxuICAgIGNvbnRlbnRzLmZvckVhY2godGhpcy50cmVhdEFjdGl2aXR5Rm9sZGVyKVxuICB9XG5cblxuICAvKipcbiAgICogQ2FsbGVkIGJ5IGltcG9ydEFsbCgpXG4gICAqXG4gICAqIEBwYXJhbSAgICB7c3RyaW5nfSAgIGFjdGl2aXR5ICBuYW1lIG9mIGFjdGl2aXR5IGZvbGRlclxuICAgKi9cbiAgdHJlYXRBY3Rpdml0eUZvbGRlciAoYWN0aXZpdHkpIHtcbiAgICBjb25zdCBhY3Rpdml0eVBhdGggPSBwYXRoLmpvaW4oQUNUSVZJVFlfRk9MREVSLCBhY3Rpdml0eSlcblxuICAgIGNvbnN0IHN0YXRzID0gZnMuc3RhdFN5bmMoYWN0aXZpdHlQYXRoKVxuICAgIGlmICghc3RhdHMuaXNEaXJlY3RvcnkoKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgdmFyIGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoYWN0aXZpdHlQYXRoKVxuICAgIC8vIGNvbnNvbGUubG9nKFwidHJlYXRBY3Rpdml0eUZvbGRlclwiLCBhY3Rpdml0eVBhdGgsIGNvbnRlbnRzKVxuICAgIC8vIFsgJ2Jhc2ljJywgJ2hvbWUnLCAnaWNvbicsICdyb290Lmpzb24nIF1cblxuICAgIGxldCBjYW5jZWxsZWQgPSB0aGlzLmpzb25Jc01pc3NpbmcoY29udGVudHMsIGFjdGl2aXR5UGF0aClcbiAgICAvLyBpZiAoY2FuY2VsbGVkKSB7IGNvbnNvbGUubG9nKFwianNvbklzTWlzc2luZ1wiKX1cblxuICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICBjb25zdCB7IGpzb24sIGpzb25QYXRoIH0gPSB0aGlzLnJlYWRKU09ORmlsZSggLy8gaW4gSU9IZWxwZXJcbiAgICAgICAgYWN0aXZpdHlQYXRoXG4gICAgICAsIFtqc29uTmFtZV1cbiAgICAgIClcblxuICAgICAgY2FuY2VsbGVkID0gISFqc29uIC0gMSAvLyAwIGlmIGpzb24gaXMgdmFsaWQsIC0xIGlmIG5vdFxuXG4gICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICBjb25zdCB0b1VwZGF0ZSA9IHRoaXMuZ2V0X0lkT3JVcGRhdGVDb25maXJtYXRpb24oXG4gICAgICAgICAganNvblBhdGhcbiAgICAgICAgLCBhY3Rpdml0eVxuICAgICAgICApXG4gICAgICAgIGNhbmNlbGxlZCA9ICF0b1VwZGF0ZVxuXG4gICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgLy8gLi4uIGFuZCBoYXMgYmVlbiB1cGRhdGVkIHNpbmNlIHRoZSBsYXN0IGNhbGxcbiAgICAgICAgICB0aGlzLnVwZGF0ZUFjdGl2aXR5RGF0YShcbiAgICAgICAgICAgIGNvbnRlbnRzXG4gICAgICAgICAgLCBhY3Rpdml0eVxuICAgICAgICAgICwgYWN0aXZpdHlQYXRoXG4gICAgICAgICAgLCBqc29uXG4gICAgICAgICAgLCBqc29uUGF0aFxuICAgICAgICAgICwgdG9VcGRhdGVcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmxvZ09wZXJhdGlvbihjYW5jZWxsZWQpXG4gIH1cblxuXG4gIC8qKiBDaGVja3MgaWYganNvbk5hbWUgKHJvb3QuanNvbikgZXhpc3RzLiBJZiBub3QgbG9ncyB0aGUgZXJyb3IuXG4gICAqXG4gICAqIEBwYXJhbSAge2FycmF5fSAgIGNvbnRlbnRzICAgICAgTmFtZXMgb2YgZmlsZXMgYXQgYWN0aXZpdHlQYXRoXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWyAnaWNvbicgfCAnaWNvbi5pbWcnXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCAncm9vdC5qc29uJ1xuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgPHN1YmZvbGRlcj4sIC4uLlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICogQHBhcmFtICB7c3RyaW5nfSAgYWN0aXZpdHlQYXRoICBhYnNvbHV0ZSBwYXRoIHRvIGZvbGRlclxuICAgKlxuICAgKiBAcmV0dXJuIHticW9sZWFufSAtMTogY2FuY2VsbGVkICAtIGFuIGVycm9yIG9jY3VycmVkXG4gICAqICAgICAgICAgICAgICAgICAgICsxOiBjYW5jZWxsZWQgIC0gbm8gdXBkYXRlIG5lZWRlZFxuICAgKiAgICAgICAgICAgICAgICAgICAgMDogc3VjY2Vzc2Z1bCAtIHJvb3QuanNvbiByZXdyaXR0ZW4gYW5kXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTW9uZ29EQiBjb2xsZWN0aW9uIHVwZGF0ZWRcbiAgICovXG4gIGpzb25Jc01pc3NpbmcoY29udGVudHMsIGFjdGl2aXR5UGF0aCkge1xuICAgIC8vIGNvbnNvbGUubG9nKGNvbnRlbnRzKVxuICAgIC8vIGNvbnRlbnRzOiAgWyAnYmFzaWMnLCAnaG9tZScsICdpY29uJywgJ3Jvb3QuanNvbicgXVxuXG4gICAgaWYgKCEoY29udGVudHMuaW5jbHVkZXMoanNvbk5hbWUpKSkge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICBgRXJyb3IgZm9yICR7dGhpcy5hY3Rpdml0eX0gYWN0aXZpdHk6XG4gICAgICAgIFRoZSBcIiR7anNvbk5hbWV9XCIgZmlsZSBpcyBtaXNzaW5nIGZvclxuICAgICAgICAke2FjdGl2aXR5UGF0aH1cbiAgICAgICAgQXZhaWxhYmxlIGl0ZW1zOiAke2NvbnRlbnRzfVxuICAgICAgIGBcbiAgICAgIHRoaXMubG9nKG1lc3NhZ2UpXG5cbiAgICAgIHJldHVybiAtMVxuICAgIH1cblxuICAgIHJldHVybiAwXG4gIH1cblxuXG4gIGdldF9JZE9yVXBkYXRlQ29uZmlybWF0aW9uKGpzb25QYXRoLCBhY3Rpdml0eU5hbWUpIHtcbiAgICBjb25zdCBzZWxlY3QgPSB7IGtleTogYWN0aXZpdHlOYW1lIH1cblxuICAgIGNvbnN0IHRvVXBkYXRlID0gdGhpcy5kaXJlY3RvcnlOZWVkc1VwZGF0aW5nKCAvLyBpbiBJT0hlbHBlclxuICAgICAganNvblBhdGhcbiAgICAsIEFjdGl2aXR5XG4gICAgLCBzZWxlY3RcbiAgICApXG5cbiAgICAvLy8gKioqIEN1cnJlbnRseSBhbHdheXMgcmV0dXJucyB0cnVlICoqKiA/Ly8vXG5cbiAgICByZXR1cm4gdG9VcGRhdGVcbiAgfVxuXG5cbiAgdXBkYXRlQWN0aXZpdHlEYXRhKFxuICAgIGNvbnRlbnRzXG4gICwgYWN0aXZpdHlcbiAgLCBhY3Rpdml0eVBhdGhcbiAgLCBqc29uXG4gICwganNvblBhdGhcbiAgLCB0b1VwZGF0ZVxuICApIHtcblxuICAgIGNvbnN0IGpzeFJlZ2V4ID0gbmV3IFJlZ0V4cChhY3Rpdml0eSArIFwiLmpzeD9cIilcbiAgICBjb25zdCBtb2RhbCA9ICFjb250ZW50cy5maW5kKCBmaWxlID0+IGpzeFJlZ2V4LnRlc3QoZmlsZSkgKVxuXG4gICAgLy8gY29uc29sZS5sb2coY29udGVudHMsIG1vZGFsKVxuXG4gICAgdGhpcy51cGRhdGVKU09OT2JqZWN0KGFjdGl2aXR5LGFjdGl2aXR5UGF0aCxqc29uLGNvbnRlbnRzLG1vZGFsKVxuICAgIC8vIEJvdGggJ2ljb24nIGFuZCBKU09OwqBmaWxlIHdpbGwgaGF2ZSBiZWVuIHJlbW92ZWQgZnJvbSBjb250ZW50c1xuXG4gICAgaWYgKCFtb2RhbCkge1xuICAgICAgdGhpcy53cml0ZVRvRmlsZUFuZE1vbmdvREIoXG4gICAgICAgIGpzb25cbiAgICAgICwganNvblBhdGhcbiAgICAgICwgdG9VcGRhdGVcbiAgICAgIClcbiAgICB9XG4gIH1cblxuXG4gIHVwZGF0ZUpTT05PYmplY3QgKGFjdGl2aXR5LCBhY3Rpdml0eVBhdGgsIGpzb24sIGNvbnRlbnRzLCBtb2RhbCkge1xuICAgIGNvbnN0IHBhdGggPSBcIi9cIiArIGFjdGl2aXR5XG4gICAganNvbi5wYXRoICA9IHBhdGhcbiAgICBqc29uLm1vZGFsID0gbW9kYWxcblxuICAgIC8vIENyZWF0ZSBhIHBsYWNlaG9sZGVyIGljb24gaWYgbm9uZSBleGlzdHMsIGFuZCByZW1vdmUgdGhlXG4gICAgLy8gaWNvbiBkYXRhIGZyb20gY29udGVudHNcbiAgICBqc29uLmljb24gPSB0aGlzLmdldEljb25NYXAoYWN0aXZpdHlQYXRoLCBjb250ZW50cylcbiAgfVxuXG5cbiAgLyoqwqBXcml0ZXMgYW55IG5ldyBkYXRhIHRvIHRoZSBKU09OwqBmaWxlIGFuZCB1cGRhdGVzIEFjdGl2aXR5XG4gICAqICBjb2xsZWN0aW9uIHdpdGggdGhlIG5ldyBkYXRhIGFuZCB0aGUgbW9kIGRhdGUgb2YgdGhlIEpTT04gZmlsZS5cbiAgICpcbiAgICogTk9URTogSWYgYSBNb25nb0RCIGNvbGxlY3Rpb24gd2FzIGNyZWF0ZWQgYW5kIHRoZW4gbGF0ZXJcbiAgICogZHJvcHBlZCwgX2lkIHdpbGwgYmUgYHRydWVgLCBidXQganNvbi5faWQgd2lsbCBjb250YWluIHRoZVxuICAgKiBfaWQgZnJvbSB0aGUgZHJvcHBlZCBjb2xsZWN0aW9uLiBUaGUgbmV3IGRvY3VtZW50IHdpbGwgdGh1c1xuICAgKiBhZG9wdCB0aGUgcHJldmlvdXMgX2lkLlxuICAgKlxuICAgKiBJZiwgb24gdGhlIG90aGVyIGhhbmQsIHRoZSBKU09OwqBmaWxlIGhhcyBiZWVuIGVkaXRlZCB0b1xuICAgKiByZW1vdmUgaXRzIHByZXZpb3VzbHktY3JlYXRlZCBfaWQsIGJ1dCBhIE1vbmdvREIgZG9jdW1lbnRcbiAgICogc3RpbGwgZXhpc3RzIGZvciB0aGlzIGFjdGl2aXR5LCB0aGVuIF9pZCB3aWxsIGNvbnRhaW4gdGhlXG4gICAqIGN1cnJlbnQgX2lkIHN0cmluZywgYW5kIG5vIGR1cGxpY2F0ZSBkb2N1bWVudCB3aWxsIGJlIGNyZWF0ZWQuXG4gICAqXG4gICAqIEBwYXJhbSAgIHtzdHJpbmd9ICAganNvblBhdGggICAgYWJzb2x1dGUgcGF0aCB0byBKU09OIGZpbGVcbiAgICogQHBhcmFtICAge29iamVjdH0gICBqc29uICAgICAgICB7IFwibmFtZVwiOiB7IGxvY2FsaXplZCBzdHJpbmdzIH1cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFwiZGVzY3JpcHRpb25cIjogZGl0dG9cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFwiaWNvblwiOiA8dXJsPlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgXCJrZXlcIjogIDxzdHJpbmcgYWN0aXZpdHkgbmFtZT5cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFssIFwiX2lkXCI6ICA8c3RyaW5nIF9pZD5dXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgKiBAcGFyYW0gICB7YXJyYXl9ICAgIGNvbnRlbnRzICAgIFsgLi4uLCBpY29uKC54eGcpLCAuLi4gXVxuICAgKiBAcGFyYW0gICB7bXVsdGl9ICAgIF9pZCAgICAgICAgIHRydWUgb3IgX2lkIHN0cmluZ1xuICAgKi9cbiAgd3JpdGVUb0ZpbGVBbmRNb25nb0RCKGpzb24sIGpzb25QYXRoLCBfaWQpIHtcbiAgICBpZiAoX2lkID09PSB0cnVlKSB7XG4gICAgICBfaWQgPSBqc29uLl9pZCAvLyBtYXkgYmUgdW5kZWZpbmVkXG4gICAgfVxuXG4gICAgLy8gY29uc29sZS5sb2coXCJ3cml0ZVRvRmlsZUFuZE1vbmdvREJcIiwgSlNPTi5zdHJpbmdpZnkoanNvbiwgbnVsbCwgXCIgIFwiKSlcblxuICAgIGlmICghX2lkKSB7XG4gICAgICAvLyBDcmVhdGUgYSBuZXcgZG9jdW1lbnQgdG8gZ2V0IGl0cyBfaWQuLi5cbiAgICAgIF9pZCA9IEFjdGl2aXR5Lmluc2VydCgganNvbiApXG4gICAgICBqc29uLl9pZCA9IF9pZFxuICAgICAgLy8gLi4uIHRoZW4gc2F2ZSB0aGUgdXBkYXRlZCBKU09OIGZpbGUgYW5kIHVwZGF0ZSB0aGUgbmV3XG4gICAgICAvLyBkb2N1bWVudCB3aXRoIHRoZSBmaWxlJ3MgbmV3IG1vZCBkYXRlXG4gICAgICBjb25zdCBtb2QgPSB0aGlzLndyaXRlSlNPTihqc29uUGF0aCwganNvbilcbiAgICAgIEFjdGl2aXR5LnVwZGF0ZSh7IF9pZCB9LCB7ICRzZXQ6IHsgbW9kIH19KVxuXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFNhdmUgdGhlIF9pZCB0byByb290Lmpzb24gYW5kIHJvb3QuanNvbidzIG1vZCB0byBNb25nb0RCXG4gICAgICBqc29uLl9pZCA9IF9pZCAvLyBpdCBwcm9iYWJseSBhbHJlYWR5IGhhcyB0aGlzIHZhbHVlXG4gICAgICBqc29uLm1vZCA9IHRoaXMud3JpdGVKU09OKGpzb25QYXRoLCBqc29uKVxuICAgICAgQWN0aXZpdHkudXBkYXRlKHsgX2lkIH0sIHsgJHNldDoganNvbiB9LCB7dXBzZXJ0OiB0cnVlfSlcbiAgICB9XG4gIH1cblxuXG4gIGxvZ09wZXJhdGlvbihjYW5jZWxsZWQsIGFjdGl2aXR5UGF0aCkge1xuICAgIGxldCBtZXNzYWdlXG5cbiAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgbWVzc2FnZSA9IGArKysrKysrKysrKysrXG4gICAgICBBY3Rpdml0eSBjb2xsZWN0aW9uOiB1cGRhdGUgZm9yICR7dGhpcy5hY3Rpdml0eX0gc3VjY2Vzc2Z1bC5cbiAgICAgIGBcbiAgICB9IGVsc2UgaWYgKGNhbmNlbGxlZCA8IDApIHtcbiAgICAgIC8vIEFuIGVycm9yIG9jY3VyZWRcbiAgICAgIG1lc3NhZ2UgPSBgLS0tLS0tLS0tLS0tLVxuICAgICAgQUNJVklUWSAke3RoaXMuYWN0aXZpdHl9IE5PVMKgVVBEQVRFRC5cbiAgICAgIFNFRcKgRVJST1LCoE1FU1NBR0VTwqBBQk9WRS5cbiAgICAgIGBcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlIEpTT04gZmlsZSBoYXMgbm90IGJlZW4gY2hhbmdlZFxuICAgICAgbWVzc2FnZSA9IGA9PT09PT09PT09PT09XG4gICAgICBBY3Rpdml0eSAke3RoaXMuYWN0aXZpdHl9IG5vdMKgdXBkYXRlZC5cbiAgICAgIFRoaXMgc2hvdWxkIGJlIGZpbmUsIGJ1dCBpZiB5b3UgcmVjZW50bHkgYWx0ZXJlZCBhbnkgYXNzZXRcbiAgICAgIGZpbGVzIG9yIGljb25zLCBwbGVhc2UgdG91Y2ggb3IgcmVzYXZlIHRoZSBKU09OIGZpbGUgYXQuLi5cbiAgICAgICAgJHthY3Rpdml0eVBhdGh9XG4gICAgICAuLi50byBjaGFuZ2UgaXRzIG1vZGlmaWNhdGlvbiBkYXRlLiAgICAgIGBcbiAgICB9XG5cbiAgICB0aGlzLmxvZyhtZXNzYWdlKVxuICB9XG59XG4iLCIvKipcbiAqIC9zZXJ2ZXIvbGF1bmNoLmpzXG4gKi9cblxuXG5cbmltcG9ydCBQcm92aXNpb24gZnJvbSAnLi9wcm92aXNpb24nXG5cbmltcG9ydCBJbXBvcnRBc3NldHMgZnJvbSAnLi4vaW1wb3J0cy9hcGkvbWV0aG9kcy9hc3NldHMvaW1wb3J0QXNzZXRzJ1xuaW1wb3J0IEltcG9ydEFjdGl2aXRpZXMgZnJvbSAnLi9pbXBvcnRBY3Rpdml0aWVzJ1xuXG5cblxuLy8gVXBkYXRlIHRoZSBVSVRleHQgYW5kIFRlYWNoZXIgY29sbGVjdGlvbnMsIGFzIG5lZWRlZFxubmV3IFByb3Zpc2lvbigpXG5cbi8vIFVwZGF0ZSB0aGUgdmFyaW91cyBhY3Rpdml0eSBjb2xsZWN0aW9ucywgYXMgbmVlZGVkXG5uZXcgSW1wb3J0QXNzZXRzKClcbm5ldyBJbXBvcnRBY3Rpdml0aWVzKCkiLCIvKipcbiAqIC9zZXJ2ZXIvcHJvdmlzaW9uLmpzXG4gKlxuICogUmVhZHMgYWxsIEpTT07CoGZpbGVzIGZyb20gdGhlIC9wcml2YXRlIChhc3NldHMpIGZvbGRlciBhbmRcbiAqIHJlZnJlc2hlcyB0aGUgYXNzb2NpYXRlZCBjb2xsZWN0aW9ucyBpbiB0aGUgTW9uZ29EQsKgZGF0YWJhc2VcbiAqIGlmIHRoZSB2ZXJzaW9uIG51bWJlcnMgaGF2ZSBpbmNyZWFzZWQuXG4gKlxuICogVE9ETzogQWRvcHQgdGhlIGBtb2RgIHN5c3RlbSB1c2VkIGJ5IHRoZSBJbXBvcnRBc3NldHMgY2xhc3NlcyBzb1xuICogdGhhdCB0aGUgdmVyc2lvbiBudW1iZXIgY2FuIGJlIHJlbW92ZWQuXG4gKi9cblxuaW1wb3J0IENvbGxlY3RKU09OIGZyb20gJy4vY29sbGVjdEpTT04nXG5cbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxuY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFByb3Zpc2lvbntcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgY29uc3Qga25vd25GaWxlICAgPSBcImwxMG4uanNvblwiXG4gICAgY29uc3QgcHJpdmF0ZVBhdGggPSBBc3NldHMuYWJzb2x1dGVGaWxlUGF0aChrbm93bkZpbGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2Uoa25vd25GaWxlLCBcIlwiKVxuICAgIGNvbnN0IGpzb25SZWdleCA9IC8uanNvbiQvXG4gICAgY29uc3QgSlNPTmZpbGVzID0gdGhpcy5jcmF3bChwcml2YXRlUGF0aCwganNvblJlZ2V4KVxuXG4gICAgSlNPTmZpbGVzLmZvckVhY2goanNvbkZpbGUgPT4ge1xuICAgICAgbmV3IENvbGxlY3RKU09OKGpzb25GaWxlKVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogQWRkcyB0byBgbGlzdGAgYWxsIGRvY3VtZW50cyB3aXRoIHRoZSBleHRlbnNpb24gYHR5cGVgIGZvdW5kIGluXG4gICAqIGZvbGRlciBvciBhbnkgb2YgaXRzIHN1YmZvbGRlcnNcbiAgICpcbiAgICogQHBhcmFtICAgICAge3N0cmluZ30gIGZvbGRlciAgIFRoZSBmb2xkZXIgdG8gc2VhcmNoIGluXG4gICAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICByZWdleCAgICAvLmpzb24kLyBvciBhbnkgcmVnZXggdG8gZGVmaW5lIGFcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGUgdHlwZVxuICAgKiBAcGFyYW0gICAgICB7YXJyYXl9ICAgbGlzdCAgICAgQW4gKGVtcHR5KSBhcnJheVxuICAgKiBAcmV0dXJuICAgICB7QXJyYXl9ICAgICAgICAgICAgVGhlIGlucHV0IGxpc3QsIG5vdyBwb3B1bGF0ZWQgd2l0aFxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWJzb2x1dGUgcGF0aHMgdG8gZmlsZXMgb2YgdGhlXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnaXZlbiB0eXBlXG4gICAqL1xuICBjcmF3bCggZm9sZGVyLCByZWdleCwgbGlzdD1bXSApIHtcbiAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKGZvbGRlcilcblxuICAgIGlmIChzdGF0cy5pc0RpcmVjdG9yeSgpKXtcbiAgICAgIGNvbnN0IGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoZm9sZGVyKVxuXG4gICAgICBjb250ZW50cy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgICBjb25zdCBpdGVtUGF0aCA9IHBhdGguam9pbihmb2xkZXIsIGl0ZW0pXG5cbiAgICAgICAgaWYgKHJlZ2V4LnRlc3QoaXRlbVBhdGgpKSB7XG4gICAgICAgICAgbGlzdC5wdXNoKGl0ZW1QYXRoKVxuXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5jcmF3bCggaXRlbVBhdGgsIHJlZ2V4LCBsaXN0IClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICByZXR1cm4gbGlzdFxuICB9XG59IiwiLyoqXG4gKiAvc2VydmVyL3NldHVwLmpzXG4gKi9cblxuXG5pbXBvcnQgTWV0aG9kTWludGVyIGZyb20gJy4vbWludGVycy9tZXRob2RzJ1xuaW1wb3J0IEFjdGl2aXR5TWludGVyIGZyb20gJy4vbWludGVycy9hY3Rpdml0aWVzJ1xuaW1wb3J0IENvbGxlY3Rpb25NaW50ZXIgZnJvbSAnLi9taW50ZXJzL2NvbGxlY3Rpb25zJ1xuaW1wb3J0IHsgSUNPTl9SRUdFWCB9IGZyb20gJy4uL2ltcG9ydHMvdG9vbHMvY3VzdG9tL2NvbnN0YW50cydcblxuXG5cbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxuY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuXG5cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2V0VXB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMucHVibGljUGF0aCAgPSBcIi4uLy4uL3B1YmxpYy9cIlxuICAgIHRoaXMuYnJvd3NlclBhdGggPSBcIi4uL3dlYi5icm93c2VyL2FwcC9cIlxuXG4gICAgdGhpcy5maW5kQWN0aXZpdGllcyhcIkFjdGl2aXRpZXNcIilcbiAgICB0aGlzLmdldEFzc2V0cyhcIkFzc2V0c1wiKVxuICB9XG5cblxuICBmaW5kQWN0aXZpdGllcyhmb2xkZXIpIHtcbiAgICBjb25zdCBhY3Rpdml0aWVzID0gW11cblxuICAgIGNvbnN0IGFjdGl2aXR5UGF0aCA9IHBhdGguam9pbih0aGlzLmJyb3dzZXJQYXRoLCBmb2xkZXIpXG4gICAgY29uc3QgYWN0aXZpdHlOYW1lcyA9IGZzLnJlYWRkaXJTeW5jKGFjdGl2aXR5UGF0aClcblxuICAgIGFjdGl2aXR5TmFtZXMuZm9yRWFjaChuYW1lID0+IHtcbiAgICAgIGlmIChuYW1lICE9PSBcInNoYXJlZFwiKSB7XG4gICAgICAgIGNvbnN0IGRpcmVjdG9yeSA9IHBhdGguam9pbihhY3Rpdml0eVBhdGgsIG5hbWUpXG4gICAgICAgIGNvbnN0IHN0YXRzID0gZnMuc3RhdFN5bmMoZGlyZWN0b3J5KVxuXG4gICAgICAgIGlmIChzdGF0cy5pc0RpcmVjdG9yeSgpKXtcbiAgICAgICAgICBjb25zdCBhY3Rpdml0eURhdGEgPSB0aGlzLmdldEpTRGF0YShuYW1lLCBkaXJlY3RvcnkpXG5cbiAgICAgICAgICBpZiAoYWN0aXZpdHlEYXRhKSB7XG4gICAgICAgICAgICBhY3Rpdml0aWVzLnB1c2goYWN0aXZpdHlEYXRhKVxuXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSWdub3JpbmcgbW9kdWxlOlwiLCBuYW1lKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLm1pbnRTY3JpcHRzKGFjdGl2aXRpZXMpXG4gIH1cblxuXG4gIGdldEpTRGF0YShuYW1lLCBmb2xkZXIpIHtcbiAgICBsZXQgZGF0YVxuICAgIGNvbnN0IGNvbnRlbnRzID0gZnMucmVhZGRpclN5bmMoZm9sZGVyKVxuICAgIGNvbnN0IGtleXMgPSBjb250ZW50cy5tYXAoZmlsZSA9PiB7XG4gICAgICBjb25zdCBiYXNlTmFtZSA9IHBhdGguYmFzZW5hbWUoZmlsZSwgcGF0aC5leHRuYW1lKGZpbGUpKVxuXG4gICAgICBpZiAoYmFzZU5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbmFtZS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICAgIHJldHVybiBcInNjcmlwdFwiXG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBiYXNlTmFtZVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBpZiAoa2V5cy5pbmNsdWRlcyhcInNjcmlwdFwiKSB8fCBrZXlzLmluY2x1ZGVzKFwibWV0aG9kc1wiKSkge1xuICAgICAgZGF0YSA9IGtleXMucmVkdWNlKChtYXAsIGtleSwgaW5kZXgpID0+IHtcbiAgICAgICAgbGV0IGZpbGUgPSBwYXRoLmpvaW4oZm9sZGVyLCBjb250ZW50c1tpbmRleF0pXG4gICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKHRoaXMuYnJvd3NlclBhdGgsIHRoaXMucHVibGljUGF0aClcbiAgICAgICAgbWFwW2tleV0gPSB7XG4gICAgICAgICAgICBuYW1lXG4gICAgICAgICAgLCBmaWxlXG4gICAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBtYXBcbiAgICAgIH0sIHt9KVxuXG4gICAgICByZXR1cm4gZGF0YVxuICAgIH1cbiAgfVxuXG5cbiAgZ2V0QXNzZXRzKGZvbGRlcikge1xuICAgIGNvbnN0IGNvbGxlY3Rpb25zID0gW11cblxuICAgIGNvbnN0IGFzc2V0c1BhdGggPSBwYXRoLmpvaW4odGhpcy5icm93c2VyUGF0aCwgZm9sZGVyKVxuICAgIGNvbnN0IGFzc2V0TmFtZXMgPSBmcy5yZWFkZGlyU3luYyhhc3NldHNQYXRoKVxuXG4gICAgYXNzZXROYW1lcy5mb3JFYWNoKG5hbWUgPT4ge1xuICAgICAgY29uc3QgZGlyZWN0b3J5ID0gcGF0aC5qb2luKGFzc2V0c1BhdGgsIG5hbWUpXG4gICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKGRpcmVjdG9yeSlcblxuICAgICAgaWYgKHN0YXRzLmlzRGlyZWN0b3J5KCkpe1xuICAgICAgICBjb2xsZWN0aW9ucy5wdXNoKG5hbWUpXG4gICAgICB9XG4gICAgfSlcblxuICAgIG5ldyBDb2xsZWN0aW9uTWludGVyKGNvbGxlY3Rpb25zKVxuICB9XG5cblxuICBtaW50U2NyaXB0cyhhY3Rpdml0aWVzKSB7XG4gICAgY29uc3Qgc2NyaXB0cyAgPSBbXVxuICAgIGNvbnN0IG1ldGhvZHMgID0gW11cblxuICAgIGFjdGl2aXRpZXMuZm9yRWFjaCggYWN0aXZpdHkgPT4ge1xuICAgICAgaWYgKGFjdGl2aXR5LnNjcmlwdCkge1xuICAgICAgICAvLyBXaWxsIGJlIG1pc3NpbmcgZm9yIG1vZGFsIGFjdGl2aXRpZXNcbiAgICAgICAgc2NyaXB0cy5wdXNoKGFjdGl2aXR5LnNjcmlwdClcbiAgICAgIH1cbiAgICAgIGlmIChhY3Rpdml0eS5tZXRob2RzKSB7XG4gICAgICAgIC8vIE1heSBiZSBtaXNzaW5nIGZvciBleHRlbmRlZCBhY3Rpdml0aWVzXG4gICAgICAgIG1ldGhvZHMucHVzaChhY3Rpdml0eS5tZXRob2RzKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBuZXcgTWV0aG9kTWludGVyKG1ldGhvZHMpXG4gICAgbmV3IEFjdGl2aXR5TWludGVyKHNjcmlwdHMpXG4gIH1cbn1cblxuIiwiLyoqXG4gKiAvc2VydmVyL21haW4uanNcbiAqL1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG4vLyBBY3RpdmF0ZSB0aGUgTW9uZ29EQi1mcmVlIFBvaW50cyBjb2xsZWN0aW9uIChmb3IgdHJhY2tpbmcgdXNlclxuLy8gbW91c2UgYW5kIHRvdWNoIHBvc2l0aW9ucykgYW5kIHRoZSBtZXRob2RzIGFzc29jaWF0ZWQgd2l0aCBpdFxuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy9wb2ludHMnXG5cbmltcG9ydCBTZXRVcCBmcm9tICcuL3NldHVwJ1xuXG5cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICBpZiAoTWV0ZW9yLmlzRGV2ZWxvcG1lbnQpIHtcbiAgICAvLyBSZWdlbmVyYXRlIHRoZSB2YXJpb3VzIG1pbnQuanMgZmlsZXMgdGhhdCBpbXBvcnQgYW5kIHRoZW5cbiAgICAvLyByZS1leHBvcnQgY29tYmluZWQgY29sbGVjdGlvbiwgbWV0aG9kIGFuZCBhY3Rpdml0eSBzY3JpcHRzXG4gICAgLy8gVGhpcyBlbnN1cmVzIHRoYXQgYWNjZXNzIHRvIE1vbmdvRELCoHJlZmxlY3RzIGFueSBjaGFuZ2VzIHRvXG4gICAgLy8gdGhlIGFjdGl2aXR5IG1vZHVsZXNcbiAgICBuZXcgU2V0VXAoKVxuICB9XG5cbiAgLy8gTm93IHRoYXQgdGhlIE1vbmdvREIgY2VsbGVjdGlvbnMgYW5kIHRoZSBtZXRob2RzIHRvIGFjY2VzcyB0aGVtXG4gIC8vIGFyZSBpbiBzeW5jIHdpdGggdGhlIGFjdGl2aXRpZXMsIHdlIGNhbjpcbiAgLy8gKiBVcGRhdGUgdGhlIFVJVGV4dCBhbmQgVGVhY2hlciBjb2xsZWN0aW9uc1xuICAvLyAqIFVwZGF0ZSB0aGUgQWN0aXZpdHkgY29sbGVjdGlvbnMgaWYgbmVjZXNzYXJ5XG4gIHJlcXVpcmUoJy4vbGF1bmNoLmpzJylcbn0pO1xuIl19
