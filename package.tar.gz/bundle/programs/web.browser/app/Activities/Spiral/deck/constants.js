/**
 * /public/activities/Spiral/deck/constants.js
 */



export const phi = (1 + Math.sqrt(5)) / 2
export const thick = 100 / phi
export const thin  = (100 - thick)