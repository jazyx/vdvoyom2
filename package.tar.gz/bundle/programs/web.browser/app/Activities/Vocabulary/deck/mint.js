/**
 * /public/activities/Vocabulary/mount/mint.js
 */



// import Cloze from '../../Cloze/custom'
import Drag from '../../Drag/custom'
import Flash from '../../Flash/custom'



export {
  Drag
, Flash
// , Cloze
}